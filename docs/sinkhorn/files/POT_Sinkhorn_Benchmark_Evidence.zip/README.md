# POT Sinkhorn final source: matched replay

Final source: `66ce7cc34844345fa7cf9613e5ac6a1b6eed43e6`. The three implementations ran inside one equal Linux CPU environment and Python 3.12.14 / NumPy 2.3.5 process, one CPU and one BLAS thread. The two stock entry points match the pinned POT master's code, ignoring docstrings. The Python source under test is the exact candidate checkout. The unrelated compiled extensions were from release 0.9.7.post1 and shared by all three arms; this was not a fresh native build. Each setting had 12 trials per arm with orders balanced within blocks. The old released adapter is the unmodified 0.2.0 wheel. All ordinary runs leave `plan_tol` unset.

## 160 archived workloads outside the targeted eight

| Workload | Stock POT (ms) | Adapter 0.2.0 (ms) | Final candidate (ms) |
|---|---:|---:|---:|
| Original 27 dense settings | 108.12 | 63.83 | 62.72 |
| Eight independent fixtures, cold cache | 27.07 | 10.66 | 10.53 |
| Eight independent fixtures, warmed cache | 27.23 | 9.36 | 9.46 |
| Four basic fixtures | 2.05 | 1.02 | 0.99 |
| 84 planted-plan fixtures | 70.78 | 31.23 | 29.91 |
| MNIST, 900 pairs × 3 regularizations | 1,714.68 | 866.22 | 861.95 |
| MNIST, 625 pairs × 3 regularizations | 1,180.37 | 600.91 | 573.96 |
| RGB palette, 64 dense solves | 1,045.57 | 686.04 | 646.85 |
| Fixed cost matrices | 68.66 | 42.41 | 41.65 |
| Cost reuse, copies and changes | 265.76 | 185.31 | 184.01 |
| graspologic graph alignment, 400 solves | 802.46 | 740.73 | 735.14 |
| Bunny, remaining 8-frame terminal window | 12.52 | 12.86 | 9.97 |
| Bunny, remaining 56-frame job | 119.41 | 122.08 | 84.38 |

The grouped times sum per-setting medians. The final candidate had a shorter median than stock in 160/160 settings and matched the 0.2.0 output digest in 158/160 settings. All 5,417 candidate calls satisfied their requested marginal tolerance. Timing medians do not prove individual differences are significant.

## Eight historically weak registration settings

| Workload | Stock POT (ms) | Adapter 0.2.0 (ms) | Final candidate (ms) |
|---|---:|---:|---:|
| Bunny 192 at reg 0.08, 56 frames | 35.13 | 35.39 | 22.15 |
| Bunny 192 at reg 0.24, 56 frames | 30.36 | 29.65 | 18.72 |
| Bunny 512 at reg 0.08, 56 frames | 167.64 | 162.38 | 115.45 |
| Two-lobe cloud 384 at reg 0.08, 56 frames | 63.75 | 63.57 | 51.44 |
| Two-lobe cloud 384 at reg 0.24, 56 frames | 55.83 | 54.73 | 46.77 |
| Bunny 192 at reg 0.08, final 8 frames | 2.96 | 2.98 | 1.73 |
| Bunny 192 at reg 0.24, final 8 frames | 1.96 | 1.98 | 1.87 |
| Bunny 512 at reg 0.24, final 8 frames | 14.83 | 15.19 | 10.91 |

Terminal windows share the same cost matrices and input scalings; live runs start identically but each solver advances its own pose. Each candidate plan met `1e-7` on both marginals (worst 9.993e-08). Full-plan TV errors against a tighter reference and final pose comparisons are in the CSV files. This table is for ordinary warm starts, not extra whole-plan accuracy.

## Separate verification

The earlier GCC native suite for this exact source tree recorded 1,585 passed, 170 skipped, 4 expected failures. A direct rerun of the release-level source uses shared binary extensions as stated above. This archive includes the timing and accuracy CSVs; test and documentation-check counts are summarized below. Timings from older RGB interpolation and the separate grid solver are not applicable to this PR.

## Separate warm-start and numerical-edge stress tests

| Case | Stock POT (µs) | Adapter 0.2.0 (µs) | Final candidate (µs) |
|---|---:|---:|---:|
| 8x8-same | 29.8 | 31.2 | 38.4 |
| 8x8-near | 160.7 | 167.7 | 72.7 |
| 8x8-far | 419.5 | 319.2 | 114.5 |
| 8x8-very-small | 30.7 | 33.9 | 48.4 |
| 32x128-same | 47.2 | 49.5 | 53.6 |
| 32x128-near | 227.5 | 213.6 | 120.5 |
| 32x128-far | 198.6 | 221.6 | 114.3 |
| 32x128-very-small | 48.6 | 47.9 | 57.6 |
| 256x384-same | 1,246.0 | 1,170.4 | 569.6 |
| 256x384-near | 1,064.3 | 1,029.3 | 552.1 |
| 256x384-far | 1,694.1 | 1,730.1 | 856.3 |
| 256x384-very-small | 563.7 | 557.1 | 501.8 |
| normal | 911.6 | 483.7 | 386.9 |
| tiny_positive | 19,026.3 | 20,045.9 | 19,363.9 |
| partial_underflow | 19,268.5 | 18,767.4 | 19,676.7 |
| zero_column_rollback | 87.5 | 152.8 | 106.7 |
| cloud_tiny | 52,071.5 | 52,500.0 | 51,333.9 |
| cloud_underflow | 64,185.1 | 65,070.6 | 63,545.7 |

These single-call stress cases use a cold cache. The two tiny identical-seed cases already reach tolerance at update one under stock. Numerical-edge diagnostics include expected nonconvergence or rollback; the evidence retains the returned marginal errors and warning messages rather than treating these as converged solves. The separate graph diagnostic found 209/209 equal best matches against stock.

## Review branch and checks

The review branch [hys-ops/POT](https://github.com/hys-ops/POT/commit/56f50fa53aab0d7eaa5a771389b62be4b3a8138d) points to a single commit with exactly the same full file tree as the tested local candidate. All six configured hooks passed with no source changes. A fresh focused test run passed 126 tests and skipped 10. The HTML docs built with gallery execution disabled; the new user-guide link and gallery example were verified in the HTML, and the example ran successfully as a script. The full doc build emitted warnings; no warning-free full-gallery or hosted CI run is claimed.


## Files

The evidence directory contains raw and summarized timings, numerical residuals, and registration results. For source and test code, [download the exact reviewed POT tree](https://github.com/hys-ops/POT/archive/56f50fa53aab0d7eaa5a771389b62be4b3a8138d.zip). This evidence archive is not a self-contained benchmark runner.
