# -*- coding: utf-8 -*-
"""
General OT solvers with unified API
"""

# Author: Remi Flamary <remi.flamary@polytechnique.edu>
#         Cédric Vincent-Cuaz <cedvincentcuaz@gmail.com>
#
# License: MIT License

from ..utils import OTResult, dist, split_sample_ratio, apply_scaler
from ..lp import emd2, emd2_lazy, wasserstein_1d
from ..backend import get_backend
from ..unbalanced import mm_unbalanced, sinkhorn_knopp_unbalanced, lbfgsb_unbalanced
from ..bregman import (
    sinkhorn_log,
    empirical_sinkhorn2,
    empirical_sinkhorn_nystroem2,
    old_geomloss,
)
from ..sliced import sliced_wasserstein_distance, max_sliced_wasserstein_distance
from ..bsp import compute_bspot_bijection
from ..smooth import smooth_ot_dual
from ..gaussian import (
    empirical_bures_wasserstein_distance,
    empirical_bures_wasserstein_distance_hd,
)
from ..factored import factored_optimal_transport
from ..lowrank import lowrank_sinkhorn
from ..optim import cg
from warnings import warn

lst_valid_methods_solve = [
    "sinkhorn",  # sinkhorn for unbalanced
    "sinkhorn_log",  # sinkhorn for unbalanced
    "mm",  # unbalanced
    "lbfgsb",  # unbalanced
]


lst_method_solve_sample = [
    "1d",
    "gaussian",
    "gaussian_hd",
    "lowrank",
    "nystroem",
    "factored",
    "geomloss",
    "geomloss_auto",
    "geomloss_tensorized",
    "geomloss_online",
    "geomloss_multiscale",
    "sliced",
    "max_sliced",
    "bsp",
]

all_valid_methods_solve_sample = lst_valid_methods_solve + lst_method_solve_sample


def solve(
    M,
    a=None,
    b=None,
    reg=None,
    c=None,
    reg_type="KL",
    unbalanced=None,
    unbalanced_type="KL",
    method=None,
    n_threads=1,
    max_iter=None,
    plan_init=None,
    potentials_init=None,
    tol=None,
    verbose=False,
    grad="autodiff",
):
    r"""Solve the discrete optimal transport problem and return :any:`OTResult` object
    The function solves the following general optimal transport problem

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} + \lambda_r R(\mathbf{T}) +
        \lambda_1 U(\mathbf{T}\mathbf{1},\mathbf{a}) +
        \lambda_2 U(\mathbf{T}^T\mathbf{1},\mathbf{b})

    The regularization is selected with `reg` (:math:`\lambda_r`) and `reg_type`. By
    default ``reg=None`` and there is no regularization. The unbalanced marginal
    penalization can be selected with `unbalanced` (:math:`(\lambda_1, \lambda_2)`) and
    `unbalanced_type`. By default ``unbalanced=None`` and the function
    solves the exact optimal transport problem (respecting the marginals).

    Parameters
    ----------
    M : array-like, shape (dim_a, dim_b)
        Loss matrix
    a : array-like, shape (dim_a,), optional
        Samples weights in the source domain (default is uniform)
    b : array-like, shape (dim_b,), optional
        Samples weights in the source domain (default is uniform)
    reg : float, optional
        Regularization weight :math:`\lambda_r`, by default None (no reg., exact
        OT)
    c : array-like, shape (dim_a, dim_b), optional (default=None)
        Reference measure for the regularization.
        If None, then use :math:`\mathbf{c} = \mathbf{a} \mathbf{b}^T`.
        If :math:`\texttt{reg_type}=`'entropy', then :math:`\mathbf{c} = 1_{dim_a} 1_{dim_b}^T`.
    reg_type : str, optional
        Type of regularization :math:`R`  either "KL", "L2", "entropy",
        by default "KL". a tuple of functions can be provided for general
        solver (see :any:`cg`). This is only used when ``reg!=None``.
    unbalanced : float or indexable object of length 1 or 2
        Marginal relaxation term.
        If it is a scalar or an indexable object of length 1,
        then the same relaxation is applied to both marginal relaxations.
        The balanced OT can be recovered using :math:`unbalanced=float("inf")`.
        For semi-relaxed case, use either
        :math:`unbalanced=(float("inf"), scalar)` or
        :math:`unbalanced=(scalar, float("inf"))`.
        If unbalanced is an array,
        it must have the same backend as input arrays `(a, b, M)`.
    unbalanced_type : str, optional
        Type of unbalanced penalization function :math:`U`  either "KL", "L2",
        "TV", by default "KL".
    method : str, optional
        Method for solving the problem when multiple algorithms are available,
        default None for automatic selection.
    n_threads : int, optional
        Number of OMP threads for exact OT solver, by default 1
    max_iter : int, optional
        Maximum number of iterations, by default None (default values in each solvers)
    plan_init : array-like, shape (dim_a, dim_b), optional
        Initialization of the OT plan for iterative methods, by default None
    potentials_init : (array-like(dim_a,),array-like(dim_b,)), optional
        Initialization of the OT dual potentials for iterative methods (Sinkhorn,
        unbalanced) or warmstart for exact EMD solver. For EMD, these potentials
        are used to guide initial pivots in the network simplex. By default None
    tol : _type_, optional
        Tolerance for solution precision, by default None (default values in each solvers)
    verbose : bool, optional
        Print information in the solver, by default False
    grad : str, optional
        Type of gradient computation, either or 'autodiff', 'envelope' or 'last_step' used only for
        Sinkhorn solver. By default 'autodiff' provides gradients wrt all
        outputs (`plan, value, value_linear`) but with important memory cost.
        'envelope' provides gradients only for `value` and and other outputs are
        detached. This is useful for memory saving when only the value is needed. 'last_step' provides
        gradients only for the last iteration of the Sinkhorn solver, but provides gradient for both the OT plan and the objective values.
        'detach' does not compute the gradients for the Sinkhorn solver.

    Returns
    -------
    res : OTResult()
        Result of the optimization problem. The information can be obtained as follows:

        - res.plan : OT plan :math:`\mathbf{T}`
        - res.potentials : OT dual potentials
        - res.value : Optimal value of the optimization problem
        - res.value_linear : Linear OT loss with the optimal OT plan

        See :any:`OTResult` for more information.

    Notes
    -----

    The following methods are available for solving the OT problems:

    - **Classical exact OT problem [1]** (default parameters) :

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0

    can be solved with the following code:

    .. code-block:: python

        res = ot.solve(M, a, b)

    - **Entropic regularized OT [2]** (when ``reg!=None``):

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F + \lambda R(\mathbf{T})

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"`` regularization (``reg_type="KL"``)
        res = ot.solve(M, a, b, reg=1.0)
        # or for original Sinkhorn paper formulation [2]
        res = ot.solve(M, a, b, reg=1.0, reg_type='entropy')

        # Use envelope theorem differentiation for memory saving
        res = ot.solve(M, a, b, reg=1.0, grad='envelope') # M, a, b are torch tensors
        res.value.backward() # only the value is differentiable

    Note that by default the Sinkhorn solver uses automatic differentiation to
    compute the gradients of the values and plan. This can be changed with the
    `grad` parameter. The `envelope` mode computes the gradients only
    for the value and the other outputs are detached. This is useful for
    memory saving when only the gradient of value is needed.

    - **Quadratic regularized OT [17]** (when ``reg!=None`` and ``reg_type="L2"``):

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F + \lambda R(\mathbf{T})

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0

    can be solved with the following code:

    .. code-block:: python

        res = ot.solve(M,a,b,reg=1.0,reg_type='L2')

    - **Unbalanced OT [41]** (when ``unbalanced!=None``):

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} +
        \lambda_1 U(\mathbf{T}\mathbf{1},\mathbf{a}) +
        \lambda_2 U(\mathbf{T}^T\mathbf{1},\mathbf{b})

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"``
        res = ot.solve(M,a,b,unbalanced=1.0)
        # quadratic unbalanced OT
        res = ot.solve(M,a,b,unbalanced=1.0,unbalanced_type='L2')
        # TV = partial OT
        res = ot.solve(M,a,b,unbalanced=1.0,unbalanced_type='TV')


    - **Regularized unbalanced regularized OT [34]** (when ``unbalanced!=None`` and ``reg!=None``):

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} + \lambda_r R(\mathbf{T}) +
        \lambda_1 U(\mathbf{T}\mathbf{1},\mathbf{a}) +
        \lambda_2 U(\mathbf{T}^T\mathbf{1},\mathbf{b})

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"`` for both
        res = ot.solve(M,a,b,reg=1.0,unbalanced=1.0)
        # quadratic unbalanced OT with KL regularization
        res = ot.solve(M,a,b,reg=1.0,unbalanced=1.0,unbalanced_type='L2')
        # both quadratic
        res = ot.solve(M,a,b,reg=1.0, reg_type='L2',unbalanced=1.0,unbalanced_type='L2')


    .. _references-solve:
    References
    ----------

    .. [1] Bonneel, N., Van De Panne, M., Paris, S., & Heidrich, W.
        (2011, December).  Displacement interpolation using Lagrangian mass
        transport. In ACM Transactions on Graphics (TOG) (Vol. 30, No. 6, p.
        158). ACM.

    .. [2] M. Cuturi, Sinkhorn Distances : Lightspeed Computation
        of Optimal Transport, Advances in Neural Information Processing
        Systems (NIPS) 26, 2013

    .. [10] Chizat, L., Peyré, G., Schmitzer, B., & Vialard, F. X. (2016).
        Scaling algorithms for unbalanced transport problems.
        arXiv preprint arXiv:1607.05816.

    .. [17] Blondel, M., Seguy, V., & Rolet, A. (2018). Smooth and Sparse
        Optimal Transport. Proceedings of the Twenty-First International
        Conference on Artificial Intelligence and Statistics (AISTATS).

    .. [34] Feydy, J., Séjourné, T., Vialard, F. X., Amari, S. I., Trouvé,
        A., & Peyré, G. (2019, April). Interpolating between optimal transport
        and MMD using Sinkhorn divergences. In The 22nd International Conference
        on Artificial Intelligence and Statistics (pp. 2681-2690). PMLR.

    .. [41] Chapel, L., Flamary, R., Wu, H., Févotte, C., and Gasso, G. (2021).
        Unbalanced optimal transport through non-negative penalized
        linear regression. NeurIPS.

    """
    # detect backend
    nx = get_backend(M, a, b, c)

    # create uniform weights if not given
    if a is None:
        a = nx.ones(M.shape[0], type_as=M) / M.shape[0]
    if b is None:
        b = nx.ones(M.shape[1], type_as=M) / M.shape[1]
    if c is None:
        c = a[:, None] * b[None, :]

    if reg is None:
        reg = 0

    if method is not None and method not in lst_valid_methods_solve:
        raise ValueError(
            "Unknown method={} for solve, must be in {}".format(
                method, lst_valid_methods_solve
            )
        )

    # default values for solutions
    potentials = None
    value = None
    value_linear = None
    plan = None
    status = None

    if reg == 0:  # exact OT
        if unbalanced is None:  # Exact balanced OT
            # default values for EMD solver
            if max_iter is None:
                max_iter = 1000000

            value_linear, log = emd2(
                a,
                b,
                M,
                numItermax=max_iter,
                log=True,
                return_matrix=True,
                numThreads=n_threads,
                potentials_init=potentials_init,
            )

            value = value_linear
            potentials = (log["u"], log["v"])
            plan = log["G"]
            status = log["warning"] if log["warning"] is not None else "Converged"

        elif unbalanced_type.lower() in ["kl", "l2"]:  # unbalanced exact OT
            # default values for exact unbalanced OT
            if max_iter is None:
                max_iter = 1000
            if tol is None:
                tol = 1e-12

            plan, log = mm_unbalanced(
                a,
                b,
                M,
                reg_m=unbalanced,
                c=c,
                reg=reg,
                div=unbalanced_type,
                numItermax=max_iter,
                stopThr=tol,
                log=True,
                verbose=verbose,
                G0=plan_init,
            )

            value_linear = log["cost"]
            value = log["total_cost"]

        elif unbalanced_type.lower() == "tv":
            if max_iter is None:
                max_iter = 1000
            if tol is None:
                tol = 1e-12
            if isinstance(reg_type, str):
                reg_type = reg_type.lower()

            plan, log = lbfgsb_unbalanced(
                a,
                b,
                M,
                reg=reg,
                reg_m=unbalanced,
                c=c,
                reg_div=reg_type,
                regm_div=unbalanced_type,
                numItermax=max_iter,
                stopThr=tol,
                verbose=verbose,
                log=True,
                G0=plan_init,
            )

            value_linear = log["cost"]
            value = log["total_cost"]

        else:
            raise (
                NotImplementedError(
                    'Unknown unbalanced_type="{}"'.format(unbalanced_type)
                )
            )

    else:  # regularized OT
        if unbalanced is None:  # Balanced regularized OT
            if isinstance(reg_type, tuple):  # general solver
                f, df = reg_type

                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-9

                plan, log = cg(
                    a,
                    b,
                    M,
                    reg=reg,
                    f=f,
                    df=df,
                    numItermax=max_iter,
                    stopThr=tol,
                    log=True,
                    verbose=verbose,
                    G0=plan_init,
                )

                value_linear = nx.sum(M * plan)
                value = log["loss"][-1]
                potentials = (log["u"], log["v"])

            elif reg_type.lower() in ["entropy", "kl"]:
                if grad in [
                    "envelope",
                    "last_step",
                    "detach",
                ]:  # if envelope, last_step or detach then detach the input
                    M0, a0, b0 = M, a, b
                    M, a, b = nx.detach(M, a, b)

                # default values for sinkhorn
                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-9
                if grad == "last_step":
                    if max_iter == 0:
                        raise ValueError(
                            "The maximum number of iterations must be greater than 0 when using grad=last_step."
                        )
                    max_iter = max_iter - 1

                plan, log = sinkhorn_log(
                    a,
                    b,
                    M,
                    reg=reg,
                    numItermax=max_iter,
                    stopThr=tol,
                    log=True,
                    verbose=verbose,
                )

                potentials = (log["log_u"], log["log_v"])

                # if last_step, compute the last step of the Sinkhorn algorithm with the non-detached inputs
                if grad == "last_step":
                    loga = nx.log(a0)
                    logb = nx.log(b0)
                    v = logb - nx.logsumexp(-M0 / reg + potentials[0][:, None], 0)
                    u = loga - nx.logsumexp(-M0 / reg + potentials[1][None, :], 1)
                    plan = nx.exp(-M0 / reg + u[:, None] + v[None, :])
                    potentials = (u, v)
                    log["niter"] = max_iter + 1
                    log["log_u"] = u
                    log["log_v"] = v
                    log["u"] = nx.exp(u)
                    log["v"] = nx.exp(v)

                value_linear = nx.sum(M * plan)

                if reg_type.lower() == "entropy":
                    value = value_linear + reg * nx.sum(plan * nx.log(plan + 1e-16))
                else:
                    # stabilize kl of 0 mass
                    if nx.any(a == 0) or nx.any(b == 0):
                        a = a + 1e-15 * nx.min(a)
                        b = b + 1e-15 * nx.min(b)
                        print(
                            "Warning: a or b has 0 mass, adding small mass to avoid NaN in KL divergence."
                        )
                    value = value_linear + reg * nx.kl_div(
                        plan, a[:, None] * b[None, :] + 1e-15
                    )

                if grad == "envelope":  # set the gradient at convergence
                    value = nx.set_gradients(
                        value,
                        (M0, a0, b0),
                        (
                            plan,
                            reg * (potentials[0] - potentials[0].mean()),
                            reg * (potentials[1] - potentials[1].mean()),
                        ),
                    )

            elif reg_type.lower() == "l2":
                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-9

                plan, log = smooth_ot_dual(
                    a,
                    b,
                    M,
                    reg=reg,
                    numItermax=max_iter,
                    stopThr=tol,
                    log=True,
                    verbose=verbose,
                )

                value_linear = nx.sum(M * plan)
                value = value_linear + reg * nx.sum(plan**2)
                potentials = (log["alpha"], log["beta"])

            else:
                raise (
                    NotImplementedError(
                        'Not implemented reg_type="{}"'.format(reg_type)
                    )
                )

        else:  # unbalanced AND regularized OT
            if (
                not isinstance(reg_type, tuple)
                and reg_type.lower() in ["kl"]
                and unbalanced_type.lower() == "kl"
            ):
                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-9

                plan, log = sinkhorn_knopp_unbalanced(
                    a,
                    b,
                    M,
                    reg=reg,
                    reg_m=unbalanced,
                    method=method,
                    reg_type=reg_type,
                    c=c,
                    warmstart=potentials_init,
                    numItermax=max_iter,
                    stopThr=tol,
                    verbose=verbose,
                    log=True,
                )

                value_linear = log["cost"]
                value = log["total_cost"]

                potentials = (log["logu"], log["logv"])

            elif (
                isinstance(reg_type, tuple)
                or reg_type.lower() in ["kl", "l2", "entropy"]
            ) and unbalanced_type.lower() in ["kl", "l2", "tv"]:
                if isinstance(reg_type, tuple) and nx.__name__ == "tf":
                    raise NotImplementedError(
                        "Custom regularization is not implemented for TensorFlow backend."
                    )

                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-12
                if isinstance(reg_type, str):
                    reg_type = reg_type.lower()

                plan, log = lbfgsb_unbalanced(
                    a,
                    b,
                    M,
                    reg=reg,
                    reg_m=unbalanced,
                    c=c,
                    reg_div=reg_type,
                    regm_div=unbalanced_type,
                    numItermax=max_iter,
                    stopThr=tol,
                    verbose=verbose,
                    log=True,
                    G0=plan_init,
                )

                value_linear = log["cost"]
                value = log["total_cost"]

            else:
                raise (
                    NotImplementedError(
                        'Not implemented reg_type="{}" and unbalanced_type="{}"'.format(
                            reg_type, unbalanced_type
                        )
                    )
                )

    res = OTResult(
        potentials=potentials,
        value=value,
        value_linear=value_linear,
        plan=plan,
        status=status,
        backend=nx,
    )

    return res


def solve_sample(
    X_a,
    X_b,
    a=None,
    b=None,
    metric="sqeuclidean",
    reg=None,
    c=None,
    reg_type="KL",
    unbalanced=None,
    unbalanced_type="KL",
    lazy=False,
    batch_size=None,
    method=None,
    n_threads=1,
    max_iter=None,
    plan_init=None,
    rank=100,
    scaling=0.95,
    potentials_init=None,
    X_init=None,
    tol=None,
    verbose=False,
    grad="autodiff",
    random_state=None,
    debias=False,
    n_projections=50,
    projections=None,
    scaler=None,
):
    r"""Solve the discrete optimal transport problem using the samples in the source and target domains.

    The function solves the following general optimal transport problem

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} + \lambda_r R(\mathbf{T}) +
        \lambda_u U(\mathbf{T}\mathbf{1},\mathbf{a}) +
        \lambda_u U(\mathbf{T}^T\mathbf{1},\mathbf{b})

    where the cost matrix :math:`\mathbf{M}` is computed from the samples in the
    source and target domains such that :math:`M_{i,j} = d(x_i,y_j)` where
    :math:`d` is a metric (by default the squared Euclidean distance).

    The regularization is selected with `reg` (:math:`\lambda_r`) and `reg_type`. By
    default ``reg=None`` and there is no regularization. The unbalanced marginal
    penalization can be selected with `unbalanced` (:math:`\lambda_u`) and
    `unbalanced_type`. By default ``unbalanced=None`` and the function
    solves the exact optimal transport problem (respecting the marginals).

    Parameters
    ----------
    X_a : array-like, shape (n_samples_a, dim)
        samples in the source domain
    X_b : array-like, shape (n_samples_b, dim)
        samples in the target domain
    a : array-like, shape (dim_a,), optional
        Samples weights in the source domain (default is uniform)
    b : array-like, shape (dim_b,), optional
        Samples weights in the source domain (default is uniform)
    reg : float, optional
        Regularization weight :math:`\lambda_r`, by default None (no reg., exact
        OT)
    c : array-like, shape (dim_a, dim_b), optional (default=None)
        Reference measure for the regularization.
        If None, then use :math:`\mathbf{c} = \mathbf{a} \mathbf{b}^T`.
        If `reg_type='entropy'`, then :math:`\mathbf{c} = 1_{dim_a} 1_{dim_b}^T`.
    reg_type : str, optional
        Type of regularization :math:`R`  either "KL", "L2", "entropy", by default "KL"
    unbalanced : float or indexable object of length 1 or 2
        Marginal relaxation term.
        If it is a scalar or an indexable object of length 1,
        then the same relaxation is applied to both marginal relaxations.
        The balanced OT can be recovered using `unbalanced=float("inf")`.
        For semi-relaxed case, use either
        `unbalanced=(float("inf"), scalar)` or
        `unbalanced=(scalar, float("inf"))`.
        If unbalanced is an array,
        it must have the same backend as input arrays `(a, b, M)`.
    unbalanced_type : str, optional
        Type of unbalanced penalization function :math:`U`  either "KL", "L2", "TV", by default "KL"
    lazy : bool, optional
        Return :any:`OTResultlazy` object to reduce memory cost when True, by
        default False
    batch_size : int, optional
        Batch size for lazy solver, by default None (default values in each
        solvers)
    method : str, optional
        Method for solving the problem, this can be used to select the solver
        for unbalanced problems (see :any:`ot.solve`), or to select a specific
        large scale solver. Available methods are:

        - "1d" for 1D OT solver done in parallel for each dimension.
        - "gaussian" for Gaussian OT solver that estimates mean and
              covariance and solve the closed form solution)
        - "gaussian_hd" for high-dimensional Gaussian OT solver with rank given by `rank` parameter .
        - "lowrank" for low-rank Sinkhorn solver (see :any:`ot.lowrank`)
        - "nystroem" for Nystroem Sinkhorn solver
        - "factored" for factored OT solver
        - "geomloss" for GeomLoss Sinkhorn solver
        - "sliced" for sliced wasserstein distance (see :any:`ot.sliced`)
        - "max_sliced" for max sliced wasserstein distance (see
          :any:`ot.sliced`)
        - "bsp" for BSP-OT solver (only for distribution with same number of
          samples and uniform weights)
    n_threads : int, optional
        Number of OMP threads for exact OT solver, by default 1
    max_iter : int, optional
        Maximum number of iteration, by default None (default values in each solvers)
    plan_init : array-like, shape (dim_a, dim_b), optional
        Initialization of the OT plan for iterative methods, by default None
    rank : int, optional
        Rank of the OT matrix for lazy solvers (method='factored') or (method='nystroem'), by default 100
    scaling : float, optional
        Scaling factor for the epsilon scaling lazy solvers (method='geomloss'), by default 0.95
    potentials_init : (array-like(dim_a,),array-like(dim_b,)), optional
        Initialization of the OT dual potentials for iterative methods (Sinkhorn,
        unbalanced) or warmstart for exact EMD solver. For EMD, these potentials
        are used to guide initial pivots in the network simplex. By default None
    tol : _type_, optional
        Tolerance for solution precision, by default None (default values in each solvers)
    verbose : bool, optional
        Print information in the solver, by default False
    grad : str, optional
        Type of gradient computation, either or 'autodiff' or 'envelope'  used only for
        Sinkhorn solver. By default 'autodiff' provides gradients wrt all
        outputs (`plan, value, value_linear`) but with important memory cost.
        'envelope' provides gradients only for `value` and and other outputs are
        detached. This is useful for memory saving when only the value is needed.
    random_state : int, optional
        The random state for sampling the components in each distribution for method='nystroem'.
    debias : bool, optional
        Whether to use the debiased version of the OT problem, by default False
        if True, the value returned is the Sinkhorn divergence [23] but the plan is
        still the Sinkhorn plan. The results for all pairs of problems and
        provided in the log dictionary. if debiased='split', then X_a and X_b
        are split into two halves and the debiased value is computed using the
        two halves as proposed in minibatch OT [91].
    n_projections : int, optional
        Number of projections for sliced OT, by default 50
    projections : array-like, shape (n_projections, dim), optional
        Projections for sliced OT, by default None (random projections are used)
    scaler : callable, optional
        Function to scale the input data, following :any:`ot.utils.apply_scaler`.
        by default None (no scaling).

    Returns
    -------

    res : OTResult()
        Result of the optimization problem. The information can be obtained as follows:

        - res.plan : OT plan :math:`\mathbf{T}`
        - res.potentials : OT dual potentials
        - res.value : Optimal value of the optimization problem
        - res.value_linear : Linear OT loss with the optimal OT plan
        - res.lazy_plan : Lazy OT plan (when ``lazy=True`` or lazy method)

        See :any:`OTResult` for more information.

    Notes
    -----

    The following methods are available for solving the OT problems:

    - **Classical exact OT problem [1]** (default parameters) :

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0,  M_{i,j} = d(x_i,y_j)



    can be solved with the following code:

    .. code-block:: python

        res = ot.solve_sample(xa, xb, a, b)

        # for uniform weights
        res = ot.solve_sample(xa, xb)

    - **Entropic regularized OT [2]** (when ``reg!=None``):

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F + \lambda R(\mathbf{T})

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0,  M_{i,j} = d(x_i,y_j)

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"`` regularization (``reg_type="KL"``)
        res = ot.solve_sample(xa, xb, a, b, reg=1.0)
        # or for original Sinkhorn paper formulation [2]
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, reg_type='entropy')

        # lazy solver of memory complexity O(n)
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, lazy=True, batch_size=100)
        # lazy OT plan
        lazy_plan = res.lazy_plan

        # Use envelope theorem differentiation for memory saving
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, grad='envelope')
        res.value.backward() # only the value is differentiable

    Note that by default the Sinkhorn solver uses automatic differentiation to
    compute the gradients of the values and plan. This can be changed with the
    `grad` parameter. The `envelope` mode computes the gradients only
    for the value and the other outputs are detached. This is useful for
    memory saving when only the gradient of value is needed.

    We also have a very efficient solver with compiled CPU/CUDA code using
    geomloss/PyKeOps that can be used with the following code:

    .. code-block:: python

        # automatic solver
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, method='geomloss')

    .. warning::
        The geomloss solver is a thin wrapper around the `geomloss.ot.solve_sample`
        function. The API is still under development and some features might be missing. Please refer to the `geomloss` documentation for more information.

    - **Quadratic regularized OT [17]** (when ``reg!=None`` and ``reg_type="L2"``):

    .. math::
        \min_\mathbf{T} \quad \langle \mathbf{T}, \mathbf{M} \rangle_F + \lambda R(\mathbf{T})

        s.t. \ \mathbf{T} \mathbf{1} = \mathbf{a}

             \mathbf{T}^T \mathbf{1} = \mathbf{b}

             \mathbf{T} \geq 0,  M_{i,j} = d(x_i,y_j)

    can be solved with the following code:

    .. code-block:: python

        res = ot.solve_sample(xa, xb, a, b, reg=1.0, reg_type='L2')

    - **Debiased OT and Sinkhorn divergence** (when ``debias=True``):

    One can compute the Sinkhorn divergence between two distributions using the
    following code:

    .. code-block:: python

        div = ot.solve_sample(xa, xb, a, b, reg=1.0, debias=True).value

    Debiasing for all existing solvers is implemented and in particular one can
    recover the minibatch exact OT debiasing [91] using the following code:

    .. code-block:: python

        div = ot.solve_sample(xa, xb, a, b, debias='split').value

    - **Unbalanced OT [41]** (when ``unbalanced!=None``):

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} + \lambda_u U(\mathbf{T}\mathbf{1},\mathbf{a}) + \lambda_u U(\mathbf{T}^T\mathbf{1},\mathbf{b})

        \text{with} \ M_{i,j} = d(x_i,y_j)

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"``
        res = ot.solve_sample(xa, xb, a, b, unbalanced=1.0)
        # quadratic unbalanced OT
        res = ot.solve_sample(xa, xb, a, b, unbalanced=1.0,unbalanced_type='L2')
        # TV = partial OT
        res = ot.solve_sample(xa, xb, a, b, unbalanced=1.0,unbalanced_type='TV')


    - **Regularized unbalanced regularized OT [34]** (when ``unbalanced!=None`` and ``reg!=None``):

    .. math::
        \min_{\mathbf{T}\geq 0} \quad \sum_{i,j} T_{i,j}M_{i,j} + \lambda_r R(\mathbf{T}) + \lambda_u U(\mathbf{T}\mathbf{1},\mathbf{a}) + \lambda_u U(\mathbf{T}^T\mathbf{1},\mathbf{b})

        \text{with} \ M_{i,j} = d(x_i,y_j)

    can be solved with the following code:

    .. code-block:: python

        # default is ``"KL"`` for both
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, unbalanced=1.0)
        # quadratic unbalanced OT with KL regularization
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, unbalanced=1.0,unbalanced_type='L2')
        # both quadratic
        res = ot.solve_sample(xa, xb, a, b, reg=1.0, reg_type='L2',
        unbalanced=1.0, unbalanced_type='L2')


    - **Factored OT [2]** (when ``method='factored'``):

    This method solve the following OT problem [40]_

    .. math::
        \mathop{\arg \min}_\mu \quad  W_2^2(\mu_a,\mu)+ W_2^2(\mu,\mu_b)

    where $\mu$ is a uniform weighted empirical distribution of  :math:`\mu_a` and :math:`\mu_b` are the empirical measures associated
    to the samples in the source and target domains, and :math:`W_2` is the
    Wasserstein distance. This problem is solved using exact OT solvers for
    `reg=None` and the Sinkhorn solver for `reg!=None`. The solution provides
    two transport plans that can be used to recover a low rank OT plan between
    the two distributions.

    .. code-block:: python

        res = ot.solve_sample(xa, xb, method='factored', rank=10)

        # recover the lazy low rank plan
        factored_solution_lazy = res.lazy_plan

        # recover the full low rank plan
        factored_solution = factored_solution_lazy[:]

    - ** Nystroem OT [76] ** (when ``method='nystroem'``):

    Corresponds to a low rank approximation of entropic OT (for a squared Euclidean cost) that runs in linear time.

    - **Gaussian Bures-Wasserstein** (when ``method='gaussian'``):

    This method computes the Gaussian Bures-Wasserstein distance between two
    Gaussian distributions estimated from the empirical distributions

    .. math::
        \mathcal{W}(\mu_s, \mu_t)_2^2= \left\lVert \mathbf{m}_s - \mathbf{m}_t \right\rVert^2 + \mathcal{B}(\Sigma_s, \Sigma_t)^{2}

    where :

    .. math::
        \mathbf{B}(\Sigma_s, \Sigma_t)^{2} = \text{Tr}\left(\Sigma_s + \Sigma_t - 2 \sqrt{\Sigma_s^{1/2}\Sigma_t\Sigma_s^{1/2}} \right)

    The covariances and means are estimated from the data.

    .. code-block:: python

        res = ot.solve_sample(xa, xb, method='gaussian')

        # recover the squared Gaussian Bures-Wasserstein distance
        BW_dist = res.value

    The Gaussian-HD variant of this method can be used for high-dimensional data with the following code:

    .. code-block:: python

        res = ot.solve_sample(xa, xb, method='gaussian_hd', rank=10)

    where the rank parameter controls the rank of the covariance matrices used in the computation of the Bures-Wasserstein distance.

    - **Wasserstein 1d [1]** (when ``method='1D'``):

    This method computes the Wasserstein distance between two 1d distributions
    estimated from the empirical distributions. For multivariate data the
    distances are computed independently for each dimension.

    .. code-block:: python

        res = ot.solve_sample(xa, xb, method='1D')

        # recover the squared Wasserstein distances
        W_dists = res.value

    - **Sliced Wasserstein distance** (when ``method='sliced'``):

    This method computes the sliced Wasserstein distance between two
    distributions. The sliced Wasserstein distance
    is defined as the average of the Wasserstein distances between the projected
    distributions on random directions.

    .. code-block:: python

        swd = ot.solve_sample(xa, xb, method='sliced', n_projections=50).value

    - **Max Sliced Wasserstein [34]** (when ``method='max_sliced'``):

    This method computes the max sliced Wasserstein distance between two
    distributions.

    .. code-block:: python

        mswd = ot.solve_sample(xa, xb, method='max_sliced', n_projections=50).value

    - **Binary Space Partitioning OT  (BSP)** (when ``method='bsp'``):

    This method computes the BSP-OT distance between two distributions and
    alignments. The number of partitioning directions can be set with the `n_projections` parameter.

    .. code-block:: python

        res = ot.solve_sample(xa, xb, method='bsp', n_projections=50)

        bsp_ot_distance = res.value
        bsp_plan = res.plan


    .. _references-solve-sample:
    References
    ----------

    .. [1] Bonneel, N., Van De Panne, M., Paris, S., & Heidrich, W.
        (2011, December).  Displacement interpolation using Lagrangian mass
        transport. In ACM Transactions on Graphics (TOG) (Vol. 30, No. 6, p.
        158). ACM.

    .. [2] M. Cuturi, Sinkhorn Distances : Lightspeed Computation
        of Optimal Transport, Advances in Neural Information Processing
        Systems (NIPS) 26, 2013

    .. [10] Chizat, L., Peyré, G., Schmitzer, B., & Vialard, F. X. (2016).
        Scaling algorithms for unbalanced transport problems.
        arXiv preprint arXiv:1607.05816.

    .. [17] Blondel, M., Seguy, V., & Rolet, A. (2018). Smooth and Sparse
        Optimal Transport. Proceedings of the Twenty-First International
        Conference on Artificial Intelligence and Statistics (AISTATS).

    .. [23] Aude, G., Peyré, G., Cuturi, M., Learning Generative Models with
        Sinkhorn Divergences, Proceedings of the Twenty-First International
        Conference on Artificial Intelligence and Statistics, (AISTATS) 21, 2018

    .. [34] Feydy, J., Séjourné, T., Vialard, F. X., Amari, S. I., Trouvé,
        A., & Peyré, G. (2019, April). Interpolating between optimal transport
        and MMD using Sinkhorn divergences. In The 22nd International Conference
        on Artificial Intelligence and Statistics (pp. 2681-2690). PMLR.

    .. [40] Forrow, A., Hütter, J. C., Nitzan, M., Rigollet, P., Schiebinger,
        G., & Weed, J. (2019, April). Statistical optimal transport via factored
        couplings. In The 22nd International Conference on Artificial
        Intelligence and Statistics (pp. 2454-2465). PMLR.

    .. [41] Chapel, L., Flamary, R., Wu, H., Févotte, C., and Gasso, G. (2021).
        Unbalanced optimal transport through non-negative penalized
        linear regression. NeurIPS.

    .. [65] Scetbon, M., Cuturi, M., & Peyré, G. (2021).
        Low-rank Sinkhorn Factorization. In International Conference on
        Machine Learning.

    .. [80] Altschuler, J., Bach, F., Rudi, A., Niles-Weed, J. (2019).
        Massively scalable Sinkhorn distances via the Nyström method. NeurIPS.

    .. [91] Fatras, K., Zine, Y., Majewski, S., Flamary, R., Gribonval, R., &
        Courty, N. (2021). [Minibatch optimal transport distances; analysis and
        applications](https://arxiv.org/pdf/2101.01792). arXiv preprint arXiv:2101.01792.

    """

    if method is not None and method.lower() not in all_valid_methods_solve_sample:
        raise ValueError(
            "Unknown method={} for solve_sample. Available methods are: {}".format(
                method, all_valid_methods_solve_sample
            )
        )

    if scaler is not None:
        X_a, Xb = apply_scaler(X_a, X_b, scaler=scaler)

    if debias:
        dict_params = dict(
            metric=metric,
            reg=reg,
            c=c,
            reg_type=reg_type,
            unbalanced=unbalanced,
            unbalanced_type=unbalanced_type,
            lazy=lazy,
            batch_size=batch_size,
            method=method,
            n_threads=n_threads,
            max_iter=max_iter,
            plan_init=plan_init,
            rank=rank,
            scaling=scaling,
            potentials_init=potentials_init,
            X_init=X_init,
            tol=tol,
            verbose=verbose,
            grad=grad,
            random_state=random_state,
            debias=False,
        )

        nx = get_backend(X_a, X_b, a, b)

        if nx.__name__ == "tf":
            raise NotImplementedError(
                "Debiasing is not implemented for TensorFlow backend."
            )

        if isinstance(debias, str) and debias == "split":
            # split the samples into two halves with each half the mass
            X_a1, X_a2, a1, a2, sel_a1, sel_a2 = split_sample_ratio(X_a, a, nx=nx)
            X_b1, X_b2, b1, b2, sel_b1, sel_b2 = split_sample_ratio(X_b, b, nx=nx)

            # compute the four OT problems
            resaa = solve_sample(X_a1, X_a2, a=a1, b=a2, **dict_params)
            resbb = solve_sample(X_b1, X_b2, a=b1, b=b2, **dict_params)
            resab1 = solve_sample(X_a1, X_b1, a=a1, b=b1, **dict_params)
            resab2 = solve_sample(X_a2, X_b2, a=a2, b=b2, **dict_params)

            # compute debiased values
            value = (resab1.value + resab2.value) - (resaa.value + resbb.value)
            value_linear = value

            log = {
                "res_aa": resaa,
                "res_bb": resbb,
                "res_ab1": resab1,
                "res_ab2": resab2,
                "sel_a1": sel_a1,
                "sel_a2": sel_a2,
                "sel_b1": sel_b1,
                "sel_b2": sel_b2,
                "a1": a1,
                "a2": a2,
                "b1": b1,
                "b2": b2,
            }

            res = OTResult(
                value=value,
                value_linear=value_linear,
                plan=None,  # no plan for debiased version
                potentials=None,  # no potentials for debiased version
                sparse_plan=None,  # no sparse plan for debiased version
                lazy_plan=None,  # no lazy plan for debiased version
                status="Debiased",
                log=log,
                backend=nx,
            )

        else:
            # standard debiasing à la sinkhorn divergence

            resaa = solve_sample(X_a, X_a, a=a, b=a, **dict_params)

            resbb = solve_sample(X_b, X_b, a=b, b=b, **dict_params)

            resab = solve_sample(X_a, X_b, a=a, b=b, **dict_params)

            # compute debiased values
            value = resab.value - 0.5 * (resaa.value + resbb.value)
            value_linear = resab.value_linear - 0.5 * (
                resaa.value_linear + resbb.value_linear
            )

            log = {"res_aa": resaa, "res_bb": resbb, "res_ab": resab}

            res = OTResult(
                value=value,
                value_linear=value_linear,
                plan=resab.plan,
                potentials=resab.potentials,
                sparse_plan=resab.sparse_plan,
                lazy_plan=resab.lazy_plan,
                status=resab.status,
                log=log,
                backend=nx,
            )

        # return debiased result
        return res

    if method is not None and method.lower() in all_valid_methods_solve_sample:
        lazy0 = lazy
        lazy = True

    if not lazy:  # default non lazy solver calls ot.solve
        # compute cost matrix M and use solve function
        M = dist(X_a, X_b, metric)

        res = solve(
            M,
            a,
            b,
            reg,
            c,
            reg_type,
            unbalanced,
            unbalanced_type,
            method,
            n_threads,
            max_iter,
            plan_init,
            potentials_init,
            tol,
            verbose,
            grad,
        )

        return res

    elif lazy and method is None and (reg is None or reg == 0) and unbalanced is None:
        # Use lazy EMD solver with coordinates (no regularization, balanced)
        nx = get_backend(X_a, X_b, a, b)
        value_linear, log = emd2_lazy(
            X_a,
            X_b,
            a,
            b,
            metric=metric,
            numItermax=max_iter if max_iter is not None else 100000,
            log=True,
            return_matrix=True,
            potentials_init=potentials_init,
        )

        res = OTResult(
            potentials=(log["u"], log["v"]),
            value=value_linear,
            value_linear=value_linear,
            sparse_plan=log["G"],
            backend=nx,
            status=log["warning"] if log["warning"] is not None else "Converged",
        )

        return res

    else:
        # Detect backend
        nx = get_backend(X_a, X_b, a, b)

        # default values for solutions
        potentials = None
        value = None
        value_linear = None
        plan = None
        lazy_plan = None
        sparse_plan = None
        status = None
        log = None

        method = method.lower() if method is not None else ""

        if method == "1d":  # Wasserstein 1d (parallel on all dimensions)
            if metric == "sqeuclidean":
                p = 2
            elif metric in ["euclidean", "cityblock"]:
                p = 1
            else:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            value = wasserstein_1d(X_a, X_b, a, b, p=p)
            value_linear = value

        elif method == "sliced":  # Sliced Wasserstein distance
            if metric == "sqeuclidean":
                p = 2
            elif metric in ["euclidean", "cityblock"]:
                p = 1
            else:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            value, log = sliced_wasserstein_distance(
                X_a,
                X_b,
                a=a,
                b=b,
                p=p,
                n_projections=n_projections,
                projections=projections,
                seed=random_state,
                log=True,
            )
            value_linear = value

        elif method == "max_sliced":  # Max Sliced Wasserstein distance
            if metric == "sqeuclidean":
                p = 2
            elif metric in ["euclidean", "cityblock"]:
                p = 1
            else:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            value, log = max_sliced_wasserstein_distance(
                X_a,
                X_b,
                a=a,
                b=b,
                p=p,
                n_projections=n_projections,
                projections=projections,
                seed=random_state,
                log=True,
            )
            value_linear = value

        elif method == "bsp":  # BSP-OT solver
            if metric == "sqeuclidean":
                p = 2
            elif metric in ["euclidean", "cityblock"]:
                p = 1
            else:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if (X_a.shape[0] != X_b.shape[0]) or a is not None or b is not None:
                raise ValueError(
                    "BSP-OT solver requires the same number of samples in both distributions and uniform weights (provided as None)."
                )

            if random_state is None:
                random_state = 0

            n = X_a.shape[0]

            value, perm, perms = compute_bspot_bijection(
                X_a, X_b, p=p, seed=random_state, n_plans=n_projections
            )
            value_linear = value
            sparse_plan = nx.coo_matrix(
                nx.ones(n, type_as=X_a) / n,
                nx.arange(n),
                perm,
                shape=(n, n),
                type_as=X_a,
            )

            log = {
                "perm": perm,
                "perms": perms,
            }

        elif method == "gaussian":  # Gaussian Bures-Wasserstein
            if metric.lower() not in ["sqeuclidean"]:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if reg is None:
                reg = 1e-6

            if a is not None and len(a.shape) == 1:
                a = a.reshape(-1, 1)
            if b is not None and len(b.shape) == 1:
                b = b.reshape(-1, 1)

            value, log = empirical_bures_wasserstein_distance(
                X_a, X_b, reg=reg, ws=a, wt=b, log=True
            )
            value = value**2  # return the value (squared bures distance)
            value_linear = value  # return the value

        elif method == "gaussian_hd":  # Gaussian BW for high-dimensional data
            if metric.lower() not in ["sqeuclidean"]:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if reg is None:
                reg = 1e-5

            if a is not None and len(a.shape) == 1:
                a = a.reshape(-1, 1)
            if b is not None and len(b.shape) == 1:
                b = b.reshape(-1, 1)

            if rank > X_a.shape[1] or rank > X_b.shape[1]:
                warn(
                    "Rank is larger than the number of features. Using full rank for Gaussian Bures-Wasserstein distance."
                )
                rank = min(X_a.shape[1], X_b.shape[1])

            value, log = empirical_bures_wasserstein_distance_hd(
                X_a, X_b, d_intrinsic=rank, ws=a, wt=b, reg=reg, log=True
            )
            value = value**2  # return the value (squared bures distance)
            value_linear = value  # return the value

        elif method == "factored":  # Factored OT
            if metric.lower() not in ["sqeuclidean"]:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if max_iter is None:
                max_iter = 100
            if tol is None:
                tol = 1e-7
            if reg is None:
                reg = 0

            Q, R, X, log = factored_optimal_transport(
                X_a,
                X_b,
                reg=reg,
                r=rank,
                log=True,
                stopThr=tol,
                numItermax=max_iter,
                verbose=verbose,
            )
            log["X"] = X

            value_linear = log["costa"] + log["costb"]
            value = value_linear  # TODO add reg term
            lazy_plan = log["lazy_plan"]
            if not lazy0:  # store plan if not lazy
                plan = lazy_plan[:]

        elif method == "lowrank":
            if metric.lower() not in ["sqeuclidean"]:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if max_iter is None:
                max_iter = 2000
            if tol is None:
                tol = 1e-7
            if reg is None:
                reg = 0

            Q, R, g, log = lowrank_sinkhorn(
                X_a,
                X_b,
                rank=rank,
                reg=reg,
                a=a,
                b=b,
                numItermax=max_iter,
                stopThr=tol,
                log=True,
            )
            value = log["value"]
            value_linear = log["value_linear"]
            lazy_plan = log["lazy_plan"]
            if not lazy0:  # store plan if not lazy
                plan = lazy_plan[:]

        elif method == "nystroem":
            if metric.lower() not in ["sqeuclidean"]:
                raise (
                    NotImplementedError('Not implemented metric="{}"'.format(metric))
                )

            if max_iter is None:
                max_iter = 1000
            if tol is None:
                tol = 1e-7
            if reg is None:
                reg = 1.0

            value, log = empirical_sinkhorn_nystroem2(
                X_a,
                X_b,
                reg=reg,
                anchors=rank,
                a=a,
                b=b,
                numItermax=max_iter,
                verbose=verbose,
                stopThr=tol,
                random_state=random_state,
                log=True,
            )

            lazy_plan = log["lazy_plan"]
            if not lazy0:  # store plan if not lazy
                plan = lazy_plan[:]

        elif method.startswith("geomloss"):  # Geomloss solver for entropic OT
            split_method = method.split("_")
            if len(split_method) == 2:
                backend = split_method[1]
            else:
                if lazy0 is None:
                    backend = "auto"
                elif lazy0:
                    backend = "online"
                else:
                    backend = "tensorized"
            if lazy0 is None:
                warn(
                    f"geomloss backend is set to '{backend}' but is not yet supported by unified geomloss API yet."
                )

            if old_geomloss:  # old wrapper for old geomloss versions
                raise NotImplementedError(
                    "geomloss version >= 0.3.1 required for ot.solve_sample() geomloss backend."
                )

            else:  # new geomloss wrapper
                import geomloss.ot as got

                if max_iter is None:
                    max_iter = 1000

                res = got.solve_sample(
                    X_a,
                    X_b,
                    a=a,
                    b=b,
                    reg=reg,
                    cost=metric,
                    unbalanced=unbalanced,
                    unbalanced_type=unbalanced_type,
                    max_iter=max_iter,
                    tol=tol,
                )
                res.value_linear = None
                return res

        elif reg is None or reg == 0:  # exact OT
            if unbalanced is None:  # balanced EMD solver not available for lazy
                raise (
                    NotImplementedError(
                        "Exact OT solver with lazy=True not implemented"
                    )
                )

            else:
                raise (
                    NotImplementedError(
                        'Non regularized lazy solver with unbalanced_type="{}" not implemented'.format(
                            unbalanced_type
                        )
                    )
                )

        else:
            if unbalanced is None:
                if max_iter is None:
                    max_iter = 1000
                if tol is None:
                    tol = 1e-9
                if batch_size is None:
                    batch_size = 100

                value_linear, log = empirical_sinkhorn2(
                    X_a,
                    X_b,
                    reg,
                    a,
                    b,
                    metric=metric,
                    numIterMax=max_iter,
                    stopThr=tol,
                    isLazy=True,
                    batchSize=batch_size,
                    verbose=verbose,
                    log=True,
                )
                # compute potentials
                potentials = (log["u"], log["v"])
                lazy_plan = log["lazy_plan"]

            else:
                raise (
                    NotImplementedError(
                        'Not implemented unbalanced_type="{}" with regularization'.format(
                            unbalanced_type
                        )
                    )
                )

        res = OTResult(
            potentials=potentials,
            value=value,
            lazy_plan=lazy_plan,
            value_linear=value_linear,
            sparse_plan=sparse_plan,
            plan=plan,
            status=status,
            backend=nx,
            log=log,
        )
        return res
