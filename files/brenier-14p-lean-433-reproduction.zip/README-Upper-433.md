# Brenier replacement: checked all-compact-target upper bound

Lean 4.33.1 (compiler commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6), Mathlib 0df444a360eaa60ab8c11dca51a86af692955474.

**Entry point:** `BrenierReplacement.one_third_stability_for_all_compact_targets` in `ported/minty/ExactTerminal.lean`. The theorem assumes a compact convex source body with nonempty interior, and a nonempty compact target set. It proves the uniform 1/3 Hölder estimate for any probability measures on that target, and existence and uniqueness of their optimal transport graph plans. The normalization and notions of optimal maps, Wasserstein distance and L² map distance match the original formalization. In the manuscript dimension is fixed at d≥2; the upper bound here needs no dimension lower bound. There is no extra moment, optimal map, differentiability, site separation or optimizer premise.

The exact finite potential inequality `exact_finite_support_potential_bound` uses the coefficient 2R and allows endpoint collisions. `uniform_body_euclidean_moment` transports the specialized compact uniform trace inequality via volume-preserving Fin coordinates and shows actual strict cells and original tagged cells agree almost everywhere. `exact_actual_weighted_intercept_path` uses actual argmins, genuine argument continuity, the two envelope derivatives and the mixed rectangle. This is the alternative route, not a call to the original all-target proof. The new finite potential estimate is an input of the original generic `OAI.Problem358.one_third_stability_of_atomic_potential_estimate` to reuse interpolation and approximation as in the manuscript.

The terminal theorem exposes existence of C(K,Y); it does not claim the printed explicit C_* expression. This package does not replay the separate original, unchanged three-atom sharpness proof. The specialized Joint trace theorem does not certify the unused randomTrace and general truncation/weak-limit branch of the original larger theorem.

## Source provenance

- Original OAI sources: `openai/math` commit f5702854040e97fa7675c21ba37a9608f5f92dd3, repository path `lean/OAI/Analysis/Brenier/`. The package includes the 35-module closure unmodified and the original Apache-2.0 license; `replay_upstream.py` creates compatibility copies for the older pinned toolchain.
- Joint sources: `Joint_Brenier_Residual_Lean.zip`, SHA-256 191007e07968dbdb609b8deb920492cc152a4e6a7f53ad733933b4ff323067fa. `ported/minty` includes exact original definitions/required proof slices and compatibility adaptations; the compact trace retains true compact graph existence, a.e. differential PSD, Jacobian midpoint domination, and averaged diagram localization. No abstract midpoint or finite-sampling premise is substituted.
- Stock `ScalarL2Extract` contains the exact three real-square MemLp declarations from pinned Mathlib's L2Space (Rémy Degenne, Apache-2.0). It avoids loading unrelated L² inner-product-space functionality; original Jensen-square and measure algebra retained.

## Replay

Run `bash verify_brenier_14p_upper_433.sh`. The script expects sibling `chen-attainment-toolchain/{mathlib,lean-4.33.1-linux}` with the exact version and Mathlib pin. The Mathlib dependencies and an existing partial or full stock `.lake/build/lib/lean` cache should already be present. This package does not install toolchains or fetch external files. Missing narrowly selected stock compartments are compiled locally in bounded batches; private overlay only. The supplied log records the original offline stock process (one official pinned Rademacher object had been cached) and independent kernel replays of the six essential modules. Only `propext`, `Classical.choice` and `Quot.sound` are used.

The nested Joint source archive is deliberately not included; the relevant Lean source slices and archive fingerprint above are retained. The bundled Apache-2.0 license texts cover the upstream source attributed to their respective projects only.

**Update:** See README-Manuscript-Claims-433.md for separately verified exact printed constant and original sharpness in this expanded bundle.
