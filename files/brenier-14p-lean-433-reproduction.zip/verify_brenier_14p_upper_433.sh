#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
M=$(realpath ../chen-attainment-toolchain/mathlib)
J=$(realpath "$M/../lean-4.33.1-linux/bin")
export PATH="$J:$PATH"
export LEAN_PATH="$PWD/build/minty:$PWD/build/replacement:$PWD/build/upstream:$PWD/build/stock:$M/.lake/build/lib/lean:$(printf '%s:' "$M"/.lake/packages/*/.lake/build/lib/lean)"
lean --version | grep -F 'version 4.33.1'
[[ $(git -C "$M" rev-parse HEAD) == 0df444a360eaa60ab8c11dca51a86af692955474 ]]
# A normal full Mathlib build at the exact pin fills these stock modules already.
roots=(
  Mathlib.Analysis.Calculus.ParametricIntegral
  Mathlib.LinearAlgebra.AffineSpace.FiniteDimensional
  Mathlib.MeasureTheory.Function.SpecialFunctions.Inner
  Mathlib.Analysis.Convex.Measure Mathlib.MeasureTheory.Measure.Support
  Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
  Mathlib.Analysis.InnerProductSpace.Calculus Mathlib.Topology.Separation.Connected
  Mathlib.Analysis.Calculus.Rademacher Mathlib.MeasureTheory.Measure.Hausdorff
  Mathlib.MeasureTheory.Function.Jacobian Mathlib.Analysis.Convex.Deriv
  Mathlib.LinearAlgebra.Matrix.PosDef Mathlib.Analysis.Calculus.FDeriv.Symmetric
  Mathlib.Logic.Equiv.Fin.Rotate Mathlib.Analysis.Matrix.PosDef
  Mathlib.MeasureTheory.Measure.Prokhorov Mathlib.Analysis.Convex.Integral
  Mathlib.MeasureTheory.Function.LpSeminorm.Prod
  Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real
  Mathlib.MeasureTheory.Function.LpSeminorm.LpNorm
  Mathlib.Topology.ContinuousMap.Bounded.ArzelaAscoli
  Mathlib.Topology.MetricSpace.UniformConvergence
)
while read -r -a tranche; do
  python3 stock_overlay.py "${tranche[@]}"
done < <(python3 list_scoped_stock.py "${roots[@]}" | sed '/^$/d' | xargs -r -n 14)
mkdir -p build/minty build/replacement build/stock
lean -o build/replacement/BrenierReplacement.olean BrenierReplacement.lean
lean -o build/minty/CoordinateBridge.olean CoordinateBridge.lean
lean -o build/minty/CompactRestriction.olean CompactRestriction.lean
bash verify_rank_compact_coupling_433.sh ScalarL2Extract
python3 replay_upstream.py AtomicPaths
lean -o build/minty/UpstreamUniquenessBridge.olean UpstreamUniquenessBridge.lean
bash verify_rank_compact_coupling_433.sh \
  StaticRankConvex RankMinty RankMintyConvex RankMintyPSDLinear RankMintyDirections RankMintyPSDLimit \
  RankEndpointJacobianExtract StaticRankDet ResidualGeometry \
  CyclicPlans PredictiveRanks StaticRankPlans StaticRankCycOptimal StaticRankDual StaticRankGraph \
  RankPotential StaticRankBrenier StaticRankInverse StaticRankExistence StaticRankFinish \
  ResidualMidpointExtract ResidualCompact CompactCellPairs HarmonicCoefficientExtract \
  ResidualCompactCells ResidualCoupling ResidualEnergy ResidualFinite ResidualTraceOnly \
  ResidualDiagram ResidualDiagramCanonical LogConcaveMidpointExtract ResidualCompactTrace \
  ExactBodyMoment ExactInterception ExactFinitePotential ExactTerminal
for m in ExactTerminal ExactFinitePotential ExactInterception ExactBodyMoment ResidualCompactTrace OAI.Analysis.Brenier.AtomicPaths; do
  leanchecker -v "$m"
done
