import BrenierReplacement
import OAI.Analysis.Brenier.PrescribedCells

open MeasureTheory Filter Set
open scoped BigOperators RealInnerProductSpace Topology NNReal ENNReal

namespace BrenierReplacement

open OAI.Problem358

theorem uniform_bodyDual_normalized_minimizer_unique
    {d : ℕ} {I : Type*} [Fintype I] [Nonempty I] {K : Set (E d)}
    (hK : IsCompact K) (hconv : Convex ℝ K) (hne : (interior K).Nonempty)
    (y : I → E d) (hy : Function.Injective y) (m : I → ℝ)
    (hm : ∀ i, 0 < m i) (hsum : ∑ i, m i = 1)
    (c b : I → ℝ) (hc0 : ∑ i, m i * c i = 0) (hb0 : ∑ i, m i * b i = 0)
    (hcmin : ∀ a, bodyDual (uniformMeasure K) y m c ≤ bodyDual (uniformMeasure K) y m a)
    (hbmin : ∀ a, bodyDual (uniformMeasure K) y m b ≤ bodyDual (uniformMeasure K) y m a) :
    c = b := by
  have hvalue (a : I → ℝ) :
      bodyDual (uniformMeasure K) y m a =
        (∫ x, MaxPotential.potential y a x ∂uniformMeasure K) - ∑ i, m i * a i := by
    unfold bodyDual MaxPotential.potential
    congr 1
    apply integral_congr_ae
    filter_upwards with x
    simp only [real_inner_comm (y _) x]
    rfl
  refine MaxPotential.uniform_normalized_minimizer_unique hK hconv hne y hy m hm hsum c b hc0 hb0 ?_ ?_
  · intro a ha
    simpa only [hvalue, hc0, ha, sub_zero] using hcmin a
  · intro a ha
    simpa only [hvalue, hb0, ha, sub_zero] using hbmin a

#print axioms uniform_bodyDual_normalized_minimizer_unique


theorem tendsto_uniform_bodyDual_actual_optimizer
    {d : ℕ} {I T : Type*} [Fintype I] [Nonempty I] {K : Set (E d)}
    (hK : IsCompact K) (hconv : Convex ℝ K) (hne : (interior K).Nonempty)
    (R : ℝ≥0) (hR : ∀ x ∈ K, ‖x‖ ≤ R) (l : Filter T)
    (Y : T → I → E d) (M C : T → I → ℝ)
    (y : I → E d) (hy : Function.Injective y) (m c : I → ℝ)
    (hm : ∀ i, 0 < m i) (hsum : ∑ i, m i = 1)
    (hc0 : ∑ i, m i * c i = 0)
    (hcmin : ∀ a, bodyDual (uniformMeasure K) y m c ≤ bodyDual (uniformMeasure K) y m a)
    (hY : Tendsto Y l (𝓝 y)) (hM : Tendsto M l (𝓝 m))
    (hnorm : ∀ᶠ t in l, (∑ i, M t i)=1 ∧ (∑ i, M t i*C t i)=0)
    (hmin : ∀ᶠ t in l, ∀ a, bodyDual (uniformMeasure K) (Y t) (M t) (C t) ≤
      bodyDual (uniformMeasure K) (Y t) (M t) a) :
    Tendsto C l (𝓝 c) := by
  let _ : IsProbabilityMeasure ((volume K)⁻¹ • volume.restrict K) := UniformSource.probability hK hne
  have hvalue (a : I → ℝ) :
      bodyDual (uniformMeasure K) y m a =
        (∫ x, MaxPotential.potential y a x ∂uniformMeasure K) - ∑ i, m i * a i := by
    unfold bodyDual MaxPotential.potential
    congr 1
    apply integral_congr_ae
    filter_upwards with x
    simp only [real_inner_comm (y _) x]
    rfl
  apply tendsto_bodyDual_normalized_selection volume K hK (volume K)⁻¹ R hR
    l Y M C y m c hm hY hM hnorm hmin
  intro b hb hbm
  refine MaxPotential.uniform_normalized_minimizer_unique hK hconv hne y hy m hm hsum b c hb hc0 ?_ ?_
  · intro a ha
    have hh : bodyDual (uniformMeasure K) y m b ≤ bodyDual (uniformMeasure K) y m a := by
      simpa only [uniformMeasure, bodyDual, hb, ha, sub_zero] using hbm a ha
    simpa only [hvalue, hb, ha, sub_zero] using hh
  · intro a ha
    simpa only [hvalue, hc0, ha, sub_zero] using hcmin a

#print axioms OAI.Problem358.MaxPotential.uniform_normalized_minimizer_unique
#print axioms tendsto_uniform_bodyDual_actual_optimizer

end BrenierReplacement
