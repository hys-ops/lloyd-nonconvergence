import ExactBodyMoment
import UpstreamUniquenessBridge

open MeasureTheory Filter Set
open scoped BigOperators RealInnerProductSpace ENNReal NNReal Topology
open OAI.Problem358

namespace BrenierReplacement
noncomputable section

theorem exact_actual_weighted_intercept_path {d : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    [LinearOrder I] [MeasurableSpace I] [MeasurableSingletonClass I]
    (K : Set (E d)) (hK : IsCompact K) (hcv : Convex ℝ K) (hint : (interior K).Nonempty)
    (R : ℝ≥0) (hR : ∀ x ∈ K, ‖x‖ ≤ R)
    (y v : I → E d)
    (hinj : ∀ t ∈ Ioo (0 : ℝ) 1, Function.Injective (fun i => y i + t • v i))
    (m : I → ℝ) (hm : ∀ i, 0 < m i) (hmass : ∑ i, m i = 1) :
    ∃ c : ℝ → I → ℝ, (∀ t ∈ Ioo (0 : ℝ) 1, ∑ i, m i * c t i = 0) ∧
    (∀ t ∈ Ioo (0 : ℝ) 1, ∀ i,
      (uniformMeasure K).real (strictBodyCell (fun j => y j + t • v j) (c t) i) = m i) ∧
    (∀ s ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1,
      Real.sqrt (∑ i, m i * (c t i - c s i)^2) ≤ (R : ℝ) *
        Real.sqrt (∑ i, m i * ‖v i‖^2) * |t-s|) := by
  classical
  let ρ := uniformMeasure K
  let _ : IsProbabilityMeasure ρ := UniformSource.probability hK hint
  let q := (volume K)⁻¹
  have hp0 : volume K ≠ 0 := (Measure.measure_pos_of_nonempty_interior volume hint).ne'
  have hq : q ≠ ⊤ := ENNReal.inv_ne_top.mpr hp0
  let _ : IsProbabilityMeasure (q • volume.restrict K) := UniformSource.probability hK hint
  let Y (t : ℝ) (i : I) := y i + t • v i
  let Good (n : I → ℝ) := (∀ i, 0 < n i) ∧ ∑ i, n i = 1
  have hExist (t : ℝ) (n : I → ℝ) (hn : Good n) :
      ∃ c : I → ℝ, (∑ i,n i*c i)=0 ∧ ∀ a, bodyDual ρ (Y t) n c ≤ bodyDual ρ (Y t) n a :=
    body_finite_dual_normalized_argmin_exists volume K hK q R hR (Y t) n hn.1 hn.2
  let C (t : ℝ) (n : I → ℝ) : I → ℝ :=
    if h : Good n then Classical.choose (hExist t n h) else 0
  have hC (t : ℝ) (n : I → ℝ) (hn : Good n) :
      (∑ i,n i*C t n i)=0 ∧ ∀ a, bodyDual ρ (Y t) n (C t n) ≤ bodyDual ρ (Y t) n a := by
    simpa only [C, dif_pos hn] using Classical.choose_spec (hExist t n hn)
  have hY : Continuous Y := by unfold Y; fun_prop
  have ccont (l : Filter ℝ) (ts : ℝ → ℝ) (ns : ℝ → I → ℝ)
      (t : ℝ) (n : I → ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) (hn : Good n)
      (hts : Tendsto ts l (𝓝 t)) (hns : Tendsto ns l (𝓝 n))
      (hg : ∀ᶠ r in l, Good (ns r)) :
      Tendsto (fun r => C (ts r) (ns r)) l (𝓝 (C t n)) := by
    exact tendsto_uniform_bodyDual_actual_optimizer hK hcv hint R hR l (Y ∘ ts) ns
      (fun r => C (ts r) (ns r)) (Y t) (hinj t ht) n (C t n) hn.1 hn.2 (hC t n hn).1
      (hC t n hn).2 (hY.continuousAt.tendsto.comp hts) hns
      (hg.mono fun r hr => ⟨hr.2,(hC (ts r) (ns r) hr).1⟩)
      (hg.mono fun r hr => (hC (ts r) (ns r) hr).2)
  let F (t : ℝ) (n : I → ℝ) := bodyDual ρ (Y t) n (C t n)
  let B (t : ℝ) (n : I → ℝ) (i : I) :=
    ∫ x in strictBodyCell (Y t) (C t n) i, x ∂ρ
  have mDeriv (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) (h : I → ℝ) (hh : ∑ i,h i=0) :
      HasDerivAt (fun s : ℝ => F t (fun i => m i+s*h i)) (-(∑ i,h i*C t m i)) 0 := by
    let n (s : ℝ) (i : I) := m i+s*h i
    have hn0 : n 0 = m := by ext i; simp [n]
    have hnc : Continuous n := by unfold n; fun_prop
    have hGood : ∀ᶠ s : ℝ in 𝓝 0, Good (n s) := by
      have pos : ∀ᶠ s : ℝ in 𝓝 0, ∀ i, 0 < n s i := by
        apply Filter.eventually_all.mpr
        intro i
        exact continuousAt_const.eventually_lt ((continuous_apply i).comp hnc).continuousAt
          (by simpa [hn0] using hm i)
      filter_upwards [pos] with s hs
      exact ⟨hs,by simp [n, Finset.sum_add_distrib, ← Finset.mul_sum, hh, hmass]⟩
    have hc : ContinuousAt (fun s => C t (n s)) 0 := by
      simpa only [ContinuousAt, hn0] using ccont (𝓝 (0 : ℝ)) (fun _ => t) n t m ht
        ⟨hm,hmass⟩ tendsto_const_nhds (by simpa only [hn0] using (hnc.continuousAt (x := 0)).tendsto) hGood
    let A (k : I → ℝ) := ∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => inner ℝ (Y t i) x+k i) ∂ρ
    have hd := finite_mass_value_hasDerivAt A m h (fun s => C t (n s)) 0 hc
      (hGood.mono fun s hs => (hC t (n s) hs).2)
    change HasDerivAt (fun s : ℝ => A (C t (n s)) - ∑ i, (m i+s*h i) * C t (n s) i) _ 0
    simpa only [hn0] using hd
  have sDeriv (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) (n : I → ℝ) (hn : Good n) :
      HasDerivAt (fun u : ℝ => F u n) (∑ i, inner ℝ (v i) (B t n i)) t := by
    let c (s : ℝ) := C (t+s) n
    have ha : HasDerivAt (fun u : ℝ => u-t) 1 t := by
      simpa [id] using (hasDerivAt_id t).sub_const t
    have hc : ContinuousAt c 0 := by
      have con : Continuous (fun s : ℝ => t+s) := continuous_const.add continuous_id
      simpa [c, ContinuousAt] using
        ccont (𝓝 (0 : ℝ)) (fun s => t+s) (fun _ => n) t n ht hn
          (by simpa using (con.continuousAt (x := 0)).tendsto) tendsto_const_nhds (Filter.Eventually.of_forall fun _ => hn)
    have e (s : ℝ) : (fun i => Y t i+s • v i) = Y (t+s) := by
      ext i
      simp only [Y,add_smul,add_assoc]
    have opt : ∀ᶠ s : ℝ in 𝓝 0, ∀ a, bodyDual ρ (Y (t+s)) n (C (t+s) n) ≤ bodyDual ρ (Y (t+s)) n a :=
      Filter.Eventually.of_forall (fun s : ℝ => (hC (t+s) n hn).2)
    have localD := body_minimumDualValue_site_hasDerivAt volume K hK q hq R hR
      (Y t) v (hinj t ht) n c hc (by
        filter_upwards [opt] with s hs a
        change bodyDual ρ (fun i => Y t i+s • v i) n (c s) ≤ bodyDual ρ (fun i => Y t i+s • v i) n a
        rw [e s]
        exact hs a)
    have hcalc := localD.comp_of_eq t ha (sub_self t).symm
    have hei (i : I) : IntegrableOn (fun x : E d => x) (strictBodyCell (Y t) (C t n) i) ρ := by
      have hr : ρ.restrict K = ρ := Measure.restrict_eq_self_of_ae_mem
        (Measure.ae_smul_measure (ae_restrict_mem hK.measurableSet) q)
      have hel := continuous_id.continuousOn.integrableOn_compact (μ := ρ) hK
      rw [IntegrableOn,hr] at hel
      exact hel.integrableOn
    have hh (i : I) : (∫ x in strictBodyCell (Y t) (C t n) i, inner ℝ (v i) x ∂ρ) =
        inner ℝ (v i) (B t n i) := (innerSL ℝ (v i)).integral_comp_comm (hei i)
    simp only [add_zero, mul_one, c] at hcalc
    convert hcalc using 1 <;> try rfl
    · funext u
      have he : t + (u-t) = u := by ring
      change bodyDual ρ (Y u) n (C u n) = bodyDual ρ (fun i => Y t i + (u-t) • v i) n (C (t+(u-t)) n)
      rw [show (fun i => Y t i+(u-t) • v i) = Y u by simpa only [he] using e (u-t)]
      rw [he]
    · exact Finset.sum_congr rfl (fun i _ => (hh i).symm)
  have hM (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) (n : I → ℝ) (hn : Good n) :
      ∀ i, ρ.real (strictBodyCell (Y t) (C t n) i) = n i :=
    body_dual_argmin_prescribes_strictCell_mass volume K hK q hq R hR (Y t) (hinj t ht)
      n (C t n) (hC t n hn).2
  have lipOrdered (a b : ℝ) (ha : a ∈ Ioo (0 : ℝ) 1) (hb : b ∈ Ioo (0 : ℝ) 1) (hab : a ≤ b) :
      Real.sqrt (∑ i, m i * (C b m i-C a m i)^2) ≤
        (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * (b-a) := by
    have insideInterval : Icc a b ⊆ Ioo (0 : ℝ) 1 :=
      fun t ht => ⟨ha.1.trans_le ht.1,ht.2.trans_lt hb.2⟩
    apply weightedIntercept_path_bound F B a b R hab R.coe_nonneg m hm hmass v (fun t => C t m)
      (hC a m ⟨hm,hmass⟩).1 (hC b m ⟨hm,hmass⟩).1
    · intro t ht h hh
      have ht' : t ∈ Ioo (0 : ℝ) 1 := by
        rcases (show t=a ∨ t=b by simpa using ht) with eq|eq
        · exact eq ▸ ha
        · exact eq ▸ hb
      exact mDeriv t ht' h hh
    · exact fun t ht n hn hsum => sDeriv t (insideInterval ht) n ⟨hn,hsum⟩
    · intro t ht n hn hsum
      have h0 := hM t (insideInterval ht) m ⟨hm,hmass⟩
      have h1 := hM t (insideInterval ht) n ⟨hn,hsum⟩
      have H := uniform_body_euclidean_moment K hK hcv hint R hR
        (Y t) (hinj t (insideInterval ht)) (C t m) (C t n)
      change (∑ i, ‖B t n i - B t m i‖^2 / (ρ.real (strictBodyCell (Y t) (C t m) i) + ρ.real (strictBodyCell (Y t) (C t n) i))) ≤
        (R : ℝ)^2 * ∑ i, (ρ.real (strictBodyCell (Y t) (C t n) i) - ρ.real (strictBodyCell (Y t) (C t m) i))^2 / (ρ.real (strictBodyCell (Y t) (C t m) i) + ρ.real (strictBodyCell (Y t) (C t n) i)) at H
      simpa only [h0, h1] using H
  refine ⟨fun t => C t m, fun t _ => (hC t m ⟨hm,hmass⟩).1,
    fun t ht => hM t ht m ⟨hm,hmass⟩, ?_⟩
  intro s hs t ht
  rcases le_total s t with h|h
  · rw [abs_of_nonneg (sub_nonneg.mpr h)]
    exact lipOrdered s t hs ht h
  · rw [abs_of_nonpos (sub_nonpos.mpr h), neg_sub]
    have hsq (i : I) : (C t m i - C s m i)^2 = (C s m i - C t m i)^2 := by ring
    simp_rw [hsq]
    exact lipOrdered t s ht hs h

#print axioms exact_actual_weighted_intercept_path

end
end BrenierReplacement
