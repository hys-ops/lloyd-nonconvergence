import Mathlib.Analysis.Real.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
namespace Vortex
noncomputable section

def harmonicMass (a b : ℝ) := 2*a*b/(a+b)
theorem harmonic_nonneg {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) : 0 ≤ harmonicMass a b :=
  div_nonneg (by positivity) (add_nonneg ha hb)

theorem harmonic_le_sqrt {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) : harmonicMass a b ≤ Real.sqrt (a*b) := by
  by_cases s : 0 < a+b
  · apply (div_le_iff₀ s).mpr
    have h1 := Real.sq_sqrt (mul_nonneg ha hb)
    have ham : 2*Real.sqrt (a*b) ≤ a+b := by
      rw [Real.sqrt_mul ha]
      nlinarith only [sq_nonneg (Real.sqrt a-Real.sqrt b),Real.sq_sqrt ha,Real.sq_sqrt hb]
    nlinarith only [h1,mul_le_mul_of_nonneg_right ham (Real.sqrt_nonneg (a*b))]
  · have za : a=0 := by linarith
    simp [harmonicMass,za]

end
end Vortex
