import ResidualCompact
import CompactRestriction
open MeasureTheory Filter Set
open scoped ENNReal Topology
namespace Residual
open SequentialRanks
noncomputable section

def normalized {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsFiniteMeasure ρ]
    (A : Set X) (h : ρ A ≠ 0) : ProbabilityMeasure X :=
  ⟨(ρ A)⁻¹ • ρ.restrict A,⟨by rw [Measure.smul_apply,smul_eq_mul,Measure.restrict_apply_univ,
    ENNReal.inv_mul_cancel h (measure_ne_top _ _)]⟩⟩

theorem normalize_scale {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsFiniteMeasure ρ]
    (A : Set X) (h : ρ A ≠ 0) :
    ρ A • (normalized ρ A h : Measure X) = ρ.restrict A := by
  change ρ A • ((ρ A)⁻¹ • ρ.restrict A) = _
  rw [smul_smul,ENNReal.mul_inv_cancel h (measure_ne_top _ _),one_smul]

def cutDensity {X : Type*} [MeasurableSpace X] (ρ : Measure X) (w : X → ℝ) (A : Set X) (x : X) :=
  (ρ.real A)⁻¹ * A.indicator w x

theorem density_of_normalized {d : ℕ} (w : RankPoint d → ℝ) (A : Set (RankPoint d))
    (mA : MeasurableSet A) [IsFiniteMeasure (weighted volume w)] (h : weighted volume w A ≠ 0) :
    (normalized (weighted volume w) A h : Measure _) = weighted volume (cutDensity (weighted volume w) w A) := by
  classical
  let ρ := weighted volume w
  change (ρ A)⁻¹ • ρ.restrict A=_
  have ev : (fun x => ENNReal.ofReal (cutDensity ρ w A x)) =
      (ρ A)⁻¹ • (A.indicator (fun x => ENNReal.ofReal (w x))) := by
    funext x
    by_cases hx : x∈A
    · simp only [cutDensity,indicator_of_mem hx,Pi.smul_apply,smul_eq_mul,
        Measure.real,←ENNReal.toReal_inv, ENNReal.ofReal_mul ENNReal.toReal_nonneg]
      rw [ENNReal.ofReal_toReal (a := (ρ A)⁻¹) (ENNReal.inv_ne_top.mpr h)]
    · simp [cutDensity,hx]
  change _=volume.withDensity (fun x => ENNReal.ofReal (cutDensity ρ w A x))
  rw [ev,withDensity_smul' _ _ (ENNReal.inv_ne_top.mpr h),withDensity_indicator mA,← restrict_withDensity mA]
  rfl

theorem normalized_support {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsFiniteMeasure ρ]
    (A : Set X) (mA : MeasurableSet A) (h : ρ A ≠ 0) :
    ∀ᵐ x ∂(normalized ρ A h : Measure X), x ∈ A :=
  Measure.ae_smul_measure (ae_restrict_mem mA) _

private theorem bounded_cell_pair (w : RankPoint d → ℝ) (mw : Measurable w) (wn : ∀ x,0≤w x)
    (logmid : ∀ x y,Real.sqrt (w x)*Real.sqrt (w y)≤w (mid x y))
    [IsProbabilityMeasure (weighted volume w)] (K : Set (RankPoint d)) (hk : IsCompact K) [Nonempty K]
    (A B : Set (RankPoint d)) (mA : MeasurableSet A) (mB : MeasurableSet B)
    (subA : A ⊆ K) (subB : B ⊆ K) (ha : weighted volume w A ≠ 0) (hb : weighted volume w B ≠ 0) :
    let ρ := weighted volume w
    ∃ π : ProbabilityMeasure (RankPoint d × RankPoint d),
      π.map measurable_fst.aemeasurable = normalized ρ A ha ∧ π.map measurable_snd.aemeasurable = normalized ρ B hb ∧
      (π : Measure _).map midpoint ≤ ENNReal.ofReal (Real.sqrt (ρ.real A)⁻¹ * Real.sqrt (ρ.real B)⁻¹) • ρ := by
  let ρ := weighted volume w
  let p := cutDensity ρ w A
  let q := cutDensity ρ w B
  have hp := density_of_normalized w A mA ha
  have hq := density_of_normalized w B mB hb
  have ip : IsProbabilityMeasure (weighted volume p) := by
    change IsProbabilityMeasure (weighted volume (cutDensity ρ w A))
    rw [← hp]; exact (normalized ρ A ha).property
  have iq : IsProbabilityMeasure (weighted volume q) := by
    change IsProbabilityMeasure (weighted volume (cutDensity ρ w B))
    rw [← hq]; exact (normalized ρ B hb).property
  have pos (S : Set (RankPoint d)) (x : RankPoint d) : 0 ≤ cutDensity ρ w S x :=
    mul_nonneg (inv_nonneg.mpr measureReal_nonneg) (indicator_nonneg (fun x _ => wn x) _)
  have bd (S : Set (RankPoint d)) (x : RankPoint d) : cutDensity ρ w S x ≤ (ρ.real S)⁻¹*w x :=
    mul_le_mul_of_nonneg_left (by by_cases h : x∈S <;> simp [h,wn]) (inv_nonneg.mpr measureReal_nonneg)
  obtain ⟨π,f,g,b⟩ := compact_density_coupling K hk p q w _ _ (measurable_const.mul (mw.indicator mA))
    (pos A) (pos B) (bd A) (bd B) wn (inv_nonneg.mpr measureReal_nonneg) (inv_nonneg.mpr measureReal_nonneg) logmid
    (hp ▸ ((normalized_support ρ A mA ha).mono fun _ h => subA h))
    (hq ▸ ((normalized_support ρ B mB hb).mono fun _ h => subB h))
  exact ⟨π,Subtype.ext (f.trans hp.symm),Subtype.ext (g.trans hq.symm),b⟩

theorem positive_cell_pair_compact {d : ℕ} (w : RankPoint d → ℝ)
    (mw : Measurable w) (wn : ∀ x, 0 ≤ w x)
    (logmid : ∀ x y, Real.sqrt (w x) * Real.sqrt (w y) ≤ w (mid x y))
    [IsProbabilityMeasure (weighted volume w)] (K : Set (RankPoint d))
    (hk : IsCompact K) [Nonempty K] (hsup : ∀ᵐ x ∂weighted volume w, x ∈ K)
    (A B : Set (RankPoint d)) (mA : MeasurableSet A) (mB : MeasurableSet B)
    (ha : weighted volume w A ≠ 0) (hb : weighted volume w B ≠ 0) :
    let ρ := weighted volume w
    ∃ π : ProbabilityMeasure (RankPoint d × RankPoint d),
      π.map measurable_fst.aemeasurable = normalized ρ A ha ∧
      π.map measurable_snd.aemeasurable = normalized ρ B hb ∧
      (π : Measure _).map midpoint ≤
        ENNReal.ofReal (Real.sqrt (ρ.real A)⁻¹ * Real.sqrt (ρ.real B)⁻¹) • ρ := by
  let ρ := weighted volume w
  have cut (S : Set (RankPoint d)) : ρ.restrict (S ∩ K) = ρ.restrict S :=
    restrict_cell_inter_of_supported hsup
  have mass (S : Set (RankPoint d)) : ρ (S ∩ K) = ρ S := by
    simpa only [Measure.restrict_apply_univ] using congrArg (fun η : Measure _ => η univ) (cut S)
  have nac : ρ (A ∩ K) ≠ 0 := mass A ▸ ha
  have nbc : ρ (B ∩ K) ≠ 0 := mass B ▸ hb
  obtain ⟨π, hL, hR, hmid⟩ := bounded_cell_pair w mw wn logmid K hk (A ∩ K) (B ∩ K)
    (mA.inter hk.measurableSet) (mB.inter hk.measurableSet)
    inter_subset_right inter_subset_right nac nbc
  refine ⟨π, hL.trans ?_, hR.trans ?_, ?_⟩
  · apply Subtype.ext
    change (ρ (A ∩ K))⁻¹ • ρ.restrict (A ∩ K) = (ρ A)⁻¹ • ρ.restrict A
    rw [cut, mass]
  · apply Subtype.ext
    change (ρ (B ∩ K))⁻¹ • ρ.restrict (B ∩ K) = (ρ B)⁻¹ • ρ.restrict B
    rw [cut, mass]
  · simpa only [Measure.real, show weighted volume w (A ∩ K) = weighted volume w A from mass A,
      show weighted volume w (B ∩ K) = weighted volume w B from mass B] using hmid

end
end Residual
