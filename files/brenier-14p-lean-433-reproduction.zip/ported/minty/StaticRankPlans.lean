import CyclicPlans
import Mathlib.MeasureTheory.Measure.Prod

open MeasureTheory Filter Set
open scoped BigOperators Topology
namespace SequentialRanks
noncomputable section

/-- Existence of a Kantorovich minimizer on the compact spaces of the rank
note. Minimization is over every coupling with the prescribed marginals. -/
theorem compact_optimal_plan {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [CompactSpace Y] [CompactSpace K] [SecondCountableTopology Y] [SecondCountableTopology K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (P : ProbabilityMeasure Y) (Q : ProbabilityMeasure K) (c : Y × K → ℝ) (hc : Continuous c) :
    ∃ π : ProbabilityMeasure (Y × K), π.map (measurable_fst.aemeasurable) = P ∧ π.map (measurable_snd.aemeasurable) = Q ∧
      ∀ σ : ProbabilityMeasure (Y × K), σ.map (measurable_fst.aemeasurable) = P → σ.map (measurable_snd.aemeasurable) = Q →
        (∫ z, c z ∂(π : Measure _)) ≤ ∫ z, c z ∂(σ : Measure _) := by
  let A : Set (ProbabilityMeasure (Y × K)) := {π | π.map (measurable_fst.aemeasurable) = P ∧ π.map (measurable_snd.aemeasurable) = Q}
  have cl : IsClosed A :=
    (isClosed_eq (ProbabilityMeasure.continuous_map continuous_fst) continuous_const).inter
      (isClosed_eq (ProbabilityMeasure.continuous_map continuous_snd) continuous_const)
  let π : ProbabilityMeasure (Y × K) := ⟨(P : Measure Y).prod (Q : Measure K),inferInstance⟩
  have ff : π.map (measurable_fst.aemeasurable) = P := by
    apply ProbabilityMeasure.toMeasure_injective
    change (Measure.map Prod.fst ((P : Measure Y).prod (Q : Measure K))) = (P : Measure Y)
    simp
  have ss : π.map (measurable_snd.aemeasurable) = Q := by
    apply ProbabilityMeasure.toMeasure_injective
    change (Measure.map Prod.snd ((P : Measure Y).prod (Q : Measure K))) = (Q : Measure K)
    simp
  let g : C(Y × K,ℝ) := ⟨c,hc⟩
  have cont := ProbabilityMeasure.continuous_integral_continuousMap g
  obtain ⟨r,hr,hm⟩ := cl.isCompact.exists_isMinOn (show A.Nonempty from ⟨π,ff,ss⟩) cont.continuousOn
  exact ⟨r,hr.1,hr.2, fun σ h1 h2 => hm ⟨h1,h2⟩⟩

end
end SequentialRanks
