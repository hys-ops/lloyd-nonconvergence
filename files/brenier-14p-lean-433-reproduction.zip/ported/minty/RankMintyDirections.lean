import RankMinty
import Mathlib.MeasureTheory.Covering.DensityTheorem

open MeasureTheory Set Filter Metric
open scoped Topology Pointwise
namespace SequentialRanks
noncomputable section

/-- Simultaneously approximate each of finitely many tangent directions at one
Lebesgue density point of G, using the same sequence of positive radii. This
allows a finite cyclic inequality on actual graph points to pass to its differential. -/
theorem minty_density_directions {d : ℕ} (G : Set (RankPoint d)) :
    ∀ᵐ x ∂volume.restrict G, ∀ (m : ℕ) (v : Fin m → RankPoint d),
      ∃ (r : ℕ → ℝ) (u : ℕ → Fin m → RankPoint d), (∀ n, 0 < r n) ∧
        Tendsto r atTop (𝓝 0) ∧ (∀ i, Tendsto (fun n => u n i) atTop (𝓝 (v i))) ∧
        ∀ n i, x+r n • u n i ∈ G := by
  filter_upwards [Besicovitch.ae_tendsto_measure_inter_div volume G] with x hx
  intro m v
  let δ := fun n : ℕ => 1/((n:ℝ)+1)
  have pos (n) : 0 < δ n := by unfold δ; positivity
  have limit : Tendsto δ atTop (𝓝 0) := tendsto_one_div_add_atTop_nhds_zero_nat
  have step (n : ℕ) : ∃ r : ℝ, 0 < r ∧ r ≤ δ n ∧
      ∀ i, ∃ z : RankPoint d, dist z (v i) ≤ δ n ∧ x+r • z ∈ G := by
    have ex (i : Fin m) : ∀ᶠ r in 𝓝[>] (0:ℝ), (G ∩ ({x} + r • closedBall (v i) (δ n))).Nonempty :=
      Measure.eventually_nonempty_inter_smul_of_density_one volume G x hx _ measurableSet_closedBall
        (measure_closedBall_pos volume (v i) (pos n)).ne'
    have lt : ∀ᶠ r in 𝓝[>] (0:ℝ), r < δ n := mem_nhdsWithin_of_mem_nhds (gt_mem_nhds (pos n))
    obtain ⟨r,hr,hr',h⟩ := ((show ∀ᶠ r in 𝓝[>] (0:ℝ), 0 < r from self_mem_nhdsWithin).and
      (lt.and (Filter.eventually_all.mpr ex))).exists
    refine ⟨r,hr,hr'.le,fun i => ?_⟩
    obtain ⟨y,yg,hy⟩ := h i
    obtain ⟨a,ha,b,hb,he⟩ := hy
    obtain ⟨z,hz,rfl⟩ := hb
    obtain rfl : a = x := ha
    change a+r • z = y at he
    exact ⟨z,hz,by rw [he]; exact yg⟩
  choose r hr hδ rest using step
  choose u hu gu using rest
  refine ⟨r,u,hr,squeeze_zero (fun n => (hr n).le) hδ limit,?_,gu⟩
  intro i
  exact tendsto_iff_dist_tendsto_zero.mpr (squeeze_zero (fun _ => dist_nonneg) (fun n => hu n i) limit)

/-- The differential governs secants whose directions vary with the scale. -/
theorem minty_derivative_along {d : ℕ} {G : Set (RankPoint d)}
    {U : RankPoint d → RankPoint d} {A : RankDifferential d} {x v : RankPoint d}
    (der : HasFDerivWithinAt U A G x) {r : ℕ → ℝ} {u : ℕ → RankPoint d}
    (pos : ∀ n, 0 < r n) (rz : Tendsto r atTop (𝓝 0)) (uv : Tendsto u atTop (𝓝 v))
    (mem : ∀ n, x+r n • u n ∈ G) :
    Tendsto (fun n => (r n)⁻¹ • (U (x+r n • u n)-U x)) atTop (𝓝 (A v)) := by
  apply der.lim (d := fun n => r n • u n) (c := fun n => (r n)⁻¹)
    (by simpa using rz.smul uv) (.of_forall mem)
  simpa [smul_smul,fun n => (pos n).ne'] using uv

end
end SequentialRanks
