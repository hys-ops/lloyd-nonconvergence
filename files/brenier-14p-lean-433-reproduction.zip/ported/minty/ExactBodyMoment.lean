import ResidualCompactTrace
import CoordinateBridge
import BrenierReplacement
import OAI.Analysis.Brenier.Uniform

open MeasureTheory Set Filter
open scoped BigOperators RealInnerProductSpace ENNReal NNReal
open Residual SequentialRanks OAI.Problem358

namespace BrenierReplacement
noncomputable section

def strictBodyCell {d : ℕ} {I : Type*} (y : I → E d) (c : I → ℝ) (i : I) : Set (E d) :=
  {x | ∀ j, j ≠ i → inner ℝ (y j) x + c j < inner ℝ (y i) x + c i}

theorem uniform_body_euclidean_moment {d : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    [LinearOrder I] [MeasurableSpace I] [MeasurableSingletonClass I]
    (K : Set (E d)) (hK : IsCompact K) (hcv : Convex ℝ K) (hint : (interior K).Nonempty)
    (R : ℝ≥0) (hR : ∀ x ∈ K, ‖x‖ ≤ R)
    (y : I → E d) (hy : Function.Injective y) (a b : I → ℝ) :
    let ρ := uniformMeasure K
    let U := strictBodyCell y a
    let V := strictBodyCell y b
    let A := fun i => ρ.real (U i)
    let B := fun i => ρ.real (V i)
    (∑ i, ‖(∫ x in V i, x ∂ρ) - (∫ x in U i, x ∂ρ)‖ ^ 2 / (A i + B i)) ≤
      (R : ℝ)^2 * ∑ i, (B i - A i)^2 / (A i + B i) := by
  classical
  dsimp only
  let ρ := uniformMeasure K
  let e := PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin d => ℝ)
  let J := e '' K
  let σ := (volume J)⁻¹ • volume.restrict J
  let v (i : I) : RankPoint d := e (y i)
  let tag (c : I → ℝ) := powerTag v c
  let T (c : I → ℝ) (i : I) := tag c ⁻¹' {i}
  have hm : MeasurePreserving e ρ σ := normalized_volume_ofLp d K hK.measurableSet
  have emb := e.toHomeomorph.toMeasurableEquiv.measurableEmbedding
  have hJ : IsCompact J := hK.image e.continuous
  have hjc : Convex ℝ J := hcv.linear_image e.toLinearMap
  have hji : (interior J).Nonempty := by
    change (interior (e.toHomeomorph '' K)).Nonempty
    rw [← e.toHomeomorph.image_interior]
    exact hint.image _
  have hrad (z) (hz : z ∈ J) : ∑ r, z r ^ 2 ≤ (R : ℝ)^2 := by
    rcases hz with ⟨x,hx,rfl⟩
    have hh := pow_le_pow_left₀ (norm_nonneg x) (hR x hx) 2
    rw [PiLp.norm_sq_eq_of_L2] at hh
    change (∑ r, x r ^ 2) ≤ (R : ℝ)^2
    simpa only [Real.norm_eq_abs, sq_abs] using hh
  have hs (c : I → ℝ) (i : I) (x : E d) :
      powerScore v c i (e x) = inner ℝ (y i) x + c i := by
    unfold powerScore rankCovector
    rw [PiLp.inner_apply]
    simp only [sum_apply, smul_apply,
      ContinuousLinearMap.proj_apply, smul_eq_mul, RCLike.inner_apply, conj_trivial]
    congr 1
    apply Finset.sum_congr rfl
    intro r _
    change (y i r) * x r = _
    ring
  have hae (c : I → ℝ) (i : I) :
      (e ⁻¹' T c i : Set (E d)) =ᵐ[ρ] strictBodyCell y c i := by
    filter_upwards [ae_strict_affineWinner_restrict_smul volume K (volume K)⁻¹ y hy c]
      with x hx
    obtain ⟨k,hk⟩ := hx
    have htag : tag c (e x) = k := by
      by_contra hne
      have w := powerTag_wins v c (e x) (k)
      exact (not_lt_of_ge (by simpa only [tag, hs c] using w)) (hk _ hne)
    apply propext
    change tag c (e x) = i ↔ x ∈ strictBodyCell y c i
    rw [htag]
    constructor
    · rintro rfl
      exact hk
    · intro hi
      by_contra hne
      exact (not_lt_of_ge (hk i (Ne.symm hne)).le) (hi k hne)
  have hmass (c : I → ℝ) (i : I) :
      mass σ (tag c) i = ρ.real (strictBodyCell y c i) := by
    change (σ (T c i)).toReal = (ρ (strictBodyCell y c i)).toReal
    rw [← hm.measure_preimage ((measurable_powerTag v c) (measurableSet_singleton i)).nullMeasurableSet,
      measure_congr (hae c i)]
  have hρp : IsProbabilityMeasure ρ := UniformSource.probability hK hint
  have hρB : ρ.restrict K = ρ := Measure.restrict_eq_self_of_ae_mem
    (Measure.ae_smul_measure (ae_restrict_mem hK.measurableSet) (volume K)⁻¹)
  have hInt : Integrable (fun x : E d => x) ρ := by
    have h := continuous_id.continuousOn.integrableOn_compact (μ := ρ) hK
    rwa [IntegrableOn, hρB] at h
  have hmoment (c : I → ℝ) (i : I) (r : Fin d) :
      (∫ x in T c i, x r ∂σ) = (∫ x in strictBodyCell y c i, x ∂ρ) r := by
    rw [← (hm.restrict_preimage_emb emb (T c i)).integral_comp emb (fun z => z r),
      Measure.restrict_congr_set (hae c i)]
    exact (PiLp.proj (𝕜 := ℝ) 2 (fun _ : Fin d => ℝ) r).integral_comp_comm hInt.integrableOn
  have htrace := uniform_compact_body_moment_trace J hJ hjc hji R hrad v
    (e.injective.comp hy) b a
  change (errorMatrix σ (tag b) (tag a) (fun i x => x i)).trace ≤
    (R : ℝ)^2 * delta (mass σ (tag b)) (mass σ (tag a)) at htrace
  unfold errorMatrix Residual.change delta at htrace
  simp_rw [show ∀ c i r, (∫ x in tag c ⁻¹' {i}, x r ∂σ) =
    (∫ x in strictBodyCell y c i, x ∂ρ) r from hmoment, hmass] at htrace
  rw [coordinate_cellMoment_trace] at htrace
  simpa only [add_comm] using htrace

#print axioms uniform_body_euclidean_moment

end
end BrenierReplacement
