import RankEndpointJacobianExtract
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

def normSq {d : ℕ} (u : Fin d → ℝ) := ∑ i, (u i)^2
def diff {d : ℕ} (u v : Fin d → ℝ) (i : Fin d) := u i-v i
def squareCost {d : ℕ} {A B : Set (Fin d → ℝ)} (z : A × B) : ℝ :=
  normSq (diff z.1.1 z.2.1)

end
end SequentialRanks
