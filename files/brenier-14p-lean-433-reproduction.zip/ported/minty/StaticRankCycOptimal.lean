import StaticRankPlans
import Mathlib.MeasureTheory.Constructions.Pi

open MeasureTheory Filter Set
open scoped BigOperators Topology ENNReal
namespace SequentialRanks
noncomputable section

private theorem pi_support {Z : Type*} [MetricSpace Z] [MeasurableSpace Z] [BorelSpace Z]
    (π : ProbabilityMeasure Z) {n : ℕ} {z : Fin n → Z} (h : ∀ i, z i ∈ (π : Measure Z).support) :
    z ∈ (Measure.pi fun _ : Fin n => (π : Measure Z)).support := by
  apply (Measure.mem_support_iff_forall _).mpr
  intro s hs
  obtain ⟨r,hr,sub⟩ := Metric.mem_nhds_iff.mp hs
  apply lt_of_lt_of_le _ (measure_mono sub)
  rw [Measure.pi_ball _ _ hr]
  exact pos_iff_ne_zero.mpr (Finset.prod_ne_zero_iff.mpr fun i _ =>
    ((Measure.mem_support_iff_forall _).mp (h i) _ (Metric.ball_mem_nhds _ hr)).ne')

/-- Conditional on a measurable improvement event, a coordinate permutation
can reassign the destinations of n draws without changing their sum of laws. -/
private theorem reassign_sum {Z K : Type*} [MeasurableSpace Z] [MeasurableSpace K]
    {n : ℕ} (μ : Measure Z) (F : Fin n → Z → K) (mF : ∀ i, Measurable (F i))
    (σ : Equiv.Perm (Fin n)) (s : Set Z) (hs : MeasurableSet s) [DecidablePred (· ∈ s)] :
    (∑ i, μ.map (s.piecewise (F (σ i)) (F i))) = ∑ i, μ.map (F i) := by
  classical
  have split (f g : Z → K) (hf : Measurable f) (hg : Measurable g) :
      μ.map (s.piecewise f g) = (μ.restrict s).map f + (μ.restrict sᶜ).map g := by
    ext b mb
    rw [Measure.map_apply (hf.piecewise hs hg) mb,Measure.add_apply,Measure.map_apply hf mb,
      Measure.map_apply hg mb,Measure.restrict_apply (hf mb),Measure.restrict_apply (hg mb)]
    have eq : (s.piecewise f g) ⁻¹' b = (f ⁻¹' b ∩ s) ∪ (g ⁻¹' b ∩ sᶜ) := by
      ext x; by_cases h : x ∈ s <;> simp [piecewise,h]
    rw [eq,measure_union _ ((hg mb).inter hs.compl)]
    exact disjoint_left.mpr fun _ h hh => hh.2 h.2
  simp_rw [split _ _ (mF _) (mF _)]
  rw [Finset.sum_add_distrib,Equiv.sum_comp σ (fun i => (μ.restrict s).map (F i)),← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simpa using (split (F i) (F i) (mF i) (mF i)).symm

private theorem average_marginal {X Z D : Type*} [MeasurableSpace X] [MeasurableSpace Z]
    [MeasurableSpace D] {n : ℕ} (hn : n ≠ 0) (μ : Measure X) (π : Measure Z)
    (f e : Fin n → X → Z) (mf : ∀ i, Measurable (f i)) (me : ∀ i, Measurable (e i))
    (em : ∀ i, μ.map (e i) = π) (l : Z → D) (ml : Measurable l)
    (same : (∑ i, μ.map (l ∘ f i)) = ∑ i, μ.map (l ∘ e i)) :
    ((n:ℝ≥0∞)⁻¹ • ∑ i, μ.map (f i)).map l = π.map l := by
  have norm_factor : (n:ℝ≥0∞)⁻¹*(n:ℝ≥0∞)=1 := ENNReal.inv_mul_cancel (by exact_mod_cast hn) (by simp)
  rw [Measure.map_smul _ _ _,Measure.map_finset_sum' ml.aemeasurable]
  simp_rw [Measure.map_map ml (mf _)]
  rw [same]
  have (i : Fin n) : μ.map (l ∘ e i) = π.map l := by rw [← Measure.map_map ml (me i),em]
  simp_rw [this]
  rw [Finset.sum_const,Finset.card_univ,Fintype.card_fin,← Nat.cast_smul_eq_nsmul ℝ≥0∞,smul_smul,
    norm_factor,one_smul]

/-- Every compact Kantorovich optimizer has cyclically monotone support.
If a permutation improves a sampled tuple, apply it to that tuple only;
averaging all n resulting edges gives another coupling. -/
theorem optimal_plan_is_cyclic {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [CompactSpace Y] [CompactSpace K] [SecondCountableTopology Y] [SecondCountableTopology K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) (π : ProbabilityMeasure (Y × K))
    (opt : ∀ γ : ProbabilityMeasure (Y × K), γ.map (measurable_fst.aemeasurable) = π.map (measurable_fst.aemeasurable) →
      γ.map (measurable_snd.aemeasurable) = π.map (measurable_snd.aemeasurable) →
      (∫ z, c z ∂(π : Measure _)) ≤ ∫ z, c z ∂(γ : Measure _)) : cyclicSupport c π := by
  classical
  intro n σ z hz
  by_cases hn : n = 0
  · subst n; simp
  let μ := Measure.pi fun _ : Fin n => (π : Measure (Y × K))
  let e (i : Fin n) (x : Fin n → (Y × K)) := x i
  let b (i : Fin n) (x : Fin n → (Y × K)) : (Y × K) := ((x i).1,(x (σ i)).2)
  let r (x : Fin n → (Y × K)) := ∑ i, c (e i x)
  let v (x : Fin n → (Y × K)) := ∑ i, c (b i x)
  let s : Set (Fin n → (Y × K)) := {x | v x < r x}
  have cr : Continuous r := by unfold r e; fun_prop
  have cv : Continuous v := by unfold v b; fun_prop
  have so : IsOpen s := isOpen_lt cv cr
  let f (i : Fin n) := s.piecewise (b i) (e i)
  have m (i : Fin n) : Measurable (f i) := by unfold f b e; fun_prop (disch := exact so.measurableSet)
  let α : ℝ≥0∞ := (n : ℝ≥0∞)⁻¹
  let γ : Measure (Y × K) := α • ∑ i, μ.map (f i)
  have evalmap (i : Fin n) : μ.map (e i) = (π : Measure (Y × K)) := (measurePreserving_eval _ i).map_eq
  have meval (i : Fin n) : Measurable (e i) := measurable_pi_apply i
  have ff := average_marginal hn μ (π : Measure _) f e m meval evalmap (Prod.fst : Y × K → Y) measurable_fst (by
    apply Finset.sum_congr rfl
    intro i _
    congr 1; funext x; by_cases h : x ∈ s <;> simp [f,b,e,h])
  have sec (i : Fin n) : Prod.snd ∘ f i = s.piecewise (fun x => (x (σ i)).2) (fun x => (x i).2) := by
    funext x; by_cases h : x ∈ s <;> simp [f,b,e,h]
  have ss := average_marginal hn μ (π : Measure _) f e m meval evalmap (Prod.snd : Y × K → K) measurable_snd (by
    simp_rw [sec]
    exact reassign_sum μ (fun i x => (x i).2) (fun i => measurable_snd.comp (measurable_pi_apply i))
      σ s so.measurableSet)
  have pg : IsProbabilityMeasure γ := by
    constructor
    change γ univ = 1
    calc γ univ = (γ.map Prod.fst) (univ : Set Y) := by rw [Measure.map_apply measurable_fst MeasurableSet.univ]; rfl
         _ = 1 := by rw [show γ.map (Prod.fst : Y × K → Y) = (π : Measure (Y × K)).map (Prod.fst : Y × K → Y) from ff,
                            Measure.map_apply measurable_fst MeasurableSet.univ]; simp
  let γ' : ProbabilityMeasure (Y × K) := ⟨γ,pg⟩
  have least := opt γ' (ProbabilityMeasure.toMeasure_injective ff) (ProbabilityMeasure.toMeasure_injective ss)
  let t (x : Fin n → (Y × K)) := ∑ i, c (f i x)
  have cb : ∃ C : ℝ, ∀ z, ‖c z‖ ≤ C := by
    let g : C(Y × K,ℝ) := ⟨c,hc⟩
    exact ⟨‖g‖,g.norm_coe_le_norm⟩
  obtain ⟨C,c_bd⟩ := cb
  have ic {g : (Fin n → Y × K) → (Y × K)}
      (mg : Measurable g) : Integrable (fun x => c (g x)) μ :=
    (integrable_const C).mono' (hc.measurable.comp mg).aestronglyMeasurable (.of_forall fun _ => c_bd _)
  have aint (i : Fin n) : Integrable c (μ.map (f i)) :=
    (integrable_map_measure hc.aestronglyMeasurable (m i).aemeasurable).mpr (ic (m i))
  have it : Integrable t μ := integrable_finsetSum _ fun i _ => ic (m i)
  have ir : Integrable r μ := integrable_finsetSum _ fun i _ => ic (measurable_pi_apply i)
  have rt : ∀ x, t x = min (r x) (v x) := by
    intro x
    by_cases h : x ∈ s
    · simp [t,f,h,v,min_eq_right_of_lt (show v x < r x from h)]
    · simp [t,f,h,r,min_eq_left (show r x ≤ v x from le_of_not_gt h)]
  have cost : (∫ z, c z ∂γ) = (n:ℝ)⁻¹ * ∫ x, t x ∂μ := by
    rw [show γ = α • ∑ i, μ.map (f i) from rfl,integral_smul_measure,
      integral_finsetSum_measure (fun i _ => aint i)]
    simp_rw [integral_map (m _).aemeasurable hc.aestronglyMeasurable]
    rw [show (∫ x, t x ∂μ) = ∑ i, ∫ x, c (f i x) ∂μ from integral_finsetSum _ (fun i _ => ic (m i))]
    simp [α]
  have old : (∫ x, r x ∂μ) = (n:ℝ)*(∫ z, c z ∂(π : Measure (Y × K))) := by
    have evint (i : Fin n) : (∫ x, c (e i x) ∂μ) = ∫ z, c z ∂(π : Measure (Y × K)) := by
      rw [← integral_map (measurable_pi_apply i).aemeasurable hc.aestronglyMeasurable,
        show (μ.map fun x => x i) = _ from evalmap i]
    calc _ = ∑ i, ∫ x, c (e i x) ∂μ := integral_finsetSum _ (fun i _ => ic (meval i))
         _ = ∑ _i : Fin n, ∫ z, c z ∂(π : Measure (Y × K)) := Finset.sum_congr rfl (fun i _ => evint i)
         _ = _ := by simp
  change _ ≤ ∫ z, c z ∂γ at least
  rw [cost] at least
  have npos : 0 < (n:ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
  have ht : (∫ x, r x ∂μ) ≤ ∫ x, t x ∂μ := by
    rw [old]; field_simp at least; linarith
  have eq0 : (∫ x, r x-t x ∂μ) = 0 := by
    rw [integral_sub ir it]; apply le_antisymm (sub_nonpos.mpr ht)
    exact sub_nonneg.mpr (integral_mono it ir fun x => (rt x) ▸ min_le_left ..)
  have ae0 := (integral_eq_zero_iff_of_nonneg (fun x => sub_nonneg.mpr ((rt x) ▸ min_le_left ..))
    (ir.sub it)).mp eq0
  by_contra! hh
  have ins : z ∈ s := hh
  have pos := (Measure.mem_support_iff_forall _).mp (pi_support π hz) s (so.mem_nhds ins)
  have null : μ s = 0 := by
    apply measure_mono_null _ (ae_iff.mp ae0)
    intro x hx eq
    change r x-t x=0 at eq
    rw [rt x,min_eq_right_of_lt (show v x < r x from hx)] at eq
    exact (show v x < r x from hx).ne (sub_eq_zero.mp eq).symm
  exact pos.ne' null

/-- Existence of a certified cyclic coupling with the prescribed marginals. -/
theorem compact_cyclic_optimal_plan {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [CompactSpace Y] [CompactSpace K] [SecondCountableTopology Y] [SecondCountableTopology K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (P : ProbabilityMeasure Y) (Q : ProbabilityMeasure K) (c : Y × K → ℝ) (hc : Continuous c) :
    ∃ π : ProbabilityMeasure (Y × K), certifiedPlan c P Q π ∧
      ∀ σ : ProbabilityMeasure (Y × K), σ.map (measurable_fst.aemeasurable) = P → σ.map (measurable_snd.aemeasurable) = Q →
        (∫ z, c z ∂(π : Measure _)) ≤ ∫ z, c z ∂(σ : Measure _) := by
  obtain ⟨π,hP,hQ,minimal⟩ := compact_optimal_plan P Q c hc
  exact ⟨π,⟨hP,hQ, optimal_plan_is_cyclic c hc π (fun γ h1 h2 => minimal γ (h1.trans hP) (h2.trans hQ))⟩,minimal⟩

end
end SequentialRanks
