import RankMinty
import Mathlib.Topology.Maps.Proper.Basic

open MeasureTheory Set Filter Function
open scoped Topology BigOperators ENNReal
namespace SequentialRanks
noncomputable section

private theorem cov_eval {d : ℕ} (v y : RankPoint d) :
    rankCovector v y = ∑ i,v i*y i := by
  simp [rankCovector]

private theorem continuous_of_isClosed_graph_433 {X Y : Type*}
    [TopologicalSpace X] [TopologicalSpace Y] [CompactSpace Y]
    {f : X → Y} (hf : IsClosed f.graph) : Continuous f := by
  apply continuous_iff_isClosed.mpr
  intro S hS
  have he : Prod.fst '' (f.graph ∩ Prod.snd ⁻¹' S) = f ⁻¹' S := by
    ext x
    constructor
    · rintro ⟨⟨y,z⟩, ⟨hy,hz⟩, rfl⟩
      exact (show f y = z from Function.mem_graph.mp hy) ▸ hz
    · intro hx
      exact ⟨(x,f x), ⟨Function.mem_graph.mpr rfl,hx⟩,rfl⟩
  rw [← he]
  exact isClosedMap_fst_of_compactSpace _ (hf.inter (hS.preimage continuous_snd))

/-- Continuity on the differentiability locus follows from the closed graph of
supporting covectors and uniqueness at a differentiability point. -/
theorem gradient_continuous_on_supporting {d : ℕ} (φ : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) (G K : Set (RankPoint d)) (compact : IsCompact K)
    (rangeU : MapsTo U G K)
    (grad : ∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x)
    (support : ∀ x ∈ G, ∀ y, rankCovector (U x) (y-x) ≤ φ y-φ x) :
    ContinuousOn U G := by
  let f : G → K := fun x => ⟨U x, rangeU x.2⟩
  let _ : CompactSpace K := isCompact_iff_compactSpace.mp compact
  have cφ : Continuous (fun x : G => φ x) := continuousOn_iff_continuous_domRestrict.mp
    (fun x hx => (grad x hx).continuousAt.continuousWithinAt)
  have cg : f.graph = ⋂ y : RankPoint d,
      {p : G × K | rankCovector p.2.1 (y-p.1.1) ≤ φ y-φ p.1.1} := by
    ext p
    rw [mem_iInter]
    constructor
    · intro hp y
      have e : U p.1 = p.2 := congrArg Subtype.val
        (show f p.1=p.2 from Function.mem_graph.mp hp)
      change rankCovector p.2.1 (y-p.1.1) ≤ _
      rw [←e]
      exact support p.1 p.1.2 y
    · intro hp
      have mn : IsLocalMin (fun z => φ z-rankCovector p.2.1 z) p.1.1 := by
        apply Filter.Eventually.of_forall
        intro y
        have h := hp y
        change rankCovector p.2.1 (y-p.1.1) ≤ φ y-φ p.1.1 at h
        rw [map_sub] at h
        change φ p.1.1 - _ ≤ φ y - _
        linarith
      have eqcov := sub_eq_zero.mp (mn.hasFDerivAt_eq_zero
        ((grad p.1 p.1.2).sub (rankCovector p.2.1).hasFDerivAt))
      apply Function.mem_graph.mpr
      apply Subtype.ext
      exact rank_covector_injective eqcov
  have ct : Continuous f := continuous_of_isClosed_graph_433 (by
    rw [cg]
    apply isClosed_iInter
    intro y
    apply isClosed_le
    · simp_rw [cov_eval]
      apply continuous_finsetSum
      intro i _
      exact ((continuous_apply i).comp (continuous_subtype_val.comp continuous_snd)).mul
        (continuous_const.sub ((continuous_apply i).comp (continuous_subtype_val.comp continuous_fst)))
    · exact continuous_const.sub (cφ.comp continuous_fst))
  exact continuousOn_iff_continuous_domRestrict.mpr (continuous_subtype_val.comp ct)

theorem rank_monotone_of_supporting {d : ℕ} (φ : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) (G : Set (RankPoint d))
    (hf : ∀ x ∈ G, ∀ y, rankCovector (U x) (y-x) ≤ φ y-φ x) : RankMonotoneOn U G := by
  intro x hx y hy
  have l := hf x hx y
  have r := hf y hy x
  rw [cov_eval] at l r
  have eqn : (∑ i,(x i-y i)*(U x i-U y i)) =
      -(∑ i,U x i*(y-x) i) - ∑ i,U y i*(x-y) i := by
    rw [←Finset.sum_neg_distrib,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    simp only [Pi.sub_apply]
    ring
  rw [eqn]
  linarith

/-- For a bounded convex-gradient graph with its supporting inequalities, remove one Borel
Lebesgue-null set. At all remaining points U has a derivative within G, hence within *any*
smaller subset containing the point. This provides the differentiability input to area change. -/
theorem gradient_regular_of_supporting {d : ℕ} (φ : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) (G K : Set (RankPoint d)) (compact : IsCompact K)
    (rangeU : MapsTo U G K)
    (grad : ∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x)
    (support : ∀ x ∈ G, ∀ y, rankCovector (U x) (y-x) ≤ φ y-φ x) :
    ∃ N : Set (RankPoint d), MeasurableSet N ∧ volume N = 0 ∧
      ∀ x ∈ G, x ∉ N → HasFDerivWithinAt U (fderivWithin ℝ U G x) G x := by
  obtain ⟨N,m,h,der⟩ := minty_regular_on U G (rank_monotone_of_supporting φ U G support)
    (gradient_continuous_on_supporting φ U G K compact rangeU grad support)
  exact ⟨N,m,h,fun x hx xn => (der x hx xn).hasFDerivWithinAt⟩

/-- The nonsmooth differentiability step from bounded range and the actual gradients
of a convex potential. It introduces no second-order regularity hypothesis. -/
theorem rank_gradient_regular {d : ℕ} (φ : RankPoint d → ℝ) (U : RankPoint d → RankPoint d)
    (G K : Set (RankPoint d)) (compact : IsCompact K) (rangeU : MapsTo U G K)
    (conv : ConvexOn ℝ univ φ) (grad : ∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x) :
    ∃ N : Set (RankPoint d), MeasurableSet N ∧ volume N = 0 ∧
      ∀ x ∈ G, x ∉ N → HasFDerivWithinAt U (fderivWithin ℝ U G x) G x :=
  gradient_regular_of_supporting φ U G K compact rangeU grad
    (fun x hx y => rank_convex_support conv (grad x hx) y)

end
end SequentialRanks
