import ResidualFinite
import Mathlib.LinearAlgebra.Matrix.Trace
open MeasureTheory Set Filter Matrix
open scoped ENNReal BigOperators
namespace Residual
noncomputable section
def errorMatrix {X I : Type*} [MeasurableSpace X] [Fintype I] {m : ℕ}
    (ρ : Measure X) (j k : X → I) (F : Fin m → X → ℝ) : Matrix (Fin m) (Fin m) ℝ :=
  fun u v => ∑ i, change ρ j k (F u) i * change ρ j k (F v) i / (mass ρ j i+mass ρ k i)

end
end Residual
