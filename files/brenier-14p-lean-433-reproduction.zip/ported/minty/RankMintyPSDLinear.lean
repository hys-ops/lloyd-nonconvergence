import StaticRankConvex
import Mathlib.Analysis.Calculus.FDeriv.Symmetric
import Mathlib.LinearAlgebra.Matrix.PosDef

open MeasureTheory Filter Set Matrix
open scoped BigOperators Topology
namespace SequentialRanks
noncomputable section

def rankCovectorMap (d : ℕ) : RankPoint d →L[ℝ] RankPoint d →L[ℝ] ℝ :=
  ∑ i : Fin d, (ContinuousLinearMap.proj (R := ℝ) i).smulRight (ContinuousLinearMap.proj (R := ℝ) i)

theorem rankCovectorMap_apply {d : ℕ} (x : RankPoint d) : rankCovectorMap d x = rankCovector x := by
  simp [rankCovectorMap,rankCovector,_root_.sum_apply]

/-- A full cyclic inequality for the linear blow-up, in work rather than cost units. -/
def LinearCycleWork {d : ℕ} (A : RankDifferential d) : Prop :=
  ∀ (n : ℕ) (z : ℕ → RankPoint d),
    (∑ i ∈ Finset.range n, rankCovector (A (z i)) (z (i+1)-z i))+
      rankCovector (A (z n)) (z 0-z n) ≤ 0

private theorem linear_support_primitive {d : ℕ} (A : RankDifferential d) (h : LinearCycleWork A) :
    ∃ f : RankPoint d → ℝ, ∀ x y, rankCovector (A x) (y-x) ≤ f y-f x := by
  classical
  let work (z : ℕ → RankPoint d) (n : ℕ) := ∑ i ∈ Finset.range n, rankCovector (A (z i)) (z (i+1)-z i)
  let values (x : RankPoint d) := {r : ℝ | ∃ (n : ℕ) (z : ℕ → RankPoint d), z 0=0 ∧ z n=x ∧ r=work z n}
  let f := fun x => sSup (values x)
  have ne (x : RankPoint d) : (values x).Nonempty :=
    ⟨_,1,(fun i => if i=0 then 0 else x),by simp,by simp,rfl⟩
  have bd (x : RankPoint d) : BddAbove (values x) := by
    refine ⟨rankCovector (A x) x,?_⟩
    rintro r ⟨n,z,h0,hn,rfl⟩
    have cl := h n z
    change work z n + _ ≤ 0 at cl
    rw [h0,hn,zero_sub,map_neg] at cl
    linarith
  refine ⟨f,fun x y => ?_⟩
  suffices f x ≤ f y-rankCovector (A x) (y-x) by linarith
  apply csSup_le (ne x)
  rintro r ⟨n,z,h0,hn,rfl⟩
  let u (i : ℕ) := if i ≤ n then z i else y
  have hu0 : u 0 = 0 := by simp [u,h0]
  have last : u (n+1) = y := by simp [u]
  have old (i : ℕ) (hi : i ∈ Finset.range n) : rankCovector (A (u i)) (u (i+1)-u i) =
      rankCovector (A (z i)) (z (i+1)-z i) := by
    have hl := Finset.mem_range.mp hi
    simp [u,hl.le,hl]
  have more : work u (n+1) = work z n+rankCovector (A x) (y-x) := by
    simp only [work,Finset.sum_range_succ,Finset.sum_congr rfl old,last]
    simp [u,hn]
  have bound := le_csSup (bd y) (show work u (n+1) ∈ values y from ⟨n+1,u,hu0,last,rfl⟩)
  change work u (n+1) ≤ f y at bound
  rw [more] at bound; linarith

private theorem support_gradient {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (f : E → ℝ) (B : E →L[ℝ] E →L[ℝ] ℝ)
    (sup : ∀ x y, B x (y-x) ≤ f y-f x) (x : E) : HasFDerivAt f (B x) x := by
  rw [hasFDerivAt_iff_isLittleO_nhds_zero,Asymptotics.isLittleO_iff]
  intro ε hε
  have lim : Tendsto (fun h : E => ‖B h‖) (𝓝 0) (𝓝 0) := by simpa using (B.continuous.norm.tendsto (0 : E))
  filter_upwards [lim.eventually (gt_mem_nhds hε)] with h hh
  have low := sup x (x+h)
  have hi := sup (x+h) x
  simp only [add_sub_cancel_left] at low
  rw [show x-(x+h) = -h by abel,map_neg,map_add,_root_.add_apply] at hi
  change ‖f (x+h)-f x-B x h‖ ≤ ε*‖h‖
  rw [Real.norm_eq_abs,abs_of_nonneg (by linarith only [low])]
  calc _ ≤ B h h := by linarith only [hi]
       _ ≤ ‖B h h‖ := Real.le_norm_self _
       _ ≤ ‖B h‖*‖h‖ := (B h).le_opNorm _
       _ ≤ ε*‖h‖ := mul_le_mul_of_nonneg_right hh.le (norm_nonneg _)

/-- A linear cyclically monotone map is both symmetric and positive.
Cyclic work bounds finite-chain integrals, whose supremum has the given
linear gradient. Equality of its mixed second derivatives gives symmetry. -/
theorem linear_cyclic_psd {d : ℕ} (A : RankDifferential d) (cyc : LinearCycleWork A) :
    (LinearMap.toMatrix' A.toLinearMap).PosSemidef := by
  classical
  let B := (rankCovectorMap d).comp A
  obtain ⟨f,hf⟩ := linear_support_primitive A cyc
  have sup (x y : RankPoint d) : B x (y-x) ≤ f y-f x := by
    simpa only [B,ContinuousLinearMap.comp_apply,rankCovectorMap_apply] using hf x y
  have sym (u v : RankPoint d) : B u v = B v u :=
    second_derivative_symmetric_of_eventually_of_real
      (x := (0 : RankPoint d)) (.of_forall (support_gradient f B sup)) B.hasFDerivAt u v
  apply Matrix.posSemidef_iff_dotProduct_mulVec.mpr
  constructor
  · apply Matrix.IsHermitian.ext
    intro i j
    have eq := sym (Pi.single i 1) (Pi.single j 1)
    simpa [B,rankCovectorMap_apply,rankCovector,_root_.sum_apply,LinearMap.toMatrix'_apply,Pi.single_apply] using eq
  · intro u
    have low := sup 0 u
    have hi := sup u 0
    simp only [map_zero,_root_.zero_apply,zero_sub,map_neg] at low hi
    rw [LinearMap.toMatrix'_mulVec]
    simpa [B,rankCovectorMap_apply,rankCovector,_root_.sum_apply,dotProduct,mul_comm] using
      (show 0 ≤ B u u by linarith only [low,hi])

end
end SequentialRanks
