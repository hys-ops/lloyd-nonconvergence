import ResidualEnergy

open MeasureTheory Set Filter Function
open scoped ENNReal BigOperators
namespace Residual
noncomputable section
variable {X I : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    [MeasurableSpace X] [BorelSpace X] [SecondCountableTopology X]
    [Fintype I] [MeasurableSpace I] [MeasurableSingletonClass I]

def change (ρ : Measure X) (j k : X → I) (f : X → ℝ) (i : I) :=
  (∫ x in j ⁻¹' {i}, f x ∂ρ) - ∫ x in k ⁻¹' {i}, f x ∂ρ

def scalarEnergy (ρ : Measure X) (j k : X → I) (f : X → ℝ) :=
  ∑ i, change ρ j k f i ^ 2 / (mass ρ j i + mass ρ k i)

structure CoupledCells (ρ : Measure X) (j k : X → I) where
  plans : I → ProbabilityMeasure (X × X)
  left : ∀ i, ρ (j ⁻¹' {i}) • (plans i : Measure (X × X)).map Prod.fst = ρ.restrict (j ⁻¹' {i})
  right : ∀ i, ρ (k ⁻¹' {i}) • (plans i : Measure (X × X)).map Prod.snd = ρ.restrict (k ⁻¹' {i})
  dominated : midLaw (mass ρ j) (mass ρ k) plans ≤ ρ

omit [NormedAddCommGroup X] [NormedSpace ℝ X] [BorelSpace X] [SecondCountableTopology X] in
theorem fiber_sum (ρ : Measure X) (j : X → I) (mj : Measurable j)
    (f : X → ℝ) (hf : Integrable f ρ) :
    (∑ i, ∫ x in j ⁻¹' {i},f x ∂ρ) = ∫ x,f x ∂ρ := by
  rw [← integral_iUnion_fintype (fun i => mj (measurableSet_singleton i)) _ (fun _ => hf.integrableOn)]
  · have full : (⋃ i,j ⁻¹' {i}) = univ := by ext x; simp
    rw [full,setIntegral_univ]
  · intro i j h; exact Disjoint.preimage _ (Set.disjoint_singleton.mpr h)

omit [NormedAddCommGroup X] [NormedSpace ℝ X] [BorelSpace X] [SecondCountableTopology X] in
theorem endpoint_int {Ω : Type*} [MeasurableSpace Ω] (ρ : Measure X) (P : Measure Ω)
    (p : Ω → X) (mp : Measurable p) (A : Set X)
    (law : ρ A • P.map p = ρ.restrict A) (f : X → ℝ) (mf : Measurable f) :
    ρ.real A * (∫ x,f (p x) ∂P) = ∫ x in A, f x ∂ρ := by
  rw [←law,integral_smul_measure,integral_map mp.aemeasurable mf.aestronglyMeasurable]; rfl

omit [NormedAddCommGroup X] [NormedSpace ℝ X] [BorelSpace X] [SecondCountableTopology X] in
theorem endpoint_memLp {Ω : Type*} [MeasurableSpace Ω] (ρ : Measure X) [IsFiniteMeasure ρ]
    (P : Measure Ω) (p : Ω → X) (mp : Measurable p) (A : Set X) (pos : ρ.real A ≠ 0)
    (law : ρ A • P.map p = ρ.restrict A) (f : X → ℝ) (mf : Measurable f) (lf : MemLp f 2 ρ) :
    MemLp (fun x => f (p x)) 2 P := by
  have nz : ρ A ≠ 0 := fun h => pos (by simp [Measure.real,h])
  have eqn : P.map p = (ρ A)⁻¹ • ρ.restrict A := by rw [←law,smul_smul,ENNReal.inv_mul_cancel nz (measure_ne_top _ _),one_smul]
  apply (memLp_map_measure_iff mf.aestronglyMeasurable mp.aemeasurable).1
  rw [eqn]
  exact (lf.mono_measure Measure.restrict_le_self).smul_measure (by simpa using nz)

omit [MeasurableSpace I] [MeasurableSingletonClass I] in
theorem midLaw_integral (ρ : Measure X) [IsProbabilityMeasure ρ] (a b : I → ℝ)
    (γ : I → ProbabilityMeasure (X × X)) (na : ∀ i,0≤a i) (nb : ∀ i,0≤b i)
    (dom : midLaw a b γ ≤ ρ) (f : X → ℝ) (mf : Measurable f) (hf : Integrable f ρ) :
    (∫ x,f x ∂midLaw a b γ) =
    ∑ i, Vortex.harmonicMass (a i) (b i) * ∫ z,f (midpoint z) ∂(γ i : Measure (X × X)) := by
  classical
  have mm : Measurable (@midpoint X _ _) := by unfold midpoint; fun_prop
  have hi := hf.mono_measure dom
  unfold midLaw at hi ⊢
  rw [integral_finsetSum_measure (integrable_finsetSum_measure.mp hi)]
  apply Finset.sum_congr rfl
  intro i _
  rw [integral_smul_measure,ENNReal.toReal_ofReal (Vortex.harmonic_nonneg (na i) (nb i)),
    integral_map mm.aemeasurable mf.aestronglyMeasurable,smul_eq_mul]

omit [NormedAddCommGroup X] [NormedSpace ℝ X] [BorelSpace X] [SecondCountableTopology X] in
theorem residual_int {ρ η : Measure X} [IsProbabilityMeasure ρ] (dom : η ≤ ρ) (f : X → ℝ)
    (hf : Integrable f ρ) : (∫ x,f x ∂(ρ-η)) = (∫ x,f x ∂ρ) - ∫ x,f x ∂η := by
  have : IsFiniteMeasure η := ⟨(dom _).trans_lt (measure_lt_top ρ univ)⟩
  have e := Measure.sub_add_cancel_of_le dom
  have h := integral_add_measure (hf.mono_measure (Measure.sub_le (μ:=ρ) (ν:=η))) (hf.mono_measure dom)
  rw [e] at h
  linarith

theorem scalar_from_couplings (ρ : Measure X) [IsProbabilityMeasure ρ] (j k : X → I)
    (mj : Measurable j) (mk : Measurable k) (c : CoupledCells ρ j k)
    (f : X → ℝ) (mf : Measurable f) (lf : MemLp f 2 ρ)
    (aff : ∀ x y, f (midpoint (x,y)) = (f x+f y)/2) :
    let ζ := ρ-midLaw (mass ρ j) (mass ρ k) c.plans
    scalarEnergy ρ j k f ≤ 2*∫ x,(f x)^2 ∂ζ := by
  let a := mass ρ j
  let b := mass ρ k
  let γ := c.plans
  let η := midLaw a b γ
  let sq := fun x => f x^2
  have ms : Measurable sq := mf.pow_const 2
  have isq : Integrable sq ρ := lf.integrable_sq
  have cmp (i : I) : change ρ j k f i^2/(a i+b i) ≤
      (∫ x in j ⁻¹' {i},sq x ∂ρ)+(∫ x in k ⁻¹' {i},sq x ∂ρ) -
      2*(Vortex.harmonicMass (a i) (b i)*(∫ z, sq (midpoint z) ∂(γ i : Measure (X × X)))) := by
    have e := cell_energy (γ i : Measure (X × X)) (a i) (b i) measureReal_nonneg measureReal_nonneg
      (fun z => f z.1) (fun z => f z.2)
      (fun h => endpoint_memLp ρ _ Prod.fst measurable_fst _ h (c.left i) f mf lf)
      (fun h => endpoint_memLp ρ _ Prod.snd measurable_snd _ h (c.right i) f mf lf)
    have L (g : X → ℝ) (mg : Measurable g) := endpoint_int ρ (γ i : Measure (X × X)) Prod.fst measurable_fst _ (c.left i) g mg
    have R (g : X → ℝ) (mg : Measurable g) := endpoint_int ρ (γ i : Measure (X × X)) Prod.snd measurable_snd _ (c.right i) g mg
    change (a i*(∫ z,f z.1 ∂(γ i : Measure (X × X))) - b i*(∫ z,f z.2 ∂(γ i : Measure (X × X))))^2/(a i+b i) ≤
      a i*(∫ z,sq z.1 ∂(γ i : Measure (X × X))) + b i*(∫ z,sq z.2 ∂(γ i : Measure (X × X))) -
      2*Vortex.harmonicMass (a i) (b i)*(∫ z,((f z.1+f z.2)/2)^2 ∂(γ i : Measure (X × X))) at e
    unfold change
    simp only [a,b,mass] at e ⊢
    rw [L f mf,R f mf,L sq ms,R sq ms] at e
    simpa only [sq,show ∀ z : X × X,f (midpoint z)=(f z.1+f z.2)/2 from fun z => aff z.1 z.2,mul_assoc] using e
  have tot := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => cmp i)
  simp only [Finset.sum_sub_distrib,Finset.sum_add_distrib,←Finset.mul_sum,
    fiber_sum ρ j mj sq isq,fiber_sum ρ k mk sq isq] at tot
  have eqn := midLaw_integral ρ a b γ (fun _ => measureReal_nonneg) (fun _ => measureReal_nonneg)
    c.dominated sq ms isq
  change _ ≤ 2*(∫ x,sq x ∂(ρ-η))
  rw [residual_int c.dominated sq isq]
  change (∑ i,change ρ j k f i^2/(a i+b i)) ≤ _
  linarith only [tot,eqn]

end
end Residual
