import ResidualCompactCells
import ResidualTraceOnly
import ResidualDiagramCanonical
import LogConcaveMidpointExtract

open MeasureTheory Set Matrix
open scoped ENNReal BigOperators
namespace Residual
open SequentialRanks
noncomputable section

theorem bounded_coordinate_trace {d : ℕ} {I : Type*} [Fintype I] [MeasurableSpace I]
    [MeasurableSingletonClass I] (ρ : Measure (RankPoint d)) [IsProbabilityMeasure ρ]
    (j k : RankPoint d → I) (mj : Measurable j) (mk : Measurable k)
    (c : CoupledCells ρ j k) (R : ℝ) (ball : ∀ᵐ x ∂ρ,(∑ r,x r^2) ≤ R^2) :
    (errorMatrix ρ j k (fun i x => x i)).trace ≤ R^2 * delta (mass ρ j) (mass ρ k) := by
  let ζ := ρ-midLaw (mass ρ j) (mass ρ k) c.plans
  obtain ⟨sub,sz,_⟩ := residual_mass ρ (mass ρ j) (mass ρ k) c.plans (fun _ => measureReal_nonneg)
    (fun _ => measureReal_nonneg) (mass_sum ρ j mj) (mass_sum ρ k mk) c.dominated
  have iz : IsFiniteMeasure ζ := isFiniteMeasure_of_le _ sub
  have sq (r : Fin d) : Integrable (fun x : RankPoint d => x r^2) ρ := by
    apply (integrable_const (R^2)).mono' ((measurable_pi_apply r).pow_const 2).aestronglyMeasurable
    filter_upwards [ball] with x hx
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    exact (Finset.single_le_sum (f:=fun i => x i^2) (fun _ _ => sq_nonneg _) (Finset.mem_univ r)).trans hx
  have lp (r : Fin d) : MemLp (fun x : RankPoint d => x r) 2 ρ :=
    (memLp_two_iff_integrable_sq (measurable_pi_apply _).aestronglyMeasurable).mpr (sq r)
  have aff (r : Fin d) (x y : RankPoint d) : (midpoint (x,y)) r=(x r+y r)/2 := by simp [midpoint]; ring
  have h := Finset.sum_le_sum (s:=Finset.univ) (fun r _ =>
      scalar_from_couplings ρ j k mj mk c _ (measurable_pi_apply _) (lp r) (aff r))
  have hr : (errorMatrix ρ j k (fun i x => x i)).trace ≤ 2 * ∫ x, ∑ r,x r^2 ∂ζ := by
    rw [integral_finsetSum _ fun r _ => (sq r).mono_measure sub, Finset.mul_sum]
    simpa [trace,diag,errorMatrix,scalarEnergy,pow_two,ζ] using h
  have hb := integral_mono_ae (integrable_finsetSum _ fun r _ => (sq r).mono_measure sub)
    (integrable_const (μ:=ζ) (R^2)) (sub.absolutelyContinuous.ae_le ball)
  rw [integral_const,smul_eq_mul,sz] at hb
  linarith

/-- The precise trace consequence used by the 14-page Brenier proof.
    It uses compactly supported couplings directly rather than truncation and random trace. -/
theorem uniform_compact_body_moment_trace {d : ℕ} {I : Type*} [Fintype I] [MeasurableSpace I]
    [MeasurableSingletonClass I] [Nonempty I] [LinearOrder I]
    (K : Set (RankPoint d)) (hk : IsCompact K) (cv : Convex ℝ K) (inside : (interior K).Nonempty)
    (R : ℝ) (bd : ∀ x∈K,(∑ i,x i^2)≤R^2)
    (v : I → RankPoint d) (iv : Function.Injective v) (a b : I→ℝ) :
    let ρ := (volume K)⁻¹ • volume.restrict K
    let j := powerTag v a
    let k := powerTag v b
    (errorMatrix ρ j k (fun i x => x i)).trace ≤ R^2 * delta (mass ρ j) (mass ρ k) := by
  let m := (volume K)⁻¹
  let ρ := m • volume.restrict K
  have mkp := hk.isClosed.measurableSet
  have pos : volume K≠0 := (Measure.measure_pos_of_nonempty_interior volume inside).ne'
  have htop : volume K≠⊤ := hk.measure_ne_top
  have fin : m≠⊤ := ENNReal.inv_ne_top.mpr pos
  have mp : 0<m.toReal := ENNReal.toReal_pos (ENNReal.inv_ne_zero.mpr htop) fin
  have prob : IsProbabilityMeasure ρ := ⟨by
    simp only [ρ,m,Measure.smul_apply,smul_eq_mul,Measure.restrict_apply_univ,ENNReal.inv_mul_cancel pos htop]⟩
  let w := K.indicator (fun _ => m.toReal)
  have eqn : weighted volume w=ρ := by
    have f : (fun x => ENNReal.ofReal (w x)) = K.indicator (fun _ => m) := by
      funext x
      by_cases hx : x∈K <;> simp [w,hx,ENNReal.ofReal_toReal fin]
    rw [weighted,f,withDensity_indicator mkp,withDensity_const]
  have setpos : {x | 0<w x}=K := by
    ext x
    by_cases h : x∈K <;> simp [w,h,mp]
  have lc : ConcaveOn ℝ {x | 0<w x} (fun x => Real.log (w x)) := by
    rw [setpos]
    refine ⟨cv,?_⟩
    intro x hx y hy s t hs ht add
    have comb := cv hx hy hs ht add
    simp only [w,indicator_of_mem hx,indicator_of_mem hy,indicator_of_mem comb,smul_eq_mul,←add_mul,add,one_mul,le_refl]
  have : IsProbabilityMeasure (weighted volume w) := eqn ▸ prob
  have support : ∀ᵐ x ∂weighted volume w, x ∈ K := by
    rw [eqn]
    exact Measure.ae_smul_measure (ae_restrict_mem (μ:=volume) mkp) m
  let _ : Nonempty K := (inside.mono interior_subset).to_subtype
  let ν := weighted volume w
  let j := powerTag v a
  let k := powerTag v b
  have mj := measurable_powerTag v a
  have mk := measurable_powerTag v b
  have mw : Measurable w := (measurable_const : Measurable (fun _ : RankPoint d => m.toReal)).indicator mkp
  have wn : ∀ x, 0 ≤ w x := fun x => indicator_nonneg (fun _ _ => mp.le) x
  choose plans left right middle using fun i =>
    compact_cell_harmonic_coupling w mw wn (log_concave_density_midpoint w wn lc)
      K hk support (j ⁻¹' {i}) (k ⁻¹' {i}) (mj (measurableSet_singleton i))
      (mk (measurableSet_singleton i))
  let c : CoupledCells ν j k := diagram_couplings ν (withDensity_absolutelyContinuous _ _) v iv a b j k
    (fun i _ => (ae_restrict_mem (mj (measurableSet_singleton i))).mono fun x hx s _ =>
      (show j x=i from hx) ▸ powerTag_wins v a x s)
    (fun i _ => (ae_restrict_mem (mk (measurableSet_singleton i))).mono fun x hx s _ =>
      (show k x=i from hx) ▸ powerTag_wins v b x s) plans left right middle
  have result := bounded_coordinate_trace ν j k mj mk c R (support.mono bd)
  change (errorMatrix ρ j k (fun i x => x i)).trace ≤ R^2 * delta (mass ρ j) (mass ρ k)
  simpa only [ν, eqn] using result

end
end Residual
