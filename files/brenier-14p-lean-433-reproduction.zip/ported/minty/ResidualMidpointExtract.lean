import Mathlib.Analysis.Normed.Lp.PiLp
namespace Residual
noncomputable section
def midpoint {X : Type*} [Add X] [SMul ℝ X] (z : X × X) := (1/2 : ℝ) • (z.1+z.2)

end
end Residual
