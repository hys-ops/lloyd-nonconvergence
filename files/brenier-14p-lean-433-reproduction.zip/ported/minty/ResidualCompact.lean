import ResidualGeometry
import StaticRankFinish
import ResidualMidpointExtract
open MeasureTheory Set Filter
open scoped ENNReal
namespace Residual
open SequentialRanks
noncomputable section

theorem compact_density_coupling {d} (K : Set (RankPoint d)) (hk : IsCompact K) [Nonempty K]
    (p q w : RankPoint d → ℝ) (C D : ℝ) (mp : Measurable p) (pn : ∀ x,0≤p x)
    (qn : ∀ x,0≤q x) (pc : ∀ x,p x≤C*w x) (qd : ∀ x,q x≤D*w x)
    (wn : ∀ x,0≤w x) (cn : 0≤C) (dn : 0≤D)
    (logmid : ∀ x y,Real.sqrt (w x)*Real.sqrt (w y)≤w (mid x y))
    [IsProbabilityMeasure (weighted volume p)] [IsProbabilityMeasure (weighted volume q)]
    (sp : ∀ᵐ x ∂weighted volume p,x∈K) (sq : ∀ᵐ x ∂weighted volume q,x∈K) :
    ∃ π : ProbabilityMeasure (RankPoint d × RankPoint d),
      (π : Measure (RankPoint d × RankPoint d)).map Prod.fst = weighted volume p ∧
      (π : Measure (RankPoint d × RankPoint d)).map Prod.snd = weighted volume q ∧
      (π : Measure (RankPoint d × RankPoint d)).map midpoint ≤ ENNReal.ofReal (Real.sqrt C*Real.sqrt D) • weighted volume w := by
  obtain ⟨U,mu,_,law,gr⟩ := compact_rank_graph_exists K K hk hk p q sp sq
  obtain ⟨φ,G,a,conv,mg,full,inj,grad,der,psd⟩ := good_hessian_set K K hk hk p q U mp mu law gr
  have mon := rank_monotone_of_supporting φ U G (fun x hx y => rank_convex_support conv (grad x hx) y)
  have bound := weighted_cell_midpoint_area p q w U C D mp pn qn pc qd wn cn dn logmid mu law G mg full a der inj mon psd
  let f := fun x => (x,U x)
  have mf : Measurable f := measurable_id.prodMk mu
  let P : ProbabilityMeasure (RankPoint d) := ⟨weighted volume p,inferInstance⟩
  refine ⟨P.map mf.aemeasurable,?_,?_,?_⟩
  · rw [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst mf]
    exact Measure.map_id
  · rw [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_snd mf]
    exact law
  · rw [ProbabilityMeasure.toMeasure_map,Measure.map_map (by unfold midpoint; fun_prop) mf]
    have eqn : midpoint ∘ f = fun x => mid x (U x) := by
      funext x i; change (1/2:ℝ)*(x i+U x i)=(x i+U x i)/2; ring
    rw [eqn]; exact bound

end
end Residual
