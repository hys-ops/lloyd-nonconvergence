import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

open Matrix
open scoped BigOperators
namespace SequentialRanks
noncomputable section

theorem unit_mid_det {n : Type*} [Fintype n] [DecidableEq n]
    {D : Matrix n n ℝ} (hD : D.PosSemidef) :
    Real.sqrt D.det ≤ ((1/2:ℝ) • (1+D)).det := by
  let v := hD.isHermitian.eigenvalues
  let T := Unitary.conjStarAlgAut ℝ _ hD.isHermitian.eigenvectorUnitary
  have decomp : D = T (diagonal v) := hD.isHermitian.spectral_theorem
  have ha : (1/2:ℝ) • (1 + D) = T (diagonal (fun i => (1+v i)/2)) := by
    have h : diagonal (fun i => (1+v i)/2) = (1/2:ℝ) • (1 + diagonal v) := by
      ext i j
      by_cases h : i=j
      · subst j; simp [Matrix.smul_apply]; ring
      · simp [Matrix.one_apply_ne h,Matrix.smul_apply, h]
    rw [h,map_smul,map_add,map_one,← decomp]
  rw [ha,hD.isHermitian.det_eq_prod_eigenvalues]
  change Real.sqrt (∏ i, v i) ≤ (T (diagonal (fun i => (1+v i)/2))).det
  rw [Real.sqrt_prod _ (fun i _ => hD.eigenvalues_nonneg i)]
  have hd : (T (diagonal (fun i => (1+v i)/2))).det = ∏ i, (1+v i)/2 := by
    simp [T, -Unitary.conjStarAlgAut_apply]
  rw [hd]
  apply Finset.prod_le_prod (fun i _ => Real.sqrt_nonneg _) (fun i _ => ?_)
  nlinarith only [sq_nonneg (Real.sqrt (v i)-1),Real.sq_sqrt (hD.eigenvalues_nonneg i)]

end
end SequentialRanks
