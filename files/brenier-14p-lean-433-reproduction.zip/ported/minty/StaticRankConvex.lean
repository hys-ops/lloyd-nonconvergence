import Mathlib.Analysis.Normed.Lp.PiLp
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.Deriv.AffineMap
import Mathlib.Analysis.Calculus.LocalExtr.Basic

open MeasureTheory Set
open scoped Topology BigOperators
namespace SequentialRanks
noncomputable section

abbrev RankPoint (d : ℕ) := Fin d → ℝ
abbrev RankDifferential (d : ℕ) := RankPoint d →L[ℝ] RankPoint d

/-- Coordinate representation of the Euclidean covector with gradient u. -/
def rankCovector {d : ℕ} (u : RankPoint d) : RankPoint d →L[ℝ] ℝ :=
  ∑ i, (u i) • ContinuousLinearMap.proj (R := ℝ) i

private theorem cvadd {d : ℕ} (u v : RankPoint d) :
    rankCovector (u+v) = rankCovector u+rankCovector v := by
  unfold rankCovector; simp [add_smul,Finset.sum_add_distrib]

theorem rank_covector_injective {d : ℕ} : Function.Injective (@rankCovector d) := by
  intro u v e
  funext i
  have ev := DFunLike.congr_fun e (Pi.single i (1:ℝ))
  simpa [rankCovector,sum_apply,Pi.single_apply] using ev

theorem rank_convex_support {d : ℕ} {f : RankPoint d → ℝ} (conv : ConvexOn ℝ univ f)
    {x : RankPoint d} {L : RankPoint d →L[ℝ] ℝ} (der : HasFDerivAt f L x) (y : RankPoint d) :
    L (y-x) ≤ f y - f x := by
  let l := AffineMap.lineMap (k := ℝ) x y
  have df : HasFDerivAt f L (l 0) := by simpa [l] using der
  have dl : HasDerivAt l (y-x) 0 := AffineMap.hasDerivAt_lineMap ..
  have dc : HasDerivAt (f ∘ l) (L (y-x)) 0 := df.comp_hasDerivAt 0 dl
  have hc := conv.comp_affineMap l
  have hs := hc.le_slope_of_hasDerivAt (x := 0) (y := 1) (by simp) (by simp) zero_lt_one dc
  simpa [slope_def_field,l,Function.comp_def] using hs

end
end SequentialRanks
