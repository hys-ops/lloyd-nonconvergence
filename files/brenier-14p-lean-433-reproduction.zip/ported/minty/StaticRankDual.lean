import StaticRankConvex
import PredictiveRanks
import CyclicPlans
import Mathlib.Topology.Order.Compact

open MeasureTheory Filter Set
open scoped BigOperators Topology
namespace SequentialRanks
noncomputable section

def globalSupports {d : ℕ} (φ : RankPoint d → ℝ) (a k : RankPoint d) :=
  ∀ x, rankCovector k (x-a) ≤ φ x - φ a

private theorem pairing {d : ℕ} (k x : RankPoint d) : rankCovector k x = ∑ i, k i*x i := by
  simp [rankCovector,sum_apply]

private theorem cost_expand {d : ℕ} {A B : Set (RankPoint d)} (z : A × B) :
    squareCost z = normSq z.1.val + normSq z.2.val - 2*rankCovector z.2.val z.1.val := by
  unfold squareCost diff normSq
  rw [pairing,Finset.mul_sum,← Finset.sum_add_distrib,← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _; ring

private theorem compact_integrable {X : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] (μ : Measure X) [IsFiniteMeasure μ]
    {g : X → ℝ} (c : Continuous g) : Integrable g μ := by
  let u : C(X,ℝ) := ⟨g,c⟩
  exact (integrable_const ‖u‖).mono' c.aestronglyMeasurable (.of_forall u.norm_coe_le_norm)

/-- A continuous nonnegative Fenchel gap on A × B. The supremum defining its
dual potential ranges over a ball containing A in its interior. This ensures
that any zero gives a genuine ambient local minimum, even for thin or
irregular compact supports A. -/
theorem compact_support_duality {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A)
    (hb : IsCompact B) (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B)
    (φ : RankPoint d → ℝ) (cφ : Continuous φ) :
    ∃ D : A × B → ℝ, Continuous D ∧ (∀ z, 0 ≤ D z) ∧
      (∀ z : A × B, globalSupports φ z.1.val z.2.val → D z = 0) ∧
      (∀ z : A × B, D z = 0 → IsLocalMin (fun x => φ x - rankCovector z.2.val x) z.1.val) ∧
      ∃ k : ℝ, ∀ γ : ProbabilityMeasure (A × B), γ.map (measurable_fst.aemeasurable) = P → γ.map (measurable_snd.aemeasurable) = Q →
        (∫ z, squareCost z ∂(γ : Measure (A × B))) = k + 2*∫ z, D z ∂(γ : Measure (A × B)) := by
  let _ : CompactSpace A := isCompact_iff_compactSpace.mp ha
  let _ : CompactSpace B := isCompact_iff_compactSpace.mp hb
  obtain ⟨r,ar⟩ := ha.isBounded.subset_ball (0 : RankPoint d)
  let J := Metric.closedBall (0 : RankPoint d) r
  have cj : IsCompact J := isCompact_closedBall _ _
  let s := fun (k x : RankPoint d) => rankCovector k x - φ x
  have cs : Continuous (Function.uncurry s) := by
    unfold s; simp_rw [pairing]; unfold Function.uncurry; fun_prop
  let v := fun k => sSup (s k '' J)
  have cv : Continuous v := cj.continuous_sSup cs
  have bu (k : RankPoint d) : BddAbove (s k '' J) :=
    (cj.image (cs.comp (continuous_const.prodMk continuous_id))).bddAbove
  have bound (k x : RankPoint d) (hx : x ∈ J) : s k x ≤ v k := le_csSup (bu k) ⟨x,hx,rfl⟩
  let D := fun z : A × B => φ z.1.val + v z.2.val - rankCovector z.2.val z.1.val
  have ca : Continuous (fun z : A × B => (z.1 : RankPoint d)) := continuous_subtype_val.comp continuous_fst
  have cb : Continuous (fun z : A × B => (z.2 : RankPoint d)) := continuous_subtype_val.comp continuous_snd
  have cD : Continuous D := by
    unfold D
    apply ((cφ.comp ca).add (cv.comp cb)).sub
    simp_rw [pairing]
    exact continuous_finsetSum _ fun i _ => ((continuous_apply i).comp cb).mul ((continuous_apply i).comp ca)
  have non (z : A × B) : 0 ≤ D z := by
    have h := bound z.2.val z.1.val (Metric.ball_subset_closedBall (ar z.1.property))
    unfold D s at *; linarith
  refine ⟨D,cD,non,?_,?_,?_⟩
  · intro z hz
    have hv : v z.2.val ≤ s z.2.val z.1.val := by
      apply csSup_le (image_nonempty.mpr ⟨z.1.val,Metric.ball_subset_closedBall (ar z.1.property)⟩)
      rintro _ ⟨x,_,rfl⟩
      have h := hz x
      rw [map_sub] at h
      unfold s; linarith
    have h := non z
    unfold D s at *; linarith
  · intro z hz
    have nh : J ∈ 𝓝 z.1.val := Filter.mem_of_superset (Metric.isOpen_ball.mem_nhds (ar z.1.property)) Metric.ball_subset_closedBall
    change ∀ᶠ x in 𝓝 z.1.val, φ z.1.val - rankCovector z.2.val z.1.val ≤ φ x - rankCovector z.2.val x
    filter_upwards [nh] with x hx
    have h := bound z.2.val x hx
    unfold D s at *; linarith
  · let f := fun x : A => normSq x.val - 2*φ x.val
    let g := fun y : B => normSq y.val - 2*v y.val
    have cn : Continuous (normSq : RankPoint d → ℝ) := by unfold normSq; fun_prop
    have cf : Continuous f := (cn.comp continuous_subtype_val).sub (continuous_const.mul (cφ.comp continuous_subtype_val))
    have cg : Continuous g := (cn.comp continuous_subtype_val).sub (continuous_const.mul (cv.comp continuous_subtype_val))
    refine ⟨(∫ x,f x ∂(P : Measure A))+(∫ y,g y ∂(Q : Measure B)),?_⟩
    intro γ hf hg
    have id (z : A × B) : squareCost z = (f z.1 + g z.2) + 2*D z := by
      rw [cost_expand]; unfold f g D; ring
    have mf : ((γ : Measure (A × B)).map Prod.fst) = (P : Measure A) := congrArg Subtype.val hf
    have mg : ((γ : Measure (A × B)).map Prod.snd) = (Q : Measure B) := congrArg Subtype.val hg
    simp_rw [id]
    have fi : Integrable (fun z : A × B => f z.1) (γ : Measure _) := compact_integrable _ (cf.comp continuous_fst)
    have gi : Integrable (fun z : A × B => g z.2) (γ : Measure _) := compact_integrable _ (cg.comp continuous_snd)
    have fg : Integrable (fun z : A × B => f z.1+g z.2) (γ : Measure _) := fi.add gi
    rw [integral_add fg ((compact_integrable (γ : Measure _) cD).const_mul 2),integral_add fi gi,
      integral_const_mul,← integral_map measurable_fst.aemeasurable cf.aestronglyMeasurable,
      ← integral_map measurable_snd.aemeasurable cg.aestronglyMeasurable,mf,mg]

end
end SequentialRanks
