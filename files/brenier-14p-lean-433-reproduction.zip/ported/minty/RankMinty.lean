import StaticRankConvex
import Mathlib.MeasureTheory.Measure.Hausdorff
import Mathlib.MeasureTheory.Function.Jacobian
import Mathlib.Analysis.Calculus.Rademacher
import Mathlib.Analysis.Calculus.FDeriv.OfCompLeft

open MeasureTheory Set Filter Function
open scoped Topology BigOperators ENNReal NNReal
namespace SequentialRanks
noncomputable section

/-- Pairwise monotonicity in the actual Euclidean coordinates. -/
def RankMonotoneOn {d : ℕ} (U : RankPoint d → RankPoint d) (G : Set (RankPoint d)) : Prop :=
  ∀ x ∈ G, ∀ y ∈ G, 0 ≤ ∑ i, (x i-y i)*(U x i-U y i)

private theorem minty_distance {d : ℕ} (U : RankPoint d → RankPoint d) (G : Set (RankPoint d))
    (h : RankMonotoneOn U G) {x y : RankPoint d} (hx : x ∈ G) (hy : y ∈ G) :
    dist x y ≤ (d+1:ℝ) * dist (x+U x) (y+U y) := by
  let D := dist (x+U x) (y+U y)
  have d0 : 0 ≤ D := dist_nonneg
  have ld : 0 ≤ (d:ℝ) := Nat.cast_nonneg _
  have hsum : ∑ i, (x i-y i)^2 ≤ ∑ i, ((x+U x) i-(y+U y) i)^2 := by
    have eqn : (∑ i, ((x+U x) i-(y+U y) i)^2) =
        (∑ i, (x i-y i)^2) + 2*(∑ i, (x i-y i)*(U x i-U y i)) + ∑ i,(U x i-U y i)^2 := by
      rw [Finset.mul_sum,←Finset.sum_add_distrib,←Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro i _
      simp only [Pi.add_apply]
      ring
    rw [eqn]
    linarith [h x hx y hy, show 0 ≤ ∑ i,(U x i-U y i)^2 from Finset.sum_nonneg (fun i _ => sq_nonneg _)]
  have hu : (∑ i, ((x+U x) i-(y+U y) i)^2) ≤ (d:ℝ)*D^2 := by
    calc
      _ ≤ ∑ _ : Fin d,D^2 := by
        apply Finset.sum_le_sum
        intro i _
        have hh := pow_le_pow_left₀ (dist_nonneg (x := (x+U x) i) (y := (y+U y) i))
          (dist_le_pi_dist (x+U x) (y+U y) i) 2
        simpa only [Real.dist_eq,sq_abs] using hh
      _ = _ := by simp
  apply (dist_pi_le_iff (mul_nonneg (by positivity) d0)).mpr
  intro i
  have lone : (x i-y i)^2 ≤ ∑ j,(x j-y j)^2 :=
    Finset.single_le_sum (fun j _ => sq_nonneg (x j-y j)) (Finset.mem_univ i)
  have h1 : (x i-y i)^2 ≤ (d:ℝ)*D^2 := (lone.trans hsum).trans hu
  have h2 : (d:ℝ)*D^2 ≤ ((d+1:ℝ)*D)^2 := by
    have aux : 0 ≤ ((d:ℝ)^2+d+1)*D^2 := by positivity
    nlinarith only [aux]
  rw [Real.dist_eq,←sq_le_sq₀ (abs_nonneg _) (mul_nonneg (by positivity) d0),sq_abs]
  exact h1.trans h2

/-- The inverse spatial coordinate x of z=x+U(x) on a monotone graph admits
a globally Lipschitz extension in the product norm. No regularity of U is assumed. -/
theorem minty_inverse_extension {d : ℕ} (U : RankPoint d → RankPoint d) (G : Set (RankPoint d))
    (h : RankMonotoneOn U G) :
    ∃ f : RankPoint d → RankPoint d, LipschitzWith (d+1:ℝ≥0) f ∧ ∀ x ∈ G, f (x+U x)=x := by
  classical
  let z := fun x => x+U x
  have inj : InjOn z G := by
    intro x hx y hy eqz
    have ht := minty_distance U G h hx hy
    change dist x y ≤ _*dist (z x) (z y) at ht
    rw [eqz,dist_self,mul_zero] at ht
    exact dist_le_zero.mp ht
  let u := invFunOn z G
  have lip : LipschitzOnWith (d+1:ℝ≥0) u (z '' G) := by
    apply lipschitzOnWith_iff_dist_le_mul.mpr
    rintro _ ⟨x,hx,rfl⟩ _ ⟨y,hy,rfl⟩
    change dist (invFunOn z G (z x)) (invFunOn z G (z y)) ≤ _
    rw [inj.leftInvOn_invFunOn hx,inj.leftInvOn_invFunOn hy]
    simpa [z] using minty_distance U G h hx hy
  obtain ⟨f,l,eqf⟩ := lip.extend_pi
  exact ⟨f,l,fun x hx => (eqf (mem_image_of_mem z hx)).symm.trans (inj.leftInvOn_invFunOn hx)⟩

private theorem rank_lipschitz_null {d : ℕ} {f : RankPoint d → RankPoint d} {C : ℝ≥0}
    (lip : LipschitzWith C f) (N : Set (RankPoint d)) (hN : volume N=0) :
    volume (f '' N)=0 := by
  have t := lip.hausdorffMeasure_image_le (by positivity : 0 ≤ (Fintype.card (Fin d):ℝ)) N
  rw [hausdorffMeasure_pi_real,hN,mul_zero] at t
  exact nonpos_iff_eq_zero.mp t

/-- A Lipschitz map sends the points where its derivative is missing or singular
into a Lebesgue-null Borel set, by Rademacher, the Lipschitz null-image estimate
and the equal-dimensional Sard lemma. -/
theorem minty_critical_values {d : ℕ} (f : RankPoint d → RankPoint d) (C : ℝ≥0)
    (lip : LipschitzWith C f) :
    ∃ N : Set (RankPoint d), MeasurableSet N ∧ volume N = 0 ∧
      ∀ z, f z ∉ N → DifferentiableAt ℝ f z ∧ (fderiv ℝ f z).det ≠ 0 := by
  let A := {z | ¬ DifferentiableAt ℝ f z}
  let B := {z | DifferentiableAt ℝ f z ∧ (fderiv ℝ f z).det = 0}
  have ha : volume A=0 := ae_iff.mp (lip.ae_differentiableAt (μ := volume))
  have hb : volume (f '' B) = 0 :=
    addHaar_image_eq_zero_of_det_fderivWithin_eq_zero volume
      (fun z (hz : z ∈ B) => hz.1.hasFDerivAt.hasFDerivWithinAt) (fun _ hz => hz.2)
  let bad := f '' A ∪ f '' B
  have null : volume bad=0 := measure_union_null (rank_lipschitz_null lip A ha) hb
  refine ⟨toMeasurable volume bad,measurableSet_toMeasurable ..,by rwa [measure_toMeasurable],?_⟩
  intro z hz
  have hnot : f z ∉ bad := fun e => hz (subset_toMeasurable volume bad e)
  have diff : DifferentiableAt ℝ f z := by
    by_contra hh
    exact hnot (Or.inl (mem_image_of_mem f (show z ∈ A from hh)))
  exact ⟨diff,fun hh => hnot (Or.inr (mem_image_of_mem f (show z ∈ B from ⟨diff,hh⟩)))⟩

/-- On a set on which the monotone graph selection is continuous, a *single*
Borel null set of spatial endpoints suffices for restricted differentiability
on the whole original set. No Lipschitz or differentiability assumption on U. -/
theorem minty_regular_on {d : ℕ} (U : RankPoint d → RankPoint d) (G : Set (RankPoint d))
    (mon : RankMonotoneOn U G) (cont : ContinuousOn U G) :
    ∃ N : Set (RankPoint d), MeasurableSet N ∧ volume N = 0 ∧
      ∀ x ∈ G, x ∉ N → DifferentiableWithinAt ℝ U G x := by
  obtain ⟨f,lip,inv⟩ := minty_inverse_extension U G mon
  obtain ⟨N,me,null,regular⟩ := minty_critical_values f _ lip
  refine ⟨N,me,null,?_⟩
  intro x hx xn
  let z := fun y => y+U y
  have good := regular (z x) (by simpa [z,inv x hx] using xn)
  let L := fderiv ℝ f (z x)
  let e : RankPoint d ≃L[ℝ] RankPoint d :=
    (LinearMap.equivOfDetNeZero L.toLinearMap good.2).toContinuousLinearEquiv
  have df : HasFDerivWithinAt f (e : RankPoint d →L[ℝ] RankPoint d) univ (z x) :=
    good.1.hasFDerivAt.hasFDerivWithinAt
  have hz := df.of_local_left_inverse (g := z)
    ((continuousWithinAt_id.add (cont x hx)).tendsto_nhdsWithin (mapsTo_univ ..)) hx
    (Filter.mem_of_superset self_mem_nhdsWithin fun y hy => inv y hy)
  have du := hz.sub (hasFDerivWithinAt_id x G)
  have ident : z-id = U := by funext y; change (y+U y)-y=U y; abel
  rw [ident] at du
  exact du.differentiableWithinAt

end
end SequentialRanks
