import ExactInterception

open MeasureTheory Filter Set
open scoped BigOperators RealInnerProductSpace ENNReal NNReal Topology
open OAI.Problem358

namespace BrenierReplacement
noncomputable section

/-- The exact finite endpoint supporting potentials, with repeated endpoint sites allowed. -/
theorem exact_finite_support_potential_bound {d : ℕ} {I : Type*} [Fintype I] [Nonempty I]
    [LinearOrder I] [MeasurableSpace I] [MeasurableSingletonClass I]
    (K : Set (E d)) (hK : IsCompact K) (hcv : Convex ℝ K) (hint : (interior K).Nonempty)
    (R : ℝ≥0) (hR : ∀ x ∈ K, ‖x‖ ≤ R)
    (y z : I → E d)
    (hinj : ∀ t : ℝ, 0 < t → t < 1 → Function.Injective (fun i => (1-t) • y i+t • z i))
    (m : I → ℝ) (hm : ∀ i, 0 < m i) (hmass : ∑ i, m i = 1)
    (L : ℝ≥0) (hyL : ∀ i, ‖y i‖ ≤ L) (hzL : ∀ i, ‖z i‖ ≤ L) :
    ∃ (u v : E d → ℝ) (T S : E d → E d),
      (∀ x w, u x + inner ℝ (T x) (w-x) ≤ u w) ∧
      (∀ x w, v x + inner ℝ (S x) (w-x) ≤ v w) ∧
      Measurable T ∧ Measurable S ∧ (∀ x, ‖T x‖ ≤ L) ∧ (∀ x, ‖S x‖ ≤ L) ∧
      Measure.map T (uniformMeasure K) = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (y i) ∧
      Measure.map S (uniformMeasure K) = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (z i) ∧
      (∫ x, (u x - v x)^2 ∂uniformMeasure K) ≤ ((2:ℝ)*R)^2 * ∑ i,m i*‖y i-z i‖^2 := by
  classical
  let q := (volume K)⁻¹
  let _ : IsProbabilityMeasure (q • volume.restrict K) := UniformSource.probability hK hint
  have hp0 : volume K ≠ 0 := (Measure.measure_pos_of_nonempty_interior volume hint).ne'
  have hq : q ≠ ⊤ := ENNReal.inv_ne_top.mpr hp0
  let W (i : I) := z i-y i
  let Y (t : ℝ) (i : I) := y i+t • W i
  have hY : Continuous Y := by unfold Y W; fun_prop
  have diff (t : ℝ) (i : I) : Y t i = (1-t) • y i+t • z i := by
    simp only [Y,W,smul_sub,sub_smul,one_smul]
    abel
  have hy0 : Y 0 = y := by ext i; simp [Y]
  have hy1 : Y 1 = z := by ext i; simp [Y,W]
  have hI (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) : Function.Injective (Y t) := by
    convert hinj t ht.1 ht.2 using 1
    funext i
    exact diff t i
  obtain ⟨c,hnorm,hcell,hlip⟩ := exact_actual_weighted_intercept_path K hK hcv hint R hR y W hI m hm hmass
  let A := Real.sqrt (∑ i,m i*‖W i‖^2)
  obtain ⟨dC,hdC,heq,_⟩ := weightedIntercept_exists_normalized_extension c m 0 1
    ((R : ℝ)*A) (by norm_num) (mul_nonneg R.coe_nonneg (Real.sqrt_nonneg _)) hm hnorm
    (by intro t ht s hs; exact hlip s hs t ht)
  have hc (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) (i : I) :
      (uniformMeasure K).real (strictBodyCell (Y t) (dC t) i) = m i := by
    rw [← heq ht]
    exact hcell t ht i
  have hh (s : ℝ) (hs : s ∈ Ioo (0 : ℝ) 1) (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) :
      Real.sqrt (∑ i,m i*(dC t i-dC s i)^2) ≤ (R : ℝ)*A*|t-s| := by
    rw [← heq hs, ← heq ht]
    exact hlip s hs t ht
  let U (t : ℝ) (x : E d) := Finset.univ.sup' Finset.univ_nonempty (fun i => inner ℝ (Y t i) x+dC t i)
  have hInteriorOrdered (s t : ℝ) (hs : s ∈ Ioo (0 : ℝ) 1)
      (ht : t ∈ Ioo (0 : ℝ) 1) (hst : s ≤ t) :
      Real.sqrt (∫ x, (U t x-U s x)^2 ∂uniformMeasure K) ≤ 2*(R : ℝ)*A*(t-s) := by
    have hi : Icc s t ⊆ Ioo (0 : ℝ) 1 := fun r hr => ⟨hs.1.trans_le hr.1,hr.2.trans_lt ht.2⟩
    apply body_potential_L2_subinterval_bound volume K hK q hq R hR y W dC m hm s t hst
      (fun r hr => hI r (hi hr)) (fun r _ => hdC.continuousAt) (fun r hr => hc r (hi hr))
    intro r hr
    have ht' : Continuous (fun δ : ℝ => r+δ) := continuous_const.add continuous_id
    have hv : ∀ᶠ δ : ℝ in 𝓝 0, r+δ ∈ Ioo (0 : ℝ) 1 := by
      have ht0 : Tendsto (fun δ : ℝ => r+δ) (𝓝 0) (𝓝 r) := by
        simpa only [add_zero] using (ht'.continuousAt (x := 0)).tendsto
      exact ht0.eventually (isOpen_Ioo.mem_nhds (hi hr))
    filter_upwards [hv.filter_mono nhdsWithin_le_nhds] with δ hδ
    have h := hh r (hi hr) (r+δ) hδ
    simpa only [add_sub_cancel_left] using h
  have hInterior (s : ℝ) (hs : s ∈ Ioo (0 : ℝ) 1) (t : ℝ) (ht : t ∈ Ioo (0 : ℝ) 1) :
      Real.sqrt (∫ x, (U t x-U s x)^2 ∂uniformMeasure K) ≤ (2*(R : ℝ)*A)*|t-s| := by
    rcases le_total s t with h|h
    · rw [abs_of_nonneg (sub_nonneg.mpr h)]
      exact hInteriorOrdered s t hs ht h
    · rw [abs_of_nonpos (sub_nonpos.mpr h), neg_sub]
      have he (x : E d) : (U t x-U s x)^2 = (U s x-U t x)^2 := by ring
      simp_rw [he]
      exact hInteriorOrdered t s ht hs h
  have hEnd := body_potential_L2_colliding_endpoint_bound volume K hK q R hR Y dC hY hdC 0 1
    (2*(R : ℝ)*A) (by norm_num) hInterior
  have hFuse (t : ℝ) (ht : t ∈ Icc (0 : ℝ) 1) (htL : ∀ i, ‖Y t i‖ ≤ L) :
      ∃ T : E d → E d, Measurable T ∧
      Measure.map T (uniformMeasure K) = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (Y t i) ∧
      (∀ x, ‖T x‖ ≤ L) ∧ ∀ x w, U t x + inner ℝ (T x) (w-x) ≤ U t w := by
    let l := 𝓝[Ioo (0 : ℝ) 1] t
    have hn : l.NeBot := by
      apply mem_closure_iff_nhdsWithin_neBot.mp
      rwa [closure_Ioo (show (0:ℝ) ≠ 1 by norm_num)]
    let _ : l.NeBot := hn
    have hIn : ∀ᶠ r in l, r ∈ Ioo (0 : ℝ) 1 := self_mem_nhdsWithin
    exact fused_endpoint_globalSupport_and_pushforward volume K hK q hq l Y dC (Y t) (dC t) m
      (fun i => (hm i).le) L htL (fun i => ((continuous_apply i).comp hY).continuousAt.tendsto.mono_left nhdsWithin_le_nhds)
      (fun i => ((continuous_apply i).comp hdC).continuousAt.tendsto.mono_left nhdsWithin_le_nhds)
      (hIn.mono fun r hr => hI r hr) (hIn.mono fun r hr => hc r hr)
  obtain ⟨T,hT,hTlaw,hTL,hTs⟩ := hFuse 0 (by simp) (by simpa only [hy0] using hyL)
  obtain ⟨S,hS,hSlaw,hSL,hSs⟩ := hFuse 1 (by simp) (by simpa only [hy1] using hzL)
  refine ⟨U 0,U 1,T,S,hTs,hSs,hT,hS,hTL,hSL,by simpa only [hy0] using hTlaw,
    by simpa only [hy1] using hSlaw,?_⟩
  have hInt : 0 ≤ ∫ x, (U 1 x-U 0 x)^2 ∂uniformMeasure K :=
    integral_nonneg fun _ => sq_nonneg _
  change Real.sqrt (∫ x, (U 1 x-U 0 x)^2 ∂uniformMeasure K) ≤ (2*(R : ℝ)*A)*(1-0) at hEnd
  have h := pow_le_pow_left₀ (Real.sqrt_nonneg _) (show Real.sqrt (∫ x, (U 1 x-U 0 x)^2 ∂uniformMeasure K)
      ≤ 2*(R : ℝ)*A by simpa only [sub_zero, mul_one] using hEnd) 2
  have hms : 0 ≤ ∑ i,m i*‖W i‖^2 :=
    Finset.sum_nonneg fun i _ => mul_nonneg (hm i).le (sq_nonneg _)
  rw [Real.sq_sqrt hInt, mul_pow, show A^2 = ∑ i,m i*‖W i‖^2 from Real.sq_sqrt hms] at h
  have equal1 (x : E d) : (U 0 x-U 1 x)^2 = (U 1 x-U 0 x)^2 := by ring
  simp_rw [equal1]
  simpa only [W, norm_sub_rev] using h

#print axioms exact_finite_support_potential_bound

end
end BrenierReplacement
