import CompactCellPairs
import HarmonicCoefficientExtract
open MeasureTheory Filter Set Metric
open scoped ENNReal Topology
namespace Residual
open SequentialRanks
noncomputable section
private theorem dummy {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsProbabilityMeasure ρ] (A : Set X) :
    ∃ p : ProbabilityMeasure X, ρ A • (p : Measure X)=ρ.restrict A := by
  by_cases h : ρ A = 0
  · exact ⟨⟨ρ,inferInstance⟩,by simp [h,Measure.restrict_eq_zero.mpr h]⟩
  · exact ⟨_,normalize_scale ρ A h⟩

/-- A coupling for any two measurable cells, including disappearing cells, under the given
log-concave density on all of Euclidean space. -/
theorem compact_cell_harmonic_coupling {d} (w : RankPoint d → ℝ) (mw : Measurable w) (wn : ∀ x,0≤w x)
    (logmid : ∀ x y,Real.sqrt (w x)*Real.sqrt (w y)≤w (mid x y))
    [IsProbabilityMeasure (weighted volume w)] (K : Set (RankPoint d))
    (hk : IsCompact K) [Nonempty K] (hsup : ∀ᵐ x ∂weighted volume w, x ∈ K)
    (A B : Set (RankPoint d))
    (mA : MeasurableSet A) (mB : MeasurableSet B) :
    let ρ := weighted volume w
    ∃ γ : ProbabilityMeasure (RankPoint d × RankPoint d),
      ρ A • (γ : Measure (RankPoint d × RankPoint d)).map Prod.fst = ρ.restrict A ∧
      ρ B • (γ : Measure (RankPoint d × RankPoint d)).map Prod.snd = ρ.restrict B ∧
      ENNReal.ofReal (Vortex.harmonicMass (ρ.real A) (ρ.real B)) • (γ : Measure (RankPoint d × RankPoint d)).map midpoint ≤ ρ := by
  let ρ := weighted volume w
  by_cases both : ρ A ≠ 0 ∧ ρ B ≠ 0
  · obtain ⟨π,f,g,dom⟩ := positive_cell_pair_compact w mw wn logmid K hk hsup A B mA mB both.1 both.2
    have pf := congrArg ProbabilityMeasure.toMeasure f
    have pg := congrArg ProbabilityMeasure.toMeasure g
    change (π : Measure (RankPoint d × RankPoint d)).map Prod.fst = _ at pf
    change (π : Measure (RankPoint d × RankPoint d)).map Prod.snd = _ at pg
    refine ⟨π,pf ▸ normalize_scale ρ A both.1,pg ▸ normalize_scale ρ B both.2,?_⟩
    let a := ρ.real A
    let b := ρ.real B
    have pa : 0<a := ENNReal.toReal_pos both.1 (measure_ne_top _ _)
    have pb : 0<b := ENNReal.toReal_pos both.2 (measure_ne_top _ _)
    have hab := Vortex.harmonic_le_sqrt pa.le pb.le
    have coeff : ENNReal.ofReal (Vortex.harmonicMass a b) * ENNReal.ofReal (Real.sqrt a⁻¹*Real.sqrt b⁻¹) ≤ 1 := by
      rw [← ENNReal.ofReal_mul (Vortex.harmonic_nonneg pa.le pb.le), Real.sqrt_inv,Real.sqrt_inv,
        ←mul_inv,←Real.sqrt_mul pa.le,←div_eq_mul_inv,ENNReal.ofReal_le_one]
      exact (div_le_one (Real.sqrt_pos.mpr (mul_pos pa pb))).mpr hab
    intro S
    exact (mul_le_mul_of_nonneg_left (dom S) zero_le).trans (by
      change _ * (_ * ρ S) ≤ ρ S
      rw [←mul_assoc]
      simpa using mul_le_mul_of_nonneg_right coeff zero_le)
  · obtain ⟨p,hp⟩ := dummy ρ A
    obtain ⟨q,hq⟩ := dummy ρ B
    let π : ProbabilityMeasure (RankPoint d × RankPoint d) := ⟨(p : Measure _).prod (q : Measure _),inferInstance⟩
    refine ⟨π,by simpa [π] using hp,by simpa [π] using hq,?_⟩
    have : ρ A = 0 ∨ ρ B = 0 := by tauto
    rcases this with h|h <;>
      change ENNReal.ofReal (Vortex.harmonicMass (ρ.real A) (ρ.real B)) • _ ≤ ρ <;>
      simp [Measure.real, h,Vortex.harmonicMass] <;> exact bot_le
end
end Residual
