import ResidualDiagram

open MeasureTheory Set Filter SequentialRanks
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

variable {I : Type*} [Fintype I] [Nonempty I] [LinearOrder I] {d : ℕ}

private def winners (v : I → RankPoint d) (c : I → ℝ) (x : RankPoint d) : Finset I := by
  classical
  exact Finset.univ.filter (fun i => x ∈ powerCell v c i)

omit [Nonempty I] [LinearOrder I] in
private theorem mem_winners (v : I → RankPoint d) (c : I → ℝ) (x : RankPoint d) (i : I) :
    i ∈ winners v c x ↔ x ∈ powerCell v c i := by classical simp [winners]

omit [LinearOrder I] in
private theorem winners_nonempty (v : I → RankPoint d) (c : I → ℝ) (x : RankPoint d) :
    (winners v c x).Nonempty := by
  obtain ⟨i,_,hi⟩ := Finset.exists_max_image Finset.univ (fun l => powerScore v c l x) Finset.univ_nonempty
  exact ⟨i,(mem_winners _ _ _ _).2 (fun l => hi l (Finset.mem_univ l))⟩

/-- The least label attaining the largest score, with the same ordering at both endpoints. -/
def powerTag (v : I → RankPoint d) (c : I → ℝ) (x : RankPoint d) : I :=
  (winners v c x).min' (winners_nonempty v c x)

theorem powerTag_wins (v : I → RankPoint d) (c : I → ℝ) (x : RankPoint d) :
    x ∈ powerCell v c (powerTag v c x) :=
  (mem_winners _ _ _ _).1 (Finset.min'_mem _ _)

theorem powerTag_eq (v : I → RankPoint d) (c : I → ℝ) (i : I) (x : RankPoint d) :
    powerTag v c x = i ↔ x ∈ powerCell v c i ∧ ∀ l, l < i → x ∉ powerCell v c l := by
  constructor
  · rintro rfl
    refine ⟨powerTag_wins _ _ _,fun l lt hl => ?_⟩
    exact (not_le_of_gt lt) (Finset.min'_le _ _ ((mem_winners _ _ _ _).2 hl))
  · rintro ⟨hi,first⟩
    have le : powerTag v c x ≤ i := Finset.min'_le _ _ ((mem_winners _ _ _ _).2 hi)
    exact le.eq_or_lt.resolve_right fun lt => first _ lt (powerTag_wins _ _ _)

theorem measurable_powerTag [MeasurableSpace I] (v : I → RankPoint d) (c : I → ℝ) :
    Measurable (powerTag v c) := by
  apply measurable_to_countable'
  intro i
  have e : powerTag v c ⁻¹' {i} = powerCell v c i ∩ ⋂ (l : I) (_ : l < i), (powerCell v c l)ᶜ := by
    ext x
    simp only [mem_preimage,mem_singleton_iff,powerTag_eq,mem_inter_iff,mem_iInter,mem_compl_iff]
  rw [e]
  exact (measurableSet_powerCell v c i).inter (MeasurableSet.iInter fun l => MeasurableSet.iInter fun _ =>
    (measurableSet_powerCell v c l).compl)
end
end Residual
