import StaticRankExistence
import RankMintyPSDLimit
import RankMintyConvex

open MeasureTheory Filter Set
open scoped ENNReal Topology
namespace SequentialRanks
noncomputable section

theorem good_hessian_set {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p w : RankPoint d → ℝ) (U : RankPoint d → RankPoint d) (mp : Measurable p) (mu : Measurable U)
    (law : (weighted volume p).map U = weighted volume w) (rank : compactRankGraph A B p U) :
    ∃ (φ : RankPoint d → ℝ) (G : Set (RankPoint d)) (a : RankPoint d → RankDifferential d),
      ConvexOn ℝ univ φ ∧ MeasurableSet G ∧ (∀ᵐ x ∂volume, 0 < p x → x ∈ G) ∧ InjOn U G ∧
      (∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x) ∧ (∀ x ∈ G, HasFDerivWithinAt U (a x) G x) ∧
      ∀ x ∈ G, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef := by
  obtain ⟨φ,S,cv,ms,fullS,onS,inj,grad⟩ := compact_rank_good_set A B ha hb p w U mp mu law rank
  obtain ⟨N,mn,n0,der⟩ := rank_gradient_regular φ U S B hb onS cv grad
  let T := S \ N
  let a := fun x => fderivWithin ℝ U S x
  have mt : MeasurableSet T := ms.diff mn
  have sub : T ⊆ S := sdiff_subset
  have dt (x) (hx : x ∈ T) : HasFDerivWithinAt U (a x) T x := (der x hx.1 hx.2).mono sub
  have pos := (ae_restrict_iff' mt).mp (convex_gradient_derivative_psd_ae T mt U a φ
    (fun y hy z _ => rank_convex_support cv (grad y hy.1) z) dt)
  obtain ⟨E,bad,me,e0⟩ := exists_measurable_superset_of_null (ae_iff.mp pos)
  let G := T \ E
  have gt : G ⊆ T := sdiff_subset
  have hn : ∀ᵐ x ∂volume, x ∉ N := ae_iff.mpr (by simpa using n0)
  have he : ∀ᵐ x ∂volume, x ∉ E := ae_iff.mpr (by simpa using e0)
  refine ⟨φ,G,a,cv,mt.diff me,?_,inj.mono (gt.trans sub),fun x hx => grad x hx.1.1,
    fun x hx => (dt x hx.1).mono gt,?_⟩
  · filter_upwards [fullS,hn,he] with x h xn xe px using ⟨⟨h px,xn⟩,xe⟩
  · intro x hx
    by_contra h
    exact hx.2 (bad (show ¬ (x ∈ T → (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef) from fun h' => h (h' hx.1)))

end
end SequentialRanks
