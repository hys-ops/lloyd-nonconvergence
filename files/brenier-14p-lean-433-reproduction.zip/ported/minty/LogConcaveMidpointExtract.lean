import RankEndpointJacobianExtract
import Mathlib.Analysis.SpecialFunctions.Log.Basic
open MeasureTheory Set Matrix
open scoped ENNReal
namespace SequentialRanks
noncomputable section
/-- Midpoint log-concavity also holds when one endpoint is outside the
positive-density set. The finite logarithm is used only on that set. -/
theorem log_concave_density_midpoint {d : ℕ} (w : RankPoint d → ℝ) (wn : ∀ y, 0 ≤ w y)
    (conc : ConcaveOn ℝ {z | 0 < w z} (fun z => Real.log (w z))) (u v : RankPoint d) :
    Real.sqrt (w u)*Real.sqrt (w v) ≤ w (mid u v) := by
  by_cases hu : 0 < w u
  · by_cases hv : 0 < w v
    · have m : (1/2:ℝ) • u + (1/2:ℝ) • v = mid u v := by funext i; change (1/2:ℝ) * u i + (1/2:ℝ) * v i = (u i+v i)/2; ring
      have pos := conc.1 (show u ∈ {z | 0 < w z} from hu) (show v ∈ {z | 0 < w z} from hv)
        (show (0:ℝ) ≤ 1/2 by norm_num) (show (0:ℝ) ≤ 1/2 by norm_num) (by norm_num)
      have l := conc.2 (show u ∈ {z | 0 < w z} from hu) (show v ∈ {z | 0 < w z} from hv)
        (show (0:ℝ) ≤ 1/2 by norm_num) (show (0:ℝ) ≤ 1/2 by norm_num) (by norm_num)
      rw [m] at l pos
      apply (Real.log_le_log_iff (mul_pos (Real.sqrt_pos.mpr hu) (Real.sqrt_pos.mpr hv)) pos).mp
      rw [Real.log_mul (Real.sqrt_pos.mpr hu).ne' (Real.sqrt_pos.mpr hv).ne',
        Real.log_sqrt hu.le,Real.log_sqrt hv.le]
      simpa [smul_eq_mul,div_eq_inv_mul] using l
    · simpa [Real.sqrt_eq_zero_of_nonpos (le_of_not_gt hv)] using wn (mid u v)
  · simpa [Real.sqrt_eq_zero_of_nonpos (le_of_not_gt hu)] using wn (mid u v)

end
end SequentialRanks
