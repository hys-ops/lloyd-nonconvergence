import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.MeasureTheory.Measure.Support
import Mathlib.MeasureTheory.Measure.Prokhorov

open MeasureTheory ProbabilityTheory Filter Set
open scoped Topology BigOperators
namespace SequentialRanks
noncomputable section

def cyclicSupport {Y K : Type*} [TopologicalSpace Y] [TopologicalSpace K]
    [MeasurableSpace Y] [MeasurableSpace K] (c : Y × K → ℝ) (π : ProbabilityMeasure (Y × K)) : Prop :=
  ∀ (n : ℕ) (σ : Equiv.Perm (Fin n)) (z : Fin n → Y × K),
    (∀ i, z i ∈ (π : Measure (Y × K)).support) →
    ∑ i, c (z i) ≤ ∑ i, c ((z i).1,(z (σ i)).2)

def certifiedPlan {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (c : Y × K → ℝ) (source : ProbabilityMeasure Y) (target : ProbabilityMeasure K)
    (π : ProbabilityMeasure (Y × K)) : Prop :=
  π.map (measurable_fst.aemeasurable) = source ∧
  π.map (measurable_snd.aemeasurable) = target ∧ cyclicSupport c π

end
end SequentialRanks
