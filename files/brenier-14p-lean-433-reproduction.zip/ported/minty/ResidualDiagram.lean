import ResidualFinite
import StaticRankConvex
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

open MeasureTheory Set Filter Function SequentialRanks
open scoped ENNReal BigOperators
namespace Residual
noncomputable section

variable {d : ℕ} {I : Type*}

/-- Affine score with Euclidean slope v_i; coordinates use the ordinary dot product. -/
def powerScore (v : I → RankPoint d) (c : I → ℝ) (i : I) (x : RankPoint d) : ℝ :=
  rankCovector (v i) x + c i

def powerCell (v : I → RankPoint d) (c : I → ℝ) (i : I) : Set (RankPoint d) :=
  {x | ∀ l, powerScore v c l x ≤ powerScore v c i x}

theorem measurableSet_powerCell [Countable I] (v : I → RankPoint d) (c : I → ℝ) (i : I) :
    MeasurableSet (powerCell v c i) := by
  change MeasurableSet {x | ∀ l, _}
  simp only [ofPred_forall]
  exact MeasurableSet.iInter fun l => measurableSet_le
    ((rankCovector (v l)).continuous.measurable.add measurable_const)
    ((rankCovector (v i)).continuous.measurable.add measurable_const)

/-- Distinct slopes, including in noncompact supports, give null affine score ties. -/
theorem power_score_tie_null (ρ : Measure (RankPoint d)) (ac : ρ ≪ volume)
    (v : I → RankPoint d) (inj : Injective v) (c : I → ℝ) {i l : I} (diff : i ≠ l) :
    ρ {x | powerScore v c i x = powerScore v c l x} = 0 := by
  let f := (rankCovector (v i) - rankCovector (v l)).toLinearMap.toAffineMap
  let H := (affineSpan ℝ ({c l-c i} : Set ℝ)).comap f
  have mem (x : RankPoint d) : x ∈ H ↔ powerScore v c i x = powerScore v c l x := by
    change f x ∈ affineSpan ℝ ({c l-c i} : Set ℝ) ↔ _
    rw [AffineSubspace.mem_affineSpan_singleton]
    change rankCovector (v i) x - rankCovector (v l) x = c l-c i ↔ _
    unfold powerScore
    constructor <;> intro h <;> linarith
  have proper : H ≠ ⊤ := by
    intro full
    have all (x : RankPoint d) : powerScore v c i x = powerScore v c l x :=
      (mem x).mp (by simp [full])
    have intercept : c i = c l := by simpa only [powerScore,map_zero,zero_add] using all 0
    apply diff (inj (rank_covector_injective ?_))
    ext x
    exact add_right_cancel (by simpa only [powerScore,intercept] using all x : rankCovector (v i) x+c l=rankCovector (v l) x+c l)
  apply ac
  have eqn : {x | powerScore v c i x = powerScore v c l x} = (H : Set (RankPoint d)) :=
    Set.ext (fun x => (mem x).symm)
  rw [eqn]
  exact Measure.addHaar_affineSubspace volume H proper

def commonLabel (ρ : Measure (RankPoint d)) (j k : RankPoint d → I) (i : I) : Prop :=
  0 < mass ρ j i ∧ 0 < mass ρ k i

/-- Restricted comparison region. A disappearing label imposes no restrictions and
has no middle measure. This also accommodates finite targets with differing sites. -/
def activePowerCell (v : I → RankPoint d) (c : I → ℝ) (active : I → Prop) (i : I) : Set (RankPoint d) :=
  {x | active i ∧ ∀ l, active l → powerScore v c l x ≤ powerScore v c i x}

theorem measurableSet_activePowerCell [Countable I] (v : I → RankPoint d) (c : I → ℝ) (active : I → Prop) (i : I) :
    MeasurableSet (activePowerCell v c active i) := by
  classical
  unfold activePowerCell
  simp only [ofPred_and,ofPred_forall]
  apply MeasurableSet.inter (MeasurableSet.const _)
  apply MeasurableSet.iInter
  intro l
  apply MeasurableSet.iInter
  intro _
  exact measurableSet_le ((rankCovector (v l)).continuous.measurable.add measurable_const)
    ((rankCovector (v i)).continuous.measurable.add measurable_const)

theorem active_power_cells_disjoint (ρ : Measure (RankPoint d)) (ac : ρ ≪ volume)
    (v : I → RankPoint d) (inj : Injective v) (c : I → ℝ) (active : I → Prop) :
    Pairwise (AEDisjoint ρ on activePowerCell v c active) := by
  intro i l diff
  apply measure_mono_null _ (power_score_tie_null ρ ac v inj c diff)
  exact fun x ⟨hi,hl⟩ => le_antisymm (hl.2 i hi.1) (hi.2 l hl.1)

theorem power_midpoint_compare (v : I → RankPoint d) (c e : I → ℝ) (i l : I) (x y : RankPoint d)
    (left : powerScore v c l x ≤ powerScore v c i x) (right : powerScore v e l y ≤ powerScore v e i y) :
    powerScore v (fun k => (c k+e k)/2) l (midpoint (x,y)) ≤
      powerScore v (fun k => (c k+e k)/2) i (midpoint (x,y)) := by
  simp only [powerScore,midpoint,map_smul,map_add,smul_eq_mul] at *
  linarith only [left,right]

private theorem active_endpoint {X Z : Type*} [MeasurableSpace X] [MeasurableSpace Z]
    (ρ : Measure X) (P : Measure Z) (A : Set X) (nz : ρ A ≠ 0) (f : Z → X) (mf : Measurable f)
    (law : ρ A • P.map f = ρ.restrict A) {p : X → Prop} (ae : ∀ᵐ x ∂ρ.restrict A, p x) :
    ∀ᵐ z ∂P, p (f z) := by
  rw [←law] at ae
  exact ae_of_ae_map mf.aemeasurable ((Measure.ae_ennreal_smul_measure_iff nz).mp ae)

variable [Fintype I] [MeasurableSpace I] [MeasurableSingletonClass I]

/-- Localize each globally dominated midpoint to its averaged diagram cell. The sum
remains dominated, even when either endpoint lacks some labels. -/
def diagram_couplings (ρ : Measure (RankPoint d)) [IsProbabilityMeasure ρ] (ac : ρ ≪ volume)
    (v : I → RankPoint d) (inj : Injective v) (c e : I → ℝ) (j k : RankPoint d → I)
    (winsL : ∀ i, commonLabel ρ j k i → ∀ᵐ x ∂ρ.restrict (j ⁻¹' {i}), ∀ l, commonLabel ρ j k l →
      powerScore v c l x ≤ powerScore v c i x)
    (winsR : ∀ i, commonLabel ρ j k i → ∀ᵐ x ∂ρ.restrict (k ⁻¹' {i}), ∀ l, commonLabel ρ j k l →
      powerScore v e l x ≤ powerScore v e i x)
    (plans : I → ProbabilityMeasure (RankPoint d × RankPoint d))
    (left : ∀ i, ρ (j ⁻¹' {i}) • (plans i : Measure (RankPoint d × RankPoint d)).map Prod.fst = ρ.restrict (j ⁻¹' {i}))
    (right : ∀ i, ρ (k ⁻¹' {i}) • (plans i : Measure (RankPoint d × RankPoint d)).map Prod.snd = ρ.restrict (k ⁻¹' {i}))
    (middle : ∀ i, ENNReal.ofReal (Vortex.harmonicMass (mass ρ j i) (mass ρ k i)) •
      (plans i : Measure (RankPoint d × RankPoint d)).map midpoint ≤ ρ) : CoupledCells ρ j k := by
  classical
  let h := fun i => ENNReal.ofReal (Vortex.harmonicMass (mass ρ j i) (mass ρ k i))
  let η := fun i => h i • (plans i : Measure (RankPoint d × RankPoint d)).map midpoint
  let cells := activePowerCell v (fun i => (c i+e i)/2) (commonLabel ρ j k)
  have mcell (i) : MeasurableSet (cells i) := measurableSet_activePowerCell _ _ _ _
  have mm : Measurable (@midpoint (RankPoint d) _ _) := by unfold midpoint; fun_prop
  have loc (i) : η i ≤ ρ.restrict (cells i) := by
    by_cases hi : commonLabel ρ j k i
    · have nzL : ρ (j ⁻¹' {i}) ≠ 0 := fun hz => hi.1.ne' (by simp [mass,Measure.real,hz])
      have nzR : ρ (k ⁻¹' {i}) ≠ 0 := fun hz => hi.2.ne' (by simp [mass,Measure.real,hz])
      have aL := active_endpoint ρ (plans i : Measure (RankPoint d × RankPoint d)) _ nzL Prod.fst measurable_fst (left i) (winsL i hi)
      have aR := active_endpoint ρ (plans i : Measure (RankPoint d × RankPoint d)) _ nzR Prod.snd measurable_snd (right i) (winsR i hi)
      have support : ∀ᵐ x ∂(plans i : Measure (RankPoint d × RankPoint d)).map midpoint, x ∈ cells i := by
        apply (ae_map_iff mm.aemeasurable (mcell i)).2
        filter_upwards [aL,aR] with z hl hr
        exact ⟨hi,fun l al => power_midpoint_compare _ _ _ _ _ z.1 z.2 (hl l al) (hr l al)⟩
      have support' : ∀ᵐ x ∂η i, x ∈ cells i := (Measure.AbsolutelyContinuous.rfl.smul_left _).ae_le support
      rw [← Measure.restrict_eq_self_of_ae_mem support']
      exact Measure.restrict_mono Subset.rfl (middle i)
    · have zero : h i = 0 := by
        unfold commonLabel at hi
        push Not at hi
        rcases eq_or_lt_of_le (show 0 ≤ mass ρ j i from measureReal_nonneg) with a|a
        · simp [h,Vortex.harmonicMass,←a]
        · have b := le_antisymm (hi a) (show 0 ≤ mass ρ k i from measureReal_nonneg)
          simp [h,Vortex.harmonicMass,b]
      simp only [η,zero,zero_smul]
      exact fun _ => zero_le
  refine ⟨plans,left,right, Measure.le_iff.mpr ?_⟩
  intro s ms
  change (∑ i, η i) s ≤ _
  rw [Measure.finsetSum_apply]
  have total := Measure.restrict_iUnion_apply_ae (active_power_cells_disjoint ρ ac v inj _ (commonLabel ρ j k))
    (fun i => (mcell i).nullMeasurableSet) ms
  rw [tsum_fintype] at total
  exact (Finset.sum_le_sum fun i _ => loc i s).trans (total ▸ Measure.restrict_le_self s)

end
end Residual
