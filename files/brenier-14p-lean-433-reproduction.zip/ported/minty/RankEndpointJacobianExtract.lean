import StaticRankConvex
import Mathlib.MeasureTheory.Function.Jacobian
import Mathlib.MeasureTheory.Function.AEEqOfLIntegral
import Mathlib.MeasureTheory.Measure.WithDensity

open MeasureTheory Set Matrix
open scoped ENNReal
namespace SequentialRanks
noncomputable section
def mid {d : ℕ} (u v : Fin d → ℝ) (i : Fin d) := (u i+v i)/2
def weighted {X : Type*} [MeasurableSpace X] (μ : Measure X) (f : X → ℝ) :=
  μ.withDensity (fun x => ENNReal.ofReal (f x))

/-- An endpoint marginal and injective differentiability on G already imply
the Jacobian inequality needed there. There is no Monge–Ampère identity among
the hypotheses, and other preimages outside G are allowed. -/
theorem endpoint_density_le_jacobian {d : ℕ} (p w : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) (a : RankPoint d → RankDifferential d)
    (G : Set (RankPoint d)) (hG : MeasurableSet G) (hp : Measurable p)
    (hU : Measurable U) (wn : ∀ y, 0 ≤ w y)
    (push : (weighted volume p).map U = weighted volume w)
    (reg : ∀ x ∈ G, HasFDerivWithinAt U (a x) G x) (inj : InjOn U G) :
    ∀ᵐ x ∂volume.restrict G, p x ≤ |(a x).det| * w (U x) := by
  have h : (fun x => ENNReal.ofReal (p x)) ≤ᵐ[volume.restrict G]
      (fun x => ENNReal.ofReal |(a x).det| * ENNReal.ofReal (w (U x))) := by
    apply ae_le_of_forall_setLIntegral_le_of_sigmaFinite (ENNReal.measurable_ofReal.comp hp)
    intro s hs _
    rw [Measure.restrict_restrict hs]
    let T := s ∩ G
    have mT : MeasurableSet T := hs.inter hG
    have tr : T ⊆ G := inter_subset_right
    have dT := fun x hx => (reg x (tr hx)).mono tr
    have mI := measurable_image_of_fderivWithin mT dT (inj.mono tr)
    have ar := lintegral_image_eq_lintegral_abs_det_fderiv_mul volume mT dT (inj.mono tr)
      (fun y => ENNReal.ofReal (w y))
    rw [← ar]
    calc
      _ = weighted volume p T := (withDensity_apply _ mT).symm
      _ ≤ weighted volume p (U ⁻¹' (U '' T)) := measure_mono (subset_preimage_image U T)
      _ = ((weighted volume p).map U) (U '' T) := (Measure.map_apply hU mI).symm
      _ = _ := by rw [push]; exact withDensity_apply _ mI
  filter_upwards [h] with x hx
  change ENNReal.ofReal (p x) ≤ ENNReal.ofReal |(a x).det| * ENNReal.ofReal _ at hx
  rw [← ENNReal.ofReal_mul (abs_nonneg _)] at hx
  exact (ENNReal.ofReal_le_ofReal_iff (mul_nonneg (abs_nonneg _) (wn _))).mp hx

end
end SequentialRanks
