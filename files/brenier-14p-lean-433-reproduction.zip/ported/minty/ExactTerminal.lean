import ExactFinitePotential
import OAI.Analysis.Brenier.AtomicPaths

open MeasureTheory Set
open scoped BigOperators RealInnerProductSpace ENNReal NNReal
open OAI.Problem358

namespace BrenierReplacement

/-- The all-target stability upper bound via the 14-page replacement's exact finite potential estimate. -/
theorem one_third_stability_via_compact_body_moments
    {d : ℕ} {K Y : Set (E d)}
    (hK : IsCompact K) (hKconv : Convex ℝ K)
    (hKint : (interior K).Nonempty) (hY : IsCompact Y) (hYne : Y.Nonempty)
    (L : ℝ≥0) (hYL : ∀ z ∈ Y, ‖z‖ ≤ L) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (μ ν : Measure (E d)),
      IsProbabilityMeasure μ → IsProbabilityMeasure ν →
      IsSupported μ Y → IsSupported ν Y →
      ∃ Tμ Tν : E d → E d,
        IsUniqueQuadraticOptimalMap (uniformMeasure K) μ Tμ ∧
        IsUniqueQuadraticOptimalMap (uniformMeasure K) ν Tν ∧
        mapL2Dist (uniformMeasure K) Tμ Tν ≤
          C * Real.rpow (wasserstein2 μ ν) (1 / 3 : ℝ) := by
  obtain ⟨r,hr⟩ := hK.isBounded.subset_closedBall (0 : E d)
  let R : ℝ≥0 := ⟨|r|,abs_nonneg _⟩
  have hR (x : E d) (hx : x ∈ K) : ‖x‖ ≤ R := by
    have h := Metric.mem_closedBall.mp (hr hx)
    rw [dist_zero_right] at h
    exact h.trans (le_abs_self _)
  apply one_third_stability_of_atomic_potential_estimate hK hKconv hKint hY hYne L hYL (2*(R : ℝ))
  intro n hn m y z hm hmass hyL hzL hinj
  let _ : Nonempty (Fin n) := Fin.pos_iff_nonempty.mp hn
  let _ : MeasurableSpace (Fin n) := ⊤
  let _ : MeasurableSingletonClass (Fin n) := ⟨fun _ => trivial⟩
  obtain ⟨u,v,T,S,hu,hv,hT,hS,hTL,hSL,hTlaw,hSlaw,hsq⟩ :=
    exact_finite_support_potential_bound K hK hKconv hKint R hR y z hinj m hm hmass L hyL hzL
  refine ⟨u,v,T,S,?_,?_,hT,hS,hTL,hSL,hTlaw,hSlaw,0,?_⟩
  · intro x w
    simpa only [real_inner_comm (w-x) (T x)] using hu x w
  · intro x w
    simpa only [real_inner_comm (w-x) (S x)] using hv x w
  · simpa only [sub_zero] using hsq

/-- The 14-page upper bound stated without a chosen target radius. -/
theorem one_third_stability_for_all_compact_targets
    {d : ℕ} {K Y : Set (E d)}
    (hK : IsCompact K) (hKconv : Convex ℝ K)
    (hKint : (interior K).Nonempty) (hY : IsCompact Y) (hYne : Y.Nonempty) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (μ ν : Measure (E d)),
      IsProbabilityMeasure μ → IsProbabilityMeasure ν →
      IsSupported μ Y → IsSupported ν Y →
      ∃ Tμ Tν : E d → E d,
        IsUniqueQuadraticOptimalMap (uniformMeasure K) μ Tμ ∧
        IsUniqueQuadraticOptimalMap (uniformMeasure K) ν Tν ∧
        mapL2Dist (uniformMeasure K) Tμ Tν ≤
          C * Real.rpow (wasserstein2 μ ν) (1 / 3 : ℝ) := by
  obtain ⟨r,hr⟩ := hY.isBounded.subset_closedBall (0 : E d)
  let L : ℝ≥0 := ⟨|r|,abs_nonneg _⟩
  refine one_third_stability_via_compact_body_moments hK hKconv hKint hY hYne L ?_
  intro y hy
  have h := Metric.mem_closedBall.mp (hr hy)
  rw [dist_zero_right] at h
  exact h.trans (le_abs_self _)

#print axioms OAI.Problem358.one_third_stability_of_atomic_potential_estimate
#print axioms BrenierReplacement.one_third_stability_for_all_compact_targets
#print axioms BrenierReplacement.one_third_stability_via_compact_body_moments

end BrenierReplacement
