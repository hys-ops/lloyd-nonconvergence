import StaticRankConvex
import PredictiveRanks
import CyclicPlans
import Mathlib.Logic.Equiv.Fin.Rotate

open Set MeasureTheory
open scoped BigOperators NNReal ENNReal
namespace SequentialRanks
noncomputable section
private theorem cost_move {d} {A B : Set (RankPoint d)} (x y : A) (u : B) :
    squareCost (y,u) - squareCost (x,u) =
      normSq y.val-normSq x.val-2*rankCovector u.val (y.val-x.val) := by
  unfold squareCost normSq diff rankCovector
  simp only [sum_apply,smul_apply,ContinuousLinearMap.proj_apply,
    Pi.sub_apply,smul_eq_mul]
  rw [←Finset.sum_sub_distrib,←Finset.sum_sub_distrib,Finset.mul_sum,←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl; intro i _; ring

private theorem cycle_work {d} {A B : Set (RankPoint d)} (π : ProbabilityMeasure (A × B))
    (cyc : cyclicSupport squareCost π) (n : ℕ) (z : ℕ → A × B)
    (hz : ∀ i,z i ∈ (π : Measure (A × B)).support) :
    (∑ i ∈ Finset.range n, rankCovector (z i).2.val ((z (i+1)).1.val-(z i).1.val))+
      rankCovector (z n).2.val ((z 0).1.val-(z n).1.val) ≤ 0 := by
  let s := finRotate (n+1)
  let q (i : Fin (n+1)) := z i
  have hh := cyc _ s.symm q (fun i => hz i)
  have reindex := Equiv.sum_comp s (fun i => squareCost ((q i).1,(q (s.symm i)).2))
  simp only [Equiv.symm_apply_apply] at reindex
  rw [←reindex] at hh
  have cost : (0:ℝ) ≤ ∑ i,squareCost ((q (s i)).1,(q i).2)- ∑ i,squareCost (q i) := sub_nonneg.mpr hh
  rw [←Finset.sum_sub_distrib] at cost
  have compId (i : Fin (n+1)) := cost_move (q i).1 (q (s i)).1 (q i).2
  simp only [Prod.mk.eta] at compId
  simp_rw [compId] at cost
  rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib,←Finset.mul_sum] at cost
  have cycNorm := Equiv.sum_comp s (fun i => normSq (q i).1.val)
  rw [cycNorm,sub_self,zero_sub] at cost
  have zz : (∑ i,rankCovector (q i).2.val ((q (s i)).1.val-(q i).1.val)) ≤ 0 := by linarith only [cost]
  rw [Fin.sum_univ_castSucc] at zz
  have rr (i : Fin n) : s i.castSucc = i.succ := finRotate_of_lt i.isLt
  simp only [rr] at zz
  change (∑ i : Fin n,rankCovector (z i).2.val ((z ((i:ℕ)+1)).1.val-(z i).1.val))+
    rankCovector (z n).2.val ((z (s (Fin.last n))).1.val-(z n).1.val) ≤ 0 at zz
  rw [show s (Fin.last n)=0 from finRotate_last,Fin.sum_univ_eq_sum_range (fun i => rankCovector (z i).2.val ((z (i+1)).1.val-(z i).1.val))] at zz
  exact zz

private def chainValue {d : ℕ} {A B : Set (RankPoint d)}
    (z : ℕ → A × B) (n : ℕ) (x : RankPoint d) : ℝ :=
  (∑ i ∈ Finset.range n,rankCovector (z i).2.val ((z (i+1)).1.val-(z i).1.val))+
    rankCovector (z n).2.val (x-(z n).1.val)

private theorem chain_shift {d} {A B : Set (RankPoint d)} (z : ℕ → A × B) (n : ℕ) (x y : RankPoint d) :
    chainValue z n x = chainValue z n y + rankCovector (z n).2.val (x-y) := by
  unfold chainValue; simp only [map_sub]; ring

/-- Rockafellar's finite-chain supremum for the quadratic transport cost.
Only the compactness of the destination is needed to obtain a globally
Lipschitz convex potential; every support pair gives a supporting plane. -/
theorem square_cyclic_potential {d : ℕ} (A B : Set (RankPoint d)) (hb : IsCompact B)
    (π : ProbabilityMeasure (A × B)) (cyc : cyclicSupport squareCost π) :
    ∃ (φ : RankPoint d → ℝ) (L : ℝ≥0), LipschitzWith L φ ∧ ConvexOn ℝ univ φ ∧
      ∀ z ∈ (π : Measure (A × B)).support, ∀ x : RankPoint d,
        rankCovector z.2.val (x-z.1.val) ≤ φ x-φ z.1.val := by
  classical
  let H := (π : Measure (A × B)).support
  obtain ⟨z₀,_,hz₀⟩ := Measure.nonempty_inter_support_of_pos
    (show 0 < (π : Measure (A × B)) univ by simp)
  have cv : Continuous (rankCovector : RankPoint d → (RankPoint d →L[ℝ] ℝ)) := by
    unfold rankCovector; fun_prop
  obtain ⟨K,hK⟩ := hb.bddAbove_image cv.norm.continuousOn
  let L := Real.toNNReal K
  have bound (u : B) : ‖rankCovector u.val‖ ≤ (L:ℝ) :=
    (hK (mem_image_of_mem _ u.property)).trans (Real.le_coe_toNNReal _)
  let vals (x : RankPoint d) := {r : ℝ | ∃ (z : ℕ → A × B) (n : ℕ), z 0=z₀ ∧
    (∀ i,z i ∈ H) ∧ r=chainValue z n x}
  let φ := fun x => sSup (vals x)
  have ne (x) : (vals x).Nonempty := ⟨_,fun _ => z₀,0,rfl,(fun _ => hz₀),rfl⟩
  have step (z : ℕ → A × B) (n) (x y : RankPoint d) :
      chainValue z n x ≤ chainValue z n y+(L:ℝ)*dist x y := by
    rw [chain_shift z n x y,dist_eq_norm]
    have h := (rankCovector (z n).2.val).le_opNorm (x-y)
    exact add_le_add_right ((le_abs_self _).trans (h.trans (mul_le_mul_of_nonneg_right (bound _) (norm_nonneg _)))) _
  have bdd (x) : BddAbove (vals x) := by
    refine ⟨(L:ℝ)*dist x z₀.1.val,?_⟩
    rintro r ⟨z,n,zer,good,rfl⟩
    have neg := cycle_work π cyc n z good
    change chainValue z n (z 0).1.val ≤ 0 at neg
    rw [zer] at neg
    linarith only [neg,step z n x z₀.1.val]
  have upper (x y) : φ x ≤ φ y+(L:ℝ)*dist x y := by
    apply csSup_le (ne x)
    rintro r ⟨z,n,zero,good,rfl⟩
    exact (step z n x y).trans (add_le_add_left (le_csSup (bdd y) ⟨z,n,zero,good,rfl⟩) _)
  refine ⟨φ,L,LipschitzWith.of_dist_le_mul (fun x y => ?_),⟨convex_univ,?_⟩,?_⟩
  · rw [Real.dist_eq,abs_le]; have h := upper y x; rw [dist_comm y x] at h
    exact ⟨by linarith only [h], by linarith only [upper x y]⟩
  · intro x _ y _ a b ha hb hab
    apply csSup_le (ne _)
    rintro r ⟨z,n,root,good,rfl⟩
    have hx := le_csSup (bdd x) (show chainValue z n x ∈ vals x from ⟨z,n,root,good,rfl⟩)
    have hy := le_csSup (bdd y) (show chainValue z n y ∈ vals y from ⟨z,n,root,good,rfl⟩)
    change _ ≤ a*φ x+b*φ y
    calc
      _ = a*chainValue z n x +b*chainValue z n y := by
        unfold chainValue; simp only [map_sub,map_add,map_smul,smul_eq_mul]
        have bval : b = 1-a := by linarith only [hab]
        rw [bval]; ring
      _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hx ha) (mul_le_mul_of_nonneg_left hy hb)
  · intro p hp x
    suffices h : φ p.1.val ≤ φ x-rankCovector p.2.val (x-p.1.val) by linarith
    apply csSup_le (ne _)
    rintro r ⟨z,n,root,good,rfl⟩
    let u (i : ℕ) := if i ≤ n then z i else p
    have ini : u 0 = z₀ := by simpa [u] using root
    have on (i) : u i ∈ H := by dsimp [u]; split <;> first | exact good _ | exact hp
    have old (i : ℕ) (hi : i ∈ Finset.range n) :
        rankCovector (u i).2.val ((u (i+1)).1.val-(u i).1.val) =
        rankCovector (z i).2.val ((z (i+1)).1.val-(z i).1.val) := by
      have hn := Finset.mem_range.mp hi
      simp [u,hn.le,show i+1 ≤ n by omega]
    have ext : chainValue u (n+1) x =
        chainValue z n p.1.val + rankCovector p.2.val (x-p.1.val) := by
      unfold chainValue; rw [Finset.sum_range_succ,Finset.sum_congr rfl old]
      simp [u]
    have top := le_csSup (bdd x) (show chainValue u (n+1) x ∈ vals x from ⟨u,n+1,ini,on,rfl⟩)
    rw [ext] at top
    change _ ≤ φ x at top
    linarith only [top]
end
end SequentialRanks
