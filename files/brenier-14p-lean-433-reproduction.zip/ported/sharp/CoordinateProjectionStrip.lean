import OAI.Analysis.Brenier.BoundaryStrip
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.MeasureTheory.Constructions.Pi

open MeasureTheory Set
open scoped ENNReal NNReal BigOperators

namespace BrenierReplacement
noncomputable section

/-- Euclidean coordinate deletion, with the removed coordinate placed last. -/
def coordinateSplit {n : ℕ} (i : Fin (n + 1)) :
    EuclideanSpace ℝ (Fin (n + 1)) ≃L[ℝ] ((Fin n → ℝ) × ℝ) :=
  ({ toEquiv := ((MeasurableEquiv.toLp 2 (Fin (n + 1) → ℝ)).symm.trans
      ((MeasurableEquiv.piFinSuccAbove (fun _ => ℝ) i).trans MeasurableEquiv.prodComm)).toEquiv
     map_add' := fun _ _ => rfl
     map_smul' := fun _ _ => rfl } :
      EuclideanSpace ℝ (Fin (n + 1)) ≃ₗ[ℝ] ((Fin n → ℝ) × ℝ)).toContinuousLinearEquiv

theorem coordinateSplit_apply {n : ℕ} (i : Fin (n + 1))
    (x : EuclideanSpace ℝ (Fin (n + 1))) :
    coordinateSplit i x = ((fun j => x (i.succAbove j)), x i) := rfl

theorem coordinateSplit_measurePreserving {n : ℕ} (i : Fin (n + 1)) :
    MeasurePreserving (coordinateSplit i) volume
      ((volume : Measure (Fin n → ℝ)).prod volume) := by
  exact (Measure.measurePreserving_swap.comp (volume_preserving_piFinSuccAbove (fun _ => ℝ) i)).comp
    (PiLp.volume_preserving_ofLp (Fin (n+1)))

theorem coordinateSplit_single {n : ℕ} (i : Fin (n + 1)) :
    coordinateSplit i (EuclideanSpace.single i (1 : ℝ)) = (0,1) := by
  change ((fun j => EuclideanSpace.single i (1 : ℝ) (i.succAbove j)),
    EuclideanSpace.single i (1 : ℝ) i) = (0,1)
  apply Prod.ext
  · funext j
    simp [Fin.succAbove_ne]
  · simp

/-- Lebesgue (d−1)-volume of the orthogonal projection with coordinate i deleted. -/
def coordinateProjectionVolume {n : ℕ} (K : Set (EuclideanSpace ℝ (Fin (n + 1))))
    (i : Fin (n + 1)) : ℝ :=
  (volume : Measure (Fin n → ℝ)).real (Prod.fst '' (coordinateSplit i '' K))

theorem coordinateProjectionVolume_nonneg {n : ℕ} (K : Set (EuclideanSpace ℝ (Fin (n + 1))))
    (i : Fin (n + 1)) : 0 ≤ coordinateProjectionVolume K i := measureReal_nonneg

theorem coordinate_boundary_strip_bound {n : ℕ} (K : Set (EuclideanSpace ℝ (Fin (n + 1))))
    (hK : IsCompact K) (hc : Convex ℝ K) (i : Fin (n + 1)) {h : ℝ} (hh : 0 ≤ h) :
    (volume : Measure (EuclideanSpace ℝ (Fin (n + 1)))).real
      {x | x ∈ K ∧ x + h • EuclideanSpace.single i 1 ∉ K} ≤ coordinateProjectionVolume K i * h := by
  have hp := ((hK.image (coordinateSplit i).continuous).image continuous_fst).measure_ne_top
    (μ := (volume : Measure (Fin n → ℝ)))
  have raw := OAI.Problem358.boundary_strip_le_of_coordinate_split
    (coordinateSplit i) volume (volume : Measure (Fin n → ℝ)) (coordinateSplit_measurePreserving i)
    (coordinateSplit_single i) hK hc hh
  have hp' : ENNReal.ofReal h * (volume : Measure (Fin n → ℝ)) (Prod.fst '' (coordinateSplit i '' K)) ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top hp
  have hreal := ENNReal.toReal_mono hp' raw
  simpa only [Measure.real, coordinateProjectionVolume, ENNReal.toReal_mul, ENNReal.toReal_ofReal hh,
    mul_comm] using hreal

#print axioms coordinate_boundary_strip_bound

end
end BrenierReplacement
