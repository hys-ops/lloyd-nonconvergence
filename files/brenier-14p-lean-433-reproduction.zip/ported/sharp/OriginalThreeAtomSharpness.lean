import OAI.Analysis.Brenier.Sharpness

/-! The sharpness declaration from the pinned Stability.lean, independently of
    its imports for the replaced upper bound. The declaration and proof are unchanged. -/
namespace OAI
noncomputable section
open MeasureTheory
namespace Problem358

theorem one_third_exponent_is_sharp :
    ∀ (d : ℕ), 2 ≤ d → ∀ α : ℝ, (1 / 3 : ℝ) < α →
      ∀ C : ℝ, 0 < C →
        ∃ (μ ν : Measure (E d)) (Tμ Tν : E d → E d),
          IsProbabilityMeasure μ ∧ IsProbabilityMeasure ν ∧
          IsSupported μ (cube d) ∧ IsSupported ν (cube d) ∧
          HasExactlyThreeAtoms μ (cube d) ∧ HasExactlyThreeAtoms ν (cube d) ∧
          μ ≠ ν ∧
          IsUniqueQuadraticOptimalMap (uniformMeasure (cube d)) μ Tμ ∧
          IsUniqueQuadraticOptimalMap (uniformMeasure (cube d)) ν Tν ∧
          0 < wasserstein2 μ ν ∧
          C * Real.rpow (wasserstein2 μ ν) α <
            mapL2Dist (uniformMeasure (cube d)) Tμ Tν := by
  exact one_third_exponent_is_sharp_via_rectangle

end Problem358

end

end OAI

#print axioms OAI.Problem358.one_third_exponent_is_sharp

open MeasureTheory
open scoped ENNReal

namespace BrenierReplacement
open OAI.Problem358

/-- Exact L² map-distance square calculated in the unchanged sharpness section. -/
theorem exact_three_atom_map_distance_square {d : ℕ} (i j : Fin d) (hij : i ≠ j)
    (a b : ℝ) (hb : 0 ≤ b) (hba : b ≤ a) (hab : a+b ≤ 1) :
    (mapL2Dist (uniformMeasure (cube d)) (Sharpness.slabMap i j a 0)
      (Sharpness.slabMap i j a b))^2 = b/2+a*b^2 := by
  let _ : IsProbabilityMeasure (uniformMeasure (cube d)) := Sharpness.uniformCube_isProbabilityMeasure d
  unfold mapL2Dist
  rw [Real.sq_sqrt (integral_nonneg fun _ => sq_nonneg _)]
  rw [Sharpness.integral_slabMap_norm_sq_difference i j hij a b]
  have hc := uniformMeasure_cube_centralCell i j hij a b hb hba hab
  have hd := uniformMeasure_cube_centralCell_symmDiff i j hij a b hb hba hab
  have h0 : Sharpness.centralCell i j a 0 = {x : E d | |x i| ≤ a} := by
    ext x
    simp [Sharpness.centralCell]
  rw [h0]
  change (uniformMeasure (cube d) (symmDiff {x : E d | |x i| ≤ a} {x : E d | |x i| ≤ a+b*x j})).toReal +
    b^2 * (uniformMeasure (cube d) {x : E d | |x i| ≤ a+b*x j}).toReal = _
  rw [hc,hd, ENNReal.toReal_ofReal (hb.trans hba), ENNReal.toReal_ofReal (by positivity : 0 ≤ b/2)]
  ring

#print axioms exact_three_atom_map_distance_square

end BrenierReplacement
