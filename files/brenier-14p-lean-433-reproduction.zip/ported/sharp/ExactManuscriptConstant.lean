import CoordinateInterpolation
import ExactFinitePotential
import OAI.Analysis.Brenier.AtomicPaths

open MeasureTheory Set Filter
open scoped BigOperators RealInnerProductSpace ENNReal NNReal
open OAI.Problem358 OAI.Problem358.SupportingMapInterpolation

namespace BrenierReplacement
noncomputable section

/-- Manuscript P_K: sum of the (d−1)-volumes of the coordinate projections. -/
def projectionSum {n : ℕ} (K : Set (E (n+1))) : ℝ :=
  ∑ i : Fin (n+1), coordinateProjectionVolume K i

/-- The revised manuscript's displayed C_* at C₀=1, with d=n+1. -/
def manuscriptConstant {n : ℕ} (K : Set (E (n+1))) (R L : ℝ≥0) : ℝ :=
  Real.sqrt (12 * ((n+1 : ℕ) : ℝ) * (R : ℝ)^2 * (1 + Real.sqrt 1)^2 +
    28 * (L : ℝ)^2 * projectionSum K / (volume K).toReal)

theorem manuscriptConstant_normalized_interpolation {n : ℕ} {K : Set (E (n+1))}
    (hK : IsCompact K) (hc : Convex ℝ K) (R L : ℝ≥0)
    {u v : E (n+1) → ℝ} {T S : E (n+1) → E (n+1)}
    (huc : Continuous u) (hvc : Continuous v) (hu : Supports u T) (hv : Supports v S)
    (hT : Measurable T) (hS : Measurable S)
    (hTL : ∀ x, ‖T x‖ ≤ L) (hSL : ∀ x, ‖S x‖ ≤ L)
    {w : ℝ} (hw : 0 ≤ w)
    (hpotential : (∫ x, (u x - v x)^2 ∂uniformMeasure K) ≤ (2*(R : ℝ))^2*w^2) :
    mapL2Dist (uniformMeasure K) T S ≤ manuscriptConstant K R L * Real.rpow w (1/3 : ℝ) := by
  let B : ℝ := 28 * (L : ℝ)^2 * projectionSum K
  have hB : 0 ≤ B := by
    unfold B projectionSum
    exact mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _))
      (Finset.sum_nonneg fun i _ => coordinateProjectionVolume_nonneg K i)
  have hf : IntegrableOn (fun x => (u x-v x)^2) K volume :=
    ContinuousOn.integrableOn_compact hK ((huc.sub hvc).pow 2).continuousOn
  have raw (h : ℝ) (hh : 0 < h) :
      (∫ x in K, ‖T x-S x‖^2) ≤
        (12 * ((n+1 : ℕ) : ℝ) / h^2) * (∫ x in K, (u x-v x)^2) + B*h := by
    simpa only [B, projectionSum, Fintype.card_fin] using
      integral_norm_sub_sq_le_of_coordinate_strips (μ := volume) hu hv hT hS
        hK.measurableSet hK.measure_ne_top (coordinateProjectionVolume K) hTL hSL hh
        (huc.sub hvc).measurable hf (fun i => coordinate_boundary_strip_bound K hK hc i hh.le)
  have h := OAI.Problem358.UniformInterpolation.one_third_bound_of_raw K
    (by positivity : 0 ≤ 12 * ((n+1 : ℕ) : ℝ)) hB hw hpotential raw
  have const : Real.sqrt (12 * ((n+1 : ℕ) : ℝ) * (2*(R : ℝ))^2 +
      ((volume K)⁻¹).toReal * B) = manuscriptConstant K R L := by
    unfold manuscriptConstant B
    rw [Real.sqrt_one, ENNReal.toReal_inv]
    congr 1
    ring
  rw [const] at h
  exact h

/-- The exact displayed C_* works for arbitrary probability targets supported on a fixed compact set. -/
theorem one_third_stability_with_manuscript_constant
    {n : ℕ} {K Y : Set (E (n+1))}
    (hK : IsCompact K) (hKconv : Convex ℝ K) (hKint : (interior K).Nonempty)
    (hY : IsCompact Y) (hYne : Y.Nonempty)
    (R L : ℝ≥0) (hR : ∀ x ∈ K, ‖x‖ ≤ R) (hYL : ∀ x ∈ Y, ‖x‖ ≤ L) :
    ∀ (μ ν : Measure (E (n+1))), IsProbabilityMeasure μ → IsProbabilityMeasure ν →
      IsSupported μ Y → IsSupported ν Y →
      ∃ Tμ Tν : E (n+1) → E (n+1),
        IsUniqueQuadraticOptimalMap (uniformMeasure K) μ Tμ ∧
        IsUniqueQuadraticOptimalMap (uniformMeasure K) ν Tν ∧
        mapL2Dist (uniformMeasure K) Tμ Tν ≤ manuscriptConstant K R L *
          Real.rpow (wasserstein2 μ ν) (1/3 : ℝ) := by
  apply one_third_stability_of_finite_targets hK hKconv hKint hY hYne (Real.sqrt_nonneg _)
  intro μ ν hμprob hνprob hμfinite hνfinite
  let _ : IsProbabilityMeasure μ := hμprob
  let _ : IsProbabilityMeasure ν := hνprob
  obtain ⟨F,hF,hFY,hμF⟩ := hμfinite
  obtain ⟨G,hG,hGY,hνG⟩ := hνfinite
  obtain ⟨k,hk,m,y,z,hm,hsum,hyF,hzG,hμeq,hνeq,_,henergy,hinj⟩ :=
    exists_finite_atomic_motion hF hG hμF hνG
  let _ : Nonempty (Fin k) := Fin.pos_iff_nonempty.mp hk
  let _ : MeasurableSpace (Fin k) := ⊤
  let _ : MeasurableSingletonClass (Fin k) := ⟨fun _ => trivial⟩
  obtain ⟨u,v,T,S,hu,hv,hT,hS,hTL,hSL,hTlaw,hSlaw,hsq⟩ :=
    exact_finite_support_potential_bound K hK hKconv hKint R hR y z hinj m hm hsum L
      (fun i => hYL _ (hFY (hyF i))) (fun i => hYL _ (hGY (hzG i)))
  have hu' : Supports u T := fun x w => by simpa only [real_inner_comm (w-x) (T x)] using hu x w
  have hv' : Supports v S := fun x w => by simpa only [real_inner_comm (w-x) (S x)] using hv x w
  have huLip := hu'.lipschitzWith hTL
  have hvLip := hv'.lipschitzWith hSL
  have hμY : IsSupported μ Y := le_antisymm ((measure_mono (Set.compl_subset_compl.mpr hFY)).trans_eq hμF) zero_le
  have hνY : IsSupported ν Y := le_antisymm ((measure_mono (Set.compl_subset_compl.mpr hGY)).trans_eq hνG) zero_le
  have hKne : K.Nonempty := hKint.mono interior_subset
  refine ⟨T,S,?_,?_,?_⟩
  · apply isUniqueQuadraticOptimalMap_of_supporting_potential hK hKconv hKne
      hY hμY huLip.lipschitzOnWith hT (hTlaw.trans hμeq.symm)
    exact Filter.Eventually.of_forall fun x w _ => hu x w
  · apply isUniqueQuadraticOptimalMap_of_supporting_potential hK hKconv hKne
      hY hνY hvLip.lipschitzOnWith hS (hSlaw.trans hνeq.symm)
    exact Filter.Eventually.of_forall fun x w _ => hv x w
  · exact manuscriptConstant_normalized_interpolation hK hKconv R L huLip.continuous hvLip.continuous
      hu' hv' hT hS hTL hSL (wasserstein2_nonneg μ ν) (by simpa only [henergy] using hsq)

#print axioms manuscriptConstant_normalized_interpolation
#print axioms one_third_stability_with_manuscript_constant

end
end BrenierReplacement
