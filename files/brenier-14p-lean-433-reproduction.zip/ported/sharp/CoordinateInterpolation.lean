import CoordinateProjectionStrip
import OAI.Analysis.Brenier.UniformInterpolation

open MeasureTheory Set
open scoped BigOperators RealInnerProductSpace ENNReal NNReal
open OAI.Problem358.SupportingMapInterpolation

namespace BrenierReplacement
noncomputable section

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
variable {μ : Measure (EuclideanSpace ℝ ι)} [Measure.IsAddHaarMeasure μ]

/-- Summing the directional estimate gives full-dimensional interpolation for
bounded supporting maps. Only a linear boundary-strip estimate is needed. -/
theorem integral_norm_sub_sq_le_of_coordinate_strips
    {u v : EuclideanSpace ℝ ι → ℝ}
    {T S : EuclideanSpace ℝ ι → EuclideanSpace ℝ ι}
    (hu : Supports u T) (hv : Supports v S)
    (hT : Measurable T) (hS : Measurable S)
    {K : Set (EuclideanSpace ℝ ι)} (hK : MeasurableSet K) (hKfin : μ K ≠ ⊤)
    {L h : ℝ} (A : ι → ℝ) (hTL : ∀ x, ‖T x‖ ≤ L) (hSL : ∀ x, ‖S x‖ ≤ L)
    (hh : 0 < h)
    (hfm : Measurable (fun x => u x - v x))
    (hf : IntegrableOn (fun x => (u x - v x) ^ 2) K μ)
    (hstrip : ∀ i : ι,
      μ.real {x | x ∈ K ∧ x + h • EuclideanSpace.single i (1 : ℝ) ∉ K} ≤ A i * h) :
    (∫ x in K, ‖T x - S x‖ ^ 2 ∂μ) ≤
      (12 * (Fintype.card ι : ℝ) / h ^ 2) * (∫ x in K, (u x - v x) ^ 2 ∂μ) +
      28 * L ^ 2 * (∑ i, A i) * h := by
  classical
  have hcoordInt (i : ι) : IntegrableOn (fun x => (T x i - S x i) ^ 2) K μ := by
    simpa only [OAI.Problem358.SupportingMapInterpolation.slope, EuclideanSpace.inner_single_left, map_one, one_mul] using
      (integrableOn_slope_difference_sq hT hS hKfin hTL hSL
        (e := EuclideanSpace.single i 1) (by simp))
  have hcoordBound (i : ι) :
      (∫ x in K, (T x i - S x i) ^ 2 ∂μ) ≤
        (12 / h ^ 2) * (∫ x in K, (u x - v x) ^ 2 ∂μ) + 28 * L ^ 2 * A i * h := by
    let e : EuclideanSpace ℝ ι := EuclideanSpace.single i 1
    have he : ‖e‖ ≤ 1 := by simp [e]
    have hb := integral_slope_difference_sq_le hu hv hT hS hK hKfin hTL hSL
      hh he hfm hf
    have hset : K \ (K ∩ (fun x => x + h • e) ⁻¹' K) =
        {x | x ∈ K ∧ x + h • e ∉ K} := by
      ext x
      simp only [Set.mem_sdiff, Set.mem_inter_iff, Set.mem_preimage, Set.mem_ofPred_eq]
      tauto
    rw [hset] at hb
    have hs : μ.real {x | x ∈ K ∧ x + h • e ∉ K} ≤ A i * h := hstrip i
    have hbound := hb.trans (add_le_add le_rfl
      (mul_le_mul_of_nonneg_left hs (by positivity : 0 ≤ 28 * L ^ 2)))
    simpa only [e, OAI.Problem358.SupportingMapInterpolation.slope, EuclideanSpace.inner_single_left, map_one, one_mul, mul_assoc] using hbound
  calc
    (∫ x in K, ‖T x - S x‖ ^ 2 ∂μ) =
        ∫ x in K, ∑ i, (T x i - S x i) ^ 2 ∂μ := by
      congr 1
      funext x
      simp [EuclideanSpace.real_norm_sq_eq]
    _ = ∑ i, ∫ x in K, (T x i - S x i) ^ 2 ∂μ :=
      integral_finsetSum _ fun i _ => hcoordInt i
    _ ≤ ∑ i : ι, ((12 / h ^ 2) * (∫ x in K, (u x - v x) ^ 2 ∂μ) + 28 * L ^ 2 * A i * h) :=
      Finset.sum_le_sum fun i _ => hcoordBound i
    _ = _ := by
      rw [Finset.sum_add_distrib]
      simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      rw [← Finset.sum_mul, ← Finset.mul_sum]
      ring


#print axioms integral_norm_sub_sq_le_of_coordinate_strips

end
end BrenierReplacement
