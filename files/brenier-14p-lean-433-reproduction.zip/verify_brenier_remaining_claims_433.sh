#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
M=$(realpath ../chen-attainment-toolchain/mathlib)
J=$(realpath "$M/../lean-4.33.1-linux/bin")
export PATH="$J:$PATH"
export LEAN_PATH="$PWD/build/sharp:$PWD/build/minty:$PWD/build/replacement:$PWD/build/upstream:$PWD/build/stock:$M/.lake/build/lib/lean:$(printf '%s:' "$M"/.lake/packages/*/.lake/build/lib/lean)"
lean --version | grep -F 'version 4.33.1'
[[ $(git -C "$M" rev-parse HEAD) == 0df444a360eaa60ab8c11dca51a86af692955474 ]]
test -f build/minty/ExactFinitePotential.olean || bash verify_brenier_14p_upper_433.sh
while read -r -a tranche; do
  python3 stock_overlay.py "${tranche[@]}"
done < <(python3 list_scoped_stock.py Mathlib.Probability.Independence.Basic Mathlib.Analysis.SpecialFunctions.Integrals.Basic | sed '/^$/d' | xargs -r -n 14)
mkdir -p build/sharp
BREN_REUSE_DONE=1 BREN_FORCE_MODULES=Cube,SharpTargets,SharpMaps,SharpOptimality,SharpRectangle,Sharpness python3 replay_upstream.py Sharpness
for n in OriginalThreeAtomSharpness CoordinateProjectionStrip CoordinateInterpolation ExactManuscriptConstant; do
  echo "Source module: $n"
  lean --root="$PWD/ported/sharp" -o "build/sharp/$n.olean" "ported/sharp/$n.lean"
done
for n in OriginalThreeAtomSharpness OAI.Analysis.Brenier.Sharpness CoordinateProjectionStrip CoordinateInterpolation ExactManuscriptConstant; do
  leanchecker -v "$n"
done
