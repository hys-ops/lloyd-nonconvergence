import Mathlib.Analysis.Calculus.LocalExtr.Basic
import Mathlib.Analysis.Calculus.Deriv.Shift
import Mathlib.MeasureTheory.Measure.Dirac
import Mathlib.MeasureTheory.Measure.Real
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Topology.MetricSpace.Pseudo.Constructions
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.MeasureTheory.Order.Lattice
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar
import Mathlib.Analysis.InnerProductSpace.LinearMap
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.Real.Sqrt
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Topology.MetricSpace.Lipschitz
import Mathlib.Topology.Order.DenselyOrdered
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.MetricSpace.Pseudo.Pi

namespace BrenierReplacement
/-! Compatibility section: btrial. -/



open Filter Set
open scoped Topology



private theorem segmentDerivativeBound
    {f g : ℝ → ℝ} {x t e : ℝ}
    (hd : ∀ q ∈ Icc (min x t) (max x t), HasDerivAt f (g q) q)
    (hb : ∀ q ∈ Icc (min x t) (max x t), ‖g q‖ ≤ e) :
    ‖f t - f x‖ ≤ e * ‖t - x‖ := by
  rcases le_total x t with h | h
  · rw [min_eq_left h, max_eq_right h] at hd hb
    rw [Real.norm_eq_abs (t-x), abs_of_nonneg (sub_nonneg.mpr h)]
    exact norm_image_sub_le_of_norm_deriv_le_segment'
      (fun q hq => (hd q hq).hasDerivWithinAt)
      (fun q hq => hb q (Ico_subset_Icc_self hq)) t ⟨h, le_rfl⟩
  · rw [min_eq_right h, max_eq_left h] at hd hb
    rw [norm_sub_rev (f t) (f x), Real.norm_eq_abs (t-x),
      abs_of_nonpos (sub_nonpos.mpr h), neg_sub]
    exact norm_image_sub_le_of_norm_deriv_le_segment'
      (fun q hq => (hd q hq).hasDerivWithinAt)
      (fun q hq => hb q (Ico_subset_Icc_self hq)) x ⟨h, le_rfl⟩

/-- Directional envelope argument in revised Brenier §3, lines 61–64.
    c(t) is an actual minimizer when the real parameter t is near x.
    Only local, not global, optimizer inequalities are used. -/
theorem envelope_hasDerivAt
    {C : Type*} [PseudoMetricSpace C]
    (G d : ℝ → C → ℝ) (c : ℝ → C) (x : ℝ)
    (hc : ContinuousAt c x)
    (hjoint : ContinuousAt (fun p : ℝ × C => d p.1 p.2) (x, c x))
    (hderiv : ∀ᶠ p : ℝ × C in 𝓝 (x, c x),
      HasDerivAt (fun q => G q p.2) (d p.1 p.2) p.1)
    (hmin : ∀ᶠ t in 𝓝 x, ∀ k, G t (c t) ≤ G t k) :
    HasDerivAt (fun t => G t (c t)) (d x (c x)) x := by
  refine hasDerivAt_iff_isLittleO.mpr (Asymptotics.isLittleO_iff.mpr ?_)
  intro e he
  have hj : ∀ᶠ p : ℝ × C in 𝓝 (x, c x),
      dist (d p.1 p.2) (d x (c x)) < e :=
    hjoint.eventually (Metric.ball_mem_nhds _ he)
  obtain ⟨r, hr, hd⟩ := Metric.eventually_nhds_iff.mp
    (hderiv.and hj)
  have hp : ∀ q t, dist q x < r → dist (c t) (c x) < r →
      HasDerivAt (fun z => G z (c t)) (d q (c t)) q ∧
      dist (d q (c t)) (d x (c x)) < e := by
    intro q t hq ht
    exact hd (y := (q, c t)) (by simpa [Prod.dist_eq, max_lt_iff] using And.intro hq ht)
  have hminx := Filter.Eventually.self_of_nhds hmin
  filter_upwards [Metric.eventually_nhds_iff.mpr ⟨r, hr, fun _ h => h⟩,
    hc.eventually (Metric.ball_mem_nhds (c x) hr), hmin] with t ht hct hmt
  have hseg (q) (hq : q ∈ Icc (min x t) (max x t)) : dist q x < r := by
    rcases le_total x t with hxt | htx
    · rw [min_eq_left hxt, max_eq_right hxt] at hq
      rw [Real.dist_eq, abs_of_nonneg (sub_nonneg.mpr hq.1)]
      rw [Real.dist_eq, abs_of_nonneg (sub_nonneg.mpr hxt)] at ht
      linarith [hq.2]
    · rw [min_eq_right htx, max_eq_left htx] at hq
      rw [Real.dist_eq, abs_of_nonpos (sub_nonpos.mpr hq.2)]
      rw [Real.dist_eq, abs_of_nonpos (sub_nonpos.mpr htx)] at ht
      linarith [hq.1]
  let D := d x (c x)
  have hbound (a : ℝ) (ha : dist (c a) (c x) < r) :
      ‖G t (c a) - G x (c a) - (t - x) * D‖ ≤ e * ‖t - x‖ := by
    have H := segmentDerivativeBound
      (f := fun q => G q (c a) - q * D)
      (g := fun q => d q (c a) - D)
      (x := x) (t := t) (e := e)
      (fun q hq => (hp q a (hseg q hq) ha).1.sub
        (show HasDerivAt (fun y : ℝ => y * D) D q by
          simpa using (hasDerivAt_id q).mul_const D))
      (fun q hq => le_of_lt (by simpa [Real.dist_eq, Real.norm_eq_abs, D] using
        (hp q a (hseg q hq) ha).2))
    convert H using 2; ring
  have hupper := hbound x (by simpa using hr)
  have hlower := hbound t hct
  rw [smul_eq_mul, Real.norm_eq_abs, abs_le]
  rw [Real.norm_eq_abs, abs_le] at hupper hlower
  constructor
  · linarith [hlower.1, hminx (c t)]
  · linarith [hupper.2, hmt (c x)]

open scoped BigOperators

/-- Exact mass-direction envelope formula of revised §3, using any integrated
    finite maximum as the time-independent term A. The positive-simplex and
    distinct-site hypotheses belong to the existence/continuity proof of c and
    the local dual minimum, not to this conclusion once those facts are supplied. -/
theorem finite_mass_value_hasDerivAt
    {I : Type*} [Fintype I]
    (A : (I → ℝ) → ℝ) (m h : I → ℝ) (c : ℝ → I → ℝ) (x : ℝ)
    (hc : ContinuousAt c x)
    (hmin : ∀ᶠ t in 𝓝 x, ∀ k,
      A (c t) - (∑ i, (m i + t * h i) * c t i) ≤
        A k - (∑ i, (m i + t * h i) * k i)) :
    HasDerivAt (fun t => A (c t) - ∑ i, (m i + t * h i) * c t i)
      (-(∑ i, h i * c x i)) x := by
  have expand (t : ℝ) (k : I → ℝ) :
      (∑ i, (m i + t * h i) * k i) =
        (∑ i, m i * k i) + t * (∑ i, h i * k i) := by
    simp_rw [add_mul, mul_assoc, Finset.sum_add_distrib, Finset.mul_sum]
  apply envelope_hasDerivAt
    (G := fun t k => A k - ∑ i, (m i + t * h i) * k i)
    (d := fun _ k => -(∑ i, h i * k i)) (c := c) (x := x) hc _ _ hmin
  · fun_prop
  · apply Filter.Eventually.of_forall
    intro p
    have hp : HasDerivAt (fun t : ℝ => t * (∑ i, h i * p.2 i))
        (∑ i, h i * p.2 i) p.1 := by
      simpa using (hasDerivAt_id p.1).mul_const (∑ i, h i * p.2 i)
    have hlinear := hp.const_sub (A p.2 - (∑ i, m i * p.2 i))
    have heq : (fun t : ℝ => A p.2 - ∑ i, (m i + t * h i) * p.2 i) =
        (fun t : ℝ => (A p.2 - ∑ i, m i * p.2 i) - t * (∑ i, h i * p.2 i)) := by
      funext t
      rw [expand]
      ring
    rw [heq]
    exact hlinear






/-! Compatibility section: intsite. -/



open Filter Set
open scoped Topology NNReal



noncomputable def finiteAffineMax {I : Type*} [Fintype I] [Nonempty I]
    (a b : I → ℝ) (t : ℝ) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun i => a i + t * b i)

/-- A strict winning label of a finite affine maximum persists near the
    base parameter; no common stability neighborhood over source points
    is assumed. -/
theorem finiteAffineMax_eventually_eq_of_strict
    {I : Type*} [Fintype I] [Nonempty I] (a b : I → ℝ)
    (t₀ : ℝ) (i : I) (hi : ∀ j, j ≠ i → a j + t₀ * b j < a i + t₀ * b i) :
    (fun t => finiteAffineMax a b t) =ᶠ[𝓝 t₀] fun t => a i + t * b i := by
  classical
  have hnear : ∀ᶠ t in 𝓝 t₀, ∀ j ∈ (Finset.univ : Finset I),
      j ≠ i → a j + t * b j < a i + t * b i :=
    (eventually_all_finset _).mpr fun j _ => by
      by_cases hji : j = i
      · exact Filter.Eventually.of_forall fun _ hj => False.elim (hj hji)
      · have hj : ContinuousAt (fun t : ℝ => a j + t * b j) t₀ := by fun_prop
        have hci : ContinuousAt (fun t : ℝ => a i + t * b i) t₀ := by fun_prop
        exact (hj.eventually_lt hci (hi j hji)).mono fun _ h _ => h
  filter_upwards [hnear] with t ht
  unfold finiteAffineMax
  refine le_antisymm (Finset.sup'_le _ _ fun j hj => ?_) (Finset.le_sup' (fun j => a j + t * b j) (Finset.mem_univ i))
  by_cases hji : j = i
  · simp [hji]
  · exact (ht j hj hji).le

/-- The directional derivative is the slope of the strict winning label. -/
theorem finiteAffineMax_hasDerivAt_of_strict
    {I : Type*} [Fintype I] [Nonempty I] (a b : I → ℝ)
    (t₀ : ℝ) (i : I) (hi : ∀ j, j ≠ i → a j + t₀ * b j < a i + t₀ * b i) :
    HasDerivAt (finiteAffineMax a b) (b i) t₀ := by
  have ha : HasDerivAt (fun t : ℝ => a i + t * b i) (b i) t₀ := by
    simpa using ((hasDerivAt_id t₀).mul_const (b i)).const_add (a i)
  exact ha.congr_of_eventuallyEq (finiteAffineMax_eventually_eq_of_strict a b t₀ i hi)

/-- Uniform domination for differentiation under the source integral:
    the finite maximum is Lipschitz with any common bound on the slopes. -/
theorem finiteAffineMax_lipschitz
    {I : Type*} [Fintype I] [Nonempty I] (a b : I → ℝ)
    (K : ℝ≥0) (hK : ∀ i, |b i| ≤ K) :
    LipschitzWith K (finiteAffineMax a b) := by
  apply LipschitzWith.of_dist_le_mul
  intro s t
  have hst (u v : ℝ) : finiteAffineMax a b u ≤
      finiteAffineMax a b v + (K : ℝ) * |u - v| := by
    apply Finset.sup'_le
    intro i _
    have hi : a i + v * b i ≤ finiteAffineMax a b v :=
      Finset.le_sup' (fun j => a j + v * b j) (Finset.mem_univ i)
    have hb : |(u - v) * b i| ≤ (K : ℝ) * |u - v| := by
      rw [abs_mul, mul_comm (K : ℝ)]
      exact mul_le_mul_of_nonneg_left (hK i) (abs_nonneg _)
    nlinarith [le_abs_self ((u-v) * b i)]
  rw [Real.dist_eq, Real.dist_eq, abs_le]
  have hts := hst t s
  rw [abs_sub_comm t s] at hts
  constructor <;> linarith [hst s t]


open MeasureTheory
open scoped BigOperators

/-- Integrated fixed-intercept site derivative. Strict cells are enough up to
    a null set: the derivative is the sum of the integrals of label slopes on
    their strict cells. Neither a measurable winner nor differentiability at
    tied points is assumed. -/
theorem integral_finiteAffineMax_hasDerivAt
    {I X : Type*} [Fintype I] [Nonempty I] [MeasurableSpace X]
    (μ : Measure X) [IsFiniteMeasure μ] (a b : I → X → ℝ) (t₀ : ℝ)
    (ha : ∀ i, Measurable (a i)) (hb : ∀ i, Measurable (b i))
    (hbase : Integrable (fun x => finiteAffineMax (fun i => a i x) (fun i => b i x) t₀) μ)
    (K : ℝ≥0) (hK : ∀ᵐ x ∂μ, ∀ i, |b i x| ≤ K)
    (hstrict : ∀ᵐ x ∂μ, ∃ i, ∀ j, j ≠ i →
       a j x + t₀ * b j x < a i x + t₀ * b i x) :
    HasDerivAt (fun t => ∫ x, finiteAffineMax (fun i => a i x) (fun i => b i x) t ∂μ)
      (∫ x, ∑ i, ({z | ∀ j, j ≠ i → a j z + t₀ * b j z < a i z + t₀ * b i z}
        : Set X).indicator (b i) x ∂μ) t₀ := by
  classical
  let U : I → Set X := fun i =>
    {z | ∀ j, j ≠ i → a j z + t₀ * b j z < a i z + t₀ * b i z}
  let F (t : ℝ) (x : X) := finiteAffineMax (fun i => a i x) (fun i => b i x) t
  have hU (i : I) : MeasurableSet (U i) := by
    have heq : U i = ⋂ j : I,
        if j = i then Set.univ else
        {z | a j z + t₀ * b j z < a i z + t₀ * b i z} := by
      ext x
      simp only [U, Set.mem_ofPred_eq, Set.mem_iInter]
      constructor
      · intro h j
        by_cases hj : j = i
        · simp [hj]
        · simpa [hj] using h j hj
      · intro h j hj
        simpa [hj] using h j
    rw [heq]
    apply MeasurableSet.iInter
    intro j
    by_cases hj : j = i
    · simp [hj]
    · rw [if_neg hj]
      exact measurableSet_lt ((ha j).add (measurable_const.mul (hb j)))
        ((ha i).add (measurable_const.mul (hb i)))
  have hF (t : ℝ) : Measurable (F t) := by
    change Measurable (fun x => Finset.univ.sup' Finset.univ_nonempty
      (fun i => a i x + t * b i x))
    have hm := Finset.measurable_sup' Finset.univ_nonempty
      (f := fun i x => a i x + t * b i x)
      (fun i _ => (ha i).add (measurable_const.mul (hb i)))
    have hfun : Finset.univ.sup' Finset.univ_nonempty (fun i x => a i x + t * b i x) =
        (fun x => Finset.univ.sup' Finset.univ_nonempty (fun i => a i x + t * b i x)) := by
      funext x
      rw [Finset.sup'_apply]
    rwa [hfun] at hm
  let D (x : X) : ℝ := ∑ i, (U i).indicator (b i) x
  have hD : Measurable D := Finset.measurable_sum _ (fun i _ => (hb i).indicator (hU i))
  have hdiff : ∀ᵐ x ∂μ, HasDerivAt (fun t => F t x) (D x) t₀ := by
    filter_upwards [hstrict] with x hx
    obtain ⟨i, hi⟩ := hx
    have hDx : D x = b i x := by
      unfold D
      rw [Finset.sum_eq_single i]
      · exact Set.indicator_of_mem (show x ∈ U i from hi) _
      · intro j _ hji
        apply Set.indicator_of_notMem
        intro hj
        exact (lt_asymm (hi j hji)) (hj i (Ne.symm hji))
      · simp
    rw [hDx]
    exact finiteAffineMax_hasDerivAt_of_strict _ _ t₀ i hi
  have hLip : ∀ᵐ x ∂μ,
      LipschitzOnWith (Real.nnabs (K : ℝ)) (fun t => F t x) Set.univ := by
    filter_upwards [hK] with x hx
    simpa [F] using (finiteAffineMax_lipschitz (fun i => a i x) (fun i => b i x) K hx)
  exact (hasDerivAt_integral_of_dominated_loc_of_lip
    (s := Set.univ) (bound := fun _ : X => (K : ℝ)) Filter.univ_mem
    (Filter.Eventually.of_forall fun t => (hF t).aestronglyMeasurable)
    hbase hD.aestronglyMeasurable hLip (integrable_const (K : ℝ)) hdiff).2







/-! Compatibility section: ties. -/



open Set Filter MeasureTheory MeasureTheory.Measure
open scoped Topology InnerProductSpace ENNReal



/-- A nonzero linear functional has Haar-null level sets. -/
theorem linearLevel_addHaar_null
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (L : E →ₗ[ℝ] ℝ) (hL : L ≠ 0) (r : ℝ) :
    μ {x | L x = r} = 0 := by
  let A : AffineSubspace ℝ E := (affineSpan ℝ ({r} : Set ℝ)).comap L.toAffineMap
  have hA : (A : Set E) = {x | L x = r} := by
    ext x
    change L.toAffineMap x ∈ affineSpan ℝ ({r} : Set ℝ) ↔ L x = r
    rw [AffineSubspace.mem_affineSpan_singleton]
    rfl
  rw [← hA]
  apply addHaar_affineSubspace μ
  intro H
  have harr (x : E) : L x = r := by
    have hx : x ∈ (A : Set E) := by simp [H]
    rwa [hA] at hx
  have hr : r = 0 := by simpa using (harr 0).symm
  apply hL
  ext x
  simp [harr x, hr]

/-- Two affine scores of distinct sites tie on a null hyperplane. -/
theorem affineScore_tie_addHaar_null
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (y z : E) (hyz : y ≠ z) (c d : ℝ) :
    μ {x | ⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d} = 0 := by
  let L : E →ₗ[ℝ] ℝ := (innerSL ℝ (y-z)).toLinearMap
  have hL : L ≠ 0 := by
    intro H
    have Hval := congrArg (fun f : E →ₗ[ℝ] ℝ => f (y-z)) H
    have hp : 0 < ⟪y-z, y-z⟫_ℝ := real_inner_self_pos.mpr (sub_ne_zero.mpr hyz)
    change ⟪y-z, y-z⟫_ℝ = 0 at Hval
    exact (ne_of_gt hp) Hval
  have heq : {x | ⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d} = {x | L x = d-c} := by
    ext x
    change (⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d) ↔ ⟪y-z, x⟫_ℝ = d-c
    rw [inner_sub_left]
    constructor <;> intro h <;> linarith
  rw [heq]
  exact linearLevel_addHaar_null μ L hL _

/-- Haar-null affine ties remain null under any restriction and
    normalization, including normalized volume of a convex body. -/
theorem affineScore_tie_restrict_smul_null
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (q : ℝ≥0∞) (y z : E) (hyz : y ≠ z) (c d : ℝ) :
    (q • μ.restrict B) {x | ⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d} = 0 := by
  rw [Measure.smul_apply]
  have hzero : (μ.restrict B) {x | ⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d} = 0 :=
    le_antisymm (by simpa only [affineScore_tie_addHaar_null μ y z hyz c d] using
      (Measure.restrict_apply_le (μ := μ) B {x | ⟪y, x⟫_ℝ + c = ⟪z, x⟫_ℝ + d})) zero_le
  rw [hzero, smul_zero]

/-- Pairwise distinct sites have an a.e. strict winner after restricting
    and renormalizing Haar measure. This is the strict-winner hypothesis of
    the integrated finite-maximum derivative. -/
theorem ae_strict_affineWinner_restrict_smul
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (q : ℝ≥0∞)
    (y : I → E) (hy : Function.Injective y) (c : I → ℝ) :
    ∀ᵐ x ∂(q • μ.restrict B), ∃ i, ∀ j, j ≠ i →
      ⟪y j, x⟫_ℝ + c j < ⟪y i, x⟫_ℝ + c i := by
  classical
  have h (i j : I) : ∀ᵐ x ∂(q • μ.restrict B), j ≠ i →
      ⟪y j, x⟫_ℝ + c j ≠ ⟪y i, x⟫_ℝ + c i := by
    by_cases hij : j = i
    · exact Filter.Eventually.of_forall fun _ hn => False.elim (hn hij)
    · apply Filter.Eventually.mono ?_ (fun _ h _ => h)
      rw [ae_iff]
      simpa only [not_ne_iff] using
        affineScore_tie_restrict_smul_null μ B q (y j) (y i) (hy.ne hij) (c j) (c i)
  have hall : ∀ᵐ x ∂(q • μ.restrict B), ∀ i j, j ≠ i →
      ⟪y j, x⟫_ℝ + c j ≠ ⟪y i, x⟫_ℝ + c i :=
    Filter.eventually_all.mpr fun i => Filter.eventually_all.mpr (h i)
  filter_upwards [hall] with x hx
  let f : I → ℝ := fun i => ⟪y i, x⟫_ℝ + c i
  obtain ⟨i, _, hi⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty f
  refine ⟨i, fun j hj => lt_of_le_of_ne ?_ (hx i j hj)⟩
  change f j ≤ f i
  rw [← hi]
  exact Finset.le_sup' f (Finset.mem_univ j)







/-! Compatibility section: bodyfresh. -/
/-- For a bounded compact source and distinct base sites, the integrated
    affine maximum has the site derivative on strict winning cells. -/
theorem body_affineMax_site_hasDerivAt
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hcompact : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (c : I → ℝ) :
    let ρ := q • μ.restrict B
    let U (i : I) : Set E := {x | ∀ j, j ≠ i →
      ⟪y j, x⟫_ℝ + c j < ⟪y i, x⟫_ℝ + c i}
    HasDerivAt (fun t : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
      (fun i => ⟪y i + t • v i, x⟫_ℝ + c i) ∂ρ)
      (∑ i, ∫ x in U i, ⟪v i, x⟫_ℝ ∂ρ) 0 := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let U (i : I) : Set E := {x | ∀ j, j ≠ i →
    ⟪y j, x⟫_ℝ + c j < ⟪y i, x⟫_ℝ + c i}
  let a (i : I) (x : E) := ⟪y i, x⟫_ℝ + c i
  let b (i : I) (x : E) := ⟪v i, x⟫_ℝ
  have : IsFiniteMeasure (μ.restrict B) :=
    isFiniteMeasure_restrict.mpr hcompact.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hρ : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hcompact.measurableSet) q
  have ha (i : I) : Measurable (a i) := (innerSL ℝ (y i)).continuous.measurable.add_const _
  have hb (i : I) : Measurable (b i) := (innerSL ℝ (v i)).continuous.measurable
  let M : ℝ := ∑ i, (‖y i‖ * (R : ℝ) + |c i|)
  have hMA (x : E) (hx : x ∈ B) (i : I) : |a i x| ≤ M := by
    refine (abs_add_le _ _).trans ?_
    have H : |⟪y i, x⟫_ℝ| ≤ ‖y i‖ * ‖x‖ := by
      simpa only [Real.norm_eq_abs] using (norm_inner_le_norm (𝕜 := ℝ) (y i) x)
    have H' : |⟪y i, x⟫_ℝ| ≤ ‖y i‖ * (R : ℝ) :=
      H.trans (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    calc
      |⟪y i, x⟫_ℝ| + |c i| ≤ ‖y i‖ * (R : ℝ) + |c i| :=
        add_le_add_left H' (|c i|)
      _ ≤ M := Finset.single_le_sum (f := fun j => ‖y j‖ * (R : ℝ) + |c j|)
        (fun j _ => by positivity) (Finset.mem_univ i)
  let V : ℝ≥0 := (∑ i, ‖v i‖₊) * R
  have hVB (x : E) (hx : x ∈ B) (i : I) : |b i x| ≤ (V : ℝ) := by
    have H : |b i x| ≤ ‖v i‖ * ‖x‖ := by
      simpa only [b, Real.norm_eq_abs] using (norm_inner_le_norm (𝕜 := ℝ) (v i) x)
    refine H.trans ?_
    have hvi : ‖v i‖ ≤ (∑ j, ‖v j‖ : ℝ) :=
      Finset.single_le_sum (fun j _ => norm_nonneg (v j)) (Finset.mem_univ i)
    push_cast [V]
    exact mul_le_mul hvi (hR x hx) (norm_nonneg _) (by positivity)
  have hFmeas : Measurable (fun x => finiteAffineMax (fun i => a i x) (fun i => b i x) 0) := by
    have hm := Finset.measurable_sup' Finset.univ_nonempty (f := a) (fun i _ => ha i)
    have heq : Finset.univ.sup' Finset.univ_nonempty a =
        (fun x => finiteAffineMax (fun i => a i x) (fun i => b i x) 0) := by
      funext x
      rw [Finset.sup'_apply]
      simp [finiteAffineMax]
    rwa [← heq]
  have hFint : Integrable (fun x => finiteAffineMax (fun i => a i x) (fun i => b i x) 0) ρ := by
    apply (integrable_const M).mono' hFmeas.aestronglyMeasurable
    filter_upwards [hρ] with x hx
    simp only [finiteAffineMax, zero_mul, add_zero, Real.norm_eq_abs]
    obtain ⟨i, _, hi⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun i => a i x)
    rw [hi]
    exact hMA x hx i
  have hstrict : ∀ᵐ x ∂ρ, ∃ i, ∀ j, j ≠ i →
      a j x + 0 * b j x < a i x + 0 * b i x := by
    simpa [a] using ae_strict_affineWinner_restrict_smul μ B q y hy c
  have D := integral_finiteAffineMax_hasDerivAt ρ a b 0 ha hb hFint V (hρ.mono hVB) hstrict
  have hU (i : I) : MeasurableSet (U i) := by
    have heq : U i = ⋂ j : I,
        if j = i then Set.univ else {x | a j x < a i x} := by
      ext x
      simp only [U, Set.mem_ofPred_eq, Set.mem_iInter]
      constructor
      · intro h j
        by_cases hj : j = i
        · simp [hj]
        · simpa [hj, a] using h j hj
      · intro h j hj
        simpa [hj, a] using h j
    rw [heq]
    refine MeasurableSet.iInter fun j => ?_
    split_ifs
    · exact MeasurableSet.univ
    · exact measurableSet_lt (ha j) (ha i)
  have hbi (i : I) : Integrable (b i) ρ :=
    (integrable_const (V : ℝ)).mono' (hb i).aestronglyMeasurable (by
      filter_upwards [hρ] with x hx
      simpa [Real.norm_eq_abs] using hVB x hx i)
  have hD :
      (∫ x, ∑ i, (U i).indicator (b i) x ∂ρ) =
        ∑ i, ∫ x in U i, b i x ∂ρ := by
    rw [integral_finsetSum _ (fun i _ => (hbi i).indicator (hU i))]
    exact Finset.sum_congr rfl (fun i _ => integral_indicator (hU i))
  simp only [zero_mul, add_zero] at D
  change HasDerivAt _ (∫ x, ∑ i, (U i).indicator (b i) x ∂ρ) 0 at D
  rw [hD] at D
  have hfun : (fun t : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
      (fun i => ⟪y i + t • v i, x⟫_ℝ + c i) ∂ρ) =
      (fun t : ℝ => ∫ x, finiteAffineMax (fun i => a i x) (fun i => b i x) t ∂ρ) := by
    funext t
    congr 1
    funext x
    simp [finiteAffineMax, a, b, inner_add_left, real_inner_smul_left, add_right_comm]
  change HasDerivAt (fun t : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
      (fun i => ⟪y i + t • v i, x⟫_ℝ + c i) ∂ρ) (∑ i, ∫ x in U i, b i x ∂ρ) 0
  rw [hfun]
  exact D





/-! Compatibility section: contfresh. -/
/-- The integrand of the fixed-intercept derivative at a site/offset pair. It is
    zero at a tie and equals the slope of the unique winner elsewhere. -/
noncomputable def strictSiteSlope {E I : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [Fintype I]
    (y v : I → E) (c : I → ℝ) (x : E) : ℝ :=
  ∑ i, ({z | ∀ j, j ≠ i → ⟪y j, z⟫_ℝ + c j < ⟪y i, z⟫_ℝ + c i} : Set E).indicator
      (fun z => ⟪v i, z⟫_ℝ) x

private theorem strictSiteSlope_eq_of_winner {E I : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [Fintype I]
    (y v : I → E) (c : I → ℝ) (x : E) (i : I)
    (hi : ∀ j, j ≠ i → ⟪y j, x⟫_ℝ + c j < ⟪y i, x⟫_ℝ + c i) :
    strictSiteSlope y v c x = ⟪v i, x⟫_ℝ := by
  classical
  unfold strictSiteSlope
  rw [Finset.sum_eq_single i]
  · exact Set.indicator_of_mem (show x ∈ {z | ∀ j, j ≠ i →
        ⟪y j, z⟫_ℝ + c j < ⟪y i, z⟫_ℝ + c i} from hi) _
  · intro j _ hj
    apply Set.indicator_of_notMem
    intro h
    exact lt_asymm (hi j hj) (h i (Ne.symm hj))
  · simp

private theorem strictSiteSlope_measurable {E I : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [Fintype I]
    (y v : I → E) (c : I → ℝ) : Measurable (strictSiteSlope y v c) := by
  classical
  let a (i : I) (x : E) := ⟪y i, x⟫_ℝ + c i
  have ha (i : I) : Measurable (a i) := (innerSL ℝ (y i)).continuous.measurable.add_const _
  unfold strictSiteSlope
  apply Finset.measurable_sum
  intro i _
  apply (innerSL ℝ (v i)).continuous.measurable.indicator
  have heq : {z : E | ∀ j, j ≠ i → a j z < a i z} =
      ⋂ j : I, if j = i then Set.univ else {z | a j z < a i z} := by
    ext x
    simp only [Set.mem_ofPred_eq, Set.mem_iInter]
    constructor
    · intro h j
      by_cases hj : j = i
      · simp [hj]
      · simpa [hj] using h j hj
    · intro h j hj
      simpa [hj] using h j
  change MeasurableSet {z : E | ∀ j, j ≠ i → a j z < a i z}
  rw [heq]
  refine MeasurableSet.iInter fun j => ?_
  split_ifs
  · exact MeasurableSet.univ
  · exact measurableSet_lt (ha j) (ha i)

/-- Direction, sites and offsets can all vary. Injectivity is only needed at
    the limit. The strict-cell slope integrals converge under normalized
    compact-body Haar restriction. -/
theorem tendsto_body_strictSiteSlope_integral
    {E I T : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hcompact : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (l : Filter T) [l.IsCountablyGenerated]
    (Y V : T → I → E) (C : T → I → ℝ)
    (y v : I → E) (c : I → ℝ) (hy : Function.Injective y)
    (hY : ∀ i, Tendsto (fun t => Y t i) l (𝓝 (y i)))
    (hV : ∀ i, Tendsto (fun t => V t i) l (𝓝 (v i)))
    (hC : ∀ i, Tendsto (fun t => C t i) l (𝓝 (c i))) :
    let ρ := q • μ.restrict B
    Tendsto (fun t => ∫ x, strictSiteSlope (Y t) (V t) (C t) x ∂ρ) l
      (𝓝 (∫ x, strictSiteSlope y v c x ∂ρ)) := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  have : IsFiniteMeasure (μ.restrict B) :=
    isFiniteMeasure_restrict.mpr hcompact.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hρ : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hcompact.measurableSet) q
  let M : ℝ := ∑ i, (‖v i‖ + 1) * (R : ℝ)
  have hnear : ∀ᶠ t in l, ∀ i, ‖V t i‖ < ‖v i‖ + 1 := by
    apply Filter.eventually_all.mpr
    intro i
    have h := (continuous_norm.continuousAt.tendsto.comp (hV i))
    exact h.eventually (gt_mem_nhds (by linarith : ‖v i‖ < ‖v i‖ + (1 : ℝ)))
  apply tendsto_integral_filter_of_norm_le_const (μ := ρ)
  · exact Filter.Eventually.of_forall fun t =>
      (strictSiteSlope_measurable (Y t) (V t) (C t)).aestronglyMeasurable
  · refine ⟨M, ?_⟩
    filter_upwards [hnear] with t ht
    filter_upwards [hρ] with x hx
    unfold strictSiteSlope M
    refine (norm_sum_le _ _).trans (Finset.sum_le_sum (fun i _ => ?_))
    rw [Set.indicator_apply]
    split_ifs
    · exact (norm_inner_le_norm (𝕜 := ℝ) _ _).trans
        (mul_le_mul (ht i).le (hR x hx) (norm_nonneg _) (by positivity))
    · simp only [norm_zero]
      positivity
  · filter_upwards [ae_strict_affineWinner_restrict_smul μ B q y hy c] with x hx
    obtain ⟨i, hi⟩ := hx
    have hscore (j : I) : Tendsto (fun t => ⟪Y t j, x⟫_ℝ + C t j) l
        (𝓝 (⟪y j, x⟫_ℝ + c j)) := by
      have hYx := ((innerSL ℝ x).continuous.continuousAt.tendsto.comp (hY j)).add (hC j)
      change Tendsto (fun t => innerSL ℝ x (Y t j) + C t j) l
        (𝓝 (innerSL ℝ x (y j) + c j)) at hYx
      simpa only [innerSL_apply_apply, real_inner_comm x] using hYx
    have hwin : ∀ᶠ t in l, ∀ j, j ≠ i →
        ⟪Y t j, x⟫_ℝ + C t j < ⟪Y t i, x⟫_ℝ + C t i :=
      Filter.eventually_all.mpr fun j => by
        by_cases hj : j = i
        · exact Filter.Eventually.of_forall fun _ h => False.elim (h hj)
        · exact ((hscore j).eventually_lt (hscore i) (hi j hj)).mono fun _ h _ => h
    rw [strictSiteSlope_eq_of_winner y v c x i hi]
    have hv := (innerSL ℝ x).continuous.continuousAt.tendsto.comp (hV i)
    have heq : (fun t => strictSiteSlope (Y t) (V t) (C t) x) =ᶠ[l]
        (fun t => ⟪V t i, x⟫_ℝ) :=
      hwin.mono fun t h => strictSiteSlope_eq_of_winner (Y t) (V t) (C t) x i h
    apply Filter.Tendsto.congr' heq.symm
    change Tendsto (fun t => innerSL ℝ x (V t i)) l
      (𝓝 (innerSL ℝ x (v i))) at hv
    simpa only [innerSL_apply_apply, real_inner_comm x] using hv

/-- Joint continuity in the finite site, direction and intercept vectors. -/
theorem continuousAt_body_strictSiteSlope_integral
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hcompact : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (c : I → ℝ) (hy : Function.Injective y) :
    ContinuousAt (fun p : (I → E) × (I → E) × (I → ℝ) =>
      ∫ x, strictSiteSlope p.1 p.2.1 p.2.2 x ∂(q • μ.restrict B)) (y, v, c) := by
  apply tendsto_body_strictSiteSlope_integral μ B hcompact q hq R hR _ _ _ _ y v c hy
  · intro i
    exact (show Continuous (fun p : (I → E) × (I → E) × (I → ℝ) => p.1 i) by fun_prop).continuousAt
  · intro i
    exact (show Continuous (fun p : (I → E) × (I → E) × (I → ℝ) => p.2.1 i) by fun_prop).continuousAt
  · intro i
    exact (show Continuous (fun p : (I → E) × (I → E) × (I → ℝ) => p.2.2 i) by fun_prop).continuousAt






/-! Compatibility section: valuefresh. -/
private theorem strictSiteSlope_integral_eq_cells
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (c : I → ℝ) :
    let ρ := q • μ.restrict B
    (∫ x, strictSiteSlope y v c x ∂ρ) = ∑ i,
      ∫ x in {x | ∀ j, j ≠ i → ⟪y j, x⟫_ℝ + c j < ⟪y i, x⟫_ℝ + c i}, ⟪v i, x⟫_ℝ ∂ρ := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  let a (i : I) (x : E) := ⟪y i, x⟫_ℝ + c i
  let b (i : I) (x : E) := ⟪v i, x⟫_ℝ
  let U (i : I) : Set E := {x | ∀ j, j ≠ i → a j x < a i x}
  have ha i : Measurable (a i) := (innerSL ℝ (y i)).continuous.measurable.add_const _
  have hU (i : I) : MeasurableSet (U i) := by
    have heq : U i = ⋂ j : I, if j = i then Set.univ else {x | a j x < a i x} := by
      ext x
      simp only [U, Set.mem_ofPred_eq, Set.mem_iInter]
      constructor
      · intro h j
        by_cases hj : j = i
        · simp [hj]
        · simpa [hj] using h j hj
      · intro h j hj
        simpa [hj] using h j
    rw [heq]
    apply MeasurableSet.iInter
    intro j
    split_ifs
    · exact MeasurableSet.univ
    · exact measurableSet_lt (ha j) (ha i)
  have hb i : Integrable (b i) ρ := by
    apply (integrable_const (‖v i‖ * (R : ℝ))).mono'
      (innerSL ℝ (v i)).continuous.measurable.aestronglyMeasurable
    filter_upwards [hxB] with x hx
    exact (norm_inner_le_norm (𝕜 := ℝ) (v i) x).trans
      (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
  change (∫ x, ∑ i, (U i).indicator (b i) x ∂ρ) = ∑ i, ∫ x in U i, b i x ∂ρ
  rw [integral_finsetSum _ (fun i _ => (hb i).indicator (hU i))]
  exact Finset.sum_congr rfl (fun i _ => integral_indicator (hU i))

/-- The actual minimum dual value along an affine site perturbation. The mass
    vector is fixed. The existence and continuity of its optimizing intercepts
    are inputs; no derivative of the optimizing intercepts is required. -/
theorem body_minimumDualValue_site_hasDerivAt
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (m : I → ℝ)
    (optim : ℝ → I → ℝ) (hc : ContinuousAt optim 0)
    (hopt : ∀ᶠ t : ℝ in 𝓝 0, ∀ k : I → ℝ,
      (∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪y i + t • v i, x⟫_ℝ + optim t i) ∂(q • μ.restrict B)) -
        ∑ i, m i * optim t i ≤
      (∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪y i + t • v i, x⟫_ℝ + k i) ∂(q • μ.restrict B)) -
        ∑ i, m i * k i) :
    HasDerivAt (fun t : ℝ =>
      (∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪y i + t • v i, x⟫_ℝ + optim t i) ∂(q • μ.restrict B)) -
        ∑ i, m i * optim t i)
      (∑ i, ∫ x in {x | ∀ j, j ≠ i →
         ⟪y j, x⟫_ℝ + optim 0 j < ⟪y i, x⟫_ℝ + optim 0 i},
        ⟪v i, x⟫_ℝ ∂(q • μ.restrict B)) 0 := by
  classical
  let ρ := q • μ.restrict B
  let path (t : ℝ) (i : I) := y i + t • v i
  let G (t : ℝ) (k : I → ℝ) := (∫ x, Finset.univ.sup' Finset.univ_nonempty
      (fun i => ⟪path t i, x⟫_ℝ + k i) ∂ρ) - ∑ i, m i * k i
  let d (t : ℝ) (k : I → ℝ) := ∫ x, strictSiteSlope (path t) v k x ∂ρ
  rw [← strictSiteSlope_integral_eq_cells μ B hB q hq R hR y v (optim 0)]
  have hpath0 : path 0 = y := by ext i; simp [path]
  have joint : ContinuousAt (fun p : ℝ × (I → ℝ) => d p.1 p.2) (0, optim 0) := by
    have hp : ContinuousAt (fun p : ℝ × (I → ℝ) => path p.1)
        ((0 : ℝ), optim 0) := by unfold path; fun_prop
    have hs := tendsto_body_strictSiteSlope_integral μ B hB q hq R hR
      (𝓝 ((0 : ℝ), optim 0)) (fun p => path p.1) (fun _ => v) (fun p => p.2)
      (path 0) v (optim 0) (by simpa only [hpath0] using hy)
      (fun i => ((continuous_apply i).continuousAt.tendsto.comp hp.tendsto))
      (fun _ => tendsto_const_nhds)
      (fun i => ((continuous_apply i).continuousAt.tendsto.comp continuousAt_snd.tendsto))
    exact hs
  have hinj : ∀ᶠ t in 𝓝 (0 : ℝ), Function.Injective (path t) := by
    have H (i : I) : Tendsto (fun t => path t i) (𝓝 0) (𝓝 (y i)) := by
      have hp : ContinuousAt (fun t : ℝ => path t i) (0 : ℝ) := by unfold path; fun_prop
      simpa only [hpath0] using hp.tendsto
    have H' : ∀ᶠ t in 𝓝 (0 : ℝ), ∀ i j, i ≠ j → path t i ≠ path t j :=
      Filter.eventually_all.mpr fun i => Filter.eventually_all.mpr fun j => by
        by_cases h : i = j
        · exact Filter.Eventually.of_forall fun _ hij => False.elim (hij h)
        · have hd := ((H i).sub (H j)).eventually_ne (sub_ne_zero.mpr (hy.ne h))
          exact hd.mono fun _ hh _ => sub_ne_zero.mp hh
    exact H'.mono fun t H i j hij => by by_contra h; exact H i j h hij
  have hderiv : ∀ᶠ p : ℝ × (I → ℝ) in 𝓝 (0, optim 0),
      HasDerivAt (fun t => G t p.2) (d p.1 p.2) p.1 := by
    have hnear : ∀ᶠ p : ℝ × (I → ℝ) in 𝓝 ((0 : ℝ), optim 0),
        Function.Injective (path p.1) :=
      (show Tendsto (fun p : ℝ × (I → ℝ) => p.1) (𝓝 ((0 : ℝ), optim 0))
        (𝓝 0) from continuous_fst.continuousAt).eventually hinj
    filter_upwards [hnear] with p hp
    let t := p.1
    let k := p.2
    have D := body_affineMax_site_hasDerivAt μ B hB q hq R hR (path t) v hp k
    dsimp only at D
    rw [← strictSiteSlope_integral_eq_cells μ B hB q hq R hR (path t) v k] at D
    have D₀ := HasDerivAt.comp_sub_const t t (by simpa only [sub_self] using D)
    have hfun : (fun s : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪path t i + (s - t) • v i, x⟫_ℝ + k i) ∂ρ) =
        (fun s : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪path s i, x⟫_ℝ + k i) ∂ρ) := by
      have he (s : ℝ) (i : I) : path t i + (s - t) • v i = path s i := by
        dsimp [path]
        have hsum : t + (s - t) = s := by linarith
        rw [add_assoc, ← add_smul, hsum]
      simp only [he]
    change HasDerivAt (fun s : ℝ => ∫ x, Finset.univ.sup' Finset.univ_nonempty
        (fun i => ⟪path t i + (s - t) • v i, x⟫_ℝ + k i) ∂ρ) (d t k) t at D₀
    rw [hfun] at D₀
    exact D₀.sub_const (∑ i, m i * k i)
  have out := envelope_hasDerivAt G d optim 0 hc joint hderiv hopt
  simpa only [d, G, hpath0, path] using out





/-! Compatibility section: rect. -/



open Filter Set
open scoped Topology BigOperators



/-- The mixed rectangle estimate. (t) is the site path parameter and (s)
    is the mass perturbation. Derivatives in (t) are needed only for the two
    site paths (F(·,s)) and (F(·,0)). No mixed derivative is assumed. -/
theorem mixedRectangle_massDerivative_bound
    (F D : ℝ → ℝ → ℝ) (a b da db : ℝ) (hab : a ≤ b)
    (K : ℝ → ℝ) (k : ℝ) (hK : Tendsto K (𝓝[≠] (0 : ℝ)) (𝓝 k))
    (hma : HasDerivAt (F a) da 0) (hmb : HasDerivAt (F b) db 0)
    (hsite : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Icc a b,
      HasDerivAt (fun u => F u s) (D t s) t ∧
        HasDerivAt (fun u => F u 0) (D t 0) t)
    (hbound : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Icc a b,
      ‖D t s - D t 0‖ ≤ K s * ‖s‖) :
    ‖db - da‖ ≤ k * (b - a) := by
  let g (s : ℝ) := F b s - F a s
  have hg : HasDerivAt g (db - da) 0 := hmb.sub hma
  have hquot : Tendsto (fun s : ℝ => ‖(g s - g 0) / s‖)
      (𝓝[≠] (0 : ℝ)) (𝓝 ‖db - da‖) := by
    have H := continuous_norm.continuousAt.tendsto.comp hg.tendsto_slope_zero
    simpa only [Function.comp_def, zero_add, smul_eq_mul, div_eq_inv_mul] using H
  apply le_of_tendsto_of_tendsto hquot (hK.mul tendsto_const_nhds)
  have hz : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), s ≠ 0 := by
    exact self_mem_nhdsWithin
  filter_upwards [hsite, hbound, hz] with s hs hb hn
  have HM : ‖(F b s - F b 0) - (F a s - F a 0)‖ ≤
      K s * ‖s‖ * (b - a) :=
    norm_image_sub_le_of_norm_deriv_le_segment'
      (fun t ht => ((hs t ht).1.sub (hs t ht).2).hasDerivWithinAt)
      (fun t ht => hb t (Ico_subset_Icc_self ht)) b ⟨hab, le_rfl⟩
  rw [norm_div, div_le_iff₀ (norm_pos_iff.mpr hn)]
  have he : g s - g 0 = (F b s - F b 0) - (F a s - F a 0) := by unfold g; ring
  rw [he]
  simpa only [mul_assoc, mul_left_comm, mul_comm] using HM

/-- The form used by revised Brenier §5: the mass derivative is
    minus the pairing of the mass direction and the optimizing intercept.
    Gives the endpoint weighted inner-product bound, with conditional
    site-moment estimate encoded in (K(s)). -/
theorem mixedRectangle_interceptPairing_bound
    {I : Type*} [Fintype I]
    (F D : ℝ → ℝ → ℝ) (a b : ℝ) (hab : a ≤ b)
    (c : ℝ → I → ℝ) (h : I → ℝ)
    (K : ℝ → ℝ) (k : ℝ) (hK : Tendsto K (𝓝[≠] (0 : ℝ)) (𝓝 k))
    (hma : HasDerivAt (F a) (-(∑ i, h i * c a i)) 0)
    (hmb : HasDerivAt (F b) (-(∑ i, h i * c b i)) 0)
    (hsite : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Icc a b,
      HasDerivAt (fun u => F u s) (D t s) t ∧
        HasDerivAt (fun u => F u 0) (D t 0) t)
    (hbound : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Icc a b,
      ‖D t s - D t 0‖ ≤ K s * ‖s‖) :
    |∑ i, h i * (c b i - c a i)| ≤ k * (b - a) := by
  have H := mixedRectangle_massDerivative_bound F D a b _ _ hab K k hK hma hmb hsite hbound
  have he : -(∑ i, h i * c b i) - (-(∑ i, h i * c a i)) =
      -(∑ i, h i * (c b i - c a i)) := by
    simp_rw [mul_sub, Finset.sum_sub_distrib]
    ring
  simpa only [he, norm_neg, Real.norm_eq_abs] using H






/-! Compatibility section: moment. -/



open Filter
open scoped Topology BigOperators InnerProductSpace



noncomputable def massRectangleFactor {I E : Type*} [Fintype I] [Norm E]
    (R : ℝ) (m h : I → ℝ) (v : I → E) (s : ℝ) : ℝ :=
  R * Real.sqrt (∑ i, (2 * m i + s * h i) * ‖v i‖ ^ 2) *
    Real.sqrt (∑ i, h i ^ 2 / (2 * m i + s * h i))

/-- Weighted Cauchy–Schwarz converts a mass-discrimination moment bound
    into the needed site derivative bound for n = m + s h. -/
theorem momentEndpoint_to_rectangleBound
    {I E : Type*} [Fintype I] [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (R s : ℝ) (hR : 0 ≤ R) (m h : I → ℝ) (v B₀ B₁ : I → E)
    (hw : ∀ i, 0 < 2 * m i + s * h i)
    (hmoment : (∑ i, ‖B₁ i - B₀ i‖ ^ 2 / (2 * m i + s * h i)) ≤
      R ^ 2 * ∑ i, ((m i + s * h i) - m i) ^ 2 / (2 * m i + s * h i)) :
    |∑ i, ⟪v i, B₁ i⟫_ℝ - ∑ i, ⟪v i, B₀ i⟫_ℝ|
      ≤ massRectangleFactor R m h v s * |s| := by
  classical
  let w (i : I) := 2 * m i + s * h i
  let u (i : I) := B₁ i - B₀ i
  let a (i : I) := Real.sqrt (w i) * ‖v i‖
  let b (i : I) := ‖u i‖ / Real.sqrt (w i)
  have hpair : |∑ i, ⟪v i, B₁ i⟫_ℝ - ∑ i, ⟪v i, B₀ i⟫_ℝ|
      ≤ ∑ i, a i * b i := by
    rw [← Finset.sum_sub_distrib]
    simp_rw [← inner_sub_right]
    refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
    have hi : a i * b i = ‖v i‖ * ‖u i‖ := by
      dsimp [a,b]
      have hwi : 0 < w i := hw i
      rw [← mul_div_assoc]
      apply (div_eq_iff (Real.sqrt_pos.2 hwi).ne').2
      ring

    rw [hi]
    exact abs_real_inner_le_norm _ _
  have ha : (∑ i, a i ^ 2) = ∑ i, w i * ‖v i‖ ^ 2 := by
    refine Finset.sum_congr rfl fun i _ => ?_
    have hwi : 0 < w i := hw i
    simp only [a, mul_pow, Real.sq_sqrt hwi.le]
  have hb : (∑ i, b i ^ 2) = ∑ i, ‖u i‖ ^ 2 / w i := by
    refine Finset.sum_congr rfl fun i _ => ?_
    have hwi : 0 < w i := hw i
    simp only [b, div_pow, Real.sq_sqrt hwi.le]
  have hdisc : (∑ i, ((m i + s * h i) - m i) ^ 2 / w i) =
      s ^ 2 * ∑ i, h i ^ 2 / w i := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    have hh : m i + s * h i - m i = s * h i := by ring
    rw [hh, mul_pow, mul_div_assoc]
  have hsqrt : Real.sqrt (∑ i, ‖u i‖ ^ 2 / w i) ≤
      R * |s| * Real.sqrt (∑ i, h i ^ 2 / w i) := by
    have H : (∑ i, ‖u i‖ ^ 2 / w i) ≤
        (R * |s|)^2 * ∑ i, h i ^ 2 / w i := by
      change (∑ i, ‖u i‖ ^ 2 / w i) ≤
        R ^ 2 * ∑ i, ((m i + s * h i) - m i) ^ 2 / w i at hmoment
      rw [hdisc] at hmoment
      simpa only [mul_pow, sq_abs, mul_assoc] using hmoment
    apply (Real.sqrt_le_sqrt H).trans_eq
    rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (mul_nonneg hR (abs_nonneg _))]
  have hcs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ a b
  rw [ha, hb] at hcs
  have H := hpair.trans (hcs.trans (mul_le_mul_of_nonneg_left hsqrt (Real.sqrt_nonneg _)))
  simpa [massRectangleFactor, w, mul_assoc, mul_left_comm, mul_comm] using H

/-- Its continuous limit is the product of the two weighted norms. -/
theorem massRectangleFactor_tendsto_zero
    {I E : Type*} [Fintype I] [Norm E]
    (R : ℝ) (m h : I → ℝ) (v : I → E) (hm : ∀ i, 0 < m i) :
    Tendsto (massRectangleFactor R m h v) (𝓝[≠] (0 : ℝ))
      (𝓝 (R * Real.sqrt (∑ i, m i * ‖v i‖ ^ 2) *
        Real.sqrt (∑ i, h i ^ 2 / m i))) := by
  have hp (i : I) : ContinuousAt (fun s : ℝ => 2 * m i + s * h i) 0 := by fun_prop
  have h₁ : ContinuousAt (fun s : ℝ => ∑ i, (2 * m i + s * h i) * ‖v i‖ ^ 2) 0 := by
    fun_prop
  have hpiece (i : I) : ContinuousAt (fun s : ℝ => h i ^ 2 / (2 * m i + s * h i)) 0 := by
    apply continuousAt_const.div (hp i)
    simpa using (mul_ne_zero (by norm_num : (2 : ℝ) ≠ 0) (hm i).ne')
  have h₂ : ContinuousAt (fun s : ℝ => ∑ i, h i ^ 2 / (2 * m i + s * h i)) 0 := by
    fun_prop
  have H : ContinuousAt (massRectangleFactor R m h v) 0 :=
    (continuousAt_const.mul h₁.sqrt).mul h₂.sqrt
  have he : massRectangleFactor R m h v 0 =
      R * Real.sqrt (∑ i, m i * ‖v i‖ ^ 2) * Real.sqrt (∑ i, h i ^ 2 / m i) := by
    unfold massRectangleFactor
    simp only [zero_mul, add_zero]
    have e₁ : (∑ i, 2 * m i * ‖v i‖ ^ 2) = 2 * ∑ i, m i * ‖v i‖ ^ 2 := by
      simp_rw [Finset.mul_sum, mul_assoc]
    have e₂ : (∑ i, h i ^ 2 / (2 * m i)) = (1 / 2) * ∑ i, h i ^ 2 / m i := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      field_simp [(hm i).ne']
    rw [e₁, e₂, Real.sqrt_mul (by norm_num : 0 ≤ (2 : ℝ)),
      Real.sqrt_mul (by norm_num : 0 ≤ (1 / 2 : ℝ)), Real.sqrt_div (by norm_num : 0 ≤ (1 : ℝ)),
      Real.sqrt_one]
    have hs : √(2 : ℝ) ≠ 0 := by positivity
    field_simp [hs]
  rw [← he]
  exact H.tendsto.mono_left nhdsWithin_le_nhds






/-! Compatibility section: lip. -/
/-- Revised Brenier §5: the exact weighted intercept Lipschitz estimate
    from the two §3 differentiation interfaces and the endpoint moment
    inequality. The primal-dual and geometric assertions enter explicitly
    through F, Bmom, and the listed hypotheses. -/
theorem weightedIntercept_path_bound
    {I E : Type*} [Fintype I] [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (F : ℝ → (I → ℝ) → ℝ) (Bmom : ℝ → (I → ℝ) → I → E)
    (a b R : ℝ) (hab : a ≤ b) (hR : 0 ≤ R)
    (m : I → ℝ) (hm : ∀ i, 0 < m i) (hmass : ∑ i, m i = 1)
    (v : I → E) (c : ℝ → I → ℝ)
    (hca : ∑ i, m i * c a i = 0) (hcb : ∑ i, m i * c b i = 0)
    (hmassDeriv : ∀ t ∈ ({a,b} : Set ℝ), ∀ h : I → ℝ, (∑ i, h i) = 0 →
      HasDerivAt (fun s : ℝ => F t (fun i => m i + s * h i))
        (-(∑ i, h i * c t i)) 0)
    (hsiteDeriv : ∀ t ∈ Set.Icc a b, ∀ n : I → ℝ,
      (∀ i, 0 < n i) → (∑ i, n i) = 1 →
      HasDerivAt (fun u : ℝ => F u n) (∑ i, ⟪v i, Bmom t n i⟫_ℝ) t)
    (hmoment : ∀ t ∈ Set.Icc a b, ∀ n : I → ℝ,
      (∀ i, 0 < n i) → (∑ i, n i) = 1 →
      (∑ i, ‖Bmom t n i - Bmom t m i‖ ^ 2 / (m i + n i)) ≤
        R ^ 2 * ∑ i, (n i - m i) ^ 2 / (m i + n i)) :
    Real.sqrt (∑ i, m i * (c b i - c a i) ^ 2) ≤
      R * Real.sqrt (∑ i, m i * ‖v i‖ ^ 2) * (b - a) := by
  classical
  let e (i : I) := c b i - c a i
  let h (i : I) := m i * e i
  let n (s : ℝ) (i : I) := m i + s * h i
  let A : ℝ := ∑ i, m i * e i ^ 2
  have hA : 0 ≤ A := Finset.sum_nonneg (fun i _ => mul_nonneg (hm i).le (sq_nonneg _))
  have hh : (∑ i, h i) = 0 := by
    unfold h e
    simp only [mul_sub, Finset.sum_sub_distrib, hca, hcb, sub_self]
  have hsums (s : ℝ) : (∑ i, n s i) = 1 := by
    simp [n, Finset.sum_add_distrib, ← Finset.mul_sum, hh, hmass]
  have hn : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ i, 0 < n s i := by
    apply Filter.eventually_all.mpr
    intro i
    have hc' : ContinuousAt (fun s : ℝ => n s i) 0 := by unfold n; fun_prop
    exact ((continuousAt_const.eventually_lt hc' (by simpa [n] using hm i))).filter_mono
      nhdsWithin_le_nhds
  have hweights (s : ℝ) (i : I) : m i + n s i = 2 * m i + s * h i := by unfold n; ring
  let FF (t s : ℝ) := F t (n s)
  let D (t s : ℝ) := ∑ i, ⟪v i, Bmom t (n s) i⟫_ℝ
  have hn0 : n 0 = m := by ext i; simp [n]
  have hae : HasDerivAt (FF a) (-(∑ i, h i * c a i)) 0 :=
    hmassDeriv a (by simp) h hh
  have hbe : HasDerivAt (FF b) (-(∑ i, h i * c b i)) 0 :=
    hmassDeriv b (by simp) h hh
  have hsite : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Set.Icc a b,
      HasDerivAt (fun u => FF u s) (D t s) t ∧
        HasDerivAt (fun u => FF u 0) (D t 0) t := by
    filter_upwards [hn] with s hs t ht
    exact ⟨hsiteDeriv t ht (n s) hs (hsums s), hsiteDeriv t ht (n 0) (hn0 ▸ hm) (hsums 0)⟩
  have hbound : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ∀ t ∈ Set.Icc a b,
      ‖D t s - D t 0‖ ≤ massRectangleFactor R m h v s * ‖s‖ := by
    filter_upwards [hn] with s hs t ht
    have hpos (i : I) : 0 < 2 * m i + s * h i := by
      rw [← hweights]
      exact add_pos (hm i) (hs i)
    have hmom := hmoment t ht (n s) hs (hsums s)
    simp_rw [hweights] at hmom
    have H := momentEndpoint_to_rectangleBound R s hR m h v (Bmom t m) (Bmom t (n s)) hpos hmom
    simpa only [D, hn0, Real.norm_eq_abs] using H
  have H := mixedRectangle_interceptPairing_bound FF D a b hab c h _
    _ (massRectangleFactor_tendsto_zero R m h v hm) hae hbe hsite hbound
  have hlhs : (∑ i, h i * (c b i - c a i)) = A := by
    unfold A h
    refine Finset.sum_congr rfl fun i _ => ?_
    simp only [e]
    ring
  have hrhs : (∑ i, h i ^ 2 / m i) = A := by
    unfold A h
    refine Finset.sum_congr rfl fun i _ => ?_
    field_simp [(hm i).ne']
  rw [hlhs, abs_of_nonneg hA, hrhs] at H
  by_cases hzero : A = 0
  · change Real.sqrt A ≤ _
    rw [hzero, Real.sqrt_zero]
    exact mul_nonneg (mul_nonneg hR (Real.sqrt_nonneg _)) (sub_nonneg.mpr hab)
  · change Real.sqrt A ≤ _
    have hsqrt : 0 < Real.sqrt A := Real.sqrt_pos.2 (lt_of_le_of_ne hA (Ne.symm hzero))
    apply (mul_le_mul_iff_left₀ hsqrt).mp
    rw [← sq, Real.sq_sqrt hA]
    exact H.trans_eq (by ring)





/-! Compatibility section: l2trial. -/




open Set Filter MeasureTheory
open scoped Topology BigOperators



private noncomputable def labelMax {I : Type*} [Fintype I] [Nonempty I]
    (f : I → ℝ) : ℝ := Finset.univ.sup' Finset.univ_nonempty f

private theorem labelMax_eq {I : Type*} [Fintype I] [Nonempty I]
    (f : I → ℝ) (i : I) (hi : ∀ j, j ≠ i → f j < f i) : labelMax f = f i := by
  classical
  unfold labelMax
  refine le_antisymm (Finset.sup'_le _ _ fun j _ => ?_) (Finset.le_sup' f (Finset.mem_univ i))
  by_cases h : j = i
  · simp [h]
  · exact (hi j h).le

private theorem labelMax_sub_abs_le {I : Type*} [Fintype I] [Nonempty I]
    (f g : I → ℝ) (K : ℝ) (h : ∀ i, |f i-g i| ≤ K) :
    |labelMax f - labelMax g| ≤ K := by
  have hi : labelMax f ≤ labelMax g + K := by
    refine Finset.sup'_le _ _ fun i _ => ?_
    have H := (abs_le.mp (h i)).2
    have H' : g i ≤ labelMax g := Finset.le_sup' g (Finset.mem_univ i)
    linarith
  have hj : labelMax g ≤ labelMax f + K := by
    refine Finset.sup'_le _ _ fun i _ => ?_
    have H := (abs_le.mp (h i)).1
    have H' : f i ≤ labelMax f := Finset.le_sup' f (Finset.mem_univ i)
    linarith
  exact abs_le.mpr ⟨by linarith, by linarith⟩

private def strictLabels {I X : Type*} (f : I → X → ℝ) (i : I) : Set X :=
  {x | ∀ j, j ≠ i → f j x < f i x}

private theorem strictLabels_meas {I X : Type*} [Fintype I] [MeasurableSpace X]
    (f : I → X → ℝ) (hf : ∀ i, Measurable (f i)) (i : I) :
    MeasurableSet (strictLabels f i) := by
  classical
  have heq : strictLabels f i = ⋂ j : I, if j = i then univ else {x | f j x < f i x} := by
    ext x
    simp only [strictLabels, Set.mem_ofPred_eq, Set.mem_iInter]
    constructor
    · intro h j
      by_cases hj : j = i
      · simp [hj]
      · simpa [hj] using h j hj
    · intro h j hj
      simpa [hj] using h j
  rw [heq]
  refine MeasurableSet.iInter fun j => ?_
  split_ifs
  · exact MeasurableSet.univ
  · exact measurableSet_lt (hf j) (hf i)

private theorem strictLabels_sum_eq {I X : Type*} [Fintype I] (f g : I → X → ℝ)
    (x : X) (i : I) (hi : x ∈ strictLabels f i) :
    (∑ j, (strictLabels f j).indicator (g j) x) = g i x := by
  classical
  rw [Finset.sum_eq_single i]
  · exact Set.indicator_of_mem hi _
  · intro j _ hj
    apply Set.indicator_of_notMem
    intro h
    exact lt_asymm (hi j hj) (h i (Ne.symm hj))
  · simp

/-- The squared L² error between the actual max difference quotient and the
    quotient with the base winning label frozen tends to zero. The base
    label need be strict only almost everywhere. The perturbations need
    not be differentiable; a uniform eventual bound on their quotients
    suffices, and no source-uniform winner neighborhood is required. -/
theorem finiteMax_frozenWinner_L2_error_tendsto
    {I X : Type*} [Fintype I] [Nonempty I] [MeasurableSpace X]
    (μ : Measure X) [IsFiniteMeasure μ]
    (F : ℝ → I → X → ℝ) (hF : ∀ t i, Measurable (F t i))
    (K : ℝ) (hK : 0 ≤ K)
    (hbound : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), ∀ᵐ x ∂μ, ∀ i,
      |(F t i x - F 0 i x) / t| ≤ K)
    (hstrict : ∀ᵐ x ∂μ, ∃ i, x ∈ strictLabels (F 0) i)
    (hcont : ∀ᵐ x ∂μ, ∀ i, ContinuousAt (fun t => F t i x) 0) :
    Tendsto (fun t : ℝ => ∫ x,
      (((labelMax (fun i => F t i x) - labelMax (fun i => F 0 i x)) / t) -
      ∑ i, (strictLabels (F 0) i).indicator
          (fun z => (F t i z - F 0 i z) / t) x)^2 ∂μ)
      (𝓝[≠] (0 : ℝ)) (𝓝 0) := by
  classical
  let Q (t : ℝ) (i : I) (x : X) := (F t i x - F 0 i x)/t
  let U (i : I) := strictLabels (F 0) i
  let G (t : ℝ) (x : X) :=
    (labelMax (fun i => F t i x) - labelMax (fun i => F 0 i x))/t
  let H (t : ℝ) (x : X) := ∑ i, (U i).indicator (Q t i) x
  let E (t : ℝ) (x : X) := (G t x - H t x)^2
  have htend : Tendsto (fun t => ∫ x, E t x ∂μ) (𝓝[≠] (0 : ℝ))
      (𝓝 (∫ _ : X, (0 : ℝ) ∂μ)) := by
    apply tendsto_integral_filter_of_norm_le_const
    · apply Filter.Eventually.of_forall
      intro t
      have hm (s : ℝ) : Measurable (fun x => labelMax (fun i => F s i x)) := by
        have H' := Finset.measurable_sup' Finset.univ_nonempty (f := F s) (fun i _ => hF s i)
        have he : Finset.univ.sup' Finset.univ_nonempty (F s) =
            (fun x => labelMax (fun i => F s i x)) := by
          funext x
          rw [Finset.sup'_apply]
          rfl
        rwa [← he]
      have hG : Measurable (G t) := ((hm t).sub (hm 0)).div_const _
      have hH : Measurable (H t) := Finset.measurable_sum _
        (fun i _ => (((hF t i).sub (hF 0 i)).div_const _).indicator
          (strictLabels_meas (F 0) (hF 0) i))
      exact ((hG.sub hH).pow_const 2).aestronglyMeasurable
    · refine ⟨(2*K)^2, ?_⟩
      have hn : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), t ≠ 0 := self_mem_nhdsWithin
      filter_upwards [hbound, hn] with t ht ht0
      filter_upwards [ht, hstrict] with x hx hx'
      obtain ⟨i, hi⟩ := hx'
      have hH : H t x = Q t i x := strictLabels_sum_eq (F 0) (Q t) x i hi
      have hdiff (j : I) : |F t j x - F 0 j x| ≤ K * |t| := by
        have Hj := hx j
        rw [abs_div, div_le_iff₀ (abs_pos.mpr ht0)] at Hj
        exact Hj
      have hG : |G t x| ≤ K := by
        unfold G
        rw [abs_div, div_le_iff₀ (abs_pos.mpr ht0)]
        exact labelMax_sub_abs_le _ _ _ hdiff
      have habs : |G t x-H t x| ≤ 2*K := by
        rw [hH]
        exact (abs_sub _ _).trans (by linarith [hx i, hG])
      change ‖(G t x - H t x)^2‖ ≤ (2*K)^2
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (G t x - H t x))]
      rw [← sq_abs (G t x - H t x)]
      exact (sq_le_sq₀ (abs_nonneg _) (by linarith)).mpr habs
    · filter_upwards [hstrict, hcont] with x hx hb
      obtain ⟨i, hi⟩ := hx
      have hremain : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), ∀ j, j ≠ i → F t j x < F t i x := by
        apply Filter.eventually_all.mpr
        intro j
        by_cases hj : j = i
        · exact Filter.Eventually.of_forall fun _ h => False.elim (h hj)
        · exact (((hb j).eventually_lt (hb i) (hi j hj)).filter_mono
            nhdsWithin_le_nhds).mono fun _ hj' _ => hj'
      have he : (fun t => E t x) =ᶠ[𝓝[≠] (0 : ℝ)] fun _ => 0 := by
        filter_upwards [hremain] with t ht
        have hH : H t x = Q t i x := strictLabels_sum_eq (F 0) (Q t) x i hi
        have hG : G t x = Q t i x := by
          unfold G Q
          rw [labelMax_eq _ i ht, labelMax_eq _ i hi]
        simp [E, hG, hH]
      exact tendsto_const_nhds.congr' he.symm
  simpa using htend





/-! Compatibility section: l2weighted. -/
/-- The m-weighted intercept Lipschitz bound bounds every label quotient;
    positivity of each mass is exactly what is needed here. -/
theorem abs_component_quotient_le_of_weighted_bound
    {I : Type*} [Fintype I] (m d : I → ℝ) (hm : ∀ i, 0 < m i)
    (L t : ℝ) (ht : t ≠ 0)
    (hbound : Real.sqrt (∑ i, m i * (d i)^2) ≤ L * |t|) (i : I) :
    |d i / t| ≤ L / Real.sqrt (m i) := by
  have hu : m i * (d i)^2 ≤ ∑ j, m j * (d j)^2 :=
    Finset.single_le_sum (fun j _ => mul_nonneg (hm j).le (sq_nonneg _)) (Finset.mem_univ i)
  have hs := Real.sqrt_le_sqrt hu
  rw [Real.sqrt_mul (hm i).le, Real.sqrt_sq_eq_abs] at hs
  have hh := hs.trans hbound
  rw [abs_div, div_le_iff₀ (abs_pos.mpr ht)]
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ (Real.sqrt_pos.mpr (hm i))).mpr
  simpa only [mul_comm] using hh





/-! Compatibility section: l2body. -/
/-- Actual compact-body local comparison, with a weighted intercept
    difference bound, distinct base sites, and no time derivatives. -/
theorem body_frozenWinner_L2_error_tendsto
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (c : ℝ → I → ℝ)
    (hc : ContinuousAt c 0) (m : I → ℝ) (hm : ∀ i, 0 < m i)
    (L : ℝ) (hL : 0 ≤ L)
    (hLip : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ),
      Real.sqrt (∑ i, m i * (c t i - c 0 i)^2) ≤ L * |t|) :
    let ρ := q • μ.restrict B
    let F (t : ℝ) (i : I) (x : E) := ⟪y i + t • v i, x⟫_ℝ + c t i
    Tendsto (fun t : ℝ => ∫ x,
      (((labelMax (fun i => F t i x) - labelMax (fun i => F 0 i x))/t) -
      ∑ i, (strictLabels (F 0) i).indicator
          (fun z => (F t i z - F 0 i z)/t) x)^2 ∂ρ)
      (𝓝[≠] (0 : ℝ)) (𝓝 0) := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let F (t : ℝ) (i : I) (x : E) := ⟪y i + t • v i, x⟫_ℝ + c t i
  let K : ℝ := ∑ i, (‖v i‖ * (R : ℝ) + L / Real.sqrt (m i))
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hk' (i : I) : 0 ≤ ‖v i‖ * (R : ℝ) + L / Real.sqrt (m i) := by positivity
  have hk : 0 ≤ K := Finset.sum_nonneg (fun i _ => hk' i)
  refine finiteMax_frozenWinner_L2_error_tendsto ρ F ?_ K hk ?_ ?_ ?_
  · intro t i
    exact (innerSL ℝ (y i + t • v i)).continuous.measurable.add_const _
  · have hn : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), t ≠ 0 := self_mem_nhdsWithin
    filter_upwards [hLip, hn] with t ht ht0
    filter_upwards [hxB] with x hx
    intro i
    have Hc := abs_component_quotient_le_of_weighted_bound m
      (fun j => c t j - c 0 j) hm L t ht0 ht i
    have Hv : |⟪v i, x⟫_ℝ| ≤ ‖v i‖ * (R : ℝ) :=
      (abs_real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    have Hf : (F t i x - F 0 i x) / t =
        ⟪v i, x⟫_ℝ + (c t i - c 0 i)/t := by
      simp only [F, inner_add_left, real_inner_smul_left]
      field_simp [ht0]
      ring
    rw [Hf]
    exact (abs_add_le _ _).trans ((add_le_add Hv Hc).trans
      (Finset.single_le_sum (fun j _ => hk' j) (Finset.mem_univ i)))
  · simpa only [F, strictLabels, Set.mem_ofPred_eq, zero_smul, add_zero] using
      ae_strict_affineWinner_restrict_smul μ B q y hy (c 0)
  · apply Filter.Eventually.of_forall
    intro x i
    have hi : ContinuousAt (fun t => c t i) (0 : ℝ) :=
      (continuous_apply i).continuousAt.comp hc
    have hl : Continuous (fun t : ℝ => ⟪y i + t • v i, x⟫_ℝ) := by
      simp only [inner_add_left, real_inner_smul_left]
      fun_prop
    exact hl.continuousAt.add hi





/-! Compatibility section: frozensq. -/
open scoped InnerProductSpace ENNReal NNReal
open MeasureTheory.Measure

/-- The sharp constant needed in revised §5 for the frozen label term.
    The label masses are prescribed, not re-derived in this adapter. -/
theorem body_frozenAffineSlope_squaredIntegral_le
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (c k m : I → ℝ)
    (hM : ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪y j,x⟫_ℝ+c j) i) = m i)
    (hweighted : (∑ i, m i * (k i)^2) ≤ (R : ℝ)^2 * ∑ i, m i * ‖v i‖^2) :
    let ρ := q • μ.restrict B
    let U := strictLabels (fun j x => ⟪y j,x⟫_ℝ+c j)
    (∫ x, (∑ i, (U i).indicator (fun z => ⟪v i,z⟫_ℝ + k i) x)^2 ∂ρ)
      ≤ (2 * (R : ℝ))^2 * ∑ i, m i * ‖v i‖^2 := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let A (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
  let U := strictLabels A
  let H (i : I) (x : E) := ⟪v i,x⟫_ℝ+k i
  let D (i : I) : ℝ := 2 * ((R : ℝ) * ‖v i‖)^2 + 2 * (k i)^2
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hUx (i : I) : MeasurableSet (U i) :=
    strictLabels_meas A (fun j => (innerSL ℝ (y j)).continuous.measurable.add_const _) i
  have hBx : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hsq (i : I) (x : E) (hx : x ∈ B) : (H i x)^2 ≤ D i := by
    have hinner : |⟪v i,x⟫_ℝ| ≤ (R : ℝ) * ‖v i‖ := by
      rw [mul_comm (R : ℝ)]
      exact (abs_real_inner_le_norm _ _).trans
        (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    have hsquare : (⟪v i,x⟫_ℝ)^2 ≤ ((R : ℝ) * ‖v i‖)^2 := by
      rw [← sq_abs (⟪v i,x⟫_ℝ)]
      exact (sq_le_sq₀ (abs_nonneg _) (by positivity)).mpr hinner
    dsimp [H,D]
    nlinarith only [hsquare, sq_nonneg (⟪v i,x⟫_ℝ - k i)]
  have hI (i : I) : Integrable (fun x => (H i x)^2) (ρ.restrict (U i)) := by
    apply (integrable_const (D i)).mono'
      (((innerSL ℝ (v i)).continuous.measurable.add_const (k i)).pow_const 2).aestronglyMeasurable
    have hBB : ∀ᵐ x ∂(ρ.restrict (U i)), x ∈ B := hBx.filter_mono (ae_mono Measure.restrict_le_self)
    filter_upwards [hBB] with x hx
    change ‖(H i x)^2‖ ≤ D i
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (H i x))]
    exact hsq i x hx
  have hcell (i : I) : (∫ x in U i, (H i x)^2 ∂ρ) ≤ m i * D i := by
    have hBB : ∀ᵐ x ∂(ρ.restrict (U i)), x ∈ B := hBx.filter_mono (ae_mono Measure.restrict_le_self)
    have Hmono := integral_mono_ae (hI i) (integrable_const (D i))
      (hBB.mono fun x hx => hsq i x hx)
    have hiM : ρ.real (U i) = m i := hM i
    simpa only [setIntegral_const, smul_eq_mul, hiM] using Hmono
  have heq : (fun x => (∑ i, (U i).indicator (H i) x)^2) =ᵐ[ρ]
      fun x => ∑ i, (U i).indicator (fun z => (H i z)^2) x := by
    filter_upwards [ae_strict_affineWinner_restrict_smul μ B q y hy c] with x hx
    obtain ⟨i,hi⟩ := hx
    have hi' : x ∈ strictLabels A i := hi
    rw [strictLabels_sum_eq A H x i hi',
      strictLabels_sum_eq A (fun j z => (H j z)^2) x i hi']
  change (∫ x, (∑ i, (U i).indicator (H i) x)^2 ∂ρ) ≤ _
  rw [integral_congr_ae heq, integral_finsetSum _ (fun i _ =>
    (integrable_indicator_iff (hUx i)).mpr (hI i))]
  simp_rw [integral_indicator (hUx _)]
  apply (Finset.sum_le_sum (fun i _ => hcell i)).trans
  unfold D
  simp_rw [mul_add, mul_pow]
  rw [Finset.sum_add_distrib]
  have e₁ : (∑ i, m i * (2 * ((R : ℝ)^2 * ‖v i‖^2))) =
      2 * (R : ℝ)^2 * ∑ i, m i * ‖v i‖^2 := by
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun _ _ => by ring
  have e₂ : (∑ i, m i * (2 * (k i)^2)) = 2 * ∑ i, m i * (k i)^2 := by
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun _ _ => by ring
  rw [e₁,e₂]
  nlinarith only [hweighted]





/-! Compatibility section: actualsq. -/
/-- Substitute the actual time quotient k=(c_t-c_0)/t, with weights m. -/
theorem body_frozenWinner_quotient_squaredIntegral_le
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (c : ℝ → I → ℝ)
    (m : I → ℝ) (hm : ∀ i, 0 < m i)
    (hM : ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪y j,x⟫_ℝ+c 0 j) i) = m i)
    (t : ℝ) (ht : t ≠ 0)
    (hLip : Real.sqrt (∑ i, m i * (c t i-c 0 i)^2) ≤
      (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * |t|) :
    let ρ := q • μ.restrict B
    let U := strictLabels (fun j x => ⟪y j,x⟫_ℝ+c 0 j)
    (∫ x, (∑ i, (U i).indicator
        (fun z => ((⟪y i+t • v i,z⟫_ℝ+c t i) - (⟪y i,z⟫_ℝ+c 0 i))/t) x)^2 ∂ρ)
      ≤ (2 * (R : ℝ))^2 * ∑ i, m i * ‖v i‖^2 := by
  let k (i : I) := (c t i-c 0 i)/t
  have ha : 0 ≤ (∑ i, m i * (c t i-c 0 i)^2) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (hm i).le (sq_nonneg _))
  have hv : 0 ≤ (∑ i, m i * ‖v i‖^2) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (hm i).le (sq_nonneg _))
  have hs := (sq_le_sq₀ (Real.sqrt_nonneg _)
    (by positivity : 0 ≤ (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * |t|)).mpr hLip
  rw [Real.sq_sqrt ha, mul_pow, mul_pow, Real.sq_sqrt hv, sq_abs] at hs
  have hk : (∑ i, m i * (k i)^2) ≤ (R : ℝ)^2 * ∑ i, m i * ‖v i‖^2 := by
    have he : (∑ i, m i * (k i)^2) = (∑ i, m i * (c t i-c 0 i)^2)/t^2 := by
      simp only [k, div_pow, mul_div_assoc, Finset.sum_div]
    rw [he]
    exact (div_le_iff₀ (sq_pos_of_ne_zero ht)).mpr hs
  have H := body_frozenAffineSlope_squaredIntegral_le μ B hB q hq R hR y v hy (c 0) k m hM hk
  have he (i : I) (z : E) : ((⟪y i+t • v i,z⟫_ℝ+c t i) - (⟪y i,z⟫_ℝ+c 0 i))/t =
      ⟪v i,z⟫_ℝ+k i := by
    simp only [k, inner_add_left, real_inner_smul_left]
    field_simp [ht]
    ring
  simpa only [he] using H





/-! Compatibility section: young. -/



open MeasureTheory Filter
open scoped Topology



/-- Recover the exact local upper slope from a uniformly bounded frozen
    quotient and an error tending to zero in L². Uses squared integrals
    and Young's inequality instead of differentiability. -/
theorem eventually_sqrtIntegral_sq_le_of_frozen_error
    {X T : Type*} [MeasurableSpace X] (μ : Measure X) (l : Filter T)
    (G H : T → X → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (hi : ∀ᶠ t in l,
      Integrable (fun x => (G t x - H t x)^2) μ ∧ Integrable (fun x => (H t x)^2) μ ∧
        Measurable (G t))
    (hfrozen : ∀ᶠ t in l, (∫ x, (H t x)^2 ∂μ) ≤ C^2)
    (herror : Tendsto (fun t => ∫ x, (G t x - H t x)^2 ∂μ) l (𝓝 0)) :
    ∀ r > C, ∀ᶠ t in l, Real.sqrt (∫ x, (G t x)^2 ∂μ) ≤ r := by
  intro r hr
  have hr0 : 0 ≤ r := hC.trans hr.le
  let gap := r^2 - C^2
  have hgap : 0 < gap := by dsimp [gap]; nlinarith
  let ε := gap / (2 * (C^2+1))
  have he : 0 < ε := by dsimp [ε]; positivity
  let W := 1 + 1/ε
  have hW : 0 < W := by dsimp [W]; positivity
  have hsmall : ∀ᶠ t in l, (∫ x, (G t x - H t x)^2 ∂μ) < gap / (2 * W) :=
    herror.eventually (gt_mem_nhds (by positivity))
  filter_upwards [hi, hfrozen, hsmall] with t ht hft hst
  obtain ⟨hE, hH, hG⟩ := ht
  have hp (x : X) : (G t x)^2 ≤ (1+ε)*(H t x)^2 + W*(G t x-H t x)^2 := by
    apply (mul_le_mul_iff_right₀ he).mp
    have hε : ε * W = ε + 1 := by dsimp [W]; field_simp
    rw [mul_add, ← mul_assoc, ← mul_assoc, hε]
    nlinarith only [sq_nonneg ((G t x-H t x)-ε*H t x)]
  have hA : Integrable (fun x => (1+ε)*(H t x)^2 + W*(G t x-H t x)^2) μ :=
    (hH.const_mul _).add (hE.const_mul _)
  have hGi : Integrable (fun x => (G t x)^2) μ := by
    apply hA.mono' (hG.pow_const 2).aestronglyMeasurable
    apply Filter.Eventually.of_forall
    intro x
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (G t x))]
    exact hp x
  have hs := integral_mono_ae hGi hA (Filter.Eventually.of_forall hp)
  rw [integral_add (hH.const_mul _) (hE.const_mul _), integral_const_mul, integral_const_mul] at hs
  have hsmall' : W*(∫ x, (G t x-H t x)^2 ∂μ) < gap/2 := by
    have hh := (lt_div_iff₀ (show 0 < 2*W by positivity)).mp hst
    linarith
  have heC : ε*C^2 ≤ gap/2 := by
    dsimp [ε]
    rw [div_mul_eq_mul_div]
    apply (div_le_iff₀ (show 0 < 2*(C^2+1) by positivity)).mpr
    nlinarith only [hgap]
  have hf' := mul_le_mul_of_nonneg_left hft (by positivity : 0 ≤ 1+ε)
  have Hbound : (∫ x, (G t x)^2 ∂μ) ≤ r^2 := by
    nlinarith only [hs, hsmall', heC, hf']
  exact (Real.sqrt_le_sqrt Hbound).trans_eq (Real.sqrt_sq hr0)





/-! Compatibility section: realLocal. -/
/-- The genuine compact-body potential quotient has local upper L² slope
    at most the exact 2R expression, without time differentiability. -/
theorem body_actualPotential_quotient_eventually_le_exact
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (hy : Function.Injective y) (c : ℝ → I → ℝ)
    (hc : ContinuousAt c 0) (m : I → ℝ) (hm : ∀ i, 0 < m i)
    (hM : ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪y j,x⟫_ℝ+c 0 j) i) = m i)
    (hLip : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ),
      Real.sqrt (∑ i, m i * (c t i-c 0 i)^2) ≤
        (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * |t|) :
    let ρ := q • μ.restrict B
    let F (t : ℝ) (i : I) (x : E) := ⟪y i+t • v i,x⟫_ℝ+c t i
    ∀ r > 2 * (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2),
      ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), Real.sqrt (∫ x,
        ((labelMax (fun i => F t i x)-labelMax (fun i => F 0 i x))/t)^2 ∂ρ) ≤ r := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let F (t : ℝ) (i : I) (x : E) := ⟪y i+t • v i,x⟫_ℝ+c t i
  let U := strictLabels (F 0)
  let Q (t : ℝ) (i : I) (x : E) := (F t i x-F 0 i x)/t
  let G (t : ℝ) (x : E) := (labelMax (fun i => F t i x)-labelMax (fun i => F 0 i x))/t
  let H (t : ℝ) (x : E) := ∑ i, (U i).indicator (Q t i) x
  let L : ℝ := (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2)
  have hL : 0 ≤ L := by dsimp [L]; positivity
  have h₂L : 0 ≤ 2 * L := by positivity
  have hv : 0 ≤ (∑ i, m i * ‖v i‖^2) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (hm i).le (sq_nonneg _))
  have hn : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), t ≠ 0 := self_mem_nhdsWithin
  have hF (t : ℝ) (i : I) : Measurable (F t i) :=
    (innerSL ℝ (y i+t • v i)).continuous.measurable.add_const _
  have hU (i : I) : MeasurableSet (U i) := strictLabels_meas (F 0) (hF 0) i
  have hG (t : ℝ) : Measurable (G t) := by
    have hM' (s : ℝ) : Measurable (fun x => labelMax (fun i => F s i x)) := by
      have hm' := Finset.measurable_sup' Finset.univ_nonempty (f := F s) (fun i _ => hF s i)
      have he : Finset.univ.sup' Finset.univ_nonempty (F s) =
          (fun x => labelMax (fun i => F s i x)) := by
        funext x
        rw [Finset.sup'_apply]
        rfl
      rwa [← he]
    exact ((hM' t).sub (hM' 0)).div_const _
  have hH (t : ℝ) : Measurable (H t) :=
    Finset.measurable_sum _ (fun i _ => (((hF t i).sub (hF 0 i)).div_const _).indicator (hU i))
  have hstrict : ∀ᵐ x ∂ρ, ∃ i, x ∈ U i := by
    simpa only [U,F,strictLabels, Set.mem_ofPred_eq, zero_smul,add_zero] using
      ae_strict_affineWinner_restrict_smul μ B q y hy (c 0)
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  let K : ℝ := ∑ i, (‖v i‖ * (R : ℝ) + L / Real.sqrt (m i))
  have hk' (i : I) : 0 ≤ ‖v i‖ * (R : ℝ) + L / Real.sqrt (m i) := by positivity
  have hk : 0 ≤ K := Finset.sum_nonneg (fun i _ => hk' i)
  have hInt : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ),
      Integrable (fun x => (G t x-H t x)^2) ρ ∧
      Integrable (fun x => (H t x)^2) ρ ∧ Measurable (G t) := by
    filter_upwards [hn, hLip] with t ht htLip
    have hbound : ∀ᵐ x ∂ρ, |G t x| ≤ K ∧ |H t x| ≤ K := by
      filter_upwards [hxB,hstrict] with x hx hwin
      obtain ⟨i, hi⟩ := hwin
      have hQ (j : I) : |Q t j x| ≤ K := by
        have Hc := abs_component_quotient_le_of_weighted_bound m
          (fun k => c t k-c 0 k) hm L t ht htLip j
        have Hv : |⟪v j,x⟫_ℝ| ≤ ‖v j‖ * (R : ℝ) :=
          (abs_real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
        have he : Q t j x = ⟪v j,x⟫_ℝ + (c t j-c 0 j)/t := by
          simp only [Q,F,inner_add_left,real_inner_smul_left]
          field_simp [ht]
          ring
        rw [he]
        exact (abs_add_le _ _).trans ((add_le_add Hv Hc).trans
          (Finset.single_le_sum (fun k _ => hk' k) (Finset.mem_univ j)))
      refine ⟨?_, ?_⟩
      · unfold G
        rw [abs_div, div_le_iff₀ (abs_pos.mpr ht)]
        refine labelMax_sub_abs_le _ _ _ (fun j => ?_)
        have Hj := hQ j
        change |(F t j x - F 0 j x) / t| ≤ K at Hj
        rw [abs_div, div_le_iff₀ (abs_pos.mpr ht)] at Hj
        exact Hj
      · change |∑ j, (U j).indicator (Q t j) x| ≤ K
        rw [strictLabels_sum_eq _ _ _ i hi]
        exact hQ i
    refine ⟨?_, ?_, hG t⟩
    · apply (integrable_const ((2*K)^2)).mono'
        (((hG t).sub (hH t)).pow_const 2).aestronglyMeasurable
      filter_upwards [hbound] with x hx
      change ‖(G t x-H t x)^2‖ ≤ (2*K)^2
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (G t x-H t x)), ← sq_abs (G t x-H t x)]
      exact (sq_le_sq₀ (abs_nonneg _) (by linarith)).mpr
        ((abs_sub _ _).trans (by linarith [hx.1,hx.2]))
    · apply (integrable_const (K^2)).mono' ((hH t).pow_const 2).aestronglyMeasurable
      filter_upwards [hbound] with x hx
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (H t x)), ← sq_abs (H t x)]
      exact (sq_le_sq₀ (abs_nonneg _) hk).mpr hx.2
  have herror := body_frozenWinner_L2_error_tendsto μ B hB q hq R hR y v hy c hc m hm L hL hLip
  have hFr : ∀ᶠ t : ℝ in 𝓝[≠] (0 : ℝ), (∫ x, (H t x)^2 ∂ρ) ≤ (2*L)^2 := by
    filter_upwards [hn,hLip] with t ht htLip
    have Hb := body_frozenWinner_quotient_squaredIntegral_le μ B hB q hq R hR y v hy c m hm hM t ht htLip
    have HH : (∫ x, (H t x)^2 ∂ρ) ≤ (2 * (R : ℝ))^2 * ∑ i, m i * ‖v i‖^2 := by
      simpa only [H,Q,U,F,zero_smul,add_zero] using Hb
    rw [show (2*L)^2 = (2 * (R : ℝ))^2 * ∑ i, m i * ‖v i‖^2 by
      dsimp [L]; rw [mul_pow, mul_pow, Real.sq_sqrt hv, mul_pow, mul_assoc]]
    exact HH
  have hh := eventually_sqrtIntegral_sq_le_of_frozen_error ρ _ G H (2*L) h₂L hInt hFr herror
  simpa only [G,L,mul_assoc] using hh





/-! Compatibility section: lpadapt. -/




open MeasureTheory Filter Set
open scoped Topology ENNReal



theorem norm_toLp_two_eq_sqrtIntegral_sq
    {X : Type*} [MeasurableSpace X] {μ : Measure X} {f : X → ℝ}
    (hf : MemLp f 2 μ) :
    ‖hf.toLp f‖ = Real.sqrt (∫ x, (f x)^2 ∂μ) := by
  rw [Lp.norm_toLp, hf.eLpNorm_eq_integral_rpow_norm (by norm_num) (by norm_num)]
  have hn : 0 ≤ (∫ x, (f x)^2 ∂μ) := integral_nonneg (fun _ => sq_nonneg _)
  simp only [ENNReal.toReal_ofNat, Real.rpow_two, Real.norm_eq_abs, sq_abs,
    Real.sqrt_eq_rpow, one_div]
  rw [ENNReal.toReal_ofReal (Real.rpow_nonneg hn _)]

theorem norm_toLp_two_sub_eq_sqrtIntegral_sq
    {X : Type*} [MeasurableSpace X] {μ : Measure X} {f g : X → ℝ}
    (hf : MemLp f 2 μ) (hg : MemLp g 2 μ) :
    ‖hf.toLp f - hg.toLp g‖ = Real.sqrt (∫ x, (f x-g x)^2 ∂μ) := by
  rw [← MemLp.toLp_sub hf hg]
  exact norm_toLp_two_eq_sqrtIntegral_sq (hf.sub hg)

theorem norm_toLp_two_slope_eq_sqrtIntegral_sq
    {X : Type*} [MeasurableSpace X] {μ : Measure X} {f g : X → ℝ}
    (hf : MemLp f 2 μ) (hg : MemLp g 2 μ) (t : ℝ) :
    ‖hf.toLp f - hg.toLp g‖ / |t| = Real.sqrt (∫ x, ((f x-g x)/t)^2 ∂μ) := by
  have he : (fun x => (f x - g x)/t) = t⁻¹ • (f-g) := by funext x; simp [div_eq_inv_mul]
  have h := norm_toLp_two_eq_sqrtIntegral_sq ((hf.sub hg).const_smul t⁻¹)
  rw [MemLp.toLp_const_smul t⁻¹ (hf.sub hg), MemLp.toLp_sub hf hg, norm_smul, Real.norm_eq_abs, abs_inv,
    ← div_eq_inv_mul] at h
  rw [← he] at h
  exact h





/-! Compatibility section: slope. -/


open Set Filter
open scoped Topology



/-- A local right norm-slope upper bound yields a global bound on an
    interval, without assuming a derivative at any time. Apply it to the
    L²-valued potential path. -/
theorem endpoint_norm_le_of_local_right_slopes
    {E : Type*} [NormedAddCommGroup E] (f : ℝ → E) (a b C : ℝ)
    (hab : a ≤ b) (hc : ContinuousOn f (Icc a b))
    (hloc : ∀ t ∈ Ico a b, ∀ r > C,
      ∀ᶠ u in 𝓝[>] t, ‖f u - f t‖ ≤ r * (u - t)) :
    ‖f b - f a‖ ≤ C * (b - a) := by
  let g (t : ℝ) := ‖f t - f a‖
  let V (t : ℝ) := C * (t-a)
  have hg : ContinuousOn g (Icc a b) := (hc.sub continuousOn_const).norm
  have hV : ContinuousOn V (Icc a b) := by unfold V; fun_prop
  have hV' : ∀ t ∈ Ico a b, HasDerivWithinAt V C (Ici t) t := by
    intro t _
    have h : HasDerivAt V C t := by
      simpa [V] using ((hasDerivAt_id t).sub_const a).const_mul C
    exact h.hasDerivWithinAt
  have ha : g a ≤ V a := by simp [g,V]
  have hglobal := image_le_of_liminf_slope_right_le_deriv_boundary hg ha hV hV'
  apply hglobal _ ⟨hab, le_rfl⟩
  intro t ht r hr
  let r' := (r+C)/2
  have h1 : C < r' := by unfold r'; linarith
  have h2 : r' < r := by unfold r'; linarith
  have hright : ∀ᶠ u in 𝓝[>] t, t < u := self_mem_nhdsWithin
  apply Filter.Eventually.frequently
  filter_upwards [hloc t ht r' h1, hright] with u hu hut
  rw [slope_def_field, div_lt_iff₀ (sub_pos.mpr hut)]
  have hd : g u - g t ≤ ‖f u-f t‖ := by
    unfold g
    simpa only [sub_sub_sub_cancel_right] using
      norm_sub_norm_le (f u-f a) (f t-f a)
  exact hd.trans_lt (hu.trans_lt (mul_lt_mul_of_pos_right h2 (sub_pos.mpr hut)))





/-! Compatibility section: cent. -/
/-- A centered, punctured local slope bound is enough for continuity
    and for the global right-slope inequality on a closed subinterval. -/
theorem centered_local_slopes_to_endpoint
    {P : Type*} [NormedAddCommGroup P] (f : ℝ → P) (a b C : ℝ) (hab : a ≤ b)
    (hlocal : ∀ t ∈ Icc a b, ∀ r > C, ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ),
      ‖f (t+s)-f t‖ / |s| ≤ r) :
    ‖f b-f a‖ ≤ C*(b-a) := by
  have htrans (t : ℝ) : Tendsto (fun u : ℝ => u-t) (𝓝[≠] t) (𝓝[≠] (0 : ℝ)) := by
    apply tendsto_inf.mpr
    refine ⟨?_, ?_⟩
    · have H : Continuous (fun u : ℝ => u-t) := by fun_prop
      have h := (H.continuousAt (x := t)).tendsto
      exact (by simpa only [sub_self] using h :
        Tendsto (fun u : ℝ => u - t) (𝓝 t) (𝓝 0)).mono_left nhdsWithin_le_nhds
    · rw [tendsto_principal]
      have h : ∀ᶠ u : ℝ in 𝓝[≠] t, u ≠ t := self_mem_nhdsWithin
      exact h.mono fun u hu => sub_ne_zero.mpr hu
  have hloc (t : ℝ) (ht : t ∈ Icc a b) (r : ℝ) (hr : C < r) :
      ∀ᶠ u in 𝓝[≠] t, ‖f u-f t‖ ≤ r*|u-t| := by
    have h1 := (htrans t).eventually (hlocal t ht r hr)
    have h2 : ∀ᶠ u : ℝ in 𝓝[≠] t, u ≠ t := self_mem_nhdsWithin
    filter_upwards [h1,h2] with u hu hne
    have hu' : ‖f (t+(u-t))-f t‖ / |u-t| ≤ r := hu
    have he : t+(u-t) = u := by ring
    rw [he, div_le_iff₀ (abs_pos.mpr (sub_ne_zero.mpr hne))] at hu'
    exact hu'
  have hcont : ContinuousOn f (Icc a b) := by
    intro t ht
    apply ContinuousAt.continuousWithinAt
    apply continuousAt_iff_punctured_nhds.mpr
    apply tendsto_iff_dist_tendsto_zero.mpr
    have h := hloc t ht (C+1) (by linarith)
    have H : Tendsto (fun u : ℝ => (C+1)*|u-t|) (𝓝[≠] t) (𝓝 0) := by
      have hc : Continuous (fun u : ℝ => (C+1)*|u-t|) := by fun_prop
      simpa only [sub_self, abs_zero, mul_zero] using
        (hc.continuousAt (x := t)).tendsto.mono_left nhdsWithin_le_nhds
    refine squeeze_zero' (Filter.Eventually.of_forall fun _ => dist_nonneg) ?_ H
    simpa only [dist_eq_norm] using h
  apply endpoint_norm_le_of_local_right_slopes f a b C hab hcont
  intro t ht r hr
  have hr' : ∀ᶠ u : ℝ in 𝓝[>] t, t < u := self_mem_nhdsWithin
  filter_upwards [(hloc t (Ico_subset_Icc_self ht) r hr).filter_mono (nhdsGT_le_nhdsNE t), hr'] with u hu hx
  simpa only [abs_of_pos (sub_pos.mpr hx)] using hu





/-! Compatibility section: pathfresh. -/
/-- Genuine L²-valued max-affine path on any compact interior
    subinterval. The two endpoints here are still inside the admissible
    distinct-site interval, not possibly colliding transport endpoints. -/
theorem body_potential_L2_subinterval_bound
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y v : I → E) (c : ℝ → I → ℝ) (m : I → ℝ) (hm : ∀ i, 0 < m i)
    (a b : ℝ) (hab : a ≤ b)
    (hy : ∀ t ∈ Icc a b, Function.Injective (fun i => y i+t • v i))
    (hc : ∀ t ∈ Icc a b, ContinuousAt c t)
    (hM : ∀ t ∈ Icc a b, ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪y j+t • v j,x⟫_ℝ+c t j) i) = m i)
    (hLip : ∀ t ∈ Icc a b, ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ),
      Real.sqrt (∑ i, m i * (c (t+s) i-c t i)^2) ≤
        (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * |s|) :
    let ρ := q • μ.restrict B
    let U (t : ℝ) (x : E) := labelMax (fun i => ⟪y i+t • v i,x⟫_ℝ+c t i)
    Real.sqrt (∫ x, (U b x-U a x)^2 ∂ρ) ≤
      2 * (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * (b-a) := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let Y (t : ℝ) (i : I) := y i+t • v i
  let A (t : ℝ) (i : I) (x : E) := ⟪Y t i,x⟫_ℝ+c t i
  let U (t : ℝ) (x : E) := labelMax (fun i => A t i x)
  let C : ℝ := 2 * (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2)
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hA (t : ℝ) (i : I) : Measurable (A t i) :=
    (innerSL ℝ (Y t i)).continuous.measurable.add_const _
  have hU (t : ℝ) : Measurable (U t) := by
    have hm' := Finset.measurable_sup' Finset.univ_nonempty (f := A t) (fun i _ => hA t i)
    have he : Finset.univ.sup' Finset.univ_nonempty (A t) = U t := by
      funext x
      rw [Finset.sup'_apply]
      rfl
    rwa [← he]
  have hLp (t : ℝ) : MemLp (U t) 2 ρ := by
    let D : ℝ := ∑ i, (‖Y t i‖ * (R : ℝ) + |c t i|)
    apply MemLp.of_bound (hU t).aestronglyMeasurable D
    filter_upwards [hxB] with x hx
    change ‖Finset.univ.sup' Finset.univ_nonempty (fun i => A t i x)‖ ≤ D
    obtain ⟨i, _, hei⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun i => A t i x)
    rw [hei, Real.norm_eq_abs]
    have HH := (abs_real_inner_le_norm (Y t i) x).trans
      (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    exact (abs_add_le _ _).trans ((add_le_add_left HH _).trans
      (Finset.single_le_sum (f := fun j => ‖Y t j‖ * (R : ℝ) + |c t j|)
        (fun j _ => by positivity) (Finset.mem_univ i)))
  let f (t : ℝ) : Lp ℝ 2 ρ := (hLp t).toLp (U t)
  have hlocal (t : ℝ) (ht : t ∈ Icc a b) (r : ℝ) (hr : C < r) :
      ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ), ‖f (t+s)-f t‖/|s| ≤ r := by
    let cc (s : ℝ) := c (t+s)
    have hcc : ContinuousAt cc 0 := by
      have hplus : Continuous (fun s : ℝ => t+s) := by fun_prop
      exact (hc t ht).comp_of_eq hplus.continuousAt (add_zero t)
    have hm' : ∀ i, ρ.real (strictLabels (fun j x => ⟪Y t j,x⟫_ℝ+cc 0 j) i) = m i := by
      simpa only [Y,cc,add_zero] using hM t ht
    have hlip' : ∀ᶠ s : ℝ in 𝓝[≠] (0 : ℝ),
        Real.sqrt (∑ i, m i * (cc s i-cc 0 i)^2) ≤
          (R : ℝ) * Real.sqrt (∑ i, m i * ‖v i‖^2) * |s| := by
      simpa only [cc,add_zero] using hLip t ht
    have H := body_actualPotential_quotient_eventually_le_exact μ B hB q hq R hR
      (Y t) v (hy t ht) cc hcc m hm hm' hlip' r hr
    filter_upwards [H] with s hs
    have he (i : I) : Y t i+s • v i = Y (t+s) i := by simp only [Y,add_smul,add_assoc]
    change ‖(hLp (t+s)).toLp (U (t+s))-(hLp t).toLp (U t)‖/|s| ≤ r
    rw [norm_toLp_two_slope_eq_sqrtIntegral_sq]
    simpa only [he,cc,add_zero,zero_smul,U,A] using hs
  have H := centered_local_slopes_to_endpoint f a b C hab hlocal
  change ‖(hLp b).toLp (U b)-(hLp a).toLp (U a)‖ ≤ _ at H
  rw [norm_toLp_two_sub_eq_sqrtIntegral_sq] at H
  exact H





/-! Compatibility section: extc. -/




open Set Filter
open scoped Topology BigOperators NNReal



/-- The weighted path estimate gives a genuine endpoint extension of the
    normalized intercepts, with no need for endpoint cell injectivity. -/
theorem weightedIntercept_exists_normalized_extension
    {I : Type*} [Fintype I] (c : ℝ → I → ℝ) (m : I → ℝ)
    (a b L : ℝ) (hab : a < b) (hL : 0 ≤ L) (hm : ∀ i, 0 < m i)
    (hnorm : ∀ t ∈ Ioo a b, (∑ i, m i*c t i) = 0)
    (hLip : ∀ t ∈ Ioo a b, ∀ u ∈ Ioo a b,
      Real.sqrt (∑ i, m i * (c t i-c u i)^2) ≤ L*|t-u|) :
    ∃ d : ℝ → I → ℝ, Continuous d ∧ EqOn c d (Ioo a b) ∧
      ∀ t ∈ Icc a b, (∑ i, m i*d t i) = 0 := by
  classical
  let K : ℝ := ∑ i, L / Real.sqrt (m i)
  have hK : 0 ≤ K := Finset.sum_nonneg (fun _ _ => by positivity)
  let Knn : ℝ≥0 := ⟨K,hK⟩
  have hcoord (t u : ℝ) (ht : t ∈ Ioo a b) (hu : u ∈ Ioo a b) (i : I) :
      |c t i-c u i| ≤ K*|t-u| := by
    have h₁ : m i*(c t i-c u i)^2 ≤ ∑ j, m j*(c t j-c u j)^2 :=
      Finset.single_le_sum (f := fun j => m j*(c t j-c u j)^2)
        (fun j _ => mul_nonneg (hm j).le (sq_nonneg _)) (Finset.mem_univ i)
    have hs := (Real.sqrt_le_sqrt h₁).trans (hLip t ht u hu)
    rw [Real.sqrt_mul (hm i).le, Real.sqrt_sq_eq_abs] at hs
    have hh : |c t i-c u i| ≤ (L / Real.sqrt (m i))*|t-u| := by
      rw [div_mul_eq_mul_div, le_div_iff₀ (Real.sqrt_pos.mpr (hm i))]
      simpa only [mul_comm (Real.sqrt (m i))] using hs
    apply hh.trans
    gcongr
    exact Finset.single_le_sum (f := fun j => L / Real.sqrt (m j))
      (fun j _ => by positivity) (Finset.mem_univ i)
  have hLip' : LipschitzOnWith Knn c (Ioo a b) := by
    apply LipschitzOnWith.of_dist_le_mul
    intro t ht u hu
    refine (dist_pi_le_iff (by positivity)).mpr fun i => ?_
    rw [Real.dist_eq, Real.dist_eq]
    exact hcoord t u ht hu i
  obtain ⟨d, hd, hcd⟩ := hLip'.extend_pi
  refine ⟨d, hd.continuous, hcd, ?_⟩
  have hnormd : ∀ t ∈ Ioo a b, (∑ i, m i*d t i) = 0 := by
    intro t ht
    rw [← hcd ht]
    exact hnorm t ht
  have hclosed : IsClosed {t | (∑ i, m i*d t i) = 0} := by
    apply isClosed_eq
    have hcont := hd.continuous
    · fun_prop
    · exact continuous_const
  have HH := closure_minimal hnormd hclosed
  rw [closure_Ioo hab.ne] at HH
  exact HH





/-! Compatibility section: collision. -/
/-- The radius bound controls all endpoint intercept differences by
    the distance between their endpoint sites. In particular colliding
    sites share one limiting intercept. Actual positive cell masses are
    used only at the approaching parameters, never at the collision. -/
theorem endpoint_intercept_diff_le_of_positive_body_cells
    {I E T : Type*} [Fintype I] [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [MeasurableSpace E] [BorelSpace E]
    (μ : Measure E) (B : Set E) (q : ℝ≥0∞) (R : ℝ≥0)
    (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (l : Filter T) [l.NeBot] (Y : T → I → E) (C : T → I → ℝ)
    (y : I → E) (c : I → ℝ)
    (hY : ∀ i, Tendsto (fun t => Y t i) l (𝓝 (y i)))
    (hC : ∀ i, Tendsto (fun t => C t i) l (𝓝 (c i)))
    (hpos : ∀ᶠ t in l, ∀ i, 0 < (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪Y t j,x⟫_ℝ+C t j) i)) :
    ∀ i j, |c j-c i| ≤ (R : ℝ)*‖y i-y j‖ := by
  classical
  have h₁ (i j : I) : c j-c i ≤ (R : ℝ)*‖y i-y j‖ := by
    have htend₁ := (hC j).sub (hC i)
    have htend₂ : Tendsto (fun t => (R : ℝ)*‖Y t i-Y t j‖) l (𝓝 ((R : ℝ)*‖y i-y j‖)) :=
      tendsto_const_nhds.mul (continuous_norm.continuousAt.tendsto.comp
      ((hY i).sub (hY j)))
    apply le_of_tendsto_of_tendsto htend₁ htend₂
    filter_upwards [hpos] with t ht
    by_cases hij : j = i
    · simp [hij]
    · let a (k : I) (x : E) := ⟪Y t k,x⟫_ℝ+C t k
      let S := strictLabels a i
      have hS : MeasurableSet S := strictLabels_meas a (fun k =>
        (innerSL ℝ (Y t k)).continuous.measurable.add_const _) i
      have hn : (S ∩ B).Nonempty := by
        by_contra H
        have he : S ∩ B = ∅ := Set.not_nonempty_iff_eq_empty.mp H
        have hr : (q • μ.restrict B) S = 0 := by
          rw [Measure.smul_apply, Measure.restrict_apply hS, he, measure_empty, smul_zero]
        have Hpos := ht i
        change 0 < (q • μ.restrict B).real S at Hpos
        simp only [Measure.real, hr, ENNReal.toReal_zero, lt_self_iff_false] at Hpos
      obtain ⟨x,hx,hxB⟩ := hn
      have hlt : ⟪Y t j,x⟫_ℝ+C t j < ⟪Y t i,x⟫_ℝ+C t i := hx j hij
      have hinner : C t j-C t i ≤ ⟪Y t i-Y t j,x⟫_ℝ := by
        rw [inner_sub_left]
        linarith
      apply hinner.trans
      rw [mul_comm (R : ℝ)]
      exact (real_inner_le_norm _ _).trans
        (mul_le_mul_of_nonneg_left (hR x hxB) (norm_nonneg _))
  intro i j
  have h₂ := h₁ j i
  rw [norm_sub_rev (y j) (y i)] at h₂
  exact abs_le.mpr ⟨by linarith, h₁ i j⟩





/-! Compatibility section: argmin. -/




open Set
open scoped BigOperators



/-- Positive prescribed masses and weighted normalization bound all
    offsets once the maximum offset is bounded. -/
theorem normalized_intercept_box_of_upper
    {I : Type*} [Fintype I] (m c : I → ℝ) (hm : ∀ i, 0 < m i)
    (hmass : ∑ i, m i = 1) (hn : ∑ i, m i*c i = 0)
    (K : ℝ) (hK : 0 ≤ K) (hc : ∀ i, c i ≤ K) :
    ∀ i, -(K / m i) ≤ c i ∧ c i ≤ K := by
  intro i
  refine ⟨?_, hc i⟩
  have hsum : (∑ j, m j*(K-c j)) = K := by
    simp only [mul_sub, Finset.sum_sub_distrib, hn, sub_zero]
    rw [← Finset.sum_mul, hmass, one_mul]
  have hle : m i*(K-c i) ≤ K := by
    calc
      _ ≤ ∑ j, m j*(K-c j) := Finset.single_le_sum (f := fun j => m j*(K-c j))
        (fun j _ => mul_nonneg (hm j).le (sub_nonneg.mpr (hc j))) (Finset.mem_univ i)
      _ = K := hsum
  have H : K-c i ≤ K/m i := (le_div_iff₀ (hm i)).mpr (by simpa only [mul_comm] using hle)
  linarith

/-- Coercive normalized minimization on the finite intercept space.
    The common-shift symmetry upgrades the normalized minimizer to a
    minimizer among all intercepts. -/
theorem normalized_dual_argmin_exists
    {I : Type*} [Fintype I] (m : I → ℝ) (hm : ∀ i, 0 < m i)
    (hmass : ∑ i, m i = 1) (F : (I → ℝ) → ℝ) (hF : Continuous F)
    (A : ℝ) (hlower : ∀ c : I → ℝ, (∑ i, m i*c i) = 0 → ∀ i, c i ≤ F c+A)
    (hshift : ∀ (c : I → ℝ) (r : ℝ), F (fun i => c i+r) = F c) :
    ∃ c : I → ℝ, (∑ i,m i*c i)=0 ∧ ∀ k, F c ≤ F k := by
  classical
  let K : ℝ := max (F 0+A) 0
  have hK : 0 ≤ K := le_max_right _ _
  let S : Set (I → ℝ) := Set.pi Set.univ (fun i => Icc (-(K/m i)) K)
  let H : Set (I → ℝ) := {c | (∑ i,m i*c i)=0}
  have hH : IsClosed H := by
    apply isClosed_eq
    · fun_prop
    · exact continuous_const
  have hS : IsCompact S := isCompact_univ_pi (fun _ => isCompact_Icc)
  have h0 : (0 : I → ℝ) ∈ S ∩ H := by
    constructor
    · intro i _
      change -(K/m i) ≤ 0 ∧ 0 ≤ K
      exact ⟨neg_nonpos.mpr (div_nonneg hK (hm i).le), hK⟩
    · change (∑ i,m i*(0 : ℝ))=0
      simp
  obtain ⟨c,hc,hmin⟩ := (hS.inter_right hH).exists_isMinOn ⟨0,h0⟩ hF.continuousOn
  refine ⟨c,hc.2,?_⟩
  intro k
  let r := -(∑ i,m i*k i)
  let kk (i : I) := k i+r
  have hkk : kk ∈ H := by
    change (∑ i,m i*(k i+r))=0
    simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hmass, one_mul, r, add_neg_cancel]
  have hFkk : F kk = F k := hshift k r
  by_cases hk : F kk ≤ F 0
  · have hup (i : I) : kk i ≤ K :=
      (hlower kk hkk i).trans ((add_le_add_left hk A).trans (le_max_left _ _))
    have hbox := normalized_intercept_box_of_upper m kk hm hmass hkk K hK hup
    have hmem : kk ∈ S := fun i _ => hbox i
    rw [← hFkk]
    exact hmin ⟨hmem,hkk⟩
  · rw [← hFkk]
    exact (hmin h0).trans (le_of_not_ge hk)





/-! Compatibility section: bodyarg. -/
open MeasureTheory.Measure
open scoped ENNReal NNReal InnerProductSpace

/-- Existence of a genuine normalized minimizer for the compact-body finite
    dual. Site collision is allowed; only the asserted optimal cell-mass
    consequences use distinctness elsewhere. -/
theorem body_finite_dual_normalized_argmin_exists
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [Fintype I] [Nonempty I]
    (μ : Measure E) (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) [IsProbabilityMeasure (q • μ.restrict B)]
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y : I → E) (m : I → ℝ) (hm : ∀ i, 0 < m i) (hmass : ∑ i, m i = 1) :
    let ρ := q • μ.restrict B
    let G (c : I → ℝ) := (∫ x, labelMax (fun i => ⟪y i,x⟫_ℝ + c i) ∂ρ) -
      ∑ i, m i*c i
    ∃ c : I → ℝ, (∑ i,m i*c i)=0 ∧ ∀ d, G c ≤ G d := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let u (c : I → ℝ) (x : E) := labelMax (fun i => ⟪y i,x⟫_ℝ + c i)
  let G (c : I → ℝ) := (∫ x, u c x ∂ρ) - ∑ i, m i*c i
  let S : ℝ := ∑ i, ‖y i‖ * (R : ℝ)
  have hBx : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hA (c : I → ℝ) (i : I) : Measurable (fun x => ⟪y i,x⟫_ℝ + c i) :=
    (innerSL ℝ (y i)).continuous.measurable.add_const _
  have hUm (c : I → ℝ) : Measurable (u c) := by
    have H := Finset.measurable_sup' Finset.univ_nonempty
      (f := fun i x => ⟪y i,x⟫_ℝ + c i) (fun i _ => hA c i)
    have he : Finset.univ.sup' Finset.univ_nonempty (fun i x => ⟪y i,x⟫_ℝ + c i) = u c := by
      funext x
      rw [Finset.sup'_apply]
      rfl
    rwa [he] at H
  have hI (c : I → ℝ) : Integrable (u c) ρ := by
    let M : ℝ := ∑ i, (‖y i‖ * (R : ℝ) + |c i|)
    apply (integrable_const M).mono' (hUm c).aestronglyMeasurable
    filter_upwards [hBx] with x hx
    obtain ⟨i,_,hi⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun i => ⟪y i,x⟫_ℝ+c i)
    change ‖Finset.univ.sup' Finset.univ_nonempty (fun i => ⟪y i,x⟫_ℝ+c i)‖ ≤ M
    rw [hi, Real.norm_eq_abs]
    have Hy := (abs_real_inner_le_norm (y i) x).trans
      (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    exact (abs_add_le _ _).trans ((add_le_add_left Hy _).trans
      (Finset.single_le_sum (f := fun j => ‖y j‖*(R : ℝ)+|c j|)
        (fun j _ => by positivity) (Finset.mem_univ i)))
  have hρreal : ρ.real univ = 1 := by simp [Measure.real]
  have hcont : Continuous (fun c => ∫ x, u c x ∂ρ) := by
    apply (show LipschitzWith 1 (fun c => ∫ x, u c x ∂ρ) from ?_).continuous
    apply LipschitzWith.of_dist_le_mul
    intro c d
    rw [Real.dist_eq, NNReal.coe_one, one_mul, ← integral_sub (hI c) (hI d), ← Real.norm_eq_abs]
    refine (norm_integral_le_integral_norm _).trans ?_
    have H := integral_mono_ae (hI c |>.sub (hI d) |>.norm)
      (integrable_const (dist c d)) (Filter.Eventually.of_forall (fun x => ?_))
    · simpa only [integral_const, smul_eq_mul, hρreal, one_mul, Pi.sub_apply] using H
    · change ‖u c x - u d x‖ ≤ dist c d
      rw [Real.norm_eq_abs]
      apply labelMax_sub_abs_le
      intro i
      have he : ⟪y i,x⟫_ℝ+c i - (⟪y i,x⟫_ℝ+d i) = c i-d i := by ring
      rw [he, ← Real.dist_eq]
      exact dist_le_pi_dist c d i
  have hG : Continuous G := by unfold G; fun_prop
  refine normalized_dual_argmin_exists m hm hmass G hG S ?_ ?_
  · intro c hc i
    have H := integral_mono_ae (integrable_const (c i - S)) (hI c) (hBx.mono fun x hx => ?_)
    · simp only [integral_const,smul_eq_mul,hρreal,one_mul] at H
      dsimp [G]
      rw [hc,sub_zero]
      linarith
    · have HH : |⟪y i,x⟫_ℝ| ≤ S :=
        ((abs_real_inner_le_norm (y i) x).trans
          (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))).trans
            (Finset.single_le_sum (f := fun j => ‖y j‖*(R : ℝ))
              (fun j _ => by positivity) (Finset.mem_univ i))
      have HB : ⟪y i,x⟫_ℝ + c i ≤ u c x :=
        Finset.le_sup' (fun j => ⟪y j,x⟫_ℝ + c j) (Finset.mem_univ i)
      exact (by linarith [(abs_le.mp HH).1] : c i-S ≤ ⟪y i,x⟫_ℝ+c i).trans HB
  · intro c r
    have he : u (fun i => c i+r) = fun x => u c x + r := by
      funext x
      simp only [u,labelMax,← add_assoc,Finset.sup'_add]
    have hm' : (∑ i,m i*(c i+r)) = (∑ i,m i*c i)+r := by
      rw [show (∑ i,m i*(c i+r)) = (∑ i,m i*c i)+(∑ i,m i*r) by
        simp_rw [mul_add,Finset.sum_add_distrib], ← Finset.sum_mul, hmass, one_mul]
    dsimp [G]
    rw [he, integral_add (hI c) (integrable_const r), integral_const, hρreal,
      smul_eq_mul, one_mul, hm']
    ring





/-! Compatibility section: masspres. -/
/-- Fermat's rule for one intercept coordinate: an actual minimizer at
    a distinct-site configuration prescribes each strict cell mass. -/
theorem body_dual_argmin_prescribes_strictCell_mass
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [FiniteDimensional ℝ E] [Fintype I] [Nonempty I]
    (μ : Measure E) [IsAddHaarMeasure μ] (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) (hq : q ≠ ∞) (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (y : I → E) (hy : Function.Injective y) (m c : I → ℝ)
    (hopt : ∀ k : I → ℝ, ((∫ x, labelMax (fun j => ⟪y j,x⟫_ℝ+c j) ∂(q • μ.restrict B)) - ∑ j,m j*c j) ≤
      ((∫ x, labelMax (fun j => ⟪y j,x⟫_ℝ+k j) ∂(q • μ.restrict B)) - ∑ j,m j*k j)) :
    ∀ i, (q • μ.restrict B).real (strictLabels (fun j x => ⟪y j,x⟫_ℝ+c j) i) = m i := by
  classical
  intro i
  let ρ := q • μ.restrict B
  let A (j : I) (x : E) := ⟪y j,x⟫_ℝ+c j
  let U := strictLabels A
  let δ (j : I) : ℝ := if j=i then 1 else 0
  let k (t : ℝ) (j : I) := c j+t*δ j
  let val (t : ℝ) := ∫ x, labelMax (fun j => ⟪y j,x⟫_ℝ+k t j) ∂ρ
  let dual (t : ℝ) := val t - ∑ j,m j*k t j
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hA (j : I) : Measurable (A j) :=
    (innerSL ℝ (y j)).continuous.measurable.add_const _
  have hU : MeasurableSet (U i) := strictLabels_meas A hA i
  have hUm : Measurable (fun x => labelMax (fun j => A j x)) := by
    have H := Finset.measurable_sup' Finset.univ_nonempty (f := A) (fun j _ => hA j)
    have he : Finset.univ.sup' Finset.univ_nonempty A = fun x => labelMax (fun j => A j x) := by
      funext x; rw [Finset.sup'_apply]; rfl
    rwa [he] at H
  have hI : Integrable (fun x => labelMax (fun j => A j x)) ρ := by
    let M : ℝ := ∑ j, (‖y j‖ * (R : ℝ) + |c j|)
    apply (integrable_const M).mono' hUm.aestronglyMeasurable
    filter_upwards [hxB] with x hx
    obtain ⟨j,_,hj⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun j => A j x)
    change ‖Finset.univ.sup' Finset.univ_nonempty (fun j => A j x)‖ ≤ M
    rw [hj, Real.norm_eq_abs]
    have H := (abs_real_inner_le_norm (y j) x).trans
      (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    exact (abs_add_le _ _).trans ((add_le_add_left H _).trans
      (Finset.single_le_sum (f := fun j => ‖y j‖*(R : ℝ)+|c j|)
        (fun j _ => by positivity) (Finset.mem_univ j)))
  have hstrict : ∀ᵐ x ∂ρ, ∃ j, ∀ l, l ≠ j → A l x + 0 * δ l < A j x + 0 * δ j := by
    simpa only [A,zero_mul,add_zero] using ae_strict_affineWinner_restrict_smul μ B q y hy c
  have heq : (fun t : ℝ => ∫ x, finiteAffineMax (fun j => A j x) δ t ∂ρ) = val := by
    funext t
    congr 1
    funext x
    simp only [finiteAffineMax,labelMax,A,k,add_assoc]
  have hd := integral_finiteAffineMax_hasDerivAt ρ A (fun j _ => δ j) 0 hA
    (fun _ => measurable_const) (by simpa only [finiteAffineMax,zero_mul,add_zero,labelMax] using hI)
    1 (Filter.Eventually.of_forall fun _ j => by by_cases H : j=i <;> simp [δ,H]) hstrict
  have hs : (fun x => ∑ j, (U j).indicator (fun _ => δ j) x) =
      (U i).indicator (fun _ => (1 : ℝ)) := by
    funext x
    rw [Finset.sum_eq_single i]
    · simp [δ]
    · intro j _ hji
      simp [δ,hji,Set.indicator_apply]
    · simp
  simp only [zero_mul, add_zero] at hd
  change HasDerivAt (fun t : ℝ => ∫ x, finiteAffineMax (fun j => A j x) δ t ∂ρ)
    (∫ x, ∑ j, (U j).indicator (fun _ => δ j) x ∂ρ) 0 at hd
  have hi' : (∫ x, ∑ j, (U j).indicator (fun _ => δ j) x ∂ρ) = ρ.real (U i) := by
    rw [hs]
    exact integral_indicator_one (μ := ρ) hU
  rw [heq, hi'] at hd
  have hmass : (fun t : ℝ => ∑ j,m j*k t j) =
      (fun t => (∑ j,m j*c j)+t*m i) := by
    funext t
    simp only [k, mul_add, Finset.sum_add_distrib]
    congr 1
    rw [Finset.sum_eq_single i]
    · simp [δ]; ring
    · intro j _ hji
      simp [δ,hji]
    · simp
  have hD : HasDerivAt (fun t : ℝ => ∑ j,m j*k t j) (m i) 0 := by
    rw [hmass]
    simpa using ((hasDerivAt_id (0 : ℝ)).mul_const (m i)).const_add (∑ j,m j*c j)
  have hDual : HasDerivAt dual (ρ.real (U i)-m i) 0 := hd.sub hD
  have hk : k 0 = c := by funext j; simp [k]
  have hlmin : IsLocalMin dual 0 :=
    Filter.Eventually.of_forall fun t => by
      change dual 0 ≤ dual t
      dsimp only [dual,val]
      rw [hk]
      exact hopt (k t)
  exact sub_eq_zero.mp (hlmin.hasDerivAt_eq_zero hDual)





/-! Compatibility section: fused. -/
/-- One fused class wins if some label in the class strictly beats every
    label outside it. Ties *within* the class are deliberately allowed. -/
def scoreGroupCell {I X : Type*} (A : I → X → ℝ) (P : I → Prop) : Set X :=
  {x | ∃ i, P i ∧ ∀ j, ¬P j → A j x < A i x}

private theorem scoreGroupCell_measurable {I X : Type*}
    [Fintype I] [MeasurableSpace X] (A : I → X → ℝ) (P : I → Prop)
    (hA : ∀ i, Measurable (A i)) : MeasurableSet (scoreGroupCell A P) := by
  classical
  have he : scoreGroupCell A P =
      ⋃ i : I, if P i then ⋂ j : I,
        (if P j then univ else {x | A j x < A i x}) else ∅ := by
    ext x
    simp only [scoreGroupCell, Set.mem_ofPred_eq, Set.mem_iUnion]
    constructor
    · rintro ⟨i,hi,h⟩
      refine ⟨i,?_⟩
      rw [if_pos hi]
      apply Set.mem_iInter.mpr
      intro j
      by_cases hj : P j
      · simp [hj]
      · simpa [hj] using h j hj
    · rintro ⟨i,hi⟩
      by_cases hp : P i
      · rw [if_pos hp] at hi
        exact ⟨i,hp,fun j hj => by simpa [hj] using Set.mem_iInter.mp hi j⟩
      · simp [hp] at hi
  rw [he]
  apply MeasurableSet.iUnion
  intro i
  split_ifs with hi
  · apply MeasurableSet.iInter
    intro j
    split_ifs
    · exact MeasurableSet.univ
    · exact measurableSet_lt (hA j) (hA i)
  · exact MeasurableSet.empty

private theorem scoreGroupCell_mem_iff_of_strictWinner {I X : Type*}
    (A : I → X → ℝ) (P : I → Prop) (x : X) (i : I)
    (hi : x ∈ strictLabels A i) :
    x ∈ scoreGroupCell A P ↔ P i := by
  constructor
  · rintro ⟨j,hj,h⟩
    by_contra hni
    have hh := h i hni
    have hne : j ≠ i := fun he => hni (he ▸ hj)
    exact lt_asymm hh (hi j hne)
  · intro hp
    exact ⟨i,hp,fun j hj => hi j (fun eq => hj (eq ▸ hp))⟩

/-- Weak-limit endpoint mass identity for a fused class. The labels with a
    common limiting site are aggregated, rather than asserting that all
    individual cells at a collision still have positive mass. -/
theorem scoreGroupCell_limit_mass
    {I E T : Type*} [Fintype I] [Nonempty I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hB : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (l : Filter T) [l.IsCountablyGenerated] [l.NeBot]
    (Y : T → I → E) (C : T → I → ℝ) (y : I → E) (c : I → ℝ) (m : I → ℝ)
    (hY : ∀ i, Tendsto (fun t => Y t i) l (𝓝 (y i)))
    (hC : ∀ i, Tendsto (fun t => C t i) l (𝓝 (c i)))
    (hInj : ∀ᶠ t in l, Function.Injective (Y t))
    (hM : ∀ᶠ t in l, ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪Y t j,x⟫_ℝ+C t j) i) = m i)
    (i₀ : I) :
    let ρ := q • μ.restrict B
    ρ.real (scoreGroupCell (fun j x => ⟪y j,x⟫_ℝ+c j) (fun j => y j = y i₀)) =
      ∑ i, @ite ℝ (y i=y i₀) (Classical.propDecidable _) (m i) 0 := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let P (i : I) := y i=y i₀
  let A (t : T) (i : I) (x : E) := ⟪Y t i,x⟫_ℝ+C t i
  let A₀ (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
  let U (t : T) := scoreGroupCell (A t) P
  let U₀ := scoreGroupCell A₀ P
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  have hmA (t : T) (i : I) : Measurable (A t i) :=
    (innerSL ℝ (Y t i)).continuous.measurable.add_const _
  have hU (t : T) : MeasurableSet (U t) := scoreGroupCell_measurable (A t) P (hmA t)
  have hU₀ : MeasurableSet U₀ := scoreGroupCell_measurable A₀ P
    (fun i => (innerSL ℝ (y i)).continuous.measurable.add_const _)
  have hties (i j : I) : ∀ᵐ x ∂ρ, y j ≠ y i → A₀ j x ≠ A₀ i x := by
    by_cases h : y j = y i
    · exact Filter.Eventually.of_forall fun _ hn => False.elim (hn h)
    · apply Filter.Eventually.mono ?_ (fun _ h _ => h)
      rw [ae_iff]
      simpa only [A₀, not_ne_iff] using
        affineScore_tie_restrict_smul_null μ B q (y j) (y i) h (c j) (c i)
  have hAll : ∀ᵐ x ∂ρ, ∀ i j, y j ≠ y i → A₀ j x ≠ A₀ i x :=
    Filter.eventually_all.mpr fun i => Filter.eventually_all.mpr (hties i)
  let f (t : T) := (U t).indicator (fun _ : E => (1 : ℝ))
  let f₀ := U₀.indicator (fun _ : E => (1 : ℝ))
  have hconv : Tendsto (fun t => ∫ x, f t x ∂ρ) l (𝓝 (∫ x, f₀ x ∂ρ)) := by
    apply tendsto_integral_filter_of_norm_le_const
    · exact Filter.Eventually.of_forall fun t => (measurable_const.indicator (hU t)).aestronglyMeasurable
    · refine ⟨1, Filter.Eventually.of_forall fun t => Filter.Eventually.of_forall fun x => ?_⟩
      simp only [f, Set.indicator_apply]
      split_ifs <;> simp
    · filter_upwards [hAll] with x hx
      obtain ⟨i,_,hmax⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun i => A₀ i x)
      have hle (j : I) : A₀ j x ≤ A₀ i x := by
        rw [← hmax]
        exact Finset.le_sup' (fun i => A₀ i x) (Finset.mem_univ j)
      have hs (j : I) : Tendsto (fun t => A t j x) l (𝓝 (A₀ j x)) := by
        have H := ((innerSL ℝ x).continuous.continuousAt.tendsto.comp (hY j)).add (hC j)
        change Tendsto (fun t => innerSL ℝ x (Y t j)+C t j) l
          (𝓝 (innerSL ℝ x (y j)+c j)) at H
        simpa only [A,A₀,innerSL_apply_apply,real_inner_comm x] using H
      have hstay : ∀ᶠ t in l, (x ∈ U t ↔ P i) := by
        have hr : ∀ᶠ t in l, ∀ j, y j ≠ y i → A t j x < A t i x :=
          Filter.eventually_all.mpr fun j => by
            by_cases hj : y j = y i
            · exact Filter.Eventually.of_forall fun _ h => False.elim (h hj)
            · exact ((hs j).eventually_lt (hs i) (lt_of_le_of_ne (hle j) (hx i j hj))).mono
                fun _ h _ => h
        filter_upwards [hr] with t ht
        constructor
        · rintro ⟨j,hj,h⟩
          by_contra hni
          have hji : y j ≠ y i := fun H => hni (by simpa only [P, ← H] using hj)
          exact lt_asymm (ht j hji) (h i hni)
        · intro hp
          exact ⟨i,hp,fun j hj => ht j (fun H => hj (by simpa only [P,H] using hp))⟩
      have hbase : x ∈ U₀ ↔ P i := by
        constructor
        · rintro ⟨j,_,hj⟩
          by_contra hni
          exact not_lt_of_ge (hle j) (hj i hni)
        · intro hp
          refine ⟨i,hp,fun j hj => lt_of_le_of_ne (hle j) (hx i j ?_)⟩
          exact fun H => hj (by simpa only [P,H] using hp)
      have he : (fun t => f t x) =ᶠ[l] fun _ => f₀ x := by
        filter_upwards [hstay] with t ht
        simp only [f,f₀,Set.indicator_apply,ht,hbase]
      exact tendsto_const_nhds.congr' he.symm
  have hconst : ∀ᶠ t in l, (∫ x, f t x ∂ρ) = ∑ i, if P i then m i else 0 := by
    filter_upwards [hInj,hM] with t hinj ht
    let g (i : I) (_ : E) : ℝ := if P i then 1 else 0
    have he : f t =ᵐ[ρ] fun x => ∑ i, (strictLabels (A t) i).indicator (g i) x := by
      filter_upwards [ae_strict_affineWinner_restrict_smul μ B q (Y t) hinj (C t)] with x hx
      obtain ⟨i,hi⟩ := hx
      have hi' : x ∈ strictLabels (A t) i := hi
      rw [strictLabels_sum_eq (A t) g x i hi']
      have HH : x ∈ U t ↔ P i := scoreGroupCell_mem_iff_of_strictWinner (A t) P x i hi'
      simp only [f,Set.indicator_apply,HH,g]
    rw [integral_congr_ae he, integral_finsetSum _ (fun i _ =>
      (integrable_const (if P i then (1 : ℝ) else 0)).indicator
        (strictLabels_meas (A t) (hmA t) i))]
    apply Finset.sum_congr rfl
    intro i _
    rw [integral_indicator (strictLabels_meas (A t) (hmA t) i), setIntegral_const, smul_eq_mul]
    have HM : ρ.real (strictLabels (A t) i)=m i := ht i
    rw [HM]
    by_cases hi : P i <;> simp [hi]
  have hct : Tendsto (fun t => ∫ x, f t x ∂ρ) l
      (𝓝 (∑ i, if P i then m i else 0)) :=
    tendsto_const_nhds.congr' (hconst.mono fun _ H => H.symm)
  have hh := tendsto_nhds_unique hconv hct
  change (∫ x, (U₀.indicator (fun _ => (1 : ℝ))) x ∂ρ) = _ at hh
  rwa [show (∫ x, (U₀.indicator (fun _ => (1 : ℝ))) x ∂ρ) = ρ.real U₀ from
    integral_indicator_one (μ := ρ) hU₀] at hh





/-! Compatibility section: selector. -/
/-- The fused class masses really are atomic preimage masses of a
    measurable endpoint selection, which selects a maximizing affine
    support at almost every source point. -/
theorem endpoint_fused_measurable_selector
    {I E : Type*} [Fintype I] [Nonempty I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (q : ℝ≥0∞) (y : I → E) (c : I → ℝ) :
    let ρ := q • μ.restrict B
    let A (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
    ∃ T : E → E, Measurable T ∧
      (∀ᵐ x ∂ρ, ∃ i, T x=y i ∧ ∀ j, A j x ≤ A i x) ∧
      ∀ i, ρ.real (T ⁻¹' {y i}) = ρ.real (scoreGroupCell A (fun j => y j=y i)) := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let A (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
  let J := Set.range y
  let toJ (i : I) : J := ⟨y i,⟨i,rfl⟩⟩
  have hsur : Function.Surjective toJ := by
    rintro ⟨z, i, h⟩
    exact ⟨i, Subtype.ext h⟩
  let : Fintype J := Fintype.ofSurjective toJ hsur
  let U (z : J) := scoreGroupCell A (fun j => y j=z.val)
  let T (x : E) : E := ∑ z : J, (U z).indicator (fun _ : E => z.val) x
  have hm (z : J) : MeasurableSet (U z) := scoreGroupCell_measurable A _
    (fun i => (innerSL ℝ (y i)).continuous.measurable.add_const _)
  have hT : Measurable T :=
    Finset.measurable_sum _ (fun z _ => measurable_const.indicator (hm z))
  have hne (i j : I) : ∀ᵐ x ∂ρ, y j ≠ y i → A j x ≠ A i x := by
    by_cases h : y j=y i
    · exact Filter.Eventually.of_forall fun _ hn => False.elim (hn h)
    · apply Filter.Eventually.mono ?_ (fun _ h _ => h)
      rw [ae_iff]
      simpa only [A,not_ne_iff] using affineScore_tie_restrict_smul_null μ B q (y j) (y i) h (c j) (c i)
  have hx : ∀ᵐ x ∂ρ, ∃ i, (∀ j, A j x ≤ A i x) ∧
      (∀ z : J, x∈U z ↔ z=toJ i) := by
    have hAll : ∀ᵐ x ∂ρ, ∀ i j, y j ≠ y i → A j x ≠ A i x :=
      Filter.eventually_all.mpr fun i => Filter.eventually_all.mpr (hne i)
    filter_upwards [hAll] with x hx
    obtain ⟨i,_,hmax⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun j => A j x)
    have hh (j : I) : A j x ≤ A i x := by
      rw [← hmax]
      exact Finset.le_sup' (fun j => A j x) (Finset.mem_univ j)
    refine ⟨i,hh,fun z => ?_⟩
    constructor
    · rintro ⟨j,hj,hlt⟩
      by_contra h
      have hi : y i ≠ z.val := fun he => h (Subtype.ext he.symm)
      exact not_lt_of_ge (hh j) (hlt i hi)
    · rintro rfl
      exact ⟨i,rfl,fun j hj => lt_of_le_of_ne (hh j) (hx i j hj)⟩
  have hval (x : E) (i : I) (hi : ∀ z : J, x∈U z ↔ z=toJ i) :
      T x = y i := by
    unfold T
    rw [Finset.sum_eq_single (toJ i)]
    · exact Set.indicator_of_mem ((hi _).mpr rfl) _
    · intro z _ hz
      exact Set.indicator_of_notMem (fun h => hz ((hi z).mp h)) _
    · simp
  refine ⟨T,hT,hx.mono (fun x ⟨i,hi,hU⟩ => ⟨i,hval x i hU,hi⟩),?_⟩
  intro i
  have he : ((T ⁻¹' {y i}).indicator (fun _ : E => (1 : ℝ))) =ᵐ[ρ]
      (U (toJ i)).indicator (fun _ : E => (1 : ℝ)) := by
    filter_upwards [hx] with x h
    obtain ⟨j,_,hj⟩ := h
    have hmem : x ∈ (T ⁻¹' {y i} : Set E) ↔ x∈U (toJ i) := by
      rw [hj (toJ i)]
      change T x=y i ↔ toJ i=toJ j
      rw [hval x j hj]
      exact ⟨fun H => Subtype.ext H.symm, fun H => (congrArg Subtype.val H).symm⟩
    simp only [Set.indicator_apply,hmem]
  have hleft : MeasurableSet (T ⁻¹' {y i}) := hT (measurableSet_singleton (y i))
  have H := integral_congr_ae he
  change (∫ x, ((T ⁻¹' {y i}).indicator (1 : E → ℝ)) x ∂ρ) =
    (∫ x, ((U (toJ i)).indicator (1 : E → ℝ)) x ∂ρ) at H
  rw [integral_indicator_one (μ := ρ) hleft, integral_indicator_one (μ := ρ) (hm (toJ i))] at H
  exact H





/-! Compatibility section: atomlaw. -/
/-- The complete discrete target law follows from the fused preimage
    masses and almost-everywhere finite-range support. -/
theorem endpoint_selector_map_eq_atomic
    {I E : Type*} [Fintype I] [MeasurableSpace E] [MeasurableSingletonClass E]
    (ρ : Measure E) [IsFiniteMeasure ρ] (T : E → E) (hT : Measurable T)
    (y : I → E) (m : I → ℝ) (hm : ∀ i, 0 ≤ m i)
    (hsupp : ∀ᵐ x ∂ρ, T x ∈ Set.range y)
    (hmass : ∀ i₀, ρ.real (T ⁻¹' {y i₀}) =
      ∑ i, @ite ℝ (y i=y i₀) (Classical.propDecidable _) (m i) 0) :
    Measure.map T ρ = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (y i) := by
  classical
  let ν := Measure.map T ρ
  let η : Measure E := ∑ i, ENNReal.ofReal (m i) • Measure.dirac (y i)
  have hY : MeasurableSet (Set.range y) := (Set.finite_range y).measurableSet
  have hνc : ν (Set.range y)ᶜ = 0 := by
    rw [Measure.map_apply hT hY.compl]
    exact ae_iff.mp hsupp
  have hηc : η (Set.range y)ᶜ = 0 := by
    unfold η
    rw [Measure.finsetSum_apply]
    apply Finset.sum_eq_zero
    intro i _
    rw [Measure.smul_apply, Measure.dirac_apply' _ hY.compl, Set.indicator_of_notMem]
    · simp
    · exact fun H => H (Set.mem_range_self i)
  have hsing (i₀ : I) : ν {y i₀} = η {y i₀} := by
    have he :
        η {y i₀} = ∑ i, if y i = y i₀ then ENNReal.ofReal (m i) else 0 := by
      unfold η
      rw [Measure.finsetSum_apply]
      refine Finset.sum_congr rfl ?_
      intro i _
      rw [Measure.smul_apply, Measure.dirac_apply' _ (measurableSet_singleton _)]
      by_cases H : y i = y i₀ <;> simp [H]
    have hfinite (i : I) : (if y i = y i₀ then ENNReal.ofReal (m i) else 0) ≠ ∞ := by
      split_ifs <;> simp
    apply (ENNReal.toReal_eq_toReal_iff' ?_ ?_).mp
    · rw [Measure.map_apply hT (measurableSet_singleton _), he,
        ENNReal.toReal_sum (fun i _ => hfinite i)]
      rw [← Measure.real, hmass i₀]
      refine Finset.sum_congr rfl ?_
      intro i _
      by_cases H : y i = y i₀ <;> simp [H, ENNReal.toReal_ofReal (hm i)]
    · rw [Measure.map_apply hT (measurableSet_singleton _)]
      exact measure_ne_top ρ _
    · rw [he]
      exact (ENNReal.sum_lt_top.mpr (fun i _ => (lt_top_iff_ne_top).mpr (hfinite i))).ne
  let S : Set (Set E) := insert (Set.range y)ᶜ (range fun i => ({y i} : Set E))
  have hS : S.Countable := (Set.countable_range _).insert _
  have hCover : ⋃₀ S = univ := by
    apply Set.eq_univ_of_forall
    intro x
    by_cases hx : x ∈ Set.range y
    · obtain ⟨i,rfl⟩ := hx
      exact Set.mem_sUnion_of_mem (Set.mem_singleton _) (Or.inr (Set.mem_range_self i))
    · exact Set.mem_sUnion_of_mem hx (Or.inl rfl)
  apply Measure.ext_of_sUnion_eq_univ hS hCover
  intro s hs
  rcases hs with rfl | ⟨i,rfl⟩
  · rw [Measure.restrict_eq_zero.mpr hνc, Measure.restrict_eq_zero.mpr hηc]
  · change ν.restrict {y i} = η.restrict {y i}
    rw [Measure.restrict_singleton, Measure.restrict_singleton, hsing i]





/-! Compatibility section: fullfused. -/
/-- Actual fused endpoint target law and support inequality. The endpoint
    may contain repeated sites. Only approaching configurations need
    distinct sites and exact labeled cell masses. -/
theorem fused_endpoint_support_and_pushforward
    {I E T : Type*} [Fintype I] [Nonempty I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hB : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (l : Filter T) [l.IsCountablyGenerated] [l.NeBot]
    (Y : T → I → E) (C : T → I → ℝ) (y : I → E) (c m : I → ℝ)
    (hm : ∀ i, 0 ≤ m i)
    (hY : ∀ i, Tendsto (fun t => Y t i) l (𝓝 (y i)))
    (hC : ∀ i, Tendsto (fun t => C t i) l (𝓝 (c i)))
    (hInj : ∀ᶠ t in l, Function.Injective (Y t))
    (hM : ∀ᶠ t in l, ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪Y t j,x⟫_ℝ+C t j) i) = m i) :
    let ρ := q • μ.restrict B
    let U (x : E) := labelMax (fun i => ⟪y i,x⟫_ℝ+c i)
    ∃ T : E → E, Measurable T ∧
      Measure.map T ρ = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (y i) ∧
      ∀ᵐ x ∂ρ, ∀ z, U x + ⟪T x,z-x⟫_ℝ ≤ U z := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let A (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
  let U (x : E) := labelMax (fun i => A i x)
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  obtain ⟨T,hT,hsel,hmass⟩ := endpoint_fused_measurable_selector μ B q y c
  have hm' (i : I) : ρ.real (T ⁻¹' {y i}) =
      ∑ j, @ite ℝ (y j=y i) (Classical.propDecidable _) (m j) 0 :=
    (hmass i).trans (scoreGroupCell_limit_mass μ B hB q hq l Y C y c m hY hC hInj hM i)
  have hs : ∀ᵐ x ∂ρ, T x ∈ Set.range y :=
    hsel.mono fun _ ⟨i,hi,_⟩ => ⟨i,hi.symm⟩
  refine ⟨T,hT,endpoint_selector_map_eq_atomic ρ T hT y m hm hs hm',?_⟩
  filter_upwards [hsel] with x hx
  obtain ⟨i,hi,hmax⟩ := hx
  intro z
  have hu : U x = A i x := by
    refine le_antisymm (Finset.sup'_le _ _ (fun j _ => hmax j)) ?_
    exact Finset.le_sup' (fun j => A j x) (Finset.mem_univ i)
  have hzu : A i z ≤ U z := Finset.le_sup' (fun j => A j z) (Finset.mem_univ i)
  change U x + ⟪T x,z-x⟫_ℝ ≤ U z
  rw [hi,hu,inner_sub_right]
  exact (by dsimp [A]; ring : A i x + (⟪y i,z⟫_ℝ - ⟪y i,x⟫_ℝ) = A i z) ▸ hzu





/-! Compatibility section: globalsel. -/
/-- Replace any a.e. affine-max selector by a measurable all-points
    selector, retaining its a.e. value. Lexicographic tie breaking works
    even when several endpoint labels occupy the same site. -/
theorem endpoint_global_support_selector
    {I E : Type*} [Fintype I] [Nonempty I] [LinearOrder I]
    [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (q : ℝ≥0∞) (y : I → E) (c : I → ℝ)
    (T : E → E)
    (hT : ∀ᵐ x ∂(q • μ.restrict B), ∃ i, T x=y i ∧
      ∀ j, ⟪y j,x⟫_ℝ+c j ≤ ⟪y i,x⟫_ℝ+c i) :
    let U (x : E) := labelMax (fun i => ⟪y i,x⟫_ℝ+c i)
    ∃ S : E → E, Measurable S ∧ S =ᵐ[q • μ.restrict B] T ∧
      (∀ x, S x ∈ Set.range y) ∧ ∀ x z, U x + ⟪S x,z-x⟫_ℝ ≤ U z := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  let A (i : I) (x : E) := ⟪y i,x⟫_ℝ+c i
  let W (i : I) : Set E := {x | (∀ j, A j x ≤ A i x) ∧ (∀ j < i, A j x < A i x)}
  let S (x : E) : E := ∑ i, (W i).indicator (fun _ : E => y i) x
  let U (x : E) := labelMax (fun i => A i x)
  have hA (i : I) : Measurable (A i) :=
    (innerSL ℝ (y i)).continuous.measurable.add_const _
  have hW (i : I) : MeasurableSet (W i) := by
    have he : W i =
        (⋂ j : I, {x | A j x ≤ A i x}) ∩
          (⋂ j : I, if j < i then {x | A j x < A i x} else univ) := by
      ext x; simp only [W, Set.mem_ofPred_eq, Set.mem_inter_iff, Set.mem_iInter]
      constructor
      · rintro ⟨h₁,h₂⟩
        refine ⟨h₁,fun j => ?_⟩
        by_cases hj : j < i
        · simpa [hj] using h₂ j hj
        · simp [hj]
      · rintro ⟨h₁,h₂⟩
        exact ⟨h₁,fun j hj => by simpa [hj] using h₂ j⟩
    rw [he]
    refine (MeasurableSet.iInter fun j => measurableSet_le (hA j) (hA i)).inter ?_
    apply MeasurableSet.iInter
    intro j
    split_ifs
    · exact measurableSet_lt (hA j) (hA i)
    · exact MeasurableSet.univ
  have hSM : Measurable S := Finset.measurable_sum _ (fun i _ => measurable_const.indicator (hW i))
  have hFound (x : E) : ∃ i, x∈W i := by
    let F := Finset.univ.filter (fun i => A i x=U x)
    have hF : F.Nonempty := by
      obtain ⟨i,_,hi⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun j => A j x)
      exact ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ i,hi.symm⟩⟩
    let i := F.min' hF
    have hi : i∈ F := Finset.min'_mem _ _
    have hval : A i x=U x := (Finset.mem_filter.mp hi).2
    have hall (j : I) : A j x≤A i x := by
      rw [hval]
      exact Finset.le_sup' (fun j => A j x) (Finset.mem_univ j)
    refine ⟨i,hall,fun j hj => lt_of_le_of_ne (hall j) ?_⟩
    intro h
    have hj' : j∈F := Finset.mem_filter.mpr ⟨Finset.mem_univ j,h.trans hval⟩
    exact not_lt_of_ge (Finset.min'_le F j hj') hj
  have hSelect (x : E) (i : I) (hi : x∈W i) : S x=y i := by
    unfold S
    rw [Finset.sum_eq_single i]
    · exact Set.indicator_of_mem hi _
    · intro j _ hj
      apply Set.indicator_of_notMem
      intro h
      rcases lt_or_gt_of_ne hj with hj'|hj'
      · exact not_lt_of_ge (h.1 i) (hi.2 j hj')
      · exact not_lt_of_ge (hi.1 j) (h.2 i hj')
    · simp
  have hne (i j : I) : ∀ᵐ x ∂ρ, y j ≠ y i → A j x ≠ A i x := by
    by_cases h : y j=y i
    · exact Filter.Eventually.of_forall fun _ hn => False.elim (hn h)
    · apply Filter.Eventually.mono ?_ (fun _ h _ => h)
      rw [ae_iff]
      simpa only [A,not_ne_iff] using affineScore_tie_restrict_smul_null μ B q (y j) (y i) h (c j) (c i)
  have hAll : ∀ᵐ x ∂ρ, ∀ i j, y j ≠ y i → A j x ≠ A i x :=
    Filter.eventually_all.mpr fun i => Filter.eventually_all.mpr (hne i)
  refine ⟨S,hSM,?_,?_,?_⟩
  · filter_upwards [hT,hAll] with x hx hne'
    obtain ⟨j,hj,hmax⟩ := hx
    obtain ⟨i,hi⟩ := hFound x
    rw [hSelect x i hi,hj]
    by_contra H
    exact hne' j i H (le_antisymm (hmax i) (hi.1 j))
  · intro x
    obtain ⟨i,hi⟩ := hFound x
    exact ⟨i,(hSelect x i hi).symm⟩
  · intro x z
    obtain ⟨i,hi⟩ := hFound x
    have hu : U x=A i x :=
      le_antisymm (Finset.sup'_le _ _ (fun j _ => hi.1 j))
        (Finset.le_sup' (fun j => A j x) (Finset.mem_univ i))
    have hz : A i z ≤ U z := Finset.le_sup' (fun j => A j z) (Finset.mem_univ i)
    change U x + ⟪S x,z-x⟫_ℝ ≤ U z
    rw [hSelect x i hi,hu,inner_sub_right]
    exact (by dsimp [A]; ring : A i x+(⟪y i,z⟫_ℝ-⟪y i,x⟫_ℝ)=A i z) ▸ hz





/-! Compatibility section: fullglobalf. -/
/-- Actual fused endpoint target law and support inequality. The endpoint
    may contain repeated sites. Only approaching configurations need
    distinct sites and exact labeled cell masses. -/
theorem fused_endpoint_globalSupport_and_pushforward
    {I E T : Type*} [Fintype I] [Nonempty I] [LinearOrder I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (μ : Measure E) [IsAddHaarMeasure μ]
    (B : Set E) (hB : IsCompact B) (q : ℝ≥0∞) (hq : q ≠ ∞)
    (l : Filter T) [l.IsCountablyGenerated] [l.NeBot]
    (Y : T → I → E) (C : T → I → ℝ) (y : I → E) (c m : I → ℝ)
    (hm : ∀ i, 0 ≤ m i) (L : ℝ) (hL : ∀ i, ‖y i‖ ≤ L)
    (hY : ∀ i, Tendsto (fun t => Y t i) l (𝓝 (y i)))
    (hC : ∀ i, Tendsto (fun t => C t i) l (𝓝 (c i)))
    (hInj : ∀ᶠ t in l, Function.Injective (Y t))
    (hM : ∀ᶠ t in l, ∀ i, (q • μ.restrict B).real
      (strictLabels (fun j x => ⟪Y t j,x⟫_ℝ+C t j) i) = m i) :
    let ρ := q • μ.restrict B
    let U (x : E) := labelMax (fun i => ⟪y i,x⟫_ℝ+c i)
    ∃ S : E → E, Measurable S ∧
      Measure.map S ρ = ∑ i, ENNReal.ofReal (m i) • Measure.dirac (y i) ∧
      (∀ x, ‖S x‖ ≤ L) ∧ ∀ x z, U x + ⟪S x,z-x⟫_ℝ ≤ U z := by
  classical
  dsimp
  let ρ := q • μ.restrict B
  have : IsFiniteMeasure (μ.restrict B) := isFiniteMeasure_restrict.mpr hB.measure_lt_top.ne
  have : IsFiniteMeasure ρ := Measure.smul_finite _ hq
  obtain ⟨T,hT,hsel,hmass⟩ := endpoint_fused_measurable_selector μ B q y c
  have hm' (i : I) : ρ.real (T ⁻¹' {y i}) =
      ∑ j, @ite ℝ (y j=y i) (Classical.propDecidable _) (m j) 0 :=
    (hmass i).trans (scoreGroupCell_limit_mass μ B hB q hq l Y C y c m hY hC hInj hM i)
  have hs : ∀ᵐ x ∂ρ, T x ∈ Set.range y :=
    hsel.mono fun _ ⟨i,hi,_⟩ => ⟨i,hi.symm⟩
  have hmap := endpoint_selector_map_eq_atomic ρ T hT y m hm hs hm'
  obtain ⟨S,hS,heq,hRange,hSupport⟩ := endpoint_global_support_selector μ B q y c T hsel
  refine ⟨S,hS,(Measure.map_congr heq).trans hmap,?_,hSupport⟩
  intro x
  obtain ⟨i,hi⟩ := hRange x
  rw [← hi]
  exact hL i





/-! Compatibility section: end2r. -/
/-- Finite max-affine potential curves are L² continuous across site
    collisions. Therefore the exact interior bound extends to the actual
    continuous endpoint intercepts. -/
theorem body_potential_L2_colliding_endpoint_bound
    {E I : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [Fintype I] [Nonempty I]
    (μ : Measure E) (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) [IsProbabilityMeasure (q • μ.restrict B)]
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (Y : ℝ → I → E) (c : ℝ → I → ℝ)
    (hY : Continuous Y) (hc : Continuous c) (a b C : ℝ) (hab : a < b)
    (hInterior : ∀ s ∈ Ioo a b, ∀ t ∈ Ioo a b,
      Real.sqrt (∫ x, (labelMax (fun i => ⟪Y t i,x⟫_ℝ+c t i) -
        labelMax (fun i => ⟪Y s i,x⟫_ℝ+c s i))^2 ∂(q • μ.restrict B))
          ≤ C*|t-s|) :
    Real.sqrt (∫ x, (labelMax (fun i => ⟪Y b i,x⟫_ℝ+c b i) -
      labelMax (fun i => ⟪Y a i,x⟫_ℝ+c a i))^2 ∂(q • μ.restrict B))
          ≤ C*(b-a) := by
  classical
  let ρ := q • μ.restrict B
  let A (t : ℝ) (i : I) (x : E) := ⟪Y t i,x⟫_ℝ+c t i
  let U (t : ℝ) (x : E) := labelMax (fun i => A t i x)
  have hxB : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hA (t : ℝ) (i : I) : Measurable (A t i) :=
    (innerSL ℝ (Y t i)).continuous.measurable.add_const _
  have hU (t : ℝ) : Measurable (U t) := by
    have h' := Finset.measurable_sup' Finset.univ_nonempty (f := A t) (fun i _ => hA t i)
    have he : Finset.univ.sup' Finset.univ_nonempty (A t) = U t := by
      funext x
      rw [Finset.sup'_apply]
      rfl
    rwa [← he]
  have hLp (t : ℝ) : MemLp (U t) 2 ρ := by
    let D : ℝ := ∑ i, (‖Y t i‖ * (R : ℝ) + |c t i|)
    apply MemLp.of_bound (hU t).aestronglyMeasurable D
    filter_upwards [hxB] with x hx
    change ‖Finset.univ.sup' Finset.univ_nonempty (fun i => A t i x)‖ ≤ D
    obtain ⟨i, _, hei⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (fun i => A t i x)
    rw [hei, Real.norm_eq_abs]
    have HH := (abs_real_inner_le_norm (Y t i) x).trans
      (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
    exact (abs_add_le _ _).trans ((add_le_add_left HH _).trans
      (Finset.single_le_sum (f := fun j => ‖Y t j‖*(R : ℝ)+|c t j|)
        (fun j _ => by positivity) (Finset.mem_univ i)))
  let f (t : ℝ) : Lp ℝ 2 ρ := (hLp t).toLp (U t)
  have hcont : Continuous f := by
    apply continuous_iff_continuousAt.mpr
    intro t
    let D (s : ℝ) : ℝ := ∑ i, (‖Y s i - Y t i‖*(R : ℝ)+|c s i-c t i|)
    have hD : Tendsto D (𝓝 t) (𝓝 0) := by
      have h : Continuous D := by
        have hY' (i : I) : Continuous (fun s => Y s i) := (continuous_apply i).comp hY
        have hc' (i : I) : Continuous (fun s => c s i) := (continuous_apply i).comp hc
        unfold D
        fun_prop
      simpa [D] using (h.continuousAt (x := t)).tendsto
    apply tendsto_iff_dist_tendsto_zero.mpr
    refine squeeze_zero (fun _ => dist_nonneg) ?_ hD
    intro s
    have hDone : 0 ≤ D s := Finset.sum_nonneg (fun i _ => by positivity)
    have hQ : ∀ᵐ x ∂ρ, |U s x-U t x| ≤ D s := by
      filter_upwards [hxB] with x hx
      apply labelMax_sub_abs_le
      intro i
      have he : A s i x-A t i x = ⟪Y s i-Y t i,x⟫_ℝ+(c s i-c t i) := by
        simp only [A,inner_sub_left]
        ring
      rw [he]
      have hinner := (abs_real_inner_le_norm (Y s i-Y t i) x).trans
        (mul_le_mul_of_nonneg_left (hR x hx) (norm_nonneg _))
      exact (abs_add_le _ _).trans ((add_le_add_left hinner _).trans
        (Finset.single_le_sum (f := fun i => ‖Y s i-Y t i‖*(R : ℝ)+|c s i-c t i|)
          (fun i _ => by positivity) (Finset.mem_univ i)))
    have hQ2 : ∀ᵐ x ∂ρ, (U s x-U t x)^2 ≤ (D s)^2 := by
      filter_upwards [hQ] with x hx
      rw [← sq_abs (U s x-U t x)]
      exact (sq_le_sq₀ (abs_nonneg _) hDone).mpr hx
    have hInt : Integrable (fun x => (U s x-U t x)^2) ρ := by
      apply (integrable_const ((D s)^2)).mono' (((hU s).sub (hU t)).pow_const 2).aestronglyMeasurable
      filter_upwards [hQ2] with x hx
      change ‖(U s x-U t x)^2‖ ≤ (D s)^2
      rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg (U s x-U t x))]
      exact hx
    have H := integral_mono_ae hInt (integrable_const ((D s)^2)) hQ2
    have hρ : ρ.real univ=1 := by simp [Measure.real]
    rw [integral_const, smul_eq_mul, hρ, one_mul] at H
    rw [dist_eq_norm]
    change ‖(hLp s).toLp (U s)-(hLp t).toLp (U t)‖ ≤ D s
    rw [norm_toLp_two_sub_eq_sqrtIntegral_sq]
    exact (Real.sqrt_le_sqrt H).trans_eq (Real.sqrt_sq hDone)
  have hinner (s : ℝ) (hs : s ∈ Ioo a b) (t : ℝ) (ht : t ∈ Ioo a b) :
      ‖f t-f s‖ ≤ C*|t-s| := by
    change ‖(hLp t).toLp (U t)-(hLp s).toLp (U s)‖ ≤ _
    rw [norm_toLp_two_sub_eq_sqrtIntegral_sq]
    exact hInterior s hs t ht
  have hb : b∈closure (Ioo a b) := by rw [closure_Ioo hab.ne]; exact ⟨hab.le,le_rfl⟩
  have ha : a∈closure (Ioo a b) := by rw [closure_Ioo hab.ne]; exact ⟨le_rfl,hab.le⟩
  have H (s : ℝ) (hs : s∈Ioo a b) : ‖f b-f s‖ ≤ C*|b-s| := by
    refine le_on_closure (fun t ht => hinner s hs t ht) ?_ ?_ hb
    · exact (hcont.sub continuous_const).norm.continuousOn
    · exact (show Continuous (fun t : ℝ => C*|t-s|) by fun_prop).continuousOn
  have H' : ‖f b-f a‖ ≤ C*|b-a| := by
    refine le_on_closure H ?_ ?_ ha
    · exact (continuous_const.sub hcont).norm.continuousOn
    · exact (show Continuous (fun s : ℝ => C*|b-s|) by fun_prop).continuousOn
  change ‖(hLp b).toLp (U b)-(hLp a).toLp (U a)‖ ≤ C*|b-a| at H'
  rw [norm_toLp_two_sub_eq_sqrtIntegral_sq, abs_of_pos (sub_pos.mpr hab)] at H'
  exact H'





/-! Compatibility section: varmass. -/
/-- Variable-mass extension of compact argmin continuity. Unlike a
    fixed feasible hyperplane, the weighted normalization varies with m.
    Global common-shift minimization allows testing a fixed competitor
    without transporting it between the hyperplanes. -/
theorem tendsto_normalized_dual_selection_variable_mass
    {I T P : Type*} [Fintype I] [TopologicalSpace P]
    (l : Filter T) (p : T → P) (p₀ : P) (hp : Tendsto p l (𝓝 p₀))
    (M : T → I → ℝ) (m₀ : I → ℝ) (hm₀ : ∀ i, 0 < m₀ i)
    (hM : ∀ i, Tendsto (fun t => M t i) l (𝓝 (m₀ i)))
    (F : P × (I → ℝ) → ℝ) (hF : Continuous F)
    (c : T → I → ℝ) (c₀ : I → ℝ) (A : ℝ)
    (hnorm : ∀ᶠ t in l, (∑ i, M t i)=1 ∧ (∑ i, M t i*c t i)=0)
    (hmin : ∀ᶠ t in l, ∀ d : I → ℝ, F (p t,c t) ≤ F (p t,d))
    (hlower : ∀ᶠ t in l, ∀ i, c t i ≤ F (p t,c t)+A)
    (hunique : ∀ d : I → ℝ, (∑ i,m₀ i*d i)=0 →
      (∀ w : I → ℝ, F (p₀,d) ≤ F (p₀,w)) → d=c₀) :
    Tendsto c l (𝓝 c₀) := by
  classical
  let K := max (F (p₀,0)+A+1) 0
  have hK : 0 ≤ K := le_max_right _ _
  let S : Set (I → ℝ) := Set.pi univ (fun i => Icc (-(K/(m₀ i/2))) K)
  have hs : IsCompact S := isCompact_univ_pi (fun _ => isCompact_Icc)
  have hpos : ∀ᶠ t in l, ∀ i, m₀ i/2 < M t i :=
    Filter.eventually_all.mpr fun i => (hM i).eventually (lt_mem_nhds (show m₀ i/2 < m₀ i by linarith [hm₀ i]))
  have hF0 : Tendsto (fun t => F (p t,0)) l (𝓝 (F (p₀,0))) :=
    hF.continuousAt.tendsto.comp (hp.prodMk_nhds tendsto_const_nhds)
  have hF0' : ∀ᶠ t in l, F (p t,0) < F (p₀,0)+1 :=
    hF0.eventually (gt_mem_nhds (show F (p₀,0) < F (p₀,0)+1 by linarith))
  have hcompact : ∀ᶠ t in l, c t∈S := by
    filter_upwards [hpos,hF0',hnorm,hmin,hlower] with t ht hF' hn hmin' hlow'
    have hu (i : I) : c t i ≤ K :=
      (hlow' i).trans ((add_le_add_left (hmin' 0) A).trans
        ((by linarith only [hF'] : F (p t,0)+A ≤ F (p₀,0)+A+1).trans (le_max_left _ _)))
    have hmPos (i : I) : 0 < M t i := by linarith [ht i,hm₀ i]
    have hh := normalized_intercept_box_of_upper (M t) (c t) hmPos hn.1 hn.2 K hK hu
    intro i _
    refine ⟨?_,hu i⟩
    apply le_trans _ (hh i).1
    apply neg_le_neg
    exact div_le_div_of_nonneg_left hK (by linarith [hm₀ i]) (ht i).le
  apply hs.tendsto_nhds_of_unique_mapClusterPt hcompact
  intro d _ hd
  obtain ⟨U, hUl, hUd⟩ := mapClusterPt_iff_ultrafilter.mp hd
  have hpU := hp.mono_left hUl
  have hsum : Tendsto (fun t => ∑ i, M t i*c t i) (U : Filter T)
      (𝓝 (∑ i,m₀ i*d i)) := by
    have hi (i : I) : Tendsto (fun t => c t i) (U : Filter T) (𝓝 (d i)) :=
      (continuous_apply i).continuousAt.tendsto.comp hUd
    exact tendsto_finsetSum _ (fun i _ => ((hM i).mono_left hUl).mul (hi i))
  have hnU : ∀ᶠ t in (U : Filter T), (∑ i,M t i)=1 ∧ (∑ i,M t i*c t i)=0 := hUl hnorm
  have hzero : Tendsto (fun t => ∑ i, M t i*c t i) (U : Filter T) (𝓝 0) :=
    tendsto_const_nhds.congr' (hnU.mono fun _ h => h.2.symm)
  apply hunique d (tendsto_nhds_unique hsum hzero)
  intro w
  have hleft : Tendsto (fun t => F (p t,c t)) (U : Filter T) (𝓝 (F (p₀,d))) :=
    hF.continuousAt.tendsto.comp (hpU.prodMk_nhds hUd)
  have hright : Tendsto (fun t => F (p t,w)) (U : Filter T) (𝓝 (F (p₀,w))) :=
    hF.continuousAt.tendsto.comp (hpU.prodMk_nhds tendsto_const_nhds)
  apply le_of_tendsto_of_tendsto hleft hright
  filter_upwards [hUl hmin] with t ht
  exact ht w





/-! Compatibility section: actualVar. -/
/-- The actual compact-body finite prescribed-cell dual objective. -/
noncomputable def bodyDual {I E : Type*} [Fintype I] [Nonempty I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] (ρ : Measure E)
    (y : I → E) (m c : I → ℝ) : ℝ :=
  (∫ x, labelMax (fun i => ⟪y i,x⟫_ℝ+c i) ∂ρ) - ∑ i, m i*c i

/-- Compact-body variable-mass continuity with the exact distinct-site
    normalized uniqueness interface supplied by upstream. -/
theorem tendsto_bodyDual_normalized_selection
    {I E T : Type*} [Fintype I] [Nonempty I] [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [MeasurableSpace E] [BorelSpace E] [FiniteDimensional ℝ E]
    (μ : Measure E) (B : Set E) (hB : IsCompact B)
    (q : ℝ≥0∞) [IsProbabilityMeasure (q • μ.restrict B)]
    (R : ℝ≥0) (hR : ∀ x ∈ B, ‖x‖ ≤ R)
    (l : Filter T) (Y : T → I → E) (M C : T → I → ℝ)
    (y : I → E) (m c : I → ℝ) (hm : ∀ i, 0 < m i)
    (hY : Tendsto Y l (𝓝 y)) (hM : Tendsto M l (𝓝 m))
    (hnorm : ∀ᶠ t in l, (∑ i, M t i)=1 ∧ (∑ i, M t i*C t i)=0)
    (hmin : ∀ᶠ t in l, ∀ d : I → ℝ,
      bodyDual (q • μ.restrict B) (Y t) (M t) (C t) ≤
        bodyDual (q • μ.restrict B) (Y t) (M t) d)
    (hunique : ∀ d : I → ℝ, (∑ i,m i*d i)=0 →
      (∀ w : I → ℝ, (∑ i,m i*w i)=0 →
        (∫ x, labelMax (fun i => ⟪y i,x⟫_ℝ+d i) ∂(q • μ.restrict B)) ≤
        (∫ x, labelMax (fun i => ⟪y i,x⟫_ℝ+w i) ∂(q • μ.restrict B))) → d=c) :
    Tendsto C l (𝓝 c) := by
  classical
  let ρ := q • μ.restrict B
  let F (p : ((I → E) × (I → ℝ)) × (I → ℝ)) := bodyDual ρ p.1.1 p.1.2 p.2
  let A : ℝ := ∑ i, (‖y i‖+1)*(R : ℝ)
  let U (p : (I → E) × (I → ℝ)) (x : E) := labelMax (fun i => ⟪p.1 i,x⟫_ℝ+p.2 i)
  have hx : ∀ᵐ x ∂ρ, x ∈ B := ae_smul_measure (ae_restrict_mem hB.measurableSet) q
  have hρ : ρ.restrict B = ρ := Measure.restrict_eq_self_of_ae_mem hx
  have hU : Continuous U.uncurry := by
    have H : Continuous (Finset.univ.sup' Finset.univ_nonempty
      (fun i (p : ((I → E) × (I → ℝ)) × E) => ⟪p.1.1 i,p.2⟫_ℝ+p.1.2 i)) := by
      apply Continuous.finset_sup'
      intro i _
      fun_prop
    convert H using 1
    funext p
    simp only [U,labelMax,Function.uncurry,Finset.sup'_apply]
  have hUint : Continuous (fun p => ∫ x, U p x ∂ρ) := by
    have H := continuous_parametric_integral_of_continuous (μ := ρ) hU hB
    rwa [hρ] at H
  have hF : Continuous F := by
    have h' : Continuous (fun p : ((I → E) × (I → ℝ)) × (I → ℝ) => ∫ x, U (p.1.1,p.2) x ∂ρ) :=
      hUint.comp (by fun_prop)
    exact h'.sub (by fun_prop)
  have hYn (i : I) : Tendsto (fun t => Y t i) l (𝓝 (y i)) :=
    (continuous_apply i).continuousAt.tendsto.comp hY
  have hMn (i : I) : Tendsto (fun t => M t i) l (𝓝 (m i)) :=
    (continuous_apply i).continuousAt.tendsto.comp hM
  have hnear : ∀ᶠ t in l, ∀ i, ‖Y t i‖ < ‖y i‖+1 := by
    apply Filter.eventually_all.mpr
    intro i
    exact (continuous_norm.continuousAt.tendsto.comp (hYn i)).eventually
      (gt_mem_nhds (show ‖y i‖ < ‖y i‖+1 by linarith))
  have hlower : ∀ᶠ t in l, ∀ i, C t i ≤ F ((Y t,M t),C t)+A := by
    filter_upwards [hnear,hnorm] with t ht hn
    intro i
    have hi : Integrable (U (Y t,C t)) ρ := by
      have hcc : Continuous (U (Y t,C t)) :=
        hU.comp (show Continuous (fun x : E => ((Y t,C t),x)) by fun_prop)
      have h := hcc.continuousOn.integrableOn_compact (μ := ρ) hB
      change Integrable (U (Y t,C t)) (ρ.restrict B) at h
      rwa [hρ] at h
    have H := integral_mono_ae (integrable_const (C t i-A)) hi (hx.mono fun x hx' => ?_)
    · have hr : ρ.real univ=1 := by simp [Measure.real]
      simp only [integral_const,smul_eq_mul,hr,one_mul] at H
      change C t i ≤ ((∫ x, U (Y t,C t) x ∂ρ) - ∑ j, M t j*C t j)+A
      rw [hn.2,sub_zero]
      linarith
    · have Hn : |⟪Y t i,x⟫_ℝ| ≤ (‖y i‖+1)*(R : ℝ) :=
        (abs_real_inner_le_norm _ _).trans
          (mul_le_mul (ht i).le (hR x hx') (norm_nonneg _) (by positivity))
      have HB : |⟪Y t i,x⟫_ℝ| ≤ A := Hn.trans
        (Finset.single_le_sum (f := fun j => (‖y j‖+1)*(R : ℝ))
          (fun j _ => by positivity) (Finset.mem_univ i))
      have HU : ⟪Y t i,x⟫_ℝ+C t i ≤ U (Y t,C t) x :=
        Finset.le_sup' (fun j => ⟪Y t j,x⟫_ℝ+C t j) (Finset.mem_univ i)
      exact (by linarith [(abs_le.mp HB).1] : C t i-A ≤ ⟪Y t i,x⟫_ℝ+C t i).trans HU
  refine tendsto_normalized_dual_selection_variable_mass l (fun t => (Y t,M t)) (y,m)
    (hY.prodMk_nhds hM) M m hm hMn F hF C c A hnorm hmin hlower ?_
  intro d hd hopt
  refine hunique d hd (fun w hw => ?_)
  have H := hopt w
  change bodyDual ρ y m d ≤ bodyDual ρ y m w at H
  simpa only [bodyDual,hd,hw,sub_zero] using H




#print axioms body_minimumDualValue_site_hasDerivAt
#print axioms weightedIntercept_path_bound
#print axioms body_potential_L2_subinterval_bound
#print axioms fused_endpoint_globalSupport_and_pushforward
#print axioms body_potential_L2_colliding_endpoint_bound
#print axioms tendsto_bodyDual_normalized_selection
end BrenierReplacement

