import os, re, subprocess, sys, shutil
from pathlib import Path
wd=Path.cwd(); m=(wd.parent/'chen-attainment-toolchain/mathlib').resolve()
base=m/'.lake/build/lib/lean'; dest=wd/'build/stock'
lean=m.parent/'lean-4.33.1-linux/bin/lean'
pkgs=[p/'.lake/build/lib/lean' for p in (m/'.lake/packages').glob('*')]
env={**os.environ,'LEAN_PATH':':'.join(map(str,[dest,*pkgs]))}
seen=set(); todo=[]
def rec(n):
 if n in seen:return
 seen.add(n)
 f=Path(n.replace('.','/')+'.lean'); o=f.with_suffix('.olean')
 if any((p/o).exists() for p in [dest,base,*pkgs]):return
 src=m/f
 if not src.is_file():raise ValueError(n)
 for i in re.findall(r'^(?:(?:public|private|meta) )*import (\S+)',src.read_text(),re.M):rec(i)
 todo.append((src,dest/o))
for n in sys.argv[1:]:rec(n)
print('stock transitive additions:',len(todo),flush=True)
if len(todo)>40:sys.exit(78)
if not (dest/'Mathlib').exists():
 dest.mkdir(parents=True,exist_ok=True)
 subprocess.run(['cp','-as',str(base/'Mathlib'),str(dest)],check=True)
for src,o in todo:
 if shutil.disk_usage(dest).free < 3*1024**3:sys.exit(78)
 o.parent.mkdir(parents=True,exist_ok=True)
 print('STOCK',src.relative_to(m),flush=True)
 subprocess.run([str(lean),'--root='+str(m),'-o',str(o),str(src)],env=env,check=True)
