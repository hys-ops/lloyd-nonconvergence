# Brenier replacement: explicit bound and original sharpness

Lean 4.33.1 (compiler commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6) with Mathlib 0df444a360eaa60ab8c11dca51a86af692955474.

This adds two checks to the previously replayed upper bound. Run the original `bash verify_brenier_14p_upper_433.sh` and then `bash verify_brenier_remaining_claims_433.sh`. The scripts use the same fixed, existing toolchain/Mathlib layout and private build compartment. `manuscript-constant-and-sharpness-final-433.log` gives the source checks and independent kernel replays.

## Exact printed upper constant

`BrenierReplacement.one_third_stability_with_manuscript_constant` certifies the all-target estimate with the displayed manuscript constant
`sqrt(12 d R² (1 + sqrt 1)² + 28 L² P_K / |K|)`. It is not a substitution of the coarser original formal interface's existential strip constant. Here `d=n+1` covers every manuscript dimension d≥2. The body and target are compact, the body is convex and has nonempty interior, and R,L are any enclosing radius bounds. There are no optimizer, moment, or noncolliding endpoint assumptions for this all-target result. `P_K` is the sum of the ordinary Lebesgue volumes of the coordinate projections: `coordinateSplit_apply` states coordinate deletion exactly, and `coordinateSplit_measurePreserving` gives the Lebesgue measure-preserving splitting needed for the Fubini estimate.

The adapter reuses pinned OAI `boundary_strip_le_of_coordinate_split`, `integral_slope_difference_sq_le`, `one_third_bound_of_raw` and `one_third_stability_of_finite_targets`. The only change to the geometric interpolation is retaining the individual projection volumes instead of replacing them by one worst-case constant before summing; it reuses the replacement finite potential estimate with exact 2R.

## Same native sharpness declaration, unchanged three-atom example

`OAI.Problem358.one_third_exponent_is_sharp` is the exact named terminal declaration from the pinned OAI `Stability.lean`, with identical theorem statement/proof, extracted without the dependencies for the old upper-bound proof. The pinned reference `Stability.lean` SHA-256 is 30be40a80f4518c674b76afd9ad73c93c2bdfdb4d08cd09b302d3ea0eddfc97a. The six dependent Sharp modules are bundled at the same OAI commit as the upper bound. The terminal lower proof uses the same tilted three-atom family with b=a/2 (and the exact W₂ formula), and uses a conservative rectangular lower bound to reach the impossibility result.

For the manuscript's sharper intermediate calculation, `BrenierReplacement.exact_three_atom_map_distance_square` proves exactly the map distance square `b/2 + a*b²` for the same two cube maps, using the pinned original exact integral and symmetric-difference mass lemmas. The exact W₂ formula itself is pinned `OAI.Problem358.wasserstein2_sharpTarget`. No claim is made that every expository comparison (for example the separate W₁ remark and literature discussion) is formalized.

All listed theorem replays depend only on `propext`, `Classical.choice` and `Quot.sound`.
