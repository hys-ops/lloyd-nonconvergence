import os,re,subprocess,sys
from pathlib import Path
wd=Path.cwd()
m=(wd.parent/'chen-attainment-toolchain/mathlib').resolve()
lean=m.parent/'lean-4.33.1-linux/bin/lean'
source=wd/'originals/upstream'
patched=wd/'ported/upstream'
out=wd/'build/upstream'
imports=[
'Mathlib.Analysis.InnerProductSpace.PiL2','Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar',
'Mathlib.Analysis.Calculus.LocalExtr.Basic',
'Mathlib.Topology.Separation.Connected',
'Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun','Mathlib.Analysis.InnerProductSpace.Calculus','Mathlib.Analysis.Calculus.ParametricIntegral',
'Mathlib.Analysis.Convex.Measure','Mathlib.MeasureTheory.Measure.Support',
'Mathlib.MeasureTheory.Function.SpecialFunctions.Inner',
'Mathlib.LinearAlgebra.AffineSpace.FiniteDimensional',
'Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace',
'Mathlib.MeasureTheory.Integral.Bochner.Basic','Mathlib.MeasureTheory.Integral.DominatedConvergence',
'Mathlib.MeasureTheory.Function.L2Space','Mathlib.MeasureTheory.Measure.Dirac',
'Mathlib.Analysis.Convex.Basic','Mathlib.Analysis.Convex.Combination','Mathlib.Order.Filter.AtTopBot.Basic',
'Mathlib.Tactic.Linarith','Mathlib.Tactic.Ring','Mathlib.Tactic.FunProp','Mathlib.Tactic.NormNum',
'Mathlib.Tactic.Positivity','Mathlib.Analysis.Calculus.MeanValue',
'Mathlib.Topology.Order.Compact','Mathlib.Analysis.SpecialFunctions.Pow.Real',
]
stock=m/'.lake/build/lib/lean'
localstock=wd/'build/stock'
def exists(n):return any((p/(n.replace('.','/')+'.olean')).is_file() for p in [localstock,stock])
imports=[s for s in imports if exists(s)]
env={**os.environ,'LEAN_PATH':':'.join(str(d) for d in [out,wd/'build/minty',localstock,stock]+[p/'.lake/build/lib/lean' for p in (m/'.lake/packages').glob('*')])}
seen=set()
def build(n):
 if n in seen:return
 seen.add(n)
 f=Path(n.replace('.','/')+'.lean')
 s=(source/f).read_text()
 for i in re.findall(r'^import (OAI\.\S+)',s,re.M):build(i)
 orig=s
 if n.endswith('.Translation'): s='import Mathlib.Analysis.Calculus.Rademacher\nimport Mathlib.Analysis.Calculus.FDeriv.Measurable\n'+s
 if n.endswith('.Difference') or n.endswith('.Translation'): s='import Mathlib.Analysis.Convex.Deriv\nimport Mathlib.MeasureTheory.Group.Integral\n'+s
 if n.endswith('.Atomic'): s=re.sub(r'Measure.map_smul _ measurable_(?:fst|snd).aemeasurable', 'Measure.map_smul _ _ _',s)
 if n.endswith('.ConvexOptimality'): s=s.replace('Measure.isProbabilityMeasure_of_map hT.aemeasurable','Measure.isProbabilityMeasure_of_map T')
 if n.endswith('.CompactMeasure'): s='import Mathlib.MeasureTheory.Integral.RieszMarkovKakutani.Real\n'+s
 if n.endswith('.PotentialTime'): s='import Mathlib.MeasureTheory.Integral.Prod\n'+s
 s=s.replace('Measure.map_smul _ hy.aemeasurable','Measure.map_smul _ _ _')
 if n.endswith('.AffinePaths'):
  s=s.replace("convert ((hasDerivAt_const q x).inner ℝ (hdy i q hq)).add (hdc i q hq) using 1\n    simp only [inner_zero_left, add_zero]\n    rfl", "let L : E d →L[ℝ] ℝ := innerSL ℝ x\n    exact (L.hasFDerivAt.comp_hasDerivAt q (hdy i q hq)).add (hdc i q hq)")
  a=s.index('  rw [Lp.dist_edist, Lp.edist_toLp_toLp, toReal_eLpNorm,')
  b=s.index('\n\nomit ',a)
  s=s[:a]+"""  rw [dist_eq_norm, ← MemLp.toLp_sub hf hg, Lp.norm_toLp,
    (hf.sub hg).eLpNorm_eq_integral_rpow_norm (by norm_num) (by norm_num)]
  have hn : 0 ≤ (∫ x, (f x-g x)^2 ∂μ) := integral_nonneg (fun _ => sq_nonneg _)
  simp only [ENNReal.toReal_ofNat, Real.rpow_two, Real.norm_eq_abs, sq_abs,
    Real.sqrt_eq_rpow, one_div]
  simp only [Pi.sub_apply, ENNReal.toReal_ofReal (Real.rpow_nonneg hn _)]"""+s[b:]
 if n.endswith('.CompactTransport'):
  s='import Mathlib.MeasureTheory.Measure.Prokhorov\n'+s
  s=s.replace('π.map Prod.fst','π.map measurable_fst.aemeasurable').replace('π.map Prod.snd','π.map measurable_snd.aemeasurable')
 if n.endswith('.SharpRectangle'):
  s=re.sub(r'ite_eq_left (hB\')',r'if_pos \1',s)
  s=s.replace('ite_eq_left','if_true').replace('ite_eq_right','if_neg')
 if n.endswith('.Cube'):
  s='import Mathlib.Probability.Independence.Basic\nimport Mathlib.Analysis.SpecialFunctions.Integrals.Basic\n'+s
  s=s.replace('Measure.map_smul _ (PiLp.volume_preserving_ofLp (Fin d)).measurable.aemeasurable','Measure.map_smul _ _ _')
 if n.endswith('.Approximation'):
  s=s.replace('Measure.isProbabilityMeasure_of_map (hTm 0).aemeasurable','Measure.isProbabilityMeasure_of_map (T 0)')
  s=s.replace('    convert (hsum.rpow_const_nhds_zero hp).const_mul C using 1\n    simp only [mul_zero]', '    simpa only [mul_zero, Real.rpow_eq_pow] using (hsum.rpow_const_nhds_zero hp).const_mul C')
 if n.endswith('.Quantization'):
  s=s.replace('⟨q, hqY, inferInstance,','⟨q, hqY, Measure.isProbabilityMeasure_map q.measurable.aemeasurable,')
  s=s.replace('· unfold graphPlan\n      infer_instance','· unfold graphPlan\n      exact Measure.isProbabilityMeasure_map hg.aemeasurable')
  s=s.replace('    inferInstance,\n    (simpleFunc_map_finite_support μ q).2','    Measure.isProbabilityMeasure_map q.measurable.aemeasurable,\n    (simpleFunc_map_finite_support μ q).2')
 if n.endswith('.PotentialLimits'):
  s='import Mathlib.Topology.ContinuousMap.Bounded.ArzelaAscoli\nimport Mathlib.Topology.MetricSpace.UniformConvergence\n'+s
  s=s.replace('  exact ((innerSL_inj (𝕜 := ℝ)).mp\n    (hasFDerivAt_eq_innerSL_of_supporting hderiv hx hsupport)).symm','  apply ext_inner_right ℝ\n  intro v\n  exact (DFunLike.congr_fun (hasFDerivAt_eq_innerSL_of_supporting hderiv hx hsupport) v).symm')
 if n.endswith('.Conjugacy'):
  s='import Mathlib.Analysis.Calculus.Rademacher\n'+s
  s=s.replace('  apply (innerSL_inj (𝕜 := ℝ)).mp\n  exact (restrictedConjugate_supporting_slope_eq_fderiv hx hu.hasFDerivAt hy).symm.trans\n    (restrictedConjugate_supporting_slope_eq_fderiv hx hu.hasFDerivAt hz)','  apply ext_inner_right ℝ\n  intro v\n  exact DFunLike.congr_fun ((restrictedConjugate_supporting_slope_eq_fderiv hx hu.hasFDerivAt hy).symm.trans\n    (restrictedConjugate_supporting_slope_eq_fderiv hx hu.hasFDerivAt hz)) v')
 if n.endswith('.MapLimits'):
  s='import Mathlib.MeasureTheory.Measure.HasOuterApproxClosed\n'+s
  s=s.replace('dite_eq_left hx','dif_pos hx')
 if n.endswith('.MapDistance'):
  s='import Mathlib.MeasureTheory.Function.LpSeminorm.LpNorm\n'+s
  s=s.replace('Lp.edist_toLp_toLp, toReal_eLpNorm]', 'Lp.edist_toLp_toLp, toReal_eLpNorm (hT.aestronglyMeasurable.sub hS.aestronglyMeasurable)]')
  s=s.replace('· unfold graphPlan\n    infer_instance','· unfold graphPlan\n    exact Measure.isProbabilityMeasure_map hm.aemeasurable')
 if n.endswith('.AffineOptimality'):
  s=s.replace('IsProbabilityMeasure (Measure.map T ρ) := inferInstance','IsProbabilityMeasure (Measure.map T ρ) := Measure.isProbabilityMeasure_map hT.aemeasurable')
 if n.endswith('.Coupling'):
  s='import ScalarL2Extract\nimport Mathlib.MeasureTheory.Function.LpSeminorm.LpNorm\n'+s
  s=s.replace('  refine ⟨inferInstance,','  refine ⟨Measure.isProbabilityMeasure_map hQR.aemeasurable,',1)
  s=s.replace('rw [← toReal_eLpNorm, ← toReal_eLpNorm]', 'rw [← toReal_eLpNorm hf, ← toReal_eLpNorm hc.aestronglyMeasurable]').replace('eLpNorm_mono_ae_real hf hb','eLpNorm_mono_ae_real hb')
 if n.endswith('.Wasserstein'):
  s='import ScalarL2Extract\nimport Mathlib.Analysis.Convex.Integral\nimport Mathlib.MeasureTheory.Measure.Portmanteau\n'+s
  s=s.replace('have : IsProbabilityMeasure π := hπ.1\n  refine ⟨inferInstance,', 'have : IsProbabilityMeasure π := hπ.1\n  refine ⟨Measure.isProbabilityMeasure_map measurable_swap.aemeasurable,',1)
  s=s.replace('  have hπ : IsCoupling μ μ π := by\n    refine ⟨inferInstance,','  have hπ : IsCoupling μ μ π := by\n    refine ⟨Measure.isProbabilityMeasure_map hmeas.aemeasurable,',1)
  s=s.replace('  have h := ProbabilityTheory.variance_nonneg f ρ\n  rw [ProbabilityTheory.variance_eq_sub hf] at h\n  exact sub_nonneg.mp h','  exact (even_two.convexOn_pow (𝕜 := ℝ)).map_integral_le (continuous_pow 2).continuousOn isClosed_univ\n    (.of_forall fun _ => Set.mem_univ _) (hf.integrable (by norm_num)) hf.integrable_sq')
 if n.endswith('.MaxCalculus'):
  s=s.replace('convert ((hasDerivAt_const t x).inner ℝ (hy j)).add (hc j) using 1\n    simp only [inner_zero_left, add_zero]', 'let L : V →L[ℝ] ℝ := innerSL ℝ x\n    exact ((L.hasFDerivAt.comp_hasDerivAt t (hy j))).add (hc j)')
  s=s.replace('convert ((hasDerivAt_const t x).inner ℝ (hy j t ht)).add (hc j t ht) using 1\n    simp only [inner_zero_left, add_zero]', 'let L : V →L[ℝ] ℝ := innerSL ℝ x\n    exact ((L.hasFDerivAt.comp_hasDerivAt t (hy j t ht))).add (hc j t ht)')
 if 'import Mathlib\n' in s:
  s=s.replace('import Mathlib\n','\n'.join('import '+i for i in imports)+'\n',1)
 if s != orig:
  f2=patched/f;f2.parent.mkdir(parents=True,exist_ok=True);f2.write_text(s)
 else: f2=source/f
 o=(out/f).with_suffix('.olean');o.parent.mkdir(parents=True,exist_ok=True)
 if os.environ.get('BREN_REUSE_DONE') == '1' and o.is_file() and n.rsplit('.',1)[-1] not in os.environ.get('BREN_FORCE_MODULES','').split(','):
  print('REUSE',n,flush=True); return
 print('BUILD',n,flush=True)
 rv=subprocess.run([str(lean),'--root='+str(f2.parents[len(f.parts)-1]),'-o',str(o),str(f2)],env=env)
 if rv.returncode:sys.exit(rv.returncode)
for t in sys.argv[1:]:build('OAI.Analysis.Brenier.'+t)
