#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
M=$(realpath ../chen-attainment-toolchain/mathlib)
J="$M/../lean-4.33.1-linux/bin"
export LEAN_PATH="$PWD/build/minty:$PWD/build/replacement:$PWD/build/upstream:$PWD/build/stock:$M/.lake/build/lib/lean:$(printf '%s:' "$M"/.lake/packages/*/.lake/build/lib/lean)"
"$J/lean" --version
git -C "$M" rev-parse HEAD
for n in "$@"; do
  echo "Joint source module: $n"
  "$J/lean" --root="$PWD/ported/minty" -o "build/minty/$n.olean" "ported/minty/$n.lean"
done
