import Mathlib.MeasureTheory.Measure.Restrict
import Mathlib.MeasureTheory.Measure.Real

open MeasureTheory Set
open scoped ENNReal

theorem restrict_cell_inter_of_supported {X : Type*} [MeasurableSpace X]
    {ρ : Measure X} {K A : Set X} (hK : ∀ᵐ x ∂ρ, x ∈ K) :
    ρ.restrict (A ∩ K) = ρ.restrict A := by
  have h : (A ∩ K : Set X) =ᵐ[ρ] A := by
    filter_upwards [hK] with x hx
    apply propext
    change (x ∈ A ∧ x ∈ K) ↔ x ∈ A
    exact ⟨And.left, fun ha => ⟨ha, hx⟩⟩
  exact Measure.restrict_congr_set h

theorem compact_cell_restriction_normalization {X : Type*} [MeasurableSpace X]
    (μ : Measure X) (K A : Set X) (hK : MeasurableSet K) (q : ℝ≥0∞) :
    let ρ := q • μ.restrict K
    ρ.restrict (A ∩ K) = ρ.restrict A ∧
      ρ (A ∩ K) = ρ A ∧
      ρ.real (A ∩ K) = ρ.real A ∧
      (ρ (A ∩ K))⁻¹ • ρ.restrict (A ∩ K) = (ρ A)⁻¹ • ρ.restrict A := by
  dsimp
  let ρ := q • μ.restrict K
  have ha : ρ.restrict (A ∩ K) = ρ.restrict A :=
    restrict_cell_inter_of_supported (Measure.ae_smul_measure (ae_restrict_mem hK) q)
  have hmass : ρ (A ∩ K) = ρ A := by
    simpa only [Measure.restrict_apply_univ] using congrArg (fun ρ' : Measure X => ρ' univ) ha
  exact ⟨ha, hmass, congrArg ENNReal.toReal hmass, by change (ρ (A ∩ K))⁻¹ • ρ.restrict (A ∩ K) = (ρ A)⁻¹ • ρ.restrict A; rw [ha, hmass]⟩

#print axioms compact_cell_restriction_normalization

/-- A compactly cut pair of cell laws gives the identical uncut laws and bound.
    The function `h` is instantiated with the original Joint harmonic mass. -/
theorem compact_cut_coupling_to_uncut {X Z : Type*}
    [MeasurableSpace X] [MeasurableSpace Z]
    (μ : Measure X) (K A B : Set X) (hK : MeasurableSet K) (q : ℝ≥0∞)
    (h : ℝ → ℝ → ℝ) (P : Measure Z) (left right middle : Z → X) :
    let ρ := q • μ.restrict K
    ρ (A ∩ K) • P.map left = ρ.restrict (A ∩ K) →
    ρ (B ∩ K) • P.map right = ρ.restrict (B ∩ K) →
    ENNReal.ofReal (h (ρ.real (A ∩ K)) (ρ.real (B ∩ K))) • P.map middle ≤ ρ →
    ρ A • P.map left = ρ.restrict A ∧
      ρ B • P.map right = ρ.restrict B ∧
      ENNReal.ofReal (h (ρ.real A) (ρ.real B)) • P.map middle ≤ ρ := by
  intro ρ hL hR hM
  obtain ⟨ha, haMass, haReal, _⟩ := compact_cell_restriction_normalization μ K A hK q
  obtain ⟨hb, hbMass, hbReal, _⟩ := compact_cell_restriction_normalization μ K B hK q
  refine ⟨?_, ?_, ?_⟩
  · exact haMass ▸ ha ▸ hL
  · exact hbMass ▸ hb ▸ hR
  · exact haReal ▸ hbReal ▸ hM

#print axioms compact_cut_coupling_to_uncut
