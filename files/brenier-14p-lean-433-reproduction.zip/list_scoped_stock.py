from pathlib import Path
import re,sys
m=Path('../chen-attainment-toolchain/mathlib').resolve()
stock=[Path('build/stock').resolve(),m/'.lake/build/lib/lean']
pks=list((m/'.lake/packages').glob('*')); stock +=[p/'.lake/build/lib/lean' for p in pks]
seen=set(); order=[]
def rec(n):
 if n in seen:return
 seen.add(n)
 f=Path(n.replace('.','/')+'.lean')
 if any((p/f.with_suffix('.olean')).is_file() for p in stock):return
 p=next((p for p in [m,*pks] if (p/f).is_file()),None)
 if p is None:raise ValueError(n)
 for j in re.findall(r'^(?:(?:public|private|meta) )*import (\S+)',(p/f).read_text(),re.M):rec(j)
 order.append(n)
for n in sys.argv[1:]:rec(n)
print('\n'.join(order))
