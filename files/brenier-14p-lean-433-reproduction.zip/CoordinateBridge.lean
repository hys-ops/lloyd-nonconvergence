import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.InnerProductSpace.LinearMap
import Mathlib.LinearAlgebra.Matrix.Trace

open MeasureTheory Set
open scoped RealInnerProductSpace ENNReal

theorem normalized_volume_ofLp (d : ℕ) (K : Set (EuclideanSpace ℝ (Fin d)))
    (hK : MeasurableSet K) :
    MeasurePreserving (WithLp.ofLp : EuclideanSpace ℝ (Fin d) → (Fin d → ℝ))
      ((volume K)⁻¹ • volume.restrict K)
      ((volume (WithLp.ofLp '' K))⁻¹ • volume.restrict (WithLp.ofLp '' K)) := by
  let e := (MeasurableEquiv.toLp 2 (Fin d → ℝ)).symm
  have hv : MeasurePreserving e volume volume :=
    EuclideanSpace.volume_preserving_symm_measurableEquiv_toLp (Fin d)
  have hvol : volume (e '' K) = volume K := by
    rw [← hv.measure_preimage (e.measurableSet_image.mpr hK).nullMeasurableSet, e.injective.preimage_image]
  exact hvol.symm ▸ (hv.restrict_image_emb e.measurableEmbedding K).smul_measure ((volume K)⁻¹)

theorem setIntegral_inner_as_cell_moment {E : Type*} [NormedAddCommGroup E]
    [InnerProductSpace ℝ E] [CompleteSpace E] [MeasurableSpace E] {μ : Measure E}
    (s : Set E) (v : E) (hint : IntegrableOn (fun x : E => x) s μ) :
    (∫ x in s, ⟪x, v⟫ ∂μ) = ⟪(∫ x in s, x ∂μ), v⟫ := by
  simpa [real_inner_comm] using
    (innerSL ℝ v).integral_comp_comm (μ := μ.restrict s) hint

#print axioms normalized_volume_ofLp
#print axioms setIntegral_inner_as_cell_moment

open scoped BigOperators

theorem coordinate_cellMoment_trace {d : ℕ} {I : Type*} [Fintype I]
    (B₀ B₁ : I → EuclideanSpace ℝ (Fin d)) (W : I → ℝ) :
    Matrix.trace (fun r s : Fin d => ∑ i,
      (B₀ i r - B₁ i r) * (B₀ i s - B₁ i s) / W i) =
      ∑ i, ‖B₀ i - B₁ i‖ ^ 2 / W i := by
  change (∑ r : Fin d, ∑ i, (B₀ i r - B₁ i r) * (B₀ i r - B₁ i r) / W i) = _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  rw [PiLp.norm_sq_eq_of_L2, Finset.sum_div]
  simp only [PiLp.sub_apply, Real.norm_eq_abs, sq_abs]; simp only [pow_two]

#print axioms coordinate_cellMoment_trace

theorem normalized_volume_cellMoment_coordinate (d : ℕ)
    (K U : Set (EuclideanSpace ℝ (Fin d))) (hK : MeasurableSet K) (r : Fin d)
    (hint : IntegrableOn (fun x : EuclideanSpace ℝ (Fin d) => x) U
      ((volume K)⁻¹ • volume.restrict K)) :
    let c : EuclideanSpace ℝ (Fin d) → (Fin d → ℝ) := WithLp.ofLp
    let ρ := (volume K)⁻¹ • volume.restrict K
    let σ := (volume (c '' K))⁻¹ • volume.restrict (c '' K)
    (∫ z in c '' U, z r ∂σ) = (∫ x in U, x ∂ρ) r := by
  let e := (MeasurableEquiv.toLp 2 (Fin d → ℝ)).symm
  let ρ := (volume K)⁻¹ • volume.restrict K
  let σ := (volume (e '' K))⁻¹ • volume.restrict (e '' K)
  change (∫ z in e '' U, z r ∂σ) = (∫ x in U, x ∂ρ) r
  have h : MeasurePreserving e ρ σ := normalized_volume_ofLp d K hK
  rw [← (h.restrict_image_emb e.measurableEmbedding U).integral_comp' (fun z => z r)]
  exact (PiLp.proj (𝕜 := ℝ) 2 (fun _ : Fin d => ℝ) r).integral_comp_comm hint

#print axioms normalized_volume_cellMoment_coordinate
