import StaticRankSubtype
import MinimaxUpperJoint

open MeasureTheory Set Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The compact-valued version of a probability law with an ambient density,
used as the reference for the sequential rank estimator. -/
def densityReference {d : ℕ} (B : Set (RankPoint d)) (hb : IsCompact B) (w : RankPoint d → ℝ)
    [IsProbabilityMeasure (weighted volume w)] (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) : ProbabilityMeasure B :=
  ⟨(weighted volume w).comap Subtype.val, (MeasurableEmbedding.subtype_coe hb.isClosed.measurableSet).isProbabilityMeasure_comap
    (by simpa using sw)⟩

theorem densityReference_law {d : ℕ} (B : Set (RankPoint d)) (hb : IsCompact B) (w : RankPoint d → ℝ)
    [IsProbabilityMeasure (weighted volume w)] (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) :
    ((densityReference B hb w sw : Measure B).map Subtype.val) = weighted volume w :=
  (map_comap_subtype_coe hb.isClosed.measurableSet _).trans (Measure.restrict_eq_self_of_ae_mem sw)

/-- Finite-list estimator for compactly supported conditional Lebesgue
densities. The same mixture estimator attains the bound for every candidate;
the theorem has no separate transport or midpoint input. -/
theorem finite_list_public_upper {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {J : Type*} [Fintype J] [Nonempty J] (a : J → Predictions A (compactObservationVolume A ha)) (T : ℕ) :
    let target := densityReference B hb w sw
    ∃ V : (t : ℕ) → History A t × A → Fin d → ℝ, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((listForecast a t).law h) target (fun y => V t (h,y))) ∧
      ∀ j, ∃ U : (t : ℕ) → History A t × A → Fin d → ℝ, (∀ t, Measurable (U t)) ∧
        (∀ t h, CertifiedRank ((a j t).law h) target (fun y => U t (h,y))) ∧
        (∑ t ∈ Finset.range T, historyRisk (a j) (fun n z => normSq (diff (U n z) (V n z))) t) ≤
          min (4*R^2*T) (16*R^2*Real.log (Fintype.card J)) := by
  let target := densityReference B hb w sw
  let _ : Nonempty B := nonempty_of_isProbabilityMeasure (target : Measure B)
  let ν := compactObservationVolume A ha
  have base : ν.map Subtype.val = volume.restrict A := map_comap_subtype_coe ha.isClosed.measurableSet _
  apply finite_list_estimator_exists A B ha hb ν target R ball a T
    (base ▸ Measure.restrict_le_self.absolutelyContinuous)
  intro j t _ h _ u v mu mv cu cv
  exact subtype_rank_midpoint A B ha hb ν base target w wn conc (densityReference_law B hb w sw)
    (a j t) (listForecast a t) h h u v mu mv cu cv

/-- Parametric i.i.d. estimator from the stated small-ball prior mass and
ordinary extended KL assumptions. It is selected independently of the true
parameter. The certified maps and their midpoint domination are derived. -/
theorem parametric_public_upper {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {Θ : Type*} [PseudoMetricSpace Θ] [MeasurableSpace Θ] [OpensMeasurableSpace Θ]
    (F : IIDFamily Θ A (compactObservationVolume A ha)) (π : Measure Θ) [IsProbabilityMeasure π] (fallback : Θ)
    (T : ℕ) (hT : 0 < T) (C c k : ℝ) (cp : 0 < c) (cn : 0 ≤ C) :
    let target := densityReference B hb w sw
    ∃ V : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((priorForecast F π fallback t).law h) target (fun y => V t (h,y))) ∧
      ∀ θ, c*(1/Real.sqrt (T:ℝ))^k ≤ π.real (Metric.ball θ (1/Real.sqrt (T:ℝ))) →
        (∀ η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ)),
          InformationTheory.klDiv ((F.forecast θ 0).law PUnit.unit : Measure A)
            ((F.forecast η 0).law PUnit.unit : Measure A) ≤ ENNReal.ofReal (C*(dist η θ)^2)) →
      ∃ U : A → RankPoint d, Measurable U ∧ CertifiedRank ((F.forecast θ 0).law PUnit.unit) target U ∧
        (∑ t ∈ Finset.range T, historyRisk (F.forecast θ) (fun n z => normSq (diff (U z.2) (V n z))) t) ≤
          16*R^2*(C+Real.log (1/c)+(k/2)*Real.log T) := by
  let target := densityReference B hb w sw
  let _ : Nonempty B := nonempty_of_isProbabilityMeasure (target : Measure B)
  let ν := compactObservationVolume A ha
  have base : ν.map Subtype.val = volume.restrict A := map_comap_subtype_coe ha.isClosed.measurableSet _
  apply parametric_estimator_exists A B ha hb ν (base ▸ Measure.restrict_le_self.absolutelyContinuous)
    target R ball F π fallback T hT C c k cp cn
  intro θ t _ h _ u v mu mv cu cv
  exact subtype_rank_midpoint A B ha hb ν base target w wn conc (densityReference_law B hb w sw)
    (F.forecast θ 0) (priorForecast F π fallback t) PUnit.unit h u v mu mv cu cv

end
end SequentialRanks
