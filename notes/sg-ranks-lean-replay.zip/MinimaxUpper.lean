import DensityChain

open MeasureTheory Filter Set
open scoped BigOperators
namespace SequentialRanks
noncomputable section
universe u
/-- A finite history is a nested product in chronological order. -/
def History (Y : Type u) : ℕ → Type u
  | 0 => PUnit
  | n+1 => History Y n × Y

instance historyMeasurable (Y : Type u) [mY : MeasurableSpace Y] : (n : ℕ) → MeasurableSpace (History Y n)
  | 0 => (⊤ : MeasurableSpace PUnit)
  | n+1 => @MeasurableSpace.prod (History Y n) Y (historyMeasurable Y n) mY

def historyBase {Y : Type u} [MeasurableSpace Y] (ν : Measure Y) : (n : ℕ) → Measure (History Y n)
  | 0 => Measure.dirac PUnit.unit
  | n+1 => (historyBase ν n).prod ν

instance historySFinite {Y : Type u} [MeasurableSpace Y] (ν : Measure Y) [SFinite ν] :
    (n : ℕ) → SFinite (historyBase ν n)
  | 0 => by change SFinite (@Measure.dirac PUnit ⊤ PUnit.unit); infer_instance
  | n+1 => by
    have : SFinite (historyBase ν n) := historySFinite ν n
    exact Measure.prod.instSFinite

/-- A jointly measurable probability density conditional on a history. -/
structure Forecast (H Y : Type*) [MeasurableSpace H] [MeasurableSpace Y] (ν : Measure Y) where
  f : H × Y → ℝ
  measurable : Measurable f
  nonneg : ∀ z, 0 ≤ f z
  integrable : ∀ h, Integrable (fun y => f (h,y)) ν
  mass : ∀ h, (∫ y, f (h,y) ∂ν) = 1

private theorem extend_integrable {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    {μ : Measure H} {ν : Measure Y} [SFinite ν] (a : Forecast H Y ν) {g : H → ℝ}
    (mg : Measurable g) (ig : Integrable g μ) :
    Integrable (fun z : H × Y => g z.1*a.f z) (μ.prod ν) := by
  apply (integrable_prod_iff (f := fun z : H × Y => g z.1*a.f z) ((mg.comp measurable_fst).mul a.measurable).aestronglyMeasurable).2
  constructor
  · exact Eventually.of_forall fun h => (a.integrable h).const_mul (g h)
  · simpa only [norm_mul,Real.norm_of_nonneg (a.nonneg _),integral_const_mul,a.mass,mul_one] using ig.norm

variable {Y : Type u} [MeasurableSpace Y] {ν : Measure Y}
abbrev Predictions (Y : Type u) [MeasurableSpace Y] (ν : Measure Y) :=
  (n : ℕ) → Forecast (History Y n) Y ν

def historyDensity (a : Predictions Y ν) : (n : ℕ) → History Y n → ℝ
  | 0, _ => 1
  | n+1, z => historyDensity a n z.1 * (a n).f z

private theorem history_m (a : Predictions Y ν) : ∀ n, Measurable (historyDensity a n)
  | 0 => measurable_const
  | n+1 => (Measurable.comp (history_m a n) measurable_fst).mul (a n).measurable

private theorem history_pos (a : Predictions Y ν) : ∀ n z, 0 ≤ historyDensity a n z
  | 0,_ => zero_le_one
  | n+1,z => mul_nonneg (history_pos a n z.1) ((a n).nonneg _)

private theorem history_i [SFinite ν] (a : Predictions Y ν) : ∀ n,
    Integrable (historyDensity a n) (historyBase ν n)
  | 0 => by change Integrable (fun _ : PUnit => (1:ℝ)) (Measure.dirac _); exact integrable_const _
  | n+1 => extend_integrable (a n) (history_m a n) (history_i a n)

private theorem history_mass [SFinite ν] (a : Predictions Y ν) : ∀ n,
    (∫ z, historyDensity a n z ∂historyBase ν n) = 1
  | 0 => by change (∫ _ : PUnit, (1:ℝ) ∂Measure.dirac _) = 1; simp
  | n+1 => by
    change (∫ z : History Y n × Y, historyDensity a n z.1*(a n).f z ∂(historyBase ν n).prod ν) = _
    rw [integral_prod (fun z : History Y n × Y => historyDensity a n z.1*(a n).f z) (history_i a (n+1))]
    simp only [integral_const_mul,(a n).mass,mul_one]
    exact history_mass a n

theorem history_is_density [SFinite ν] (a : Predictions Y ν) (n : ℕ) :
    Measurable (historyDensity a n) ∧ (∀ z, 0 ≤ historyDensity a n z) ∧
    Integrable (historyDensity a n) (historyBase ν n) ∧ (∫ z, historyDensity a n z ∂historyBase ν n) = 1 :=
  ⟨history_m a n,history_pos a n,history_i a n,history_mass a n⟩

variable {J : Type*} [Fintype J] [Nonempty J]
private def avg (f : J → ℝ) := (∑ j, f j)/(Fintype.card J : ℝ)

def listMix (a : J → Predictions Y ν) (n : ℕ) (x : History Y n) : ℝ :=
  avg (fun j => historyDensity (a j) n x)

omit [Nonempty J] in
private theorem avg_m {X : Type*} [MeasurableSpace X] {f : J → X → ℝ}
    (m : ∀ j, Measurable (f j)) : Measurable (fun x => avg (fun j => f j x)) := by
  unfold avg; fun_prop

omit [Nonempty J] in
private theorem avg_i {X : Type*} [MeasurableSpace X] {μ : Measure X} {f : J → X → ℝ}
    (i : ∀ j, Integrable (f j) μ) : Integrable (fun x => avg (fun j => f j x)) μ := by
  exact (integrable_finsetSum _ (fun j _ => i j)).div_const _

omit [Nonempty J] in
private theorem integral_avg {X : Type*} [MeasurableSpace X] {μ : Measure X} {f : J → X → ℝ}
    (i : ∀ j, Integrable (f j) μ) :
    (∫ x, avg (fun j => f j x) ∂μ) = avg (fun j => ∫ x, f j x ∂μ) := by
  unfold avg
  rw [integral_div,integral_finsetSum _ (fun j _ => i j)]

private theorem avg_pos {f : J → ℝ} (h : ∀ j, 0 ≤ f j) : 0 ≤ avg f :=
  div_nonneg (Finset.sum_nonneg fun j _ => h j) (by positivity)

private theorem avg_dom {f : J → ℝ} (h : ∀ j, 0 ≤ f j) (j : J) :
    f j ≤ Fintype.card J * avg f := by
  have hc : (Fintype.card J : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  unfold avg; rw [mul_comm, div_mul_cancel₀ _ hc]; exact
    (Finset.single_le_sum (f:=f) (fun i _ => h i) (Finset.mem_univ j))

private theorem avg_one : avg (fun _ : J => (1 : ℝ)) = 1 := by
  simp [avg,Fintype.card_ne_zero]

/-- The next conditional density of the uniform mixture of full path laws.
At null-mixture histories choose any one candidate's forecast. -/
def listForecast (a : J → Predictions Y ν) (n : ℕ) : Forecast (History Y n) Y ν where
  f z := if listMix a n z.1 = 0 then (a (Classical.choice ‹Nonempty J›) n).f z
         else listMix a (n+1) z / listMix a n z.1
  measurable := by
    have hm (i) : Measurable (listMix a i) := avg_m (fun j => history_m (a j) i)
    exact Measurable.ite (measurableSet_eq_fun ((hm n).comp measurable_fst) measurable_const)
      (a _ n).measurable ((hm (n+1)).div ((hm n).comp measurable_fst))
  nonneg := by
    intro z
    split_ifs
    · exact (a _ n).nonneg _
    · exact div_nonneg (avg_pos (fun j => history_pos (a j) _ _)) (avg_pos (fun j => history_pos (a j) n _))
  integrable := by
    intro h; dsimp only
    split_ifs
    · exact (a _ n).integrable h
    · exact (avg_i (fun j => ((a j n).integrable h).const_mul (historyDensity (a j) n h))).div_const _
  mass := by
    intro h; dsimp only
    split_ifs with hz
    · exact (a _ n).mass h
    · rw [integral_div]
      change (∫ y, avg (fun j => historyDensity (a j) n h * (a j n).f (h,y)) ∂ν) / _ = _
      rw [integral_avg (fun j => ((a j n).integrable h).const_mul _)]
      simp only [integral_const_mul,(a _ n).mass,mul_one]
      exact div_self hz

theorem list_forecast_factor (a : J → Predictions Y ν) (n : ℕ) (z : History Y n × Y) :
    listMix a n z.1 * (listForecast a n).f z = listMix a (n+1) z := by
  classical
  unfold listForecast
  dsimp only
  split_ifs with hz
  · rw [hz,zero_mul]
    have h (j : J) : historyDensity (a j) n z.1 = 0 := by
      have hj := avg_dom (fun i => history_pos (a i) n z.1) j
      change _ ≤ _ * listMix a n z.1 at hj
      rw [hz,mul_zero] at hj
      exact le_antisymm hj (history_pos (a j) n z.1)
    simp [listMix,avg,historyDensity,h]
  · field_simp

private theorem kl_sandwich {p q M : ℝ} (pn : 0 ≤ p) (qn : 0 ≤ q) (M1 : 1 ≤ M)
    (dom : p ≤ M*q) : -q ≤ klTerm p q ∧ klTerm p q ≤ p*Real.log M := by
  rcases eq_or_lt_of_le pn with hz|hp
  · simp [klTerm,← hz,qn]
  have mp : 0 < M := by linarith
  have hq : 0 < q := lt_of_le_of_ne qn (by intro h; rw [← h,mul_zero] at dom; linarith)
  refine ⟨?_,mul_le_mul_of_nonneg_left (Real.log_le_log (div_pos hp hq) ((div_le_iff₀ hq).mpr dom)) pn⟩
  have L := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos (div_pos hq hp)) pn
  rw [Real.log_div hq.ne' hp.ne',mul_sub p (q/p) 1, mul_comm p (q/p),div_mul_cancel₀ _ hp.ne',mul_one] at L
  unfold klTerm
  rw [Real.log_div hp.ne' hq.ne']
  linarith

private theorem kl_integrable {X : Type*} [MeasurableSpace X] {μ : Measure X} {p q : X → ℝ} {M : ℝ}
    (pm : Measurable p) (qm : Measurable q) (pi : Integrable p μ) (qi : Integrable q μ)
    (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x) (M1 : 1 ≤ M) (dom : ∀ x, p x ≤ M*q x) :
    Integrable (fun x => klTerm (p x) (q x)) μ := by
  apply (qi.add (pi.mul_const (Real.log M))).mono' (pm.mul (pm.div qm).log).aestronglyMeasurable
  filter_upwards with x
  obtain ⟨low,high⟩ := kl_sandwich (pn x) (qn x) M1 (dom x)
  rw [Real.norm_eq_abs,abs_le]
  change -(q x + p x*Real.log M) ≤ klTerm (p x) (q x) ∧ klTerm (p x) (q x) ≤ q x+p x*Real.log M
  constructor
  · nlinarith only [low,mul_nonneg (pn x) (Real.log_nonneg M1)]
  · linarith [qn x]

private theorem history_hellinger_point {p q a b : ℝ} (pn : 0 ≤ p) (an : 0 ≤ a) (bn : 0 ≤ b)
    (ac : 0 < p → 0 < q) (abc : 0 < p*a → 0 < q*b) :
    p*(Real.sqrt a-Real.sqrt b)^2 ≤ klTerm (p*a) (q*b)-klTerm p q*a-p*a+p*b := by
  rcases eq_or_lt_of_le pn with h|hp
  · simp [← h,klTerm]
  have tn (ha : 0 < a) : 0 < b := (mul_pos_iff_of_pos_left (ac hp)).mp (abc (mul_pos hp ha))
  rw [factor_log p q a b hp.le an ac (fun _ => tn)]
  have hh := hellinger_kl_pointwise a b an bn (fun hb => by
    by_contra! ha
    exact (tn (lt_of_le_of_ne an (Ne.symm ha))).ne' hb)
  unfold klTerm
  nlinarith only [mul_le_mul_of_nonneg_left hh hp.le]

private theorem sqrt_gap_le {a b : ℝ} (an : 0 ≤ a) (bn : 0 ≤ b) :
    (Real.sqrt a - Real.sqrt b)^2 ≤ a + b := by
  nlinarith only [Real.sq_sqrt an,Real.sq_sqrt bn,mul_nonneg (Real.sqrt_nonneg a) (Real.sqrt_nonneg b)]

/-- The actual (real) path KL density integral on a normalized factorized path.
The theorem below uses this branch only when absolute continuity and integrability hold. -/
def historyKL (a b : Predictions Y ν) (t : ℕ) : ℝ :=
  ∫ z, klTerm (historyDensity a t z) (historyDensity b t z) ∂historyBase ν t

def historyRisk (a : Predictions Y ν) (loss : (t : ℕ) → History Y t × Y → ℝ) (t : ℕ) : ℝ :=
  ∫ z, historyDensity a (t+1) z * loss t z ∂historyBase ν (t+1)

/-- Transfer a one-observation Hellinger inequality to a genuine sequence of
history-dependent forecasts on product spaces. The left side always evaluates
the bounded measurable loss on the actually observed history and new observation. -/
theorem history_rank_regret [SFinite ν] (T : ℕ) (R : ℝ) (a b : Predictions Y ν)
    (loss : (t : ℕ) → History Y t × Y → ℝ)
    (meas : ∀ t, Measurable (loss t)) (bound : ∀ t z, |loss t z| ≤ 4*R^2)
    (ac : ∀ t ≤ T, ∀ᵐ z ∂historyBase ν t, 0 < historyDensity a t z → 0 < historyDensity b t z)
    (entropy : ∀ t ≤ T, Integrable
      (fun z => klTerm (historyDensity a t z) (historyDensity b t z)) (historyBase ν t))
    (one : ∀ t < T, ∀ h, 0 < historyDensity a t h →
      (∫ y, (a t).f (h,y)*loss t (h,y) ∂ν) ≤
        16*R^2*∫ y, (Real.sqrt ((a t).f (h,y))-Real.sqrt ((b t).f (h,y)))^2 ∂ν) :
    (∑ t ∈ Finset.range T, historyRisk a loss t) ≤ min (4*R^2*T) (16*R^2*historyKL a b T) := by
  have li (t : ℕ) : Integrable (fun z => historyDensity a (t+1) z * loss t z) (historyBase ν (t+1)) := by
    apply ((history_i a (t+1)).mul_const (4*R^2)).mono' ((history_m a (t+1)).mul (meas t)).aestronglyMeasurable
    filter_upwards with z
    change ‖historyDensity a (t+1) z*loss t z‖ ≤ _
    rw [norm_mul,Real.norm_of_nonneg (history_pos a _ _),Real.norm_eq_abs]
    exact mul_le_mul_of_nonneg_left (bound _ _) (history_pos a _ _)
  apply le_min
  · calc
      _ ≤ ∑ _t ∈ Finset.range T, 4*R^2 := Finset.sum_le_sum (fun t _ => by
        have hi := integral_mono_ae (li t) ((history_i a (t+1)).mul_const (4*R^2)) (Eventually.of_forall
          fun z => mul_le_mul_of_nonneg_left ((le_abs_self _).trans (bound t z)) (history_pos a _ _))
        simpa only [historyRisk,integral_mul_const,history_mass,one_mul] using hi)
      _ = _ := by simp [mul_comm]
  · apply rank_path_increments T R _ (historyKL a b)
    · simp [historyKL,historyDensity,klTerm]
    intro t ht
    let p := historyDensity a t
    let q := historyDensity b t
    let μ := historyBase ν t
    let A := a t
    let B := b t
    let KL := fun x => klTerm (p x) (q x)
    let KL' := fun z : History Y t × Y => klTerm (p z.1*A.f z) (q z.1*B.f z)
    let gapH := fun z : History Y t × Y => (Real.sqrt (A.f z)-Real.sqrt (B.f z))^2
    have ip := history_i a t
    have mp := history_m a t
    have pm (x) : 0 ≤ p x := history_pos a t x
    have i0 : Integrable KL μ := entropy t ht.le
    have i1 : Integrable KL' (μ.prod ν) := entropy (t+1) ht
    have mg : Measurable gapH := (A.measurable.sqrt.sub B.measurable.sqrt).pow_const _
    have iA : Integrable (fun z : History Y t × Y => p z.1 * A.f z) (μ.prod ν) := extend_integrable A mp ip
    have iB : Integrable (fun z : History Y t × Y => p z.1 * B.f z) (μ.prod ν) := extend_integrable B mp ip
    have iG : Integrable (fun z : History Y t × Y => p z.1 * gapH z) (μ.prod ν) := by
      apply (iA.add iB).mono' ((mp.comp measurable_fst).mul mg).aestronglyMeasurable
      filter_upwards with z
      change ‖p z.1*gapH z‖ ≤ p z.1*A.f z + p z.1*B.f z
      rw [Real.norm_of_nonneg (mul_nonneg (pm _) (sq_nonneg _)),← mul_add]
      exact mul_le_mul_of_nonneg_left (sqrt_gap_le (A.nonneg z) (B.nonneg z)) (pm _)
    have lI : Integrable (fun z : History Y t × Y => p z.1*(A.f z*loss t z)) (μ.prod ν) := by
      simpa only [mul_assoc] using (show Integrable (fun z : History Y t × Y => (p z.1*A.f z)*loss t z)
        (μ.prod ν) from li t)
    have ik : Integrable (fun z : History Y t × Y => KL z.1 * A.f z) (μ.prod ν) := extend_integrable A ((history_m a t).mul ((history_m a t).div (history_m b t)).log) i0
    have m : (∫ z, p z.1*gapH z ∂μ.prod ν) ≤
        ∫ z, KL' z-KL z.1*A.f z-p z.1*A.f z+p z.1*B.f z ∂μ.prod ν := by
      apply integral_mono_ae iG (((i1.sub ik).sub iA).add iB)
      have last : ∀ᵐ z : History Y t × Y ∂μ.prod ν, 0 < p z.1*A.f z → 0 < q z.1*B.f z := ac (t+1) ht
      filter_upwards [(Measure.quasiMeasurePreserving_fst (ν := ν)).ae (ac t ht.le),last] with z old now
      exact history_hellinger_point (pm _) (A.nonneg _) (B.nonneg _) old now
    rw [integral_add (f := fun z => KL' z - KL z.1*A.f z-p z.1*A.f z) ((i1.sub ik).sub iA) iB,
      integral_sub (f := fun z => KL' z-KL z.1*A.f z) (i1.sub ik) iA,integral_sub i1 ik,
      integral_prod _ ik,integral_prod _ iA,integral_prod _ iB] at m
    simp only [integral_const_mul,A.mass,B.mass,mul_one] at m
    change (∫ z : History Y t × Y, p z.1*A.f z*loss t z ∂μ.prod ν) ≤ _
    conv_lhs => simp only [mul_assoc]
    rw [integral_prod _ lI]
    have K0 : 0 ≤ 16*R^2 := by positivity
    refine le_trans ?_ (mul_le_mul_of_nonneg_left (show (∫ z, p z.1*gapH z ∂μ.prod ν) ≤
      historyKL a b (t+1)-historyKL a b t from by
        unfold historyKL; change _ ≤ (∫ z, KL' z ∂μ.prod ν) - ∫ x, KL x ∂μ; linarith) K0)
    rw [integral_prod _ iG,← integral_const_mul]
    apply integral_mono_ae lI.integral_prod_left (iG.integral_prod_left.const_mul _)
    filter_upwards with x
    simp only [integral_const_mul]
    by_cases px : p x = 0
    · simp [px]
    · have hh := mul_le_mul_of_nonneg_left (one t ht x (lt_of_le_of_ne (pm _) (Ne.symm px))) (pm x)
      calc
        _ ≤ p x*(16*R^2*(∫ y, gapH (x,y) ∂ν)) := hh
        _ = _ := by ring

private theorem mixture_product (a : J → Predictions Y ν) : ∀ n z,
    historyDensity (listForecast a) n z = listMix a n z
  | 0, _ => avg_one.symm
  | n+1, z => by
    change historyDensity (listForecast a) n z.1 * _ = _
    rw [mixture_product a n z.1]
    exact list_forecast_factor a n z

/-- Finite-list upper bound, simultaneously for every correctly specified candidate.
The predictor is the rank of the Bayesian mixture's next density. Its construction,
absolute continuity, density integrability, entropy chain and path oracle are proved
inside the theorem. The one-observation comparison is the transport input. -/
theorem finite_list_mixture_upper [SFinite ν] (a : J → Predictions Y ν) (T : ℕ) (R : ℝ)
    (loss : J → (t : ℕ) → History Y t × Y → ℝ) (meas : ∀ j t, Measurable (loss j t))
    (bound : ∀ j t z, |loss j t z| ≤ 4*R^2)
    (one : ∀ j t, t < T → ∀ h, 0 < historyDensity (a j) t h →
      (∫ y, (a j t).f (h,y)*loss j t (h,y) ∂ν) ≤ 16*R^2*∫ y,
      (Real.sqrt ((a j t).f (h,y)) - Real.sqrt ((listForecast a t).f (h,y)))^2 ∂ν) :
    ∀ j, (∑ t ∈ Finset.range T, historyRisk (a j) (loss j) t) ≤
      min (4*R^2*T) (16*R^2*Real.log (Fintype.card J)) := by
  intro j
  let b := listForecast a
  let M : ℝ := Fintype.card J
  have m1 : 1 ≤ M := by change (1:ℝ) ≤ Fintype.card J; exact_mod_cast Nat.succ_le_iff.mpr (Fintype.card_pos_iff.mpr ‹Nonempty J›)
  have dom (t z) : historyDensity (a j) t z ≤ M*historyDensity b t z := by
    rw [mixture_product]; exact avg_dom (fun i => history_pos (a i) t z) j
  have ac (t z) (pos : 0 < historyDensity (a j) t z) : 0 < historyDensity b t z := by
    by_contra! hn
    have hz := le_antisymm hn (history_pos b t z)
    have h := dom t z
    rw [hz,mul_zero] at h
    linarith
  have ki (t) := kl_integrable (history_m (a j) t) (history_m b t) (history_i (a j) t) (history_i b t)
    (history_pos (a j) t) (history_pos b t) m1 (dom t)
  have path_bound := history_rank_regret T R (a j) b (loss j) (meas j) (bound j) (fun t _ => .of_forall (ac t))
    (fun t _ => ki t) (one j)
  have hk : historyKL (a j) b T ≤ Real.log M := by
    have hi := integral_mono_ae (ki T) ((history_i (a j) T).mul_const (Real.log M)) (Eventually.of_forall fun z =>
      (kl_sandwich (history_pos (a j) T z) (history_pos b T z) m1 (dom T z)).2)
    simpa only [historyKL,integral_mul_const,history_mass,one_mul] using hi
  exact path_bound.trans (min_le_min_left _ (mul_le_mul_of_nonneg_left hk (by positivity)))
end
end SequentialRanks
