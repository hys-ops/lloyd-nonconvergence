import StretchEndpoint
import Mathlib.MeasureTheory.Function.ContinuousMapDense
import Mathlib.MeasureTheory.Function.L2Space

open MeasureTheory Filter Set
open scoped Topology ENNReal BoundedContinuousFunction InnerProductSpace BigOperators

namespace Vortex
noncomputable section

/-- The quadratic dual test determines the exact energy, even for noncompact
observation space. No dual-representation or semicontinuity premise is used. -/
theorem energy_of_bounded_tests {X F : Type*} [TopologicalSpace X] [NormalSpace X]
    [MeasurableSpace X] [BorelSpace X] [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    {m : Measure X} [m.WeaklyRegular] (f : X → F) (hf : MemLp f 2 m) (C : ℝ)
    (test : ∀ g : X →ᵇ F, (∫ x, 2*⟪f x,g x⟫_ℝ - ‖g x‖^2 ∂m) ≤ C) :
    (∫ x, ‖f x‖^2 ∂m) ≤ C := by
  by_contra! bad
  let ε := ((∫ x, ‖f x‖^2 ∂m)-C)/2
  have hε : 0 < ε := by dsimp [ε]; linarith
  have hf' : MemLp f (ENNReal.ofReal (2:ℝ)) m := by simpa using hf
  obtain ⟨g,near,mg⟩ := hf'.exists_boundedContinuous_integral_rpow_sub_le (p := (2:ℝ))
    (by norm_num) hε
  have mg' : MemLp g 2 m := by simpa using mg
  have small : (∫ x, ‖f x - g x‖^2 ∂m) ≤ ε := by simpa using near
  have a := (memLp_two_iff_integrable_sq_norm hf.aestronglyMeasurable).mp hf
  have b := (memLp_two_iff_integrable_sq_norm (hf.sub mg').aestronglyMeasurable).mp (hf.sub mg')
  have id : (fun x => 2*⟪f x,g x⟫_ℝ - ‖g x‖^2) =
      (fun x => ‖f x‖^2-‖f x-g x‖^2) := by
    funext x; rw [norm_sub_sq_real]; ring
  have t := test g
  change Integrable (fun x => ‖f x - g x‖^2) m at b
  rw [id,integral_sub a b] at t
  dsimp [ε] at small
  linarith

private theorem test_cell_le {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    (A g : F) {s : ℝ} (hs : 0 ≤ s) (empty : s = 0 → A=0) :
    2*⟪A,g⟫_ℝ - s*‖g‖^2 ≤ ‖A‖^2/s := by
  rcases eq_or_lt_of_le hs with h|h
  · simp [←h,empty h.symm]
  · apply (le_div_iff₀ h).mpr
    have pos := sq_nonneg ‖A - s • g‖
    rw [norm_sub_sq_real,real_inner_smul_right,norm_smul,Real.norm_eq_abs,abs_of_pos h] at pos
    nlinarith

/-- Weighted moment energy passes from arbitrary finite atomic arrays to a
density from convergence only against bounded continuous tests. Both the
observation atoms and their weights may change with n. Zero-weight labels
have zero moment and incur zero energy. -/
theorem endpoint_of_atomic_weak_limit {X F : Type*} [TopologicalSpace X] [NormalSpace X]
    [MeasurableSpace X] [BorelSpace X] [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    {m : Measure X} [m.WeaklyRegular] (f : X → F) (hf : MemLp f 2 m)
    (N : ℕ → ℕ) (z : (n : ℕ) → Fin (N n) → X) (s : (n : ℕ) → Fin (N n) → ℝ)
    (A : (n : ℕ) → Fin (N n) → F) (C : ℝ)
    (pos : ∀ n i, 0 ≤ s n i) (empty : ∀ n i, s n i = 0 → A n i = 0)
    (finite : ∀ n, ∑ i, ‖A n i‖^2/s n i ≤ C)
    (moment : ∀ g : X →ᵇ F, Tendsto (fun n => ∑ i, ⟪A n i,g (z n i)⟫_ℝ)
      atTop (𝓝 (∫ x, ⟪f x,g x⟫_ℝ ∂m)))
    (mass : ∀ g : X →ᵇ F, Tendsto (fun n => ∑ i, s n i * ‖g (z n i)‖^2)
      atTop (𝓝 (∫ x, ‖g x‖^2 ∂m)))
    [IsFiniteMeasure m] [SecondCountableTopology F] : (∫ x, ‖f x‖^2 ∂m) ≤ C := by
  apply energy_of_bounded_tests f hf
  intro g
  have mg : MemLp g 2 m := (g.memLp_top (μ := m)).mono_exponent le_top
  have integr : Integrable (fun x => ⟪f x,g x⟫_ℝ) m := by
    apply ((hf.integrable (by norm_num)).norm.mul_const ‖g‖).mono'
      (hf.aestronglyMeasurable.inner mg.aestronglyMeasurable)
    exact .of_forall fun x => (norm_inner_le_norm _ _).trans
      (mul_le_mul_of_nonneg_left (g.norm_coe_le_norm x) (norm_nonneg _))
  rw [integral_sub (integr.const_mul 2)
    ((memLp_two_iff_integrable_sq_norm mg.aestronglyMeasurable).mp mg),integral_const_mul]
  apply le_of_tendsto ((tendsto_const_nhds.mul (moment g)).sub (mass g))
  filter_upwards with n
  change 2*(∑ i, ⟪A n i,g (z n i)⟫_ℝ) - (∑ i, s n i*‖g (z n i)‖^2) ≤ C
  rw [Finset.mul_sum,← Finset.sum_sub_distrib]
  exact (Finset.sum_le_sum (fun i _ => test_cell_le _ _ (pos n i) (empty n i))).trans (finite n)

end
end Vortex
