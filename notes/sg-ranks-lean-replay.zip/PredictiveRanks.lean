import KernelRanks
import Mathlib.Probability.Kernel.WithDensity

open MeasureTheory ProbabilityTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def densityLaw {H Y : Type*} [MeasurableSpace Y] (μ : Measure Y)
    (p : H × Y → ℝ≥0∞) (unit : ∀ h, (∫⁻ y, p (h,y) ∂μ)=1) (h : H) : ProbabilityMeasure Y :=
  ⟨μ.withDensity (fun y => p (h,y)), ⟨by rw [withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ,unit]⟩⟩

def squareCost {d : ℕ} {A B : Set (Fin d → ℝ)} (z : A × B) : ℝ :=
  normSq (diff z.1.1 z.2.1)

/-- Same compact Euclidean supports and squared transport cost as in the public note.
The only transport hypotheses are pointwise static Brenier characterization/uniqueness
and attainment by a measurable map. History-dependent densities need only be jointly
measurable and normalized. -/
theorem rank_selection_for_densities {H : Type*} [MeasurableSpace H] {d : ℕ}
    (A B : Set (Fin d → ℝ)) (ha : IsCompact A) (hb : IsCompact B) [Nonempty B]
    (μ : Measure A) [SFinite μ] (p : H × A → ℝ≥0∞) (hp : Measurable p)
    (unit : ∀ h, (∫⁻ y, p (h,y) ∂μ)=1) (target : ProbabilityMeasure B) (R : ℝ)
    (ball : ∀ k ∈ B, normSq k ≤ R^2)
    (uniquePlan : ∀ h, ∃! π, certifiedPlan (squareCost (A := A) (B := B)) (densityLaw μ p unit h) target π)
    (monge : ∀ h, ∃ f : A → B, Measurable f ∧
      certifiedPlan squareCost (densityLaw μ p unit h) target
        (ProbabilityMeasure.map (densityLaw μ p unit h) (fun y => (y,f y)))) :
    ∃ S : H × A → Fin d → ℝ, Measurable S ∧ (∀ z, normSq (S z) ≤ R^2) ∧
      ∀ h, ∃ π : ProbabilityMeasure (A × B), certifiedPlan squareCost (densityLaw μ p unit h) target π ∧
        ((densityLaw μ p unit h : Measure A).map (fun y => (y,S (h,y)))) =
          (π : Measure (A × B)).map (fun z => (z.1,z.2.1)) := by
  let _ : CompactSpace A := isCompact_iff_compactSpace.mp ha
  let _ : CompactSpace B := isCompact_iff_compactSpace.mp hb
  let P : Kernel H A := (Kernel.const H μ).withDensity (fun h y => p (h,y))
  have eqP (h : H) : P h = (densityLaw μ p unit h : Measure A) := by
    unfold P; rw [Kernel.withDensity_apply _ (show Measurable (Function.uncurry (fun h y => p (h,y))) from hp)]
    rfl
  let _ : IsMarkovKernel P := ⟨fun h => by rw [eqP]; infer_instance⟩
  have same (h : H) : (⟨P h,inferInstance⟩ : ProbabilityMeasure A) = densityLaw μ p unit h :=
    ProbabilityMeasure.toMeasure_injective (eqP h)
  have hc : Continuous (squareCost (A := A) (B := B)) := by
    have a (i : Fin d) : Continuous (fun z : A × B => z.1.1 i) :=
      (continuous_apply i).comp (continuous_subtype_val.comp continuous_fst)
    have b (i : Fin d) : Continuous (fun z : A × B => z.2.1 i) :=
      (continuous_apply i).comp (continuous_subtype_val.comp continuous_snd)
    unfold squareCost normSq diff; fun_prop
  obtain ⟨S,ms,all,hS⟩ := kernel_conditional_ranks P target squareCost hc
    (fun k : B => k.1) measurable_subtype_coe R (fun k => ball k.1 k.2)
    (fun h => by rw [same h]; exact uniquePlan h)
    (fun h => by rw [same h]; exact monge h)
  refine ⟨S,ms,all,fun h => ?_⟩
  obtain ⟨π,cert,graph⟩ := hS h
  exact ⟨π,(same h) ▸ cert,(eqP h) ▸ graph⟩
end
end SequentialRanks
