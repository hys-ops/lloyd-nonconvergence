import SGClosureFlux
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Probability law of a normalized constant patch, with its reference measure explicit. -/
def patchProbability (A : Set Space) (d : ℝ≥0) (unit : (d : ℝ≥0∞)*volume A=1) : ProbabilityMeasure Space :=
  ⟨(d : ℝ≥0∞) • volume.restrict A, ⟨by simpa using unit⟩⟩

def patchNN (A : Set Space) (d : ℝ≥0) : Space → ℝ≥0 := A.indicator fun _ => d

theorem patchNN_measurable (A : Set Space) (m : MeasurableSet A) (d : ℝ≥0) :
    Measurable (patchNN A d) := measurable_const.indicator m

theorem patchNN_toReal (A : Set Space) (d : ℝ≥0) (y : Space) :
    (patchNN A d y : ℝ)=patch A (d:ℝ) y := by
  classical by_cases h : y ∈ A <;> simp [h,patchNN,patch,indicator]

theorem patchProbability_density (A : Set Space) (m : MeasurableSet A) (d : ℝ≥0)
    (unit : (d : ℝ≥0∞)*volume A=1) : (patchProbability A d unit : Measure Space) =
      volume.withDensity fun y => (patchNN A d y : ℝ≥0∞) := by
  have eq : (fun y => (patchNN A d y : ℝ≥0∞)) = A.indicator (fun _ => (d : ℝ≥0∞)) := by
    funext y; classical by_cases hy : y∈A <;> simp [patchNN,hy,indicator]
  rw [eq,withDensity_indicator m,withDensity_const]
  rfl

theorem raw_push_of_probability (A : Set Space) (d : ℝ≥0) (hd : 0<d)
    (unit : (d : ℝ≥0∞)*volume A=1) (target : Measure Space)
    (S : Space → Space) (ms : Measurable S) (law : (patchProbability A d unit : Measure Space).map S=target) :
    (volume.restrict A).map S = (d : ℝ≥0∞)⁻¹ • target := by
  change ((d : ℝ≥0∞) • volume.restrict A).map S=target at law
  rw [Measure.map_smul _ ms.aemeasurable] at law
  rw [← law,smul_smul,ENNReal.inv_mul_cancel (by exact_mod_cast hd.ne') ENNReal.coe_ne_top,one_smul]

theorem finite_of_patch_mass (A : Set Space) (d : ℝ≥0) (hd : 0<d)
    (unit : (d : ℝ≥0∞)*volume A=1) : volume A≠⊤ := by
  intro h
  have h0 : (d : ℝ≥0∞) ≠ 0 := by exact_mod_cast hd.ne'
  simp [h,ENNReal.mul_top h0] at unit
end
end Vortex
