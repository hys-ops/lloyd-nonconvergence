import MinimaxUpperSelection
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

/-- A list of M sequential forecasting laws and their observation-wise true ranks.
The estimator receives the whole catalog, then observes the past and current datum. -/
structure RankCatalog (Y : Type*) [MeasurableSpace Y] (ν : Measure Y) (d M : ℕ) where
  forecast : Fin M → Predictions Y ν
  rank : Fin M → (t : ℕ) → History Y t × Y → Fin d → ℝ

def pathMeasure {Y : Type*} [MeasurableSpace Y] {ν : Measure Y}
    (a : Predictions Y ν) (n : ℕ) : Measure (History Y n) :=
  weighted (historyBase ν n) (historyDensity a n)

instance pathMeasureProb {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (a : Predictions Y ν) (n : ℕ) : IsProbabilityMeasure (pathMeasure a n) := by
  obtain ⟨_,pos,hi,mass⟩ := history_is_density a n
  constructor
  rw [pathMeasure,weighted,withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ,
    ←ofReal_integral_eq_lintegral_ofReal hi (.of_forall pos),mass,ENNReal.ofReal_one]

abbrev CatalogPolicy (Y : Type*) [MeasurableSpace Y] (d : ℕ) :=
  {a : (n : ℕ) → History Y n × Y → Fin d → ℝ // ∀ n, Measurable (a n)}

/-- Cumulative expected squared error of policy e at member j; +∞ is allowed. -/
def catalogRisk {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} {d M : ℕ}
    (C : RankCatalog Y ν d M) (e : CatalogPolicy Y d) (T : ℕ) (j : Fin M) :=
  ∑ t ∈ Finset.range T, ∫⁻ z,ENNReal.ofReal (normSq (diff (C.rank j t z) (e.val t z))) ∂pathMeasure (C.forecast j) (t+1)

/-- The catalog is presented before the policy is selected. -/
def catalogMinimax {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} {d M : ℕ}
    (C : RankCatalog Y ν d M) (T : ℕ) : ℝ≥0∞ :=
  ⨅ e : CatalogPolicy Y d, ⨆ j : Fin M,catalogRisk C e T j

private theorem risk_eq_real {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν] {d M : ℕ}
    (C : RankCatalog Y ν d M) (e : CatalogPolicy Y d) (T : ℕ) (j : Fin M) (R : ℝ)
    (mR : ∀ t, Measurable (C.rank j t)) (bR : ∀ t z,normSq (C.rank j t z)≤R^2)
    (bE : ∀ t z,normSq (e.val t z) ≤ R^2) :
    catalogRisk C e T j= ENNReal.ofReal (∑ t ∈ Finset.range T,
      historyRisk (C.forecast j) (fun n z => normSq (diff (C.rank j n z) (e.val n z))) t) := by
  let L (n : ℕ) (z : History Y n × Y) := normSq (diff (C.rank j n z) (e.val n z))
  have nn n (z : History Y n × Y) : 0 ≤ L n z := Finset.sum_nonneg (fun i _ =>sq_nonneg _)
  have m n : Measurable (L n) := by
    unfold L normSq diff
    apply Finset.measurable_sum
    intro i _
    exact (((measurable_pi_apply i).comp (mR n)).sub ((measurable_pi_apply i).comp (e.property n))).pow_const 2
  have point n : (∫⁻ z,ENNReal.ofReal (L n z) ∂pathMeasure (C.forecast j) (n+1)) =
      ENNReal.ofReal (historyRisk (C.forecast j) L n) := by
    obtain ⟨md,nd,id,_⟩ := history_is_density (C.forecast j) (n+1)
    let p : History Y n × Y → ℝ := historyDensity (C.forecast j) (n+1)
    have ip : Integrable (fun z => p z*L n z) (historyBase ν (n+1)) := by
      apply (id.mul_const (4*R^2)).mono' (md.mul (m n)).aestronglyMeasurable
      filter_upwards with z
      change |p z*L n z| ≤ _
      rw [abs_mul,abs_of_nonneg (nd z)]
      exact mul_le_mul_of_nonneg_left (bounded_rank_distance (bR n z) (bE n z)) (nd z)
    change (∫⁻ z, ENNReal.ofReal (L n z) ∂(historyBase ν (n+1)).withDensity (fun z => ENNReal.ofReal (p z))) =
      ENNReal.ofReal (∫ z,p z*L n z ∂historyBase ν (n+1))
    rw [lintegral_withDensity_eq_lintegral_mul _ md.ennreal_ofReal (m n).ennreal_ofReal]
    have conv := ofReal_integral_eq_lintegral_ofReal ip (.of_forall fun z => mul_nonneg (nd z) (nn n z))
    exact (lintegral_congr (μ := historyBase ν (n+1)) (fun z => (ENNReal.ofReal_mul (nd z) (q := L n z)).symm)).trans conv.symm
  unfold catalogRisk
  change (∑ n ∈ Finset.range T, ∫⁻ z,ENNReal.ofReal (L n z) ∂pathMeasure (C.forecast j) (n+1))=_
  simp_rw [point]
  symm
  apply ENNReal.ofReal_sum_of_nonneg
  intro n _
  exact integral_nonneg fun z => mul_nonneg ((history_is_density (C.forecast j) (n+1)).2.1 z) (nn n z)

/-- For any given bounded certified versions of the catalog's true ranks, the
single mixture-rank policy attains the public finite-list bound. -/
theorem catalog_minimax_upper {d M : ℕ} [Nonempty (Fin M)] (A B : Set (RankPoint d))
    (ha : IsCompact A) (hb : IsCompact B) [Nonempty B] (ν : Measure A) [SFinite ν]
    (target : ProbabilityMeasure B) (R : ℝ) (ball : ∀ k ∈ B,normSq k≤R^2)
    (C : RankCatalog A ν d M) (T : ℕ) (base : ν.map Subtype.val ≪ volume)
    (mr : ∀ j t, Measurable (C.rank j t)) (br : ∀ j t z,normSq (C.rank j t z) ≤ R^2)
    (cert : ∀ j t h,CertifiedRank ((C.forecast j t).law h) target (fun y => C.rank j t (h,y)))
    (midpoint : ∀ j t, t<T → ∀ h,0<historyDensity (C.forecast j) t h →
      ∀ v : A → RankPoint d, Measurable v → CertifiedRank ((listForecast C.forecast t).law h) target v →
      (weighted ν (fun y => Real.sqrt ((C.forecast j t).f (h,y))*Real.sqrt ((listForecast C.forecast t).f (h,y)))).map
        (fun y => mid (C.rank j t (h,y)) (v y)) ≤ (target : Measure B).map Subtype.val) :
    ∃ e : CatalogPolicy A d,
      (∀ t h,CertifiedRank ((listForecast C.forecast t).law h) target (fun y => e.val t (h,y))) ∧
      (∀ j,catalogRisk C e T j ≤ ENNReal.ofReal (min (4*R^2*T) (16*R^2*Real.log M))) ∧
      catalogMinimax C T ≤ ENNReal.ofReal (min (4*R^2*T) (16*R^2*Real.log M)) := by
  choose V mV bV cV using fun t => forecast_rank_selector A B ha hb ν target R ball (listForecast C.forecast t) base
  let ρ := (target : Measure B).map Subtype.val
  have : IsProbabilityMeasure ρ := by dsimp [ρ]; infer_instance
  have rb : ∀ᵐ y ∂ρ, normSq y ≤ R^2 := by
    apply (ae_map_iff measurable_subtype_coe.aemeasurable (measurableSet_le (by unfold normSq; fun_prop) measurable_const)).2
    exact .of_forall (fun k => ball k.val k.property)
  have source t (h : History A t) : Measurable (fun y : A => (h,y)) := measurable_const.prodMk measurable_id
  have he := finite_list_rank_upper C.forecast T d R ρ rb C.rank V mr mV br bV
    (fun j t h => certified_rank_endpoint ((mr j t).comp (source t h)) (cert j t h))
    (fun t h => certified_rank_endpoint ((mV t).comp (source t h)) (cV t h))
    (fun j t ht h ph => midpoint j t ht h ph _ ((mV t).comp (source t h)) (cV t h))
  let e : CatalogPolicy A d := ⟨V,mV⟩
  have bnd (j) := (risk_eq_real C e T j R (mr j) (br j) bV).le.trans (ENNReal.ofReal_le_ofReal (he j))
  simp only [Fintype.card_fin] at bnd
  exact ⟨e,cV,bnd,iInf_le_of_le e (iSup_le bnd)⟩
end
end SequentialRanks
