import RankExamples
import Mathlib.MeasureTheory.Integral.Prod
open Set MeasureTheory
namespace SequentialRanks
noncomputable section
def S2 (x : ℝ) := Real.sin (Real.pi*x)^2
def C2 (x : ℝ) := Real.cos (Real.pi*x)^2
def speed (z : ℝ × ℝ) := (1/Real.pi^2)*(S2 z.1*C2 z.2+C2 z.1*S2 z.2)
def perturb (z : ℝ × ℝ) : ℝ × ℝ :=
  (-Real.sin (Real.pi*z.1)*Real.cos (Real.pi*z.2)/Real.pi,
   -Real.cos (Real.pi*z.1)*Real.sin (Real.pi*z.2)/Real.pi)
theorem speed_id (z : ℝ × ℝ) : (perturb z).1^2+(perturb z).2^2 = speed z := by
  dsimp [perturb,speed,S2,C2]; ring
private theorem sin_mean : (∫ x in Icc (0:ℝ) 1, S2 x) = 1/2 := by
  rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le (by norm_num)]
  unfold S2
  rw [intervalIntegral.integral_comp_mul_left (fun t => Real.sin t ^ 2) Real.pi_ne_zero]
  simp [integral_sin_sq,smul_eq_mul]; field_simp
private theorem cos_mean : (∫ x in Icc (0:ℝ) 1, C2 x) = 1/2 := by
  rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le (by norm_num)]
  unfold C2
  rw [intervalIntegral.integral_comp_mul_left (fun t => Real.cos t ^ 2) Real.pi_ne_zero]
  simp [integral_cos_sq,smul_eq_mul]; field_simp

/-- Actual planar Lebesgue integral of the displacement energy. -/
theorem square_energy :
    (∫ z in (Icc (0:ℝ) 1) ×ˢ (Icc (0:ℝ) 1), speed z) = 1/(2*Real.pi^2) := by
  let I := Icc (0:ℝ) 1
  let μ := (volume : Measure ℝ).restrict I
  have hs : Integrable S2 μ := (show Continuous S2 by unfold S2; fun_prop).continuousOn.integrableOn_Icc
  have hc : Integrable C2 μ := (show Continuous C2 by unfold C2; fun_prop).continuousOn.integrableOn_Icc
  have h1 : Integrable (fun z : ℝ × ℝ => S2 z.1*C2 z.2) (μ.prod μ) := hs.mul_prod hc
  have h2 : Integrable (fun z : ℝ × ℝ => C2 z.1*S2 z.2) (μ.prod μ) := hc.mul_prod hs
  change (∫ z in I ×ˢ I, speed z) = _
  rw [Measure.volume_eq_prod ℝ ℝ, ← Measure.prod_restrict]
  unfold speed
  rw [integral_const_mul,integral_add h1 h2,integral_prod_mul,integral_prod_mul]
  change (1/Real.pi^2)*((∫ x in I, S2 x)*(∫ x in I, C2 x)+(∫ x in I, C2 x)*(∫ x in I, S2 x)) = _
  dsimp [I]; rw [sin_mean,cos_mean]; ring

theorem density_floor (θ c₁ c₂ : ℝ) (ht : |θ| ≤ 1/2) (hc₁ : |c₁| ≤ 1) (hc₂ : |c₂| ≤ 1) :
    1/4 ≤ (1-θ*c₁)*(1-θ*c₂) := by
  have aux (c : ℝ) (hc : |c| ≤ 1) : 1/2 ≤ 1-θ*c := by
    have h := mul_le_mul ht hc (abs_nonneg c) (by norm_num)
    rw [← abs_mul] at h
    linarith [le_abs_self (θ*c)]
  have ha := aux _ hc₁
  have hb := aux _ hc₂
  nlinarith [mul_nonneg (sub_nonneg.mpr ha) (sub_nonneg.mpr hb)]
theorem actual_density_floor (θ x y : ℝ) (ht : |θ| ≤ 1/2) :
    1/4 ≤ (1-θ*Real.cos (Real.pi*(x+y)))*(1-θ*Real.cos (Real.pi*(x-y))) :=
  density_floor _ _ _ ht (Real.abs_cos_le_one _) (Real.abs_cos_le_one _)
end
end SequentialRanks
