import StaticRankGeometry
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.Deriv.AffineMap
import Mathlib.Analysis.Calculus.LocalExtr.Basic

open MeasureTheory Set
open scoped Topology BigOperators
namespace SequentialRanks
noncomputable section

/-- Coordinate representation of the Euclidean covector with gradient u. -/
def rankCovector {d : ℕ} (u : RankPoint d) : RankPoint d →L[ℝ] ℝ :=
  ∑ i, (u i) • ContinuousLinearMap.proj (R := ℝ) i

private theorem cvadd {d : ℕ} (u v : RankPoint d) :
    rankCovector (u+v) = rankCovector u+rankCovector v := by
  unfold rankCovector; simp [add_smul,Finset.sum_add_distrib]

theorem rank_covector_injective {d : ℕ} : Function.Injective (@rankCovector d) := by
  intro u v e
  funext i
  have ev := DFunLike.congr_fun e (Pi.single i (1:ℝ))
  simpa [rankCovector,sum_apply,Pi.single_apply] using ev

theorem rank_convex_support {d : ℕ} {f : RankPoint d → ℝ} (conv : ConvexOn ℝ univ f)
    {x : RankPoint d} {L : RankPoint d →L[ℝ] ℝ} (der : HasFDerivAt f L x) (y : RankPoint d) :
    L (y-x) ≤ f y - f x := by
  let l := AffineMap.lineMap (k := ℝ) x y
  have df : HasFDerivAt f L (l 0) := by simpa [l] using der
  have dl : HasDerivAt l (y-x) 0 := AffineMap.hasDerivAt_lineMap ..
  have dc : HasDerivAt (f ∘ l) (L (y-x)) 0 := df.comp_hasDerivAt 0 dl
  have hc := conv.comp_affineMap l
  have hs := hc.le_slope_of_hasDerivAt (x := 0) (y := 1) (by simp) (by simp) zero_lt_one dc
  simpa [slope_def_field,l,Function.comp_def] using hs

/-- Two convex gradient maps, differentiable as potentials on the common good
set, have an injective midpoint there if one endpoint is injective. -/
theorem midpoint_injective_of_convex_gradients {d : ℕ}
    (f g : RankPoint d → ℝ) (U V : RankPoint d → RankPoint d) (G : Set (RankPoint d))
    (cf : ConvexOn ℝ univ f) (cg : ConvexOn ℝ univ g)
    (df : ∀ x ∈ G, HasFDerivAt f (rankCovector (U x)) x)
    (dg : ∀ x ∈ G, HasFDerivAt g (rankCovector (V x)) x)
    (iu : InjOn U G) : InjOn (fun x => mid (U x) (V x)) G := by
  intro x hx y hy e
  have uv : U x+V x=U y+V y := by
    funext i
    have h := congrFun e i
    change (U x i + V x i)/2 = (U y i + V y i)/2 at h
    change U x i+V x i=U y i+V y i
    linarith
  have addEq := congrArg (fun u => rankCovector u (y-x)) uv
  simp only [cvadd,add_apply] at addEq
  have ax := rank_convex_support cf (df x hx) y
  have bx := rank_convex_support cg (dg x hx) y
  have ay := rank_convex_support cf (df y hy) x
  have byy := rank_convex_support cg (dg y hy) x
  simp only [map_sub] at ax bx ay byy addEq
  have mn : IsLocalMin (fun z => f z - rankCovector (U x) z) y := by
    apply Filter.Eventually.of_forall
    intro z
    have az := rank_convex_support cf (df x hx) z
    rw [map_sub] at az
    change f y - _ ≤ f z - _
    linarith
  have same := mn.hasFDerivAt_eq_zero ((df y hy).sub (rankCovector (U x)).hasFDerivAt)
  exact iu hx hy (rank_covector_injective (sub_eq_zero.mp same).symm)

end
end SequentialRanks
