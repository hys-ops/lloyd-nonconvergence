#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export LEAN_NUM_THREADS="${LEAN_NUM_THREADS:-2}"
if [[ ${SKIP_DEP_CACHE:-0} != 1 ]]; then
  mapfile -t imports < <(sed -n 's/^import \(Mathlib\..*\)$/\1/p' ./*.lean | sort -u)
  lake exe cache get "${imports[@]}"
fi
python3 verify_release.py
