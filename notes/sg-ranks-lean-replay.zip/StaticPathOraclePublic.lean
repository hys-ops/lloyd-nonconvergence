import StaticPathOracleMixture

open MeasureTheory InformationTheory Filter Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The rank estimator of an arbitrary candidate path law is selected independently
of the truth and time horizon. Both rank processes are jointly measurable in the
history and observation. Their cumulative risk obeys the extended path KL bound. -/
theorem public_path_estimator {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2) (b : Predictions A (compactObservationVolume A ha)) :
    let target := densityReference B hb w sw
    ∃ V : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((b t).law h) target (fun y => V t (h,y))) ∧
      ∀ a : Predictions A (compactObservationVolume A ha),
        ∃ U : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (U t)) ∧
          (∀ t h, CertifiedRank ((a t).law h) target (fun y => U t (h,y))) ∧ ∀ T,
          ENNReal.ofReal (∑ t ∈ Finset.range T, historyRisk a (fun n z => normSq (diff (U n z) (V n z))) t) ≤
            ENNReal.ofReal (16*R^2) * klDiv (pathLaw a T) (pathLaw b T) := by
  let target := densityReference B hb w sw
  let _ : Nonempty B := nonempty_of_isProbabilityMeasure (target : Measure B)
  let ν := compactObservationVolume A ha
  have base : ν.map Subtype.val = volume.restrict A := map_comap_subtype_coe ha.isClosed.measurableSet _
  have ac : ν.map Subtype.val ≪ volume := base ▸ Measure.restrict_le_self.absolutelyContinuous
  let ρ := (target : Measure B).map Subtype.val
  have prob : IsProbabilityMeasure ρ := by dsimp [ρ]; infer_instance
  have rb : ∀ᵐ y ∂ρ, normSq y ≤ R^2 := by
    apply (ae_map_iff measurable_subtype_coe.aemeasurable
      (measurableSet_le (by unfold normSq; fun_prop) measurable_const)).2
    exact .of_forall (fun k => ball k.val k.property)
  choose V mv vb cv using (fun t => forecast_rank_selector A B ha hb ν target R ball (b t) ac)
  refine ⟨V,mv,cv,?_⟩
  intro a
  choose U mu ub cu using (fun t => forecast_rank_selector A B ha hb ν target R ball (a t) ac)
  refine ⟨U,mu,cu,?_⟩
  intro T
  apply path_rank_kl
  · intro t
    unfold normSq diff
    fun_prop
  · intro t z
    exact bounded_rank_distance (ub _ _) (vb _ _)
  intro t _ h _
  have slice : Measurable (fun y : A => (h,y)) := measurable_const.prodMk measurable_id
  exact one_step_from_geometry ν ρ R _ _ ((a t).measurable.comp slice) ((b t).measurable.comp slice)
    (fun _ => (a t).nonneg _) (fun _ => (b t).nonneg _) ((a t).integrable _) ((b t).integrable _)
    _ _ ((mu t).comp slice) ((mv t).comp slice) (fun _ => ub t _) (fun _ => vb t _) rb
    (certified_rank_endpoint ((mu t).comp slice) (cu t h)) (certified_rank_endpoint ((mv t).comp slice) (cv t h))
    (subtype_rank_midpoint A B ha hb ν base target w wn conc (densityReference_law B hb w sw)
      (a t) (b t) h h _ _ ((mu t).comp slice) ((mv t).comp slice) (cu t h) (cv t h))

/-- One Bayesian mixture estimator works for every possibly misspecified truth, every
horizon, and simultaneously every listed comparator with its own log prior penalty. -/
theorem misspecified_public_estimator {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {J : Type*} [Fintype J] [Nonempty J] (π : J → ℝ) (pp : ∀ j, 0 < π j) (mass : ∑ j, π j = 1)
    (models : J → Predictions A (compactObservationVolume A ha)) :
    let target := densityReference B hb w sw
    let b := weightedPathForecast π pp models (Classical.choice ‹Nonempty J›)
    ∃ V : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((b t).law h) target (fun y => V t (h,y))) ∧
      ∀ a : Predictions A (compactObservationVolume A ha),
        ∃ U : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (U t)) ∧
          (∀ t h, CertifiedRank ((a t).law h) target (fun y => U t (h,y))) ∧ ∀ T j,
          ENNReal.ofReal (∑ t ∈ Finset.range T, historyRisk a (fun n z => normSq (diff (U n z) (V n z))) t) ≤
            ENNReal.ofReal (16*R^2) * (klDiv (pathLaw a T) (pathLaw (models j) T) + ENNReal.ofReal (Real.log (1/π j))) := by
  let fallback := Classical.choice ‹Nonempty J›
  obtain ⟨V,mv,cv,comp⟩ := public_path_estimator A B ha hb w sw wn conc R ball (weightedPathForecast π pp models fallback)
  refine ⟨V,mv,cv,?_⟩
  intro a
  obtain ⟨U,mu,cu,loss⟩ := comp a
  exact ⟨U,mu,cu,fun T j => (loss T).trans (mul_le_mul_right (misspecified_path_kl π pp mass models fallback a T j) _)⟩

end
end SequentialRanks
