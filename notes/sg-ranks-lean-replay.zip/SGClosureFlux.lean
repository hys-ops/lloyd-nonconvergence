import SGClosureIntegrals

open MeasureTheory Set Filter
open scoped ENNReal
namespace Vortex
noncomputable section

private def henergy (u : H) : ℝ := u.1^2+u.2^2

private theorem horizontal_budget {R : ℝ} {u : H} (hi : ‖u‖ ≤ R) : henergy u ≤ 2*R^2 := by
  have l := (norm_fst_le u).trans hi
  have r := (norm_snd_le u).trans hi
  have h1 := pow_le_pow_left₀ (norm_nonneg u.1) l 2
  have h2 := pow_le_pow_left₀ (norm_nonneg u.2) r 2
  rw [Real.norm_eq_abs,sq_abs] at h1 h2
  unfold henergy; linarith

private theorem flux_between (p q : ℝ) (u v : H) (hp : 0≤p) (hq : 0≤q) :
    0 ≤ flux p q u v ∧ flux p q u v ≤ p*henergy u+q*henergy v := by
  constructor
  · unfold flux; positivity
  · by_cases h : p+q=0
    · have a : p=0 := by linarith
      have b : q=0 := by linarith
      simp [a,b,flux]
    · unfold flux henergy; apply (div_le_iff₀ (lt_of_le_of_ne (add_nonneg hp hq) (Ne.symm h))).mpr
      nlinarith only [mul_nonneg (mul_nonneg hp hq) (sq_nonneg (u.1+v.1)),
        mul_nonneg (mul_nonneg hp hq) (sq_nonneg (u.2+v.2))]

/-- The two integrability requirements in the overlap restriction follow from the
marginal's horizontal radius on each map's own source. No value off that source is bounded. -/
theorem patch_flux_integrals (E B : Set Space) (me : MeasurableSet E) (mb : MeasurableSet B)
    (fe : volume E ≠ ⊤) (fb : volume B ≠ ⊤) (ρ R : ℝ) (hρ : 0 < ρ)
    (U V : Space → H) (mu : Measurable U) (mv : Measurable V)
    (bu : ∀ᵐ y ∂volume.restrict E, ‖U y‖ ≤ R) (bv : ∀ᵐ y ∂volume.restrict B, ‖V y‖ ≤ R) :
    Integrable (overlap E B ρ Prod.fst U V) ∧
      Integrable (fun y => flux (patch E ρ y) (patch B ρ y) (U y) (V y)) := by
  classical
  let p := patch E ρ
  let q := patch B ρ
  have mp : Measurable p := (measurable_const.indicator me : Measurable (E.indicator fun _ => ρ))
  have mq : Measurable q := (measurable_const.indicator mb : Measurable (B.indicator fun _ => ρ))
  have ip : Integrable p := (integrable_indicator_iff me).mpr (integrableOn_const (C := ρ) fe)
  have iq : Integrable q := (integrable_indicator_iff mb).mpr (integrableOn_const (C := ρ) fb)
  have p0 (y : Space) : 0 ≤ p y := by by_cases h : y∈E <;> simp [p,patch,h,hρ.le]
  have q0 (y : Space) : 0 ≤ q y := by by_cases h : y∈B <;> simp [q,patch,h,hρ.le]
  have fI : Integrable (fun y => flux (p y) (q y) (U y) (V y)) := by
    apply ((ip.add iq).mul_const (2*R^2)).mono' (by apply Measurable.aestronglyMeasurable; unfold flux; fun_prop)
    filter_upwards [(ae_restrict_iff' me).mp bu,(ae_restrict_iff' mb).mp bv] with y hu hv
    have hi := flux_between (p y) (q y) (U y) (V y) (p0 y) (q0 y)
    rw [Real.norm_eq_abs,abs_of_nonneg hi.1]
    have each (A : Set Space) (Z : Space → H) (b : y∈A → ‖Z y‖≤R) :
        patch A ρ y*henergy (Z y) ≤ patch A ρ y*(2*R^2) := by
      by_cases h : y∈A
      · simp only [patch,h,ite_true]
        exact mul_le_mul_of_nonneg_left (horizontal_budget (b h)) hρ.le
      · simp [patch,h]
    apply hi.2.trans
    change p y*henergy (U y)+q y*henergy (V y) ≤ (p y+q y)*(2*R^2)
    rw [add_mul]
    exact add_le_add (each E U hu) (each B V hv)
  refine ⟨?_,fI⟩
  apply (fI.const_mul 2).mono'
  · have z : Measurable (fun y => ρ*distSq (vel y.1 (U y)) (vel y.1 (V y))) := by
      unfold distSq vel; fun_prop
    have hz : overlap E B ρ Prod.fst U V = (E∩B).indicator
        (fun y => ρ*distSq (vel y.1 (U y)) (vel y.1 (V y))) := by
      funext y; by_cases h : y ∈ E∩B <;> simp [overlap,h,indicator]
    rw [hz]
    exact (z.indicator (me.inter mb)).aestronglyMeasurable
  · filter_upwards with y
    have hpos : 0 ≤ overlap E B ρ Prod.fst U V y := by
      by_cases h : y ∈ E∩B <;> simp [overlap,h,distSq] ; positivity
    rw [Real.norm_eq_abs,abs_of_nonneg hpos]
    exact overlap_pointwise E B ρ hρ Prod.fst U V y

/-- Transfer a radius bound from the common reference law to the actual transport map. -/
theorem horizontal_support_of_transport (ν target : Measure Space) (S : Space → Space)
    (R : ℝ) (ms : Measurable S) (law : ν.map S = target)
    (radius : ∀ᵐ x ∂target, ‖x.1‖ ≤ R) :
    ∀ᵐ y ∂ν, ‖(S y).1‖ ≤ R := by
  apply (ae_map_iff ms.aemeasurable (measurableSet_le measurable_fst.norm measurable_const)).mp
  rwa [law]
end
end Vortex
