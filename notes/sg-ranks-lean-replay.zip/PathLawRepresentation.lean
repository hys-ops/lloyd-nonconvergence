import PathLawDensity
import StaticPathOracle

open MeasureTheory Filter Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

private theorem finite_history_base {Y : Type*} [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] (n : ℕ) : IsFiniteMeasure (historyBase ν n) := by
  induction n with
  | zero => change IsFiniteMeasure (@Measure.dirac PUnit ⊤ PUnit.unit); infer_instance
  | succ n ih => change IsFiniteMeasure ((historyBase ν n).prod ν); infer_instance

/-- Removing the last k observations from a chronological history of length n+k. -/
def historyPrefix {Y : Type*} (n : ℕ) : (k : ℕ) → History Y (n+k) → History Y n
  | 0 => id
  | k+1 => historyPrefix n k ∘ Prod.fst

theorem historyPrefix_measurable {Y : Type*} [MeasurableSpace Y] (n k : ℕ) :
    Measurable (historyPrefix (Y := Y) n k) := by
  induction k with
  | zero => exact measurable_id
  | succ k ih => exact ih.comp measurable_fst

/-- The law on every prefix is the marginal of the law on the full path. -/
theorem pathMeasure_prefix {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (a : Predictions Y ν) (n k : ℕ) :
    (pathMeasure a (n+k)).map (historyPrefix n k) = pathMeasure a n := by
  induction k with
  | zero => exact Measure.map_id
  | succ k ih =>
    change (pathMeasure a ((n+k)+1)).map (historyPrefix n k ∘ Prod.fst) = _
    refine (Measure.map_map (μ := (pathMeasure a ((n+k)+1) : Measure (History Y (n+k) × Y)))
      (historyPrefix_measurable n k) measurable_fst).symm.trans ?_
    exact (congrArg (fun m : Measure (History Y (n+k)) => m.map (historyPrefix n k))
      (pathLaw_fst a (n+k))).trans ih

/-- Any probability law absolutely continuous with respect to product reference measure
has a version of its one-step densities normalized at every history. -/
theorem exists_predictions_path_law {Y : Type*} [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] [NeZero ν] (T : ℕ)
    (P : Measure (History Y T)) [IsProbabilityMeasure P] (ac : P ≪ historyBase ν T) :
    ∃ a : Predictions Y ν, pathMeasure a T = P := by
  let μ := historyBase ν T
  have : IsFiniteMeasure μ := finite_history_base ν T
  let p := fun z => (P.rnDeriv μ z).toReal
  have mp : Measurable p := (Measure.measurable_rnDeriv P μ).ennreal_toReal
  have ip : Integrable p μ := integrable_toReal_of_lintegral_ne_top
    (Measure.measurable_rnDeriv P μ).aemeasurable (Measure.lintegral_rnDeriv_lt_top P μ).ne
  have mass : (∫ z, p z ∂μ) = 1 := (Measure.integral_toReal_rnDeriv (show P ≪ μ from ac)).trans (by simp)
  obtain ⟨a,ha⟩ := exists_predictions_joint_density ν T p mp (fun _ => ENNReal.toReal_nonneg) ip mass
  refine ⟨a, (withDensity_congr_ae (μ := μ) ?_).trans (Measure.withDensity_rnDeriv_eq P μ ac)⟩
  filter_upwards [ha, Measure.rnDeriv_lt_top P μ] with z h hz
  rw [h]; exact ENNReal.ofReal_toReal hz.ne

/-- For a positive horizon, the existence of an absolutely continuous probability
already implies that the observation reference measure is nonzero. -/
theorem nonzero_of_ac_path_succ {Y : Type*} [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] (T : ℕ)
    (P : Measure (History Y (T+1))) [IsProbabilityMeasure P] (ac : P ≪ historyBase ν (T+1)) :
    NeZero ν := by
  refine ⟨fun eq => ?_⟩
  have base : historyBase ν (T+1) = 0 := by
    change (historyBase ν T).prod ν = 0
    rw [eq,Measure.prod_zero]
  have hz : P univ = 0 := ac (by rw [base]; rfl)
  simp at hz

/-- The positive-horizon representation without a separate nonzero-volume premise. -/
theorem exists_predictions_path_law_succ {Y : Type*} [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] (T : ℕ)
    (P : Measure (History Y (T+1))) [IsProbabilityMeasure P] (ac : P ≪ historyBase ν (T+1)) :
    ∃ a : Predictions Y ν, pathMeasure a (T+1) = P := by
  have := nonzero_of_ac_path_succ ν T P ac
  exact exists_predictions_path_law ν (T+1) P ac

end
end SequentialRanks
