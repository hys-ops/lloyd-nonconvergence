import WeakTimeRenormalized

open MeasureTheory Set Filter
open scoped ENNReal NNReal Topology
namespace Vortex
noncomputable section

/-- Tonelli for a nonnegative observable on the actual moving spacetime patch.
Joint measurability is only needed relative to its occupation measure. -/
theorem occupation_lintegral (E : ℝ → Set Space) (T : ℝ)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) (f : SpaceTime → ℝ≥0∞)
    (hf : AEMeasurable f (occupation E T)) :
    (∫⁻ s,f s ∂occupation E T) = ∫⁻ t in Icc 0 T, ∫⁻ y in E t,f (t,y) := by
  let A := {s : SpaceTime | s.1 ∈ Icc 0 T ∧ s.2 ∈ E s.1}
  have ha : MeasurableSet A := (measurable_fst measurableSet_Icc).inter moving
  have hp : AEMeasurable (A.indicator f) ((volume : Measure ℝ).prod (volume : Measure Space)) :=
    (aemeasurable_indicator_iff ha).mpr hf
  change (∫⁻ s in A,f s) = _
  rw [←lintegral_indicator ha,Measure.volume_eq_prod ℝ Space,lintegral_prod _ hp,
    ←lintegral_indicator measurableSet_Icc]
  apply lintegral_congr
  intro t
  by_cases ht : t ∈ Icc 0 T
  · rw [indicator_of_mem ht, ←lintegral_indicator
      (show MeasurableSet (E t) from moving.preimage (measurable_const.prodMk measurable_id))]
    apply lintegral_congr
    intro y
    by_cases hy : y ∈ E t <;> simp [A,ht.1,ht.2,hy]
  · rw [indicator_of_notMem ht]
    have eqn (y : Space) : A.indicator f (t,y) = 0 :=
      indicator_of_notMem (fun h => ht h.1) _
    simp [eqn]

theorem occupation_uniform_bound (E : ℝ → Set Space) (T : ℝ)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) (f : SpaceTime → ℝ≥0∞)
    (hf : AEMeasurable f (occupation E T)) (B : ℝ≥0∞) (hB : B ≠ ⊤)
    (bound : ∀ᵐ t ∂volume.restrict (Icc 0 T), (∫⁻ y in E t,f (t,y)) ≤ B) :
    (∫⁻ s,f s ∂occupation E T) < ∞ := by
  rw [occupation_lintegral E T moving f hf]
  apply (lintegral_mono_ae bound).trans_lt
  rw [setLIntegral_const]
  exact ENNReal.mul_lt_top hB.lt_top (by simp [Real.volume_Icc])

theorem unweight_patch_bound {ρ : ℝ} (hρ : 0 < ρ) {a b : ℝ≥0∞}
    (h : ENNReal.ofReal ρ * a ≤ b) : a ≤ (ENNReal.ofReal ρ)⁻¹*b := by
  calc
    a = (ENNReal.ofReal ρ)⁻¹*(ENNReal.ofReal ρ*a) := by
      rw [←mul_assoc,ENNReal.inv_mul_cancel (ENNReal.ofReal_ne_zero_iff.mpr hρ) ENNReal.ofReal_ne_top,
        one_mul]
    _ ≤ _ := by gcongr

/-- Probability of the physical patches yields finite unweighted slab occupation. -/
theorem finite_occupation_of_probability (E : ℝ → Set Space) (T ρ : ℝ) (hρ : 0 < ρ)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1) :
    IsFiniteMeasure (occupation E T) := by
  have mass := occupation_uniform_bound E T moving (fun _ => 1) aemeasurable_const ((ENNReal.ofReal ρ)⁻¹)
    (ENNReal.inv_ne_top.mpr (ENNReal.ofReal_ne_zero_iff.mpr hρ)) (by
      filter_upwards [normMass] with t ht
      simpa [setLIntegral_const] using unweight_patch_bound hρ ht.le)
  exact ⟨by simpa [lintegral_const] using mass⟩

theorem transported_velocity_growth (S : ℝ → Space → Space) (t : ℝ) (y : Space) :
    ‖flowVelocity S (t,y)‖ ≤ ‖y‖ + ‖S t y‖ := by
  have h := (norm_sub_le y.1 (S t y).1).trans
    (add_le_add (norm_fst_le y) (norm_fst_le (S t y)))
  have identity : ‖flowVelocity S (t,y)‖ = ‖y.1-(S t y).1‖ := by
    change max ‖-(y.1.2-(S t y).1.2)‖ ‖y.1.1-(S t y).1.1‖ =
      max ‖y.1.1-(S t y).1.1‖ ‖y.1.2-(S t y).1.2‖
    rw [norm_neg,max_comm]
  rwa [identity]

/-- The original probability and uniform (mass-weighted) second-moment hypotheses,
and the bounded physical endpoint of a transport map, imply spacetime L¹ velocity.
No a priori integrability of the flux is used. The velocity is measurable as part
of the weak solution. Only per-time transport marginals are needed. -/
theorem patch_velocity_integrable (E : ℝ → Set Space) (T ρ : ℝ) (hρ : 0 < ρ)
    (S : ℝ → Space → Space) (target : Measure Space) (K : ℝ≥0) (M : ℝ≥0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity S) (occupation E T))
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T),
      ENNReal.ofReal ρ * (∫⁻ y in E t, ‖y‖ₑ^2) ≤ M)
    (radius : ∀ᵐ x ∂target, ‖x‖ ≤ K)
    (transport : ∀ᵐ t ∂volume.restrict (Icc 0 T),
      Measurable (S t) ∧ (volume.restrict (E t)).map (S t) = target) :
    Integrable (flowVelocity S) (occupation E T) := by
  let v := (ENNReal.ofReal ρ)⁻¹
  have fv : v ≠ ∞ := ENNReal.inv_ne_top.mpr (ENNReal.ofReal_ne_zero_iff.mpr hρ)
  let C := (1:ℝ≥0∞)+K
  have fc : C ≠ ∞ := by simp [C]
  refine ⟨mw,hasFiniteIntegral_iff_enorm.mpr ?_⟩
  apply occupation_uniform_bound E T moving _ mw.enorm (C*v + v*M)
    ((ENNReal.add_lt_top.mpr ⟨ENNReal.mul_lt_top fc.lt_top fv.lt_top,
      ENNReal.mul_lt_top fv.lt_top ENNReal.coe_lt_top⟩).ne)
  filter_upwards [normMass,moment,transport] with t hmass hm htr
  have bb : ∀ᵐ y ∂volume.restrict (E t), ‖S t y‖ ≤ K := by
    apply (ae_map_iff htr.1.aemeasurable (measurableSet_le measurable_norm measurable_const)).mp
    rwa [htr.2]
  calc
    _ ≤ ∫⁻ y in E t,C+‖y‖ₑ^2 := by
      apply lintegral_mono_ae
      filter_upwards [bb] with y hy
      have h : ‖flowVelocity S (t,y)‖ ≤ (1+(K:ℝ))+‖y‖^2 := by
        nlinarith only [transported_velocity_growth S t y,hy,sq_nonneg (‖y‖-1/2)]
      have hh := ENNReal.ofReal_le_ofReal h
      simpa [ENNReal.ofReal_add (by positivity : (0:ℝ) ≤ 1+(K:ℝ)),
        ENNReal.ofReal_add (by norm_num : (0:ℝ) ≤ 1),ENNReal.ofReal_pow (norm_nonneg y),C] using hh
    _ = C*volume (E t) + ∫⁻ y in E t,‖y‖ₑ^2 := by rw [lintegral_add_left measurable_const,setLIntegral_const]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left (show volume (E t) ≤ v by
      simpa [v] using unweight_patch_bound hρ hmass.le) zero_le) (unweight_patch_bound hρ hm)

/-- A common two-trace weak patch identity under probability, bounded-time
second moment, a bounded target and the renormalized initial-value PDE. -/
theorem weak_patch_from_probability_dynamics (E0 : Set Space) (E : ℝ → Set Space)
    (T ρ : ℝ) (hT : 0 ≤ T) (hρ : 0 < ρ) (S : ℝ → Space → Space) (target : Measure Space)
    (K M : ℝ≥0) (me0 : MeasurableSet E0) (p0 : ENNReal.ofReal ρ * volume E0 = 1)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity S) (occupation E T))
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * (∫⁻ y in E t, ‖y‖ₑ^2) ≤ M)
    (radius : ∀ᵐ x ∂target, ‖x‖ ≤ K)
    (transport : ∀ᵐ t ∂volume.restrict (Icc 0 T),
      Measurable (S t) ∧ (volume.restrict (E t)).map (S t) = target)
    (sol : RenormalizedPatch E0 E T ρ (flowVelocity S)) :
    ∀ᵐ t ∂volume.restrict (Icc 0 T), WeakPatchEquation E0 E t ρ (flowVelocity S) := by
  let _ := finite_occupation_of_probability E T ρ hρ moving normMass
  have fin : volume E0 ≠ ⊤ := by
    exact ((unweight_patch_bound hρ p0.le).trans_lt (by simpa using hρ)).ne
  exact weak_patch_of_renormalized E0 E T ρ hT hρ (flowVelocity S) me0 fin moving
    (patch_velocity_integrable E T ρ hρ S target K M moving mw normMass moment radius transport) sol

end
end Vortex
