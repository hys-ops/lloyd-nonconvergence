import ContinuumPhysical
import StaticRankConvex
import Mathlib.MeasureTheory.Constructions.Pi

open MeasureTheory Set
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Euclidean coordinates in the order (first horizontal, second horizontal, vertical). -/
def sgChart : Space ≃ₜ SequentialRanks.RankPoint 3 where
  toFun y := ![y.1.1,y.1.2,y.2]
  invFun x := ((x 0,x 1),x 2)
  left_inv _ := rfl
  right_inv x := by funext i; fin_cases i <;> rfl
  continuous_toFun := by
    apply continuous_pi
    intro i; fin_cases i <;> simp <;> fun_prop
  continuous_invFun := by fun_prop

theorem sgChart_volume : MeasurePreserving sgChart volume volume := by
  have h₁ := volume_preserving_piFinSuccAbove (fun _ : Fin 3 => ℝ) (Fin.last 2)
  have h₂ := (MeasurePreserving.id (volume : Measure ℝ)).prod (volume_preserving_piFinTwo (fun _ => ℝ))
  have h₃ := Measure.measurePreserving_swap (μ := (volume : Measure ℝ)) (ν := (volume : Measure H))
  have inv : MeasurePreserving sgChart.toMeasurableEquiv.symm volume volume := by
    convert h₃.comp (h₂.comp h₁) using 1
    funext x; rfl
  simpa using inv.symm

theorem sgChart_score (y x : Space) : linearScore y x = SequentialRanks.rankCovector (sgChart y) (sgChart x) := by
  simp [linearScore,SequentialRanks.rankCovector,Fin.sum_univ_three,smul_eq_mul,add_assoc]
  rfl

theorem sgChart_quadratic (y x : Space) :
    quadraticCost y x = SequentialRanks.normSq (SequentialRanks.diff (sgChart y) (sgChart x)) := by
  simp [SequentialRanks.normSq,SequentialRanks.diff,Fin.sum_univ_three,quadraticCost,distSq,add_assoc]
  rfl

theorem sgChart_patch_ac (A : Set Space) (d : ENNReal) :
    ((d • volume.restrict A).map sgChart) ≪ (volume : Measure (SequentialRanks.RankPoint 3)) := by
  rw [← sgChart_volume.map_eq]
  exact ((Measure.absolutelyContinuous_of_le Measure.restrict_le_self).smul_left d).map sgChart.measurable
end
end Vortex
