import SGFiniteConclusion
import SGFiniteCoupling

open MeasureTheory Set
namespace Vortex
noncomputable section

/-- The finite Brenier cell moment inequality for arbitrary intercept pairs and
all labels, including disappearing cells. The geometric input is the existence
of a midpoint-dominated coupling of normalized measurable pieces of a uniform body. -/
theorem finite_brenier_from_cell_midpoints (input : CellMidpoints) : OrdinaryFiniteBrenier := by
  intro J iJ convexBody W unif C bound N site inj a b ma mb pa pb
  obtain ⟨γ,winners,mw,dw,ha,hb,dom⟩ :=
    finite_power_couplings input J convexBody W unif site inj a b ma mb pa pb
  exact finite_endpoint_from_label_couplings J W C bound a b ma mb γ winners mw dw ha hb dom

end
end Vortex
