import FiniteCatalogRisk
import MinimaxLowerPaths
import SquareModel

open MeasureTheory Set
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

def obsVector (z : SquareObs) : Fin 2 → ℝ := ![z.1,z.2]
def vectorObs (z : Fin 2 → ℝ) : SquareObs := (z 0,z 1)
def squareClipObs (z : SquareObs) : SquareObs := by classical exact if z ∈ unitSquare then z else 0

private theorem mVec : Measurable obsVector := by
  apply measurable_pi_iff.mpr; intro i; fin_cases i <;> simp [obsVector] <;> fun_prop
private theorem mPair : Measurable vectorObs := (measurable_pi_apply 0).prodMk (measurable_pi_apply 1)
private theorem mClip : Measurable squareClipObs := by
  classical
  exact measurable_id.piecewise (show MeasurableSet unitSquare from measurableSet_Icc.prod measurableSet_Icc) measurable_const
private theorem clIn (z : SquareObs) : squareClipObs z ∈ unitSquare := by
  classical by_cases h : z ∈ unitSquare
  · simp [squareClipObs,h]
  · have p : squareClipObs z = 0 := by simp [squareClipObs,h]
    rw [p]; exact ⟨⟨le_rfl,zero_le_one⟩,⟨le_rfl,zero_le_one⟩⟩
private theorem baseP : IsProbabilityMeasure squareBase := by
  have e : squareLaw 0 = squareBase := by simp [squareLaw,density]
  rw [←e]; exact square_law_probability (by norm_num)
private theorem sfull (θ : ℝ) : ∀ᵐ z ∂squareLaw θ,z ∈ unitSquare := by
  apply (ae_restrict_mem (μ:=volume) (s:=unitSquare) (measurableSet_Icc.prod measurableSet_Icc)).filter_mono
  exact (withDensity_absolutelyContinuous _ _).ae_le

/-- Time-inhomogeneous independent observations with the publicly specified
square densities. The forecasts have mass one for every possible history. -/
def squareSequence (θ : ℕ → ℝ) (hθ : ∀ t, |θ t|≤1/2) : Predictions SquareObs squareBase :=
  fun t => {
    f := fun q => density (θ t) q.2
    measurable := by unfold density; fun_prop
    nonneg := fun q => (by norm_num : (0:ℝ) ≤1/4).trans (actual_density_floor _ _ _ (hθ t))
    integrable := fun _ => (show Continuous (density (θ t)) by unfold density; fun_prop).continuousOn.integrableOn_compact
      (isCompact_Icc.prod isCompact_Icc)
    mass := fun _ => square_density_normalized _ }

def squareTruth (θ : ℕ → ℝ) (n : ℕ) (q : History SquareObs n × SquareObs) : Fin 2 → ℝ :=
  obsVector (squareMap (θ n) (squareClipObs q.2))
theorem square_truth_bounded (θ : ℕ → ℝ) (hθ : ∀ t, |θ t|≤1/2) (n : ℕ) :
    Measurable (squareTruth θ n) ∧ ∀ q,normSq (squareTruth θ n q) ≤ 2 := by
  have m : Measurable (squareMap (θ n)) := by unfold squareMap perturb; fun_prop
  refine ⟨mVec.comp (m.comp (mClip.comp measurable_snd)),?_⟩
  intro q
  have M := (squareRank_bijection (θ n) (hθ n)).2
  have inD : squareMap (θ n) (squareClipObs q.2) ∈ unitSquare :=
    M ▸ mem_image_of_mem _ (clIn q.2)
  obtain ⟨ha,hb⟩ := inD
  simp only [squareTruth,obsVector,normSq,Fin.sum_univ_two,Matrix.cons_val_zero,Matrix.cons_val_one]
  linarith [mul_self_le_mul_self ha.1 ha.2,mul_self_le_mul_self hb.1 hb.2]

theorem square_sequence_paths_succ (θ : ℕ → ℝ) (ht) (n : ℕ) :
    pathMeasure (squareSequence θ ht) (n+1)=
      (pathMeasure (squareSequence θ ht) n).prod (squareLaw (θ n)) := by
  let _ := baseP
  let a := squareSequence θ ht
  obtain ⟨m,nn,_,_⟩ := history_is_density a n
  have md : Measurable (fun z => ENNReal.ofReal (density (θ n) z)) := by unfold density; fun_prop
  change ((historyBase squareBase n).prod squareBase).withDensity
    (fun x : History SquareObs n × SquareObs => ENNReal.ofReal (historyDensity a n x.1*density (θ n) x.2)) =
    ((historyBase squareBase n).withDensity (fun x => ENNReal.ofReal (historyDensity a n x))).prod
    (squareBase.withDensity (fun z => ENNReal.ofReal (density (θ n) z)))
  rw [prod_withDensity m.ennreal_ofReal md]
  congr 1; funext x; exact ENNReal.ofReal_mul (nn x.1)

private theorem prefix_paths {θ η : ℕ → ℝ} (hθ hη) (n : ℕ) (h : ∀ t<n,θ t=η t) :
    pathMeasure (squareSequence θ hθ) n=pathMeasure (squareSequence η hη) n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [square_sequence_paths_succ,square_sequence_paths_succ,ih (fun t ht => h t (by omega)),h n (by omega)]

def wordParameter : (n : ℕ) → Word n → ℕ → ℝ
  | 0, _, _ => 0
  | n+1, w, t => if t=n then signParameter w.2 else wordParameter n w.1 t
theorem word_parameter_bound : ∀ n (w : Word n) t, |wordParameter n w t|≤1/2
  | 0, _, _ => by norm_num [wordParameter]
  | n+1, w, t => by
    dsimp [wordParameter]; split
    · cases w.2 <;> norm_num [signParameter]
    · exact word_parameter_bound n w.1 t

def stageRisk (θ : ℕ → ℝ) (ht : ∀ t, |θ t|≤1/2) (e : CatalogPolicy SquareObs 2) (n : ℕ) :=
  ∫⁻ z : History SquareObs n × SquareObs, ENNReal.ofReal (normSq (diff (squareTruth θ n z) (e.val n z)))
    ∂pathMeasure (squareSequence θ ht) (n+1)

private theorem obs_error (p : Fin 2 → ℝ) (θ : ℝ) (z : SquareObs) :
    ENNReal.ofReal (normSq (diff (obsVector (squareMap θ z)) p))=lossE θ (vectorObs p) z := by
  unfold lossE sqError vectorObs obsVector normSq diff
  rw [Fin.sum_univ_two]; simp; congr 1; ring

private theorem risk_prefix {θ η : ℕ → ℝ} (hθ hη) (e : CatalogPolicy SquareObs 2) (n : ℕ)
    (eq : ∀ t≤n,θ t=η t) : stageRisk θ hθ e n=stageRisk η hη e n := by
  unfold stageRisk
  rw [prefix_paths hθ hη _ (fun t ht => eq t (by omega))]
  simp only [squareTruth,eq n le_rfl]

private theorem choose_hard (e : CatalogPolicy SquareObs 2) (n : ℕ) :
    ∃ w : Word n, (n:ℝ≥0∞)*singleFloor ≤ ∑ t ∈ Finset.range n,stageRisk (wordParameter n w) (word_parameter_bound n w) e t := by
  induction n with
  | zero => exact ⟨(),by simp⟩
  | succ n ih =>
    obtain ⟨w,hw⟩ := ih
    let θ := wordParameter n w
    let hθ := word_parameter_bound n w
    let _ := baseP
    let μ := pathMeasure (squareSequence θ hθ) n
    have : IsProbabilityMeasure μ := pathMeasureProb _ _
    obtain ⟨b,bnd⟩ := hard_sign_after_history μ (fun z => vectorObs (e.val n z)) (mPair.comp (e.property n))
    let w2 : Word (n+1) := (w,b)
    let η := wordParameter (n+1) w2
    let hη := word_parameter_bound (n+1) w2
    have same t (ht : t<n) : η t=θ t := by simp only [η,θ,wordParameter,w2,ite_eq_right_iff]; omega
    have now : η n=signParameter b := by simp [η,wordParameter,w2]
    refine ⟨w2,?_⟩
    change ↑(n+1)*singleFloor ≤ ∑ t ∈ Finset.range (n+1),stageRisk η hη e t
    rw [Finset.sum_range_succ]
    have prev : (∑ t ∈ Finset.range n,stageRisk η hη e t)=∑ t ∈ Finset.range n,stageRisk θ hθ e t := by
      apply Finset.sum_congr rfl; intro t ht
      exact risk_prefix hη hθ e t (fun i hi => same _ (lt_of_le_of_lt hi (Finset.mem_range.mp ht)))
    rw [prev]
    have last : stageRisk η hη e n=(∫⁻ y,lossE (signParameter b) (vectorObs (e.val n y)) y.2 ∂μ.prod (signLaw b)) := by
      unfold stageRisk
      rw [square_sequence_paths_succ,prefix_paths hη hθ n same,now]
      apply lintegral_congr_ae
      have ok : ∀ᵐ q ∂μ.prod (signLaw b),q.2 ∈ unitSquare :=
        Measure.quasiMeasurePreserving_snd.ae (sfull _)
      filter_upwards [ok] with q good
      change q.2 ∈ unitSquare at good
      have pn : squareClipObs q.2=q.2 := by simp [squareClipObs,good]
      simp only [squareTruth,pn,now]
      exact obs_error (e.val n q) (signParameter b) q.2
    rw [last,Nat.cast_succ,add_mul,one_mul]
    exact add_le_add hw bnd
/-- The explicit hard catalog expressed as normalized forecasts and bounded
true square-rank versions in the general History and pathMeasure conventions. -/
def squareWordCatalog {M l : ℕ} (index : Fin M → Word l) : RankCatalog SquareObs squareBase 2 M where
  forecast j := squareSequence (wordParameter l (index j)) (word_parameter_bound l (index j))
  rank j := squareTruth (wordParameter l (index j))

theorem square_catalog_minimax_lower (T M : ℕ) (hM : M ≠ 0) :
    let l := min T (Nat.log 2 M)
    ∃ index : Fin M → Word l, Function.Surjective index ∧
      (l:ℝ≥0∞)*singleFloor ≤ catalogMinimax (squareWordCatalog index) T := by
  dsimp only
  let l := min T (Nat.log 2 M)
  have within : l ≤ T := min_le_left _ _
  obtain ⟨index,onto,_⟩ := minimax_exact_catalog_lower T M hM
  refine ⟨index,onto,le_iInf fun e => ?_⟩
  obtain ⟨w,hard⟩ := choose_hard e l
  obtain ⟨j,hj⟩ := onto w
  apply le_iSup_of_le j
  change _ ≤ ∑ t ∈ Finset.range T,stageRisk (wordParameter l (index j)) (word_parameter_bound l (index j)) e t
  rw [hj]
  apply hard.trans
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono within) (fun _ _ _ => zero_le)

/-- Every active-date model has the exact square rank: pushing its density by
the explicit map gives the uniform reference, and equality in quadratic cost
among all couplings characterizes that same graph. -/
theorem square_catalog_rank_certification {l : ℕ} (w : Word l) (t : ℕ) :
    let θ := wordParameter l w t
    (squareLaw θ).map (squareMap θ)=squareBase ∧
    ∀ γ : Measure (unitSquare × unitSquare), IsProbabilityMeasure γ →
      γ.map (fun z => z.1.val)=squareLaw θ → γ.map (fun z => z.2.val)=squareBase →
      (∫ z,squareCost2 z.1.val (squareMap θ z.1.val) ∂γ) ≤ (∫ z,squareCost2 z.1.val z.2.val ∂γ) ∧
      ((∫ z,squareCost2 z.1.val z.2.val ∂γ)=(∫ z,squareCost2 z.1.val (squareMap θ z.1.val) ∂γ) ↔
        ∀ᵐ z ∂γ,z.2.val=squareMap θ z.1.val) := by
  dsimp only
  exact ⟨squareRank_pushforward _ (word_parameter_bound l w t),fun γ _ src tgt =>
    squareRank_unique_optimum _ (word_parameter_bound l w t) γ src tgt⟩
end
end SequentialRanks
