import SGClosureSolution
import SGFiniteBrenier
import SGCellMidpoints

open MeasureTheory Set
open scoped ENNReal NNReal BoundedContinuousFunction

namespace Vortex
noncomputable section

/-- The probability law with density `p` on the full geostrophic space. -/
def sgDensityProbability (p : Space → ℝ≥0) (unit : (∫⁻ y, (p y : ℝ≥0∞)) = 1) :
    ProbabilityMeasure Space :=
  ⟨volume.withDensity (fun y => (p y : ℝ≥0∞)),
    ⟨by rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ, unit]⟩⟩

private theorem horizontal_from_graphs (D : Set Space) [CompactSpace D] (conv : Convex ℝ D)
    (T : ProbabilityMeasure D) (unif : UniformBodyLaw D T)
    (R : ℝ) (radius : ∀ x ∈ D, x.1.1 ^ 2 + x.1.2 ^ 2 ≤ R ^ 2)
    (P Q : ProbabilityMeasure Space) (p q : Space → ℝ≥0) (mp : AEMeasurable p volume)
    (mq : AEMeasurable q volume)
    (lawP : (P : Measure Space) = volume.withDensity (fun y => (p y : ℝ≥0∞)))
    (lawQ : (Q : Measure Space) = volume.withDensity (fun y => (q y : ℝ≥0∞)))
    (U V : Space → D) (gu : PhysicalBrenierGraph D P T U) (gv : PhysicalBrenierGraph D Q T V) :
    Integrable (fun y => flux (p y) (q y) (U y).val.1 (V y).val.1) ∧
    Integrable (fun y => discr (p y) (q y)) ∧
    (∫ y, flux (p y) (q y) (U y).val.1 (V y).val.1) ≤ R ^ 2 * ∫ y, discr (p y) (q y) := by
  obtain ⟨p',hmp,ep⟩ := mp
  obtain ⟨q',hmq,eq⟩ := mq
  have lp : (P : Measure Space) = volume.withDensity (fun y => (p' y : ℝ≥0∞)) :=
    lawP.trans (withDensity_congr_ae (ep.mono (fun _ h => congrArg _ h)))
  have lq : (Q : Measure Space) = volume.withDensity (fun y => (q' y : ℝ≥0∞)) :=
    lawQ.trans (withDensity_congr_ae (eq.mono (fun _ h => congrArg _ h)))
  have ef : (fun y => flux (p y) (q y) (U y).val.1 (V y).val.1) =ᵐ[volume]
      (fun y => flux (p' y) (q' y) (U y).val.1 (V y).val.1) := by
    filter_upwards [ep,eq] with y hy hz; rw [hy,hz]
  have ed : (fun y => discr (p y) (q y)) =ᵐ[volume] (fun y => discr (p' y) (q' y)) := by
    filter_upwards [ep,eq] with y hy hz; rw [hy,hz]
  have ip := density_flux_integrable volume p' q' hmp hmq P Q lp lq
    (stretchedCoordinates D 0) U V gu.measurable gv.measurable
  have heq (y : Space) : densityFlux (p' y) (q' y) (stretchedCoordinates D 0 (U y))
      (stretchedCoordinates D 0 (V y)) = flux (p' y) (q' y) (U y).val.1 (V y).val.1 := by
    rw [densityFlux, EuclideanSpace.real_norm_sq_eq, Fin.sum_univ_three]
    change ((_ - _) ^ 2 + (_ - _) ^ 2 + ((p' y : ℝ)*(0*(U y).val.2)-(q' y : ℝ)*(0*(V y).val.2))^2) / _ = _
    simp only [zero_mul,mul_zero,sub_zero,zero_pow (by decide : 2 ≠ 0),add_zero]
    rfl
  simp only [heq] at ip
  have iq := density_flux_integrable volume p' q' hmp hmq P Q lp lq
    (BoundedContinuousFunction.const Unit (1 : ℝ)) (fun _ => ()) (fun _ => ()) measurable_const measurable_const
  simp only [densityFlux,BoundedContinuousFunction.const_apply,smul_eq_mul,mul_one,Real.norm_eq_abs,sq_abs] at iq
  have ds : IsCompact D := isCompact_iff_compactSpace.mpr inferInstance
  obtain ⟨height,tool⟩ := exists_stretched_tool_of_ordinary
    (finite_brenier_from_cell_midpoints uniform_cell_midpoints) D conv T unif R radius
  refine ⟨ip.congr ef.symm, (show Integrable (fun y => discr (p' y) (q' y)) volume by simpa only [discr] using iq).congr ed.symm,?_⟩
  rw [integral_congr_ae ef,integral_congr_ae ed]
  exact physical_horizontal_endpoint D P Q T p' q' hmp hmq lp lq
    U V gu.measurable gv.measurable gu.cyclic_unique gv.cyclic_unique R height
    (uniform_power_realization D ds T unif P) (uniform_power_realization D ds T unif Q) tool

/-- The horizontal endpoint estimate for any given pair of quadratic Monge maps.
`p` and `q` are arbitrary normalized densities on the full geostrophic space with
finite second moments. The only condition on each map is deterministic optimality
and its marginal law. Both integrands are integrable, including at common zeros. -/
theorem horizontal_endpoint_for_monge_maps (D : Set Space) [CompactSpace D] (conv : Convex ℝ D)
    (T : ProbabilityMeasure D) (unif : UniformBodyLaw D T)
    (R : ℝ) (radius : ∀ x ∈ D, x.1.1 ^ 2 + x.1.2 ^ 2 ≤ R ^ 2)
    (p q : Space → ℝ≥0) (mp : AEMeasurable p volume) (mq : AEMeasurable q volume)
    (unitP : (∫⁻ y, (p y : ℝ≥0∞)) = 1) (unitQ : (∫⁻ y, (q y : ℝ≥0∞)) = 1)
    (momP : Integrable (fun y : Space => ‖y‖ ^ 2) (sgDensityProbability p unitP : Measure Space))
    (momQ : Integrable (fun y : Space => ‖y‖ ^ 2) (sgDensityProbability q unitQ : Measure Space))
    (U V : Space → D) (actualU : IsQuadraticMap D (sgDensityProbability p unitP) T U)
    (actualV : IsQuadraticMap D (sgDensityProbability q unitQ) T V) :
    Integrable (fun y => flux (p y) (q y) (U y).val.1 (V y).val.1) ∧
    Integrable (fun y => discr (p y) (q y)) ∧
    (∫ y, flux (p y) (q y) (U y).val.1 (V y).val.1) ≤ R ^ 2 * ∫ y, discr (p y) (q y) := by
  exact horizontal_from_graphs D conv T unif R radius _ _ p q mp mq rfl rfl U V
    (quadratic_map_unique_graph D _ T U actualU (withDensity_absolutelyContinuous _ _) momP)
    (quadratic_map_unique_graph D _ T V actualV (withDensity_absolutelyContinuous _ _) momQ)

/-- Construct both unique optimal graph plans and prove the published horizontal
endpoint estimate. The observation densities may vanish and may have unbounded
support. The target body need not have rotational symmetry. -/
theorem horizontal_endpoint_for_densities (D : Set Space) [CompactSpace D] (conv : Convex ℝ D)
    (T : ProbabilityMeasure D) (unif : UniformBodyLaw D T)
    (R : ℝ) (radius : ∀ x ∈ D, x.1.1 ^ 2 + x.1.2 ^ 2 ≤ R ^ 2)
    (p q : Space → ℝ≥0) (mp : AEMeasurable p volume) (mq : AEMeasurable q volume)
    (unitP : (∫⁻ y, (p y : ℝ≥0∞)) = 1) (unitQ : (∫⁻ y, (q y : ℝ≥0∞)) = 1)
    (momP : Integrable (fun y : Space => ‖y‖ ^ 2) (sgDensityProbability p unitP : Measure Space))
    (momQ : Integrable (fun y : Space => ‖y‖ ^ 2) (sgDensityProbability q unitQ : Measure Space)) :
    ∃ U V : Space → D, PhysicalBrenierGraph D (sgDensityProbability p unitP) T U ∧
      PhysicalBrenierGraph D (sgDensityProbability q unitQ) T V ∧
      Integrable (fun y => flux (p y) (q y) (U y).val.1 (V y).val.1) ∧
      Integrable (fun y => discr (p y) (q y)) ∧
      (∫ y, flux (p y) (q y) (U y).val.1 (V y).val.1) ≤ R ^ 2 * ∫ y, discr (p y) (q y) := by
  obtain ⟨U,hU⟩ := physical_static_brenier D (sgDensityProbability p unitP) T
    (withDensity_absolutelyContinuous _ _) momP
  obtain ⟨V,hV⟩ := physical_static_brenier D (sgDensityProbability q unitQ) T
    (withDensity_absolutelyContinuous _ _) momQ
  exact ⟨U,V,hU,hV,horizontal_from_graphs D conv T unif R radius _ _ p q mp mq rfl rfl U V hU hV⟩

end
end Vortex
