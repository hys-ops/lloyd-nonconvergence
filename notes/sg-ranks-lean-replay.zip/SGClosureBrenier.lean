import SGClosureBrenierDef
import SGClosureChartPlans
import SGClosureCyclic
import RankFenchel

open MeasureTheory Set Filter
open scoped ENNReal Topology
namespace Vortex
noncomputable section

private theorem chart_cancel {A B : Type*} [MetricSpace A] [MetricSpace B] [MeasurableSpace A]
    [MeasurableSpace B] [BorelSpace A] [BorelSpace B] (e : A ≃ₜ B) (P : ProbabilityMeasure A) :
    (P.map e).map e.symm = P := by
  apply ProbabilityMeasure.toMeasure_injective
  rw [ProbabilityMeasure.toMeasure_map,ProbabilityMeasure.toMeasure_map,Measure.map_map e.symm.measurable e.measurable]
  simp

private theorem chart_map_inj {A B : Type*} [MetricSpace A] [MetricSpace B] [MeasurableSpace A]
    [MeasurableSpace B] [BorelSpace A] [BorelSpace B] (e : A ≃ₜ B) :
    Function.Injective (fun P : ProbabilityMeasure A => P.map e) := by
  intro P Q hx
  simpa only [chart_cancel] using congrArg (fun μ : ProbabilityMeasure B => μ.map e.symm) hx

private theorem graph_chart {A B X Y : Type*} [MetricSpace A] [MetricSpace B] [MetricSpace X] [MetricSpace Y]
    [MeasurableSpace A] [MeasurableSpace B] [MeasurableSpace X] [MeasurableSpace Y]
    [BorelSpace A] [BorelSpace B] [BorelSpace X] [BorelSpace Y]
    [SecondCountableTopology A] [SecondCountableTopology B] [SecondCountableTopology X] [SecondCountableTopology Y]
    (a : A ≃ₜ X) (b : B ≃ₜ Y) (P : ProbabilityMeasure A) (f : X→Y) (mf : Measurable f) :
    (P.map (fun x => (x,b.symm (f (a x))))).map (a.prodCongr b) =
      (P.map a).map (fun x => (x,f x)) := by
  apply ProbabilityMeasure.toMeasure_injective
  have m1 : Measurable (fun x : X => (x,f x)) := measurable_id.prodMk mf
  have m2 : Measurable (fun x : A => (x,b.symm (f (a x)))) := measurable_id.prodMk (b.symm.measurable.comp (mf.comp a.measurable))
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [Measure.map_map (a.prodCongr b).measurable m2,Measure.map_map m1 a.measurable]
  congr 1; funext x
  change (a x,b (b.symm (f (a x)))) = _
  rw [b.apply_symm_apply]; rfl

private theorem chart_marginals {A B X Y : Type*} [MetricSpace A] [MetricSpace B] [MetricSpace X] [MetricSpace Y]
    [MeasurableSpace A] [MeasurableSpace B] [MeasurableSpace X] [MeasurableSpace Y]
    [BorelSpace A] [BorelSpace B] [BorelSpace X] [BorelSpace Y]
    [SecondCountableTopology A] [SecondCountableTopology B] [SecondCountableTopology X] [SecondCountableTopology Y]
    (a : A ≃ₜ X) (b : B ≃ₜ Y) (π : ProbabilityMeasure (A × B)) :
    (π.map (a.prodCongr b)).map Prod.fst = (π.map Prod.fst).map a ∧
      (π.map (a.prodCongr b)).map Prod.snd = (π.map Prod.snd).map b := by
  constructor <;> apply ProbabilityMeasure.toMeasure_injective
  · simp only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst (a.prodCongr b).measurable,
      Measure.map_map a.measurable measurable_fst]
    rfl
  · simp only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_snd (a.prodCongr b).measurable,
      Measure.map_map b.measurable measurable_snd]
    rfl

private theorem cost_chart (D : Set Space) (π : ProbabilityMeasure (Space × D)) :
    (∫ z,SequentialRanks.squareCost z ∂(π.map (sgObservationChart.prodCongr (sgChart.image D)) : Measure (↥(univ : Set (SequentialRanks.RankPoint 3)) × ↥(sgChart '' D)))) =
      ∫ z,physicalCost D z ∂(π : Measure _) := by
  have mc : Measurable (SequentialRanks.squareCost (A := (univ : Set (SequentialRanks.RankPoint 3)))
      (B := sgChart '' D)) := by
    let A := (univ : Set (SequentialRanks.RankPoint 3))
    let B := sgChart '' D
    have u (i : Fin 3) : Measurable (fun z : A × B => z.1.val i) := (measurable_pi_apply i).comp (measurable_subtype_coe.comp measurable_fst)
    have v (i : Fin 3) : Measurable (fun z : A × B => z.2.val i) := (measurable_pi_apply i).comp (measurable_subtype_coe.comp measurable_snd)
    change Measurable (fun z : A × B => ∑ i : Fin 3, (z.1.val i-z.2.val i)^2)
    exact Finset.measurable_sum Finset.univ (fun i _ => ((u i).sub (v i)).pow_const 2)
  rw [ProbabilityMeasure.toMeasure_map,integral_map (sgObservationChart.prodCongr (sgChart.image D)).measurable.aemeasurable mc.aestronglyMeasurable]
  apply integral_congr_ae; filter_upwards with z
  exact (sgChart_quadratic z.1 z.2.val).symm

private theorem charted_moments (P : ProbabilityMeasure Space)
    (second : Integrable (fun y : Space => ‖y‖^2) (P : Measure Space)) :
    Integrable (fun z : (univ : Set (SequentialRanks.RankPoint 3)) => ‖z.val‖) (P.map sgObservationChart : Measure ↥(univ : Set (SequentialRanks.RankPoint 3))) ∧
    Integrable (fun z : (univ : Set (SequentialRanks.RankPoint 3)) => SequentialRanks.normSq z.val) (P.map sgObservationChart : Measure ↥(univ : Set (SequentialRanks.RankPoint 3))) := by
  have m2 : Measurable (fun z : (univ : Set (SequentialRanks.RankPoint 3)) => SequentialRanks.normSq z.val) := by
    exact Finset.measurable_sum _ (fun i _ => ((measurable_pi_apply i).comp measurable_subtype_coe).pow_const 2)
  have m1 : Measurable (fun z : (univ : Set (SequentialRanks.RankPoint 3)) => ‖z.val‖) := measurable_subtype_coe.norm
  simp only [ProbabilityMeasure.toMeasure_map,integrable_map_measure m1.aestronglyMeasurable
    sgObservationChart.measurable.aemeasurable,integrable_map_measure m2.aestronglyMeasurable sgObservationChart.measurable.aemeasurable]
  constructor
  · apply ((integrable_const (1:ℝ)).add second).mono' (m1.comp sgObservationChart.measurable).aestronglyMeasurable
    filter_upwards with y; change ‖‖sgChart y‖‖ ≤ 1+‖y‖^2
    rw [Real.norm_of_nonneg (norm_nonneg _)]
    exact (sgChartNorm y).trans (by nlinarith [sq_nonneg (‖y‖-1/2)])
  · apply (second.const_mul 3).mono' (m2.comp sgObservationChart.measurable).aestronglyMeasurable
    filter_upwards with y
    change ‖SequentialRanks.normSq (sgChart y)‖ ≤ 3*‖y‖^2
    have ee : SequentialRanks.normSq (sgChart y)=y.1.1^2+y.1.2^2+y.2^2 := by
      unfold SequentialRanks.normSq; rw [Fin.sum_univ_three]; rfl
    rw [ee,Real.norm_of_nonneg (by positivity)]
    have b1 := pow_le_pow_left₀ (norm_nonneg y.1.1) ((norm_fst_le y.1).trans (norm_fst_le y)) 2
    have b2 := pow_le_pow_left₀ (norm_nonneg y.1.2) ((norm_snd_le y.1).trans (norm_fst_le y)) 2
    have b3 := pow_le_pow_left₀ (norm_nonneg y.2) (norm_snd_le y) 2
    rw [Real.norm_eq_abs,sq_abs] at b1 b2 b3
    linarith

/-- Static quadratic Brenier existence and both forms of uniqueness on the actual
unbounded SG observation space. Absolute continuity and a finite second moment of
the observation law, and compactness of the target, are all the analytic inputs. -/
theorem physical_static_brenier (D : Set Space) [CompactSpace D] (P : ProbabilityMeasure Space)
    (T : ProbabilityMeasure D) (ac : (P : Measure Space) ≪ volume)
    (second : Integrable (fun y : Space => ‖y‖^2) (P : Measure Space)) :
    ∃ U : Space → D, PhysicalBrenierGraph D P T U := by
  let a := sgObservationChart
  let b := sgChart.image D
  let Q := P.map a
  let W := T.map b
  have hb : IsCompact (sgChart '' D) := (isCompact_iff_compactSpace.mpr (inferInstance : CompactSpace D)).image sgChart.continuous
  have non : Nonempty D := nonempty_of_isProbabilityMeasure (μ := (T : Measure D))
  have : Nonempty (sgChart '' D) := non.map b
  have ac' : (Q : Measure (univ : Set (SequentialRanks.RankPoint 3))).map Subtype.val ≪ volume := by
    change ((P.map a : Measure ↥(univ : Set (SequentialRanks.RankPoint 3))).map Subtype.val) ≪ volume
    rw [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_subtype_coe a.measurable]
    change (P : Measure Space).map sgChart ≪ _
    rw [← sgChart_volume.map_eq]; exact ac.map sgChart.measurable
  have mom := charted_moments P second
  have hc : Continuous (physicalCost D) := by unfold physicalCost quadraticCost distSq; fun_prop
  obtain ⟨η,hη⟩ := cyclic_plan_polish_compact (physicalCost D) hc P T
  obtain ⟨f,π,mf,cert,graph,unique,comp⟩ := SequentialRanks.unbounded_brenier_from_cyclic
    univ (sgChart '' D) hb Q W ac' mom.1 mom.2 ⟨_,charted_patch_inputs D P T η hη⟩
  let U := fun y : Space => b.symm (f (a y))
  have mU : Measurable U := b.symm.measurable.comp (mf.comp a.measurable)
  let g := physicalGraph P U
  have gj : g.map (a.prodCongr b) = π := (graph_chart a b P f mf).trans graph
  have gη : g=η := chart_map_inj (a.prodCongr b) (gj.trans (unique _ (charted_patch_inputs D P T η hη)).symm)
  refine ⟨U,⟨mU,(show SequentialRanks.certifiedPlan (physicalCost D) P T g from gη.symm ▸ hη),?_,?_⟩⟩
  · intro γ hγ
    exact chart_map_inj (a.prodCongr b) ((unique _ (charted_patch_inputs D P T γ hγ)).trans gj.symm)
  · intro γ fg sg
    obtain ⟨marg1,marg2⟩ := chart_marginals a b γ
    have comparison := comp (γ.map (a.prodCongr b)) (marg1.trans (congrArg (fun p => ProbabilityMeasure.map p a) fg))
      (marg2.trans (congrArg (fun p => ProbabilityMeasure.map p b) sg))
    have gc : (∫ z,SequentialRanks.squareCost z ∂(π : Measure (↥(univ : Set (SequentialRanks.RankPoint 3)) × ↥(sgChart '' D)))) = ∫ z,physicalCost D z ∂(g : Measure (Space × D)) :=
      gj ▸ cost_chart D g
    rw [gc,cost_chart] at comparison
    exact ⟨comparison.1,fun eq => chart_map_inj (a.prodCongr b) ((comparison.2 eq).trans gj.symm)⟩
end
end Vortex
