import CellMidpointArea
import CellMidpointDensity
import ConditionalRank
import ConservedPatch
import ContinuumCells
import ContinuumDensity
import ContinuumGrid
import ContinuumLimit
import ContinuumPhysical
import ContinuumPlans
import ContinuumPower
import ContinuumUniform
import CyclicPlans
import DensityChain
import DiskArea
import DiskRearrangement
import FiniteCatalogChart
import FiniteCatalogMinimax
import FiniteCatalogRisk
import FiniteCatalogSquare
import Geometry
import ImpulseTransport
import KernelRanks
import MinimaxLowerIID
import MinimaxLowerInformation
import MinimaxLowerJoint
import MinimaxLowerPaths
import MinimaxLowerPrior
import MinimaxLowerSquare
import MinimaxUpper
import MinimaxUpperIID
import MinimaxUpperJoint
import MinimaxUpperKL
import MinimaxUpperKernel
import MinimaxUpperParametric
import MinimaxUpperPrior
import MinimaxUpperRanks
import MinimaxUpperSelection
import PatchDynamics
import PatchTheorem
import PathLawConditional
import PathLawDensity
import PathLawPublic
import PathLawRepresentation
import PredictiveRanks
import PublishedSG
import RankExamples
import RankFenchel
import RankMinty
import RankMintyConvex
import RankMintyDirections
import RankMintyPSDLimit
import RankMintyPSDLinear
import RankPair
import RankPath
import RankPotential
import RankSquare
import RankTransport
import Ranks
import SG
import SGCellChartLaws
import SGCellMidpoints
import SGClosure
import SGClosureAdapter
import SGClosureBrenier
import SGClosureBrenierDef
import SGClosureChart
import SGClosureChartPlans
import SGClosureComplete
import SGClosureCyclic
import SGClosureData
import SGClosureFlux
import SGClosureIntegrals
import SGClosureMoments
import SGClosurePublic
import SGClosureSolution
import SGEndpointPublic
import SGFiniteBrenier
import SGFiniteConclusion
import SGFiniteCoupling
import SGFiniteHarmonic
import SGFiniteMidpointInput
import SGFiniteTies
import SGPowerCells
import SliceTransport
import SquareIIDUpper
import SquareMinimax
import SquareModel
import SquarePolicies
import StaticPathOracle
import StaticPathOracleMixture
import StaticPathOraclePublic
import StaticRankBrenier
import StaticRankBridge
import StaticRankConvex
import StaticRankCycOptimal
import StaticRankDet
import StaticRankDual
import StaticRankExistence
import StaticRankFinish
import StaticRankGeometry
import StaticRankGraph
import StaticRankInverse
import StaticRankKL
import StaticRankPlans
import StaticRankPublicUpper
import StaticRankSubtype
import StationaryAverage
import StationaryFlux
import StationaryGeometry
import StationaryOptimal
import StationaryPatch
import StationaryReference
import StretchEndpoint
import Torque
import WeakTime
import WeakTimeBounds
import WeakTimeCommon
import WeakTimeMoments
import WeakTimePatch
import WeakTimeRenormalized
import WeakTimeTwoDates

#print axioms SequentialRanks.cell_midpoint_density_area
#print axioms SequentialRanks.cell_midpoint_coupling
#print axioms SequentialRanks.measurable_plan_of_closed_graph
#print axioms SequentialRanks.measurable_rankVersion
#print axioms SequentialRanks.rankVersion_ball
#print axioms SequentialRanks.rankVersion_eq_graph_map
#print axioms SequentialRanks.conditional_ranks_of_stable_plans
#print axioms SequentialRanks.conditional_loss_versions
#print axioms Vortex.horizontal_trace_of_weak_patch
#print axioms Vortex.physical_from_trace
#print axioms Vortex.overlap_from_weak_patch
#print axioms Vortex.CellFit.certificate
#print axioms Vortex.CellFit.mass_at
#print axioms Vortex.rawMoment_test
#print axioms Vortex.endpoint_from_finite_cells
#print axioms Vortex.density_flux_integrable
#print axioms Vortex.density_endpoint_from_finite_tool
#print axioms Vortex.CommonGrid.measurable_round
#print axioms Vortex.common_grids_for_all_laws
#print axioms Vortex.discr_integrals_le
#print axioms Vortex.CommonGrid.sum_fibers
#print axioms Vortex.grid_discr_le
#print axioms Vortex.energy_of_bounded_tests
#print axioms Vortex.endpoint_of_atomic_weak_limit
#print axioms Vortex.reciprocal_scores
#print axioms Vortex.physical_horizontal_endpoint
#print axioms Vortex.stability_of_quantized_plans
#print axioms Vortex.plan_moment_test_convergence
#print axioms Vortex.cellFit_of_power_cells
#print axioms Vortex.vertical_change_of_volume
#print axioms Vortex.ordinary_tool_supplies_stretches
#print axioms Vortex.exists_stretched_tool_of_ordinary
#print axioms SequentialRanks.closed_support_tuple
#print axioms SequentialRanks.closed_cyclicSupport
#print axioms SequentialRanks.continuous_cyclic_selector
#print axioms SequentialRanks.factor_log
#print axioms SequentialRanks.density_chain
#print axioms SequentialRanks.conditional_rank_step
#print axioms SequentialRanks.rank_extension
#print axioms SequentialRanks.ball_risk_cap
#print axioms SequentialRanks.rank_path_increments
#print axioms Vortex.areaCoord_meas
#print axioms Vortex.disk_area
#print axioms Vortex.area_distribution
#print axioms Vortex.disk_rearrange
#print axioms SequentialRanks.rankBox_compact
#print axioms SequentialRanks.encode_square_meas
#print axioms SequentialRanks.box_base_is_lebesgue
#print axioms SequentialRanks.hard_history_preserving
#print axioms SequentialRanks.boxRank_cert
#print axioms SequentialRanks.box_catalog_minimax_lower_of_ambient
#print axioms SequentialRanks.rankBox_radius
#print axioms SequentialRanks.boxed_catalog_admissible
#print axioms SequentialRanks.public_catalog_minimax_upper
#print axioms SequentialRanks.square_catalog_versions
#print axioms SequentialRanks.worst_square_catalog_minimax
#print axioms SequentialRanks.catalog_minimax_upper
#print axioms SequentialRanks.square_truth_bounded
#print axioms SequentialRanks.square_sequence_paths_succ
#print axioms SequentialRanks.word_parameter_bound
#print axioms SequentialRanks.square_catalog_minimax_lower
#print axioms SequentialRanks.square_catalog_rank_certification
#print axioms Vortex.equal_exchanges
#print axioms Vortex.section_l1
#print axioms Vortex.patch_fubini
#print axioms Vortex.halfline_moment
#print axioms Vortex.annulus_pair
#print axioms Vortex.work_bound
#print axioms Vortex.impulse_balance_from_trace
#print axioms SequentialRanks.compact_law_code
#print axioms SequentialRanks.kernel_conditional_ranks
#print axioms SequentialRanks.iid_day_lower
#print axioms SequentialRanks.minimax_iid_lower
#print axioms SequentialRanks.minimax_iid_log_lower
#print axioms SequentialRanks.prior_derivative
#print axioms SequentialRanks.density_derivative
#print axioms SequentialRanks.square_density_derivative_mean
#print axioms SequentialRanks.square_score_bound
#print axioms SequentialRanks.square_score_mean
#print axioms SequentialRanks.iid_score_information
#print axioms SequentialRanks.iid_likelihood_law
#print axioms SequentialRanks.iid_scalar_bayes
#print axioms SequentialRanks.experiment_tonelli
#print axioms SequentialRanks.iid_scalar_unrestricted
#print axioms SequentialRanks.hard_pair_sum
#print axioms SequentialRanks.hard_sign_after_history
#print axioms SequentialRanks.hard_list_path_lower
#print axioms SequentialRanks.minimax_hard_list_lower
#print axioms SequentialRanks.minimax_exact_catalog_lower
#print axioms SequentialRanks.iid_score_parts
#print axioms SequentialRanks.iid_score_parts_scaled
#print axioms SequentialRanks.iid_score_factor
#print axioms SequentialRanks.prior_mass_and_information
#print axioms SequentialRanks.iid_joint_information
#print axioms SequentialRanks.basis_mean
#print axioms SequentialRanks.basis_square_mean
#print axioms SequentialRanks.density_basis
#print axioms SequentialRanks.square_density_normalized
#print axioms SequentialRanks.square_law_probability
#print axioms SequentialRanks.history_is_density
#print axioms SequentialRanks.list_forecast_factor
#print axioms SequentialRanks.history_rank_regret
#print axioms SequentialRanks.finite_list_mixture_upper
#print axioms SequentialRanks.iid_paths_measurable
#print axioms SequentialRanks.iid_path_kl
#print axioms SequentialRanks.prior_forecast_paths
#print axioms SequentialRanks.parametric_estimator_exists
#print axioms SequentialRanks.finite_kl_density_conditions
#print axioms SequentialRanks.forecast_of_ac_kernel
#print axioms SequentialRanks.iid_bayes_kl
#print axioms SequentialRanks.parametric_bayes_rank_upper
#print axioms SequentialRanks.local_mixture_kl
#print axioms SequentialRanks.bounded_rank_distance
#print axioms SequentialRanks.one_step_from_geometry
#print axioms SequentialRanks.finite_list_rank_upper
#print axioms SequentialRanks.certified_rank_endpoint
#print axioms SequentialRanks.compact_lebesgue_base_ac
#print axioms SequentialRanks.forecast_rank_selector
#print axioms SequentialRanks.finite_list_estimator_exists
#print axioms Vortex.occupation_fubini
#print axioms Vortex.radial_conservation
#print axioms Vortex.excess_of_radial_conservation
#print axioms Vortex.overlap_from_dynamics
#print axioms Vortex.at_time
#print axioms Vortex.almost_every_time
#print axioms SequentialRanks.Forecast.transition_apply
#print axioms SequentialRanks.pathMeasure_transition
#print axioms SequentialRanks.pathMeasure_condKernel
#print axioms SequentialRanks.joint_density_step
#print axioms SequentialRanks.exists_predictions_joint_density
#print axioms SequentialRanks.pathMeasure_take
#print axioms SequentialRanks.terminalPathRisk_eq
#print axioms SequentialRanks.public_raw_path_estimator
#print axioms SequentialRanks.public_raw_mixture_estimator
#print axioms SequentialRanks.historyPrefix_measurable
#print axioms SequentialRanks.pathMeasure_prefix
#print axioms SequentialRanks.exists_predictions_path_law
#print axioms SequentialRanks.nonzero_of_ac_path_succ
#print axioms SequentialRanks.exists_predictions_path_law_succ
#print axioms SequentialRanks.rank_selection_for_densities
#print axioms Vortex.circular_slice
#print axioms Vortex.physical_to_time
#print axioms Vortex.published_overlap
#print axioms Vortex.zero_torque
#print axioms SequentialRanks.two_sign_square
#print axioms SequentialRanks.harmonic_floor
#print axioms SequentialRanks.sign_risk_from_energy
#print axioms SequentialRanks.lower_log_sum
#print axioms SequentialRanks.iid_lower_from_information
#print axioms SequentialRanks.unbounded_square_contact
#print axioms SequentialRanks.unbounded_brenier_from_cyclic
#print axioms SequentialRanks.minty_inverse_extension
#print axioms SequentialRanks.minty_critical_values
#print axioms SequentialRanks.minty_regular_on
#print axioms SequentialRanks.gradient_continuous_on_supporting
#print axioms SequentialRanks.rank_monotone_of_supporting
#print axioms SequentialRanks.gradient_regular_of_supporting
#print axioms SequentialRanks.rank_gradient_regular
#print axioms SequentialRanks.minty_density_directions
#print axioms SequentialRanks.minty_derivative_along
#print axioms SequentialRanks.minty_psd_of_directions
#print axioms SequentialRanks.convex_gradient_derivative_psd_ae
#print axioms SequentialRanks.rankCovectorMap_apply
#print axioms SequentialRanks.linear_cyclic_psd
#print axioms SequentialRanks.pair_pointwise
#print axioms SequentialRanks.square_pair_lower
#print axioms SequentialRanks.rank_kl
#print axioms SequentialRanks.mixture_oracle
#print axioms SequentialRanks.finite_mix_dominates
#print axioms SequentialRanks.risk_from_score
#print axioms SequentialRanks.finite_list_lower
#print axioms SequentialRanks.square_cyclic_potential
#print axioms SequentialRanks.speed_id
#print axioms SequentialRanks.square_energy
#print axioms SequentialRanks.density_floor
#print axioms SequentialRanks.actual_density_floor
#print axioms SequentialRanks.rank_from_pushforwards
#print axioms SequentialRanks.midpoint_ball
#print axioms SequentialRanks.rank_pointwise
#print axioms SequentialRanks.rank_from_midpoint_test
#print axioms SequentialRanks.hellinger_kl_pointwise
#print axioms SequentialRanks.hellinger_kl_integral
#print axioms SequentialRanks.sequential_bounds
#print axioms Vortex.rotate_diff
#print axioms Vortex.triangular_patch
#print axioms Vortex.overlap_pointwise
#print axioms Vortex.slice_CS
#print axioms Vortex.slice_density_bound
#print axioms Vortex.overlap_velocity
#print axioms Vortex.chartVal_embedding
#print axioms Vortex.chart_body_law
#print axioms Vortex.body_density_finite
#print axioms Vortex.cell_law_probability
#print axioms Vortex.chart_normalized_cell
#print axioms Vortex.chart_normalized_cell_data
#print axioms Vortex.cell_sqrt_scale
#print axioms Vortex.uniform_cell_midpoints
#print axioms Vortex.sg_overlap_and_stationarity
#print axioms Vortex.current_of_physical_graph
#print axioms Vortex.reference_of_physical_graph
#print axioms Vortex.physical_static_brenier
#print axioms Vortex.sgChart_volume
#print axioms Vortex.sgChart_score
#print axioms Vortex.sgChart_quadratic
#print axioms Vortex.sgChart_patch_ac
#print axioms Vortex.certified_under_chart
#print axioms Vortex.sgChartNorm
#print axioms Vortex.charted_patch_inputs
#print axioms Vortex.sg_public_patch
#print axioms Vortex.sg_public_for_every_reference
#print axioms Vortex.cyclic_plan_polish_compact
#print axioms Vortex.patchNN_measurable
#print axioms Vortex.patchNN_toReal
#print axioms Vortex.patchProbability_density
#print axioms Vortex.raw_push_of_probability
#print axioms Vortex.finite_of_patch_mass
#print axioms Vortex.patch_flux_integrals
#print axioms Vortex.horizontal_support_of_transport
#print axioms Vortex.measurable_circular
#print axioms Vortex.circular_radial_integrable
#print axioms Vortex.patch_difference_integrals
#print axioms Vortex.circular_vertical_marginal
#print axioms Vortex.public_patch_second_moment
#print axioms Vortex.circular_second_moment
#print axioms Vortex.sg_public_from_finite_tool
#print axioms Vortex.quadratic_map_unique_graph
#print axioms Vortex.sg_public_from_monge_solution
#print axioms Vortex.horizontal_endpoint_for_monge_maps
#print axioms Vortex.horizontal_endpoint_for_densities
#print axioms Vortex.finite_brenier_from_cell_midpoints
#print axioms Vortex.finite_endpoint_from_label_couplings
#print axioms Vortex.harmonic_coupling
#print axioms Vortex.strictPower_measurable
#print axioms Vortex.strictPower_disjoint
#print axioms Vortex.harmonic_cell_domination
#print axioms Vortex.finite_power_couplings
#print axioms Vortex.harmonic_nonneg
#print axioms Vortex.harmonic_le_sqrt
#print axioms Vortex.harmonic_energy_identity
#print axioms Vortex.harmonic_coupling_step
#print axioms Vortex.affine_score_tie_null
#print axioms Vortex.uniform_tie_null
#print axioms Vortex.finite_power_labels
#print axioms Vortex.power_realization_in_chart
#print axioms Vortex.uniform_power_realization
#print axioms Vortex.traceScale_pos
#print axioms Vortex.traceScale_tendsto
#print axioms Vortex.height_test_conserved
#print axioms Vortex.slice_area_from_horizontal_transport
#print axioms SequentialRanks.square_statistic_mean
#print axioms SequentialRanks.clipped_mean_risk
#print axioms SequentialRanks.square_iid_uniform_upper
#print axioms SequentialRanks.square_iid_minimax
#print axioms SequentialRanks.square_iid_minimax_log
#print axioms SequentialRanks.squareRank_bijection
#print axioms SequentialRanks.squareRank_pushforward
#print axioms SequentialRanks.squareRank_unique_optimum
#print axioms SequentialRanks.square_rank_support
#print axioms SequentialRanks.pastEntries_preserving
#print axioms SequentialRanks.iid_clipped_upper
#print axioms SequentialRanks.pathLaw_fst
#print axioms SequentialRanks.path_kl_mono
#print axioms SequentialRanks.path_rank_finite_kl
#print axioms SequentialRanks.path_rank_kl
#print axioms SequentialRanks.weighted_path_factor
#print axioms SequentialRanks.weighted_path_law
#print axioms SequentialRanks.weighted_density_oracle
#print axioms SequentialRanks.probability_density_kl
#print axioms SequentialRanks.misspecified_path_kl
#print axioms SequentialRanks.public_path_estimator
#print axioms SequentialRanks.misspecified_public_estimator
#print axioms SequentialRanks.cyclic_iff_optimal
#print axioms SequentialRanks.compact_brenier
#print axioms SequentialRanks.ranks_from_lebesgue_densities
#print axioms SequentialRanks.log_concave_density_midpoint
#print axioms SequentialRanks.midpoint_from_convex_gradients
#print axioms SequentialRanks.one_step_from_regular_gradients
#print axioms SequentialRanks.rank_covector_injective
#print axioms SequentialRanks.rank_convex_support
#print axioms SequentialRanks.midpoint_injective_of_convex_gradients
#print axioms SequentialRanks.optimal_plan_is_cyclic
#print axioms SequentialRanks.compact_cyclic_optimal_plan
#print axioms SequentialRanks.determinant_midpoint
#print axioms SequentialRanks.compact_support_duality
#print axioms SequentialRanks.compact_rank_graph_exists
#print axioms SequentialRanks.good_hessian_set
#print axioms SequentialRanks.regular_gradients_of_rank_maps
#print axioms SequentialRanks.midpoint_of_rank_maps
#print axioms SequentialRanks.rank_bound_for_maps
#print axioms SequentialRanks.compact_rank_hellinger
#print axioms SequentialRanks.endpoint_density_le_jacobian
#print axioms SequentialRanks.midpoint_domination_of_regular_set
#print axioms SequentialRanks.measurable_euclideanGradient
#print axioms SequentialRanks.measurable_supportGradient
#print axioms SequentialRanks.graph_of_lipschitz_contact
#print axioms SequentialRanks.swap_square_cyclic
#print axioms SequentialRanks.compact_rank_good_set
#print axioms SequentialRanks.hellinger_le_measure_kl
#print axioms SequentialRanks.compact_optimal_plan
#print axioms SequentialRanks.densityReference_law
#print axioms SequentialRanks.finite_list_public_upper
#print axioms SequentialRanks.parametric_public_upper
#print axioms SequentialRanks.subtype_rank_midpoint
#print axioms Vortex.mirror_integral_from_rotations
#print axioms Vortex.circular_step_even
#print axioms Vortex.stationary_flux_of_symmetry
#print axioms Vortex.rotate_compose
#print axioms Vortex.mirror_on_orbit
#print axioms Vortex.rotation_volume
#print axioms Vortex.mirror_volume
#print axioms Vortex.rotate_mem_circular
#print axioms Vortex.circular_invariant
#print axioms Vortex.symmetric_body_marginals
#print axioms Vortex.monge_symmetry
#print axioms Vortex.orthogonal_covariance
#print axioms Vortex.stationary_weak_of_flux
#print axioms Vortex.stationary_circular_patch
#print axioms Vortex.circular_volume_eq
#print axioms Vortex.stationary_reference
#print axioms Vortex.drop_vertical_radius
#print axioms Vortex.endpoint_of_stretches
#print axioms Vortex.published_from_stretches
#print axioms Vortex.torque_of_optimal_map
#print axioms Vortex.scalar_time_representative
#print axioms Vortex.slice_integrability_of_radial
#print axioms Vortex.patch_dynamic_bounds
#print axioms Vortex.weak_patch_of_distributional
#print axioms Vortex.occupation_lintegral
#print axioms Vortex.occupation_uniform_bound
#print axioms Vortex.unweight_patch_bound
#print axioms Vortex.finite_occupation_of_probability
#print axioms Vortex.transported_velocity_growth
#print axioms Vortex.patch_velocity_integrable
#print axioms Vortex.weak_patch_from_probability_dynamics
#print axioms Vortex.occupation_mono_time
#print axioms Vortex.timeDirection_bound
#print axioms Vortex.spaceTime_test_integrable
#print axioms Vortex.patch_test_time_representative
#print axioms Vortex.distributional_of_renormalized_patch
#print axioms Vortex.weak_patch_of_renormalized
#print axioms Vortex.two_dates_from_renormalized
#print axioms Vortex.two_dates_from_probability_dynamics
