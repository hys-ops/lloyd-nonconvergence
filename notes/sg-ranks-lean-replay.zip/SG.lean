import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

open MeasureTheory Set
open scoped ENNReal
namespace Vortex
abbrev H := ℝ × ℝ
abbrev Space := H × ℝ
def distSq (u v : H) : ℝ := (u.1-v.1)^2+(u.2-v.2)^2
def vel (y S : H) : H := (-(y.2-S.2),y.1-S.1)
noncomputable def flux (p q : ℝ) (U V : H) : ℝ :=
  ((p*U.1-q*V.1)^2+(p*U.2-q*V.2)^2)/(p+q)
noncomputable def patch {X : Type*} (A : Set X) (ρ : ℝ) (x : X) : ℝ := by
  classical exact if x ∈ A then ρ else 0
noncomputable def overlap {X : Type*} (E B : Set X) (ρ : ℝ)
    (y U V : X → H) (x : X) : ℝ := by
  classical exact if x ∈ E ∩ B then ρ * distSq (vel (y x) (U x)) (vel (y x) (V x)) else 0

theorem rotate_diff (y U V : H) : distSq (vel y U) (vel y V) = distSq U V := by
  dsimp [distSq, vel]; ring

theorem triangular_patch {X : Type*} (E B : Set X) (ρ : ℝ) (hρ : 0 < ρ) (x : X) :
    (patch E ρ x-patch B ρ x)^2/(patch E ρ x+patch B ρ x) =
    |patch E ρ x-patch B ρ x| := by
  classical
  by_cases he : x ∈ E <;> by_cases hb : x ∈ B <;>
    simp [patch, he, hb, abs_of_pos hρ, sq, ne_of_gt hρ]

theorem overlap_pointwise {X : Type*} (E B : Set X) (ρ : ℝ) (hρ : 0 < ρ)
    (y U V : X → H) (x : X) :
    overlap E B ρ y U V x ≤ 2 * flux (patch E ρ x) (patch B ρ x) (U x) (V x) := by
  classical
  by_cases he : x ∈ E <;> by_cases hb : x ∈ B
  · simp only [overlap, Set.mem_inter_iff, he, hb, and_self, ite_true, patch, rotate_diff]
    dsimp [flux, distSq]
    field_simp [ne_of_gt hρ]; nlinarith
  all_goals simp [overlap, patch, he, hb, flux] <;> positivity

/-- Cauchy-Schwarz on the actual height interval with Lebesgue measure. -/
theorem slice_CS (a b : ℝ) (hab : a ≤ b) (d : ℝ → ℝ)
    (h1 : IntegrableOn d (Icc a b)) (h2 : IntegrableOn (fun z => d z ^ 2) (Icc a b)) :
    (∫ z in Icc a b, d z)^2 ≤ (b-a) * ∫ z in Icc a b, d z^2 := by
  let μ : Measure ℝ := volume.restrict (Icc a b)
  have hmass : μ.real univ = b-a := by
    simp [μ, Measure.real, Real.volume_Icc, ENNReal.toReal_ofReal (sub_nonneg.mpr hab)]
  change Integrable d μ at h1
  change Integrable (fun z => d z ^ 2) μ at h2
  change (∫ z, d z ∂μ)^2 ≤ (b-a)*(∫ z, d z^2 ∂μ)
  rcases eq_or_lt_of_le hab with h | h
  · subst b
    simp [μ]
  let c := (∫ z, d z ∂μ)/(b-a)
  have hi : Integrable (fun _ : ℝ => c^2) μ := integrable_const _
  have hpos : 0 ≤ ∫ z, (d z^2 - (2*c)*d z + c^2) ∂μ :=
    integral_nonneg fun z => by change 0 ≤ _; nlinarith [sq_nonneg (d z-c)]
  have hs : Integrable (fun z => d z^2 - (2*c)*d z) μ := h2.sub (h1.const_mul (2*c))
  rw [integral_add hs hi, integral_sub h2 (h1.const_mul (2*c)),
    integral_const_mul, integral_const, smul_eq_mul, hmass] at hpos
  dsimp [c] at hpos
  field_simp [ne_of_gt (sub_pos.mpr h)] at hpos
  nlinarith [sub_pos.mpr h]

/-- The external geometry is supplied as the integrated sharp annulus inequality.
The impulse on that time slice is related to the initial value separately. -/
theorem slice_density_bound (ρ a b I It L : ℝ) (d : ℝ → ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (hi1 : IntegrableOn d (Icc a b)) (hi2 : IntegrableOn (fun z => d z^2) (Icc a b))
    (hFubini : L = 2*ρ*(∫ z in Icc a b, d z))
    (hAnn : (ρ/Real.pi)*(∫ z in Icc a b, d z^2) ≤ It) (hCons : It = I) :
    L ≤ 2*Real.sqrt (Real.pi*ρ*(b-a)*I) := by
  have hcs := slice_CS a b hab d hi1 hi2
  have hp := Real.pi_pos
  have hann : ρ * (∫ z in Icc a b, d z^2) ≤ Real.pi * I := by
    rw [hCons] at hAnn
    calc
      _ = ((ρ/Real.pi)*(∫ z in Icc a b, d z^2))*Real.pi := by field_simp
      _ ≤ I * Real.pi := mul_le_mul_of_nonneg_right hAnn hp.le
      _ = _ := mul_comm ..
  have hsq : (ρ*(∫ z in Icc a b, d z))^2 ≤ Real.pi*ρ*(b-a)*I := by
    calc
      _ = ρ^2*(∫ z in Icc a b, d z)^2 := mul_pow ..
      _ ≤ ρ^2*((b-a)*(∫ z in Icc a b, d z^2)) :=
        mul_le_mul_of_nonneg_left hcs (sq_nonneg _)
      _ = (ρ*(b-a))*(ρ*(∫ z in Icc a b, d z^2)) := by ring
      _ ≤ (ρ*(b-a))*(Real.pi*I) := mul_le_mul_of_nonneg_left hann
          (mul_nonneg hρ.le (sub_nonneg.mpr hab))
      _ = _ := by ring
  have hroot := Real.sqrt_le_sqrt hsq
  rw [Real.sqrt_sq_eq_abs] at hroot
  rw [hFubini]
  linarith [le_abs_self (ρ*(∫ z in Icc a b, d z))]

/-- Fixed-time public conclusion. S and V are horizontal components of the two
optimal maps. Only the horizontal endpoint estimate and the slice/PDE inputs below are assumed. -/
theorem overlap_velocity (E B : Set Space) (ρ R a b I It : ℝ) (d : ℝ → ℝ)
    (U V : Space → H) (hρ : 0 < ρ) (hab : a ≤ b)
    (hi1 : IntegrableOn d (Icc a b)) (hi2 : IntegrableOn (fun z => d z^2) (Icc a b))
    (hFubini : (∫ y, |patch E ρ y-patch B ρ y|) = 2*ρ*(∫ z in Icc a b, d z))
    (hAnn : (ρ/Real.pi)*(∫ z in Icc a b, d z^2) ≤ It) (hCons : It = I)
    (hOv : Integrable (overlap E B ρ Prod.fst U V))
    (hFl : Integrable (fun y => flux (patch E ρ y) (patch B ρ y) (U y) (V y)))
    (hOT : (∫ y, flux (patch E ρ y) (patch B ρ y) (U y) (V y)) ≤
      R^2 * ∫ y, (patch E ρ y-patch B ρ y)^2/(patch E ρ y+patch B ρ y)) :
    (∫ y, overlap E B ρ Prod.fst U V y) ≤ 4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*I) := by
  have hl := slice_density_bound ρ a b I It _ d hρ hab hi1 hi2 hFubini hAnn hCons
  simp_rw [triangular_patch E B ρ hρ] at hOT
  have ho := integral_mono hOv (hFl.const_mul 2) (overlap_pointwise E B ρ hρ Prod.fst U V)
  rw [integral_const_mul] at ho
  have hm := mul_le_mul_of_nonneg_left hl (sq_nonneg R)
  linarith
end Vortex
