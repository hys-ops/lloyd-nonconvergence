import MinimaxUpperRanks
import StaticRankBrenier
open MeasureTheory Set Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The source law of one real-valued normalized predictive density. -/
def Forecast.law {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y] {ν : Measure Y}
    (f : Forecast H Y ν) (h : H) : ProbabilityMeasure Y :=
  densityLaw ν (fun z => ENNReal.ofReal (f.f z)) (fun x => by
    rw [← ofReal_integral_eq_lintegral_ofReal (f.integrable x) (.of_forall fun y => f.nonneg (x,y)),f.mass,ENNReal.ofReal_one]) h

/-- A rank version is certified by its entire coupling with the same observation. -/
def CertifiedRank {d : ℕ} {A B : Set (Fin d → ℝ)} (P : ProbabilityMeasure A)
    (target : ProbabilityMeasure B) (U : A → Fin d → ℝ) : Prop :=
  ∃ π : ProbabilityMeasure (A × B), certifiedPlan squareCost P target π ∧
    (P : Measure A).map (fun y => (y,U y)) = (π : Measure (A × B)).map (fun z => (z.1,z.2.val))

theorem certified_rank_endpoint {d : ℕ} {A B : Set (Fin d → ℝ)} {P : ProbabilityMeasure A}
    {target : ProbabilityMeasure B} {U : A → Fin d → ℝ} (mu : Measurable U) (cert : CertifiedRank P target U) :
    (P : Measure A).map U = (target : Measure B).map Subtype.val := by
  obtain ⟨π,h,g⟩ := cert
  have m1 : Measurable (fun y : A => (y,U y)) := measurable_id.prodMk mu
  have m2 : Measurable (fun z : A × B => (z.1,z.2.val)) := measurable_fst.prodMk (measurable_subtype_coe.comp measurable_snd)
  have e := congrArg (fun m : Measure (A × (Fin d → ℝ)) => m.map Prod.snd) g
  rw [Measure.map_map measurable_snd m1,Measure.map_map measurable_snd m2] at e
  have marg := congrArg (fun Q : ProbabilityMeasure B => (Q : Measure B)) h.2.1
  change (π : Measure (A × B)).map Prod.snd = _ at marg
  rw [← marg,Measure.map_map measurable_subtype_coe measurable_snd]
  exact e

/-- The original observation base on a compact subset A is Lebesgue measure
in coordinates. Its pushforward is exactly the ambient restriction. -/
theorem compact_lebesgue_base_ac {d : ℕ} (A : Set (RankPoint d)) (ha : IsCompact A) :
    ((Measure.comap Subtype.val (volume : Measure (RankPoint d)) : Measure A).map Subtype.val) ≪ volume := by
  rw [map_comap_subtype_coe ha.isClosed.measurableSet]
  exact Measure.restrict_le_self.absolutelyContinuous

theorem forecast_rank_selector {d : ℕ} (A B : Set (Fin d → ℝ)) (ha : IsCompact A) (hb : IsCompact B) [Nonempty B]
    (ν : Measure A) [SFinite ν] (target : ProbabilityMeasure B) (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {H : Type*} [MeasurableSpace H] (f : Forecast H A ν) (base : ν.map Subtype.val ≪ volume) :
    ∃ U : H × A → Fin d → ℝ, Measurable U ∧ (∀ z, normSq (U z) ≤ R^2) ∧
      ∀ h, CertifiedRank (f.law h) target (fun y => U (h,y)) := by
  have static (h : H) := compact_brenier A B ha hb (f.law h) target
    (((withDensity_absolutelyContinuous ν (fun y => ENNReal.ofReal (f.f (h,y)))).map measurable_subtype_coe).trans base)
  apply rank_selection_for_densities A B ha hb ν (fun z => ENNReal.ofReal (f.f z))
    (ENNReal.measurable_ofReal.comp f.measurable) _ target R ball
  · intro h; obtain ⟨_,_,π,_,_,cert,_,_,_,unique⟩ := static h; exact ⟨π,cert,unique⟩
  · intro h; obtain ⟨φ,_,_,_,_,cert,_,_,eq,_⟩ := static h
    exact ⟨supportGradient φ,measurable_supportGradient hb.isClosed.measurableSet φ,eq ▸ cert⟩

/-- The statistical estimator itself is chosen once for the finite list, independently
of the true member. Geometric hypotheses refer only to individual static laws and
versions of their graph maps, including at histories of zero density. -/
theorem finite_list_estimator_exists {d : ℕ} (A B : Set (Fin d → ℝ)) (ha : IsCompact A) (hb : IsCompact B) [Nonempty B]
    (ν : Measure A) [SFinite ν] (target : ProbabilityMeasure B) (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {J : Type*} [Fintype J] [Nonempty J] (a : J → Predictions A ν) (T : ℕ)
    (base : ν.map Subtype.val ≪ volume)
    (midpoint : ∀ j t, t < T → ∀ h, 0 < historyDensity (a j) t h →
      ∀ u v : A → Fin d → ℝ, Measurable u → Measurable v →
      CertifiedRank ((a j t).law h) target u → CertifiedRank ((listForecast a t).law h) target v →
      (weighted ν (fun y => Real.sqrt ((a j t).f (h,y))*Real.sqrt ((listForecast a t).f (h,y)))).map
        (fun y => mid (u y) (v y)) ≤ (target : Measure B).map Subtype.val) :
    ∃ V : (t : ℕ) → History A t × A → Fin d → ℝ, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((listForecast a t).law h) target (fun y => V t (h,y))) ∧
      ∀ j, ∃ U : (t : ℕ) → History A t × A → Fin d → ℝ, (∀ t, Measurable (U t)) ∧
        (∀ t h, CertifiedRank ((a j t).law h) target (fun y => U t (h,y))) ∧
        (∑ t ∈ Finset.range T, historyRisk (a j) (fun n z => normSq (diff (U n z) (V n z))) t) ≤
          min (4*R^2*T) (16*R^2*Real.log (Fintype.card J)) := by
  choose U mu ub uc using (fun j t => forecast_rank_selector A B ha hb ν target R ball (a j t) base)
  choose V mv vb vc using (fun t => forecast_rank_selector A B ha hb ν target R ball (listForecast a t) base)
  let ρ := (target : Measure B).map Subtype.val
  have prob : IsProbabilityMeasure ρ := by dsimp [ρ]; infer_instance
  have rb : ∀ᵐ y ∂ρ, normSq y ≤ R^2 := by
    apply ae_map_iff measurable_subtype_coe.aemeasurable (measurableSet_le (by unfold normSq; fun_prop) measurable_const) |>.2
    exact .of_forall (fun k => ball k.val k.property)
  have source (t) (h : History A t) : Measurable (fun y : A => (h,y)) := measurable_const.prodMk measurable_id
  have bound := finite_list_rank_upper a T d R ρ rb U V mu mv ub vb
    (fun j t h => certified_rank_endpoint ((mu j t).comp (source t h)) (uc j t h))
    (fun t h => certified_rank_endpoint ((mv t).comp (source t h)) (vc t h))
    (fun j t ht h ph => midpoint j t ht h ph _ _ ((mu j t).comp (source t h)) ((mv t).comp (source t h)) (uc j t h) (vc t h))
  exact ⟨V,mv,vc,fun j => ⟨U j,mu j,uc j,bound j⟩⟩

end
end SequentialRanks
