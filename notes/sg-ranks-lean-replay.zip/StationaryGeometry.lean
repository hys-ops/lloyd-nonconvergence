import Torque
import Mathlib.Analysis.Complex.Isometry
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

open MeasureTheory Set
namespace Vortex
noncomputable section

def mirrorMap (y : Space) : Space := ((y.1.1,-y.1.2),y.2)

theorem rotate_compose (a b : ℝ) (y : Space) :
    rotateMap a (rotateMap b y) = rotateMap (a+b) y := by
  ext <;> simp [rotateMap,Real.cos_add,Real.sin_add] <;> ring

theorem mirror_on_orbit (y : Space) : ∃ θ, mirrorMap y = rotateMap θ y := by
  let z : ℂ := ⟨y.1.1,y.1.2⟩
  let r : Space := ((‖z‖,0),y.2)
  have h : rotateMap z.arg r = y := by
    ext <;> simp [r,rotateMap,mul_comm,Complex.norm_mul_cos_arg,Complex.norm_mul_sin_arg,z]
  have hh : rotateMap (-z.arg) r = mirrorMap y := by
    ext <;> simp [r,rotateMap,mirrorMap,mul_comm,Complex.norm_mul_cos_arg,Complex.norm_mul_sin_arg,z]
  refine ⟨-z.arg-z.arg,?_⟩
  calc
    mirrorMap y = rotateMap (-z.arg) r := hh.symm
    _ = rotateMap ((-z.arg-z.arg)+z.arg) r := by ring_nf
    _ = rotateMap (-z.arg-z.arg) y := by rw [← rotate_compose,h]

theorem rotation_volume (θ : ℝ) : MeasurePreserving (rotateMap θ) volume volume := by
  let e := Complex.measurableEquivRealProd
  have h : MeasurePreserving (fun x : H =>
      e (rotation (Circle.exp θ) (e.symm x))) volume volume :=
    Complex.volume_preserving_equiv_real_prod.comp ((rotation (Circle.exp θ)).measurePreserving.comp
      (Complex.volume_preserving_equiv_real_prod.symm))
  have k := h.prod (MeasurePreserving.id (volume : Measure ℝ))
  change MeasurePreserving (rotateMap θ) (volume.prod volume) (volume.prod volume)
  convert k using 1
  funext y
  ext <;> simp [e,rotateMap,rotation_apply,Circle.coe_exp,Complex.exp_mul_I,
    ← Complex.ofReal_cos, ← Complex.ofReal_sin, Complex.mul_re,Complex.mul_im]; try ring

theorem mirror_volume : MeasurePreserving mirrorMap volume volume := by
  let e := Complex.measurableEquivRealProd
  have h : MeasurePreserving (fun x : H => e (Complex.conjLIE (e.symm x))) volume volume :=
    Complex.volume_preserving_equiv_real_prod.comp (Complex.conjLIE.measurePreserving.comp
      (Complex.volume_preserving_equiv_real_prod.symm))
  exact h.prod (MeasurePreserving.id (volume : Measure ℝ))

theorem rotate_mem_circular (E : Set Space) (θ : ℝ) (y : Space) :
    rotateMap θ y ∈ circular E ↔ y ∈ circular E := by
  suffices areaCoord (rotateMap θ y).1 = areaCoord y.1 by
    change _ ≤ volume.real (slice E y.2) ↔ areaCoord y.1 ≤ volume.real (slice E y.2); rw [this]
  unfold areaCoord rotateMap; dsimp
  congr 1
  nlinarith only [congrArg (fun t : ℝ => t*y.1.1^2) (Real.sin_sq_add_cos_sq θ),
    congrArg (fun t : ℝ => t*y.1.2^2) (Real.sin_sq_add_cos_sq θ)]

theorem circular_invariant (E : Set Space) (mE : MeasurableSet E) :
    (∀ θ, MeasurePreserving (rotateMap θ) (volume.restrict (circular E))
      (volume.restrict (circular E))) ∧
    MeasurePreserving mirrorMap (volume.restrict (circular E)) (volume.restrict (circular E)) := by
  have m : MeasurableSet (circular E) := measurableSet_le (areaCoord_meas.comp measurable_fst)
    ((ENNReal.measurable_toReal.comp (measurable_measure_prodMk_right (μ := (volume : Measure H)) mE)).comp measurable_snd)
  constructor
  · intro θ
    simpa only [show rotateMap θ ⁻¹' circular E = circular E from Set.ext (rotate_mem_circular E θ)] using
      (rotation_volume θ).restrict_preimage m
  · have pre : mirrorMap ⁻¹' circular E = circular E := by
      ext y; change areaCoord (mirrorMap y).1 ≤ _ ↔ areaCoord y.1 ≤ _
      simp [mirrorMap,areaCoord]
    simpa only [pre] using mirror_volume.restrict_preimage m

/-- Axial set symmetry implies reflection symmetry, point by point in each horizontal orbit. -/
theorem symmetric_body_marginals (D : Set Space) (md : MeasurableSet D)
    (symm : ∀ θ y, rotateMap θ y ∈ D ↔ y ∈ D) :
    (∀ θ, MeasurePreserving (rotateMap θ) (volume.restrict D) (volume.restrict D)) ∧
    MeasurePreserving mirrorMap (volume.restrict D) (volume.restrict D) := by
  constructor
  · intro θ
    simpa only [show rotateMap θ ⁻¹' D = D from Set.ext (symm θ)] using
      (rotation_volume θ).restrict_preimage md
  · have pre : mirrorMap ⁻¹' D = D := by
      ext y; obtain ⟨θ,h⟩ := mirror_on_orbit y
      change mirrorMap y ∈ D ↔ y ∈ D
      rw [h]; exact symm θ y
    simpa only [pre] using mirror_volume.restrict_preimage md
end
end Vortex
