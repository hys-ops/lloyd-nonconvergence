import Ranks
namespace SequentialRanks
open MeasureTheory
open scoped BigOperators

/-- Exact posterior minimum for the two signs; arbitrary current-observation estimate e. -/
theorem two_sign_square (a b x v e : ℝ) (ha : 0 < a) (hb : 0 < b) :
    (a*b/(a+b))*v^2 ≤ a*(e-(x+v/2))^2 + b*(e-(x-v/2))^2 := by
  have hab : 0 < a+b := by positivity
  field_simp
  nlinarith only [sq_nonneg (2*(a+b)*(e-x)-(a-b)*v)]

theorem harmonic_floor (a b : ℝ) (ha : 1/4 ≤ a) (hb : 1/4 ≤ b) :
    1/4 ≤ 2*a*b/(a+b) := by
  have hd : 0 < a+b := by linarith
  apply (le_div_iff₀ hd).mpr
  nlinarith [mul_nonneg (sub_nonneg.mpr ha) (sub_nonneg.mpr hb)]

theorem sign_risk_from_energy {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (a b energy : X → ℝ) (ha : ∀ᵐ x ∂μ, 1/4 ≤ a x) (hb : ∀ᵐ x ∂μ, 1/4 ≤ b x)
    (hv : ∀ᵐ x ∂μ, 0 ≤ energy x) (hi : Integrable energy μ)
    (hj : Integrable (fun x => energy x*(2*a x*b x/(a x+b x))) μ)
    (he : (∫ x, energy x ∂μ)=1/(2*Real.pi^2)) :
    1/(32*Real.pi^2) ≤ (1/4)*(∫ x, energy x*(2*a x*b x/(a x+b x)) ∂μ) := by
  have h := integral_mono_ae (hi.const_mul (1/4:ℝ)) hj (by
    filter_upwards [ha,hb,hv] with x hx hy hz
    change (1/4:ℝ)*energy x ≤ _
    rw [mul_comm (1/4:ℝ)]
    exact mul_le_mul_of_nonneg_left (harmonic_floor _ _ hx hy) hz)
  rw [integral_const_mul,he] at h
  calc
    1/(32*Real.pi^2) = (1/4)*((1/4)*(1/(2*Real.pi^2))) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left h (by norm_num)

/-- Lower sum versus log, including T=0, without an asymptotic axiom. -/
theorem lower_log_sum (T : ℕ) :
    Real.log (1+4*(T:ℝ)/Real.pi^2) / (128*Real.pi^2) ≤
    (1/(8*Real.pi^2)) * ∑ n ∈ Finset.range T, 1/(4*Real.pi^2+16*(n:ℝ)) := by
  let A : ℝ := 4*Real.pi^2
  have hA : 0 < A := by dsimp [A]; positivity
  have hh (t : ℕ) : Real.log ((A+16*(t:ℝ))/A) ≤
      16 * ∑ n ∈ Finset.range t, 1/(A+16*(n:ℝ)) := by
    induction t with
    | zero => simp [hA.ne']
    | succ t ih =>
      have hd : 0 < A+16*(t:ℝ) := by positivity
      have hn : 0 < A+16*((t:ℝ)+1) := by positivity
      have ht := Real.log_le_sub_one_of_pos (div_pos hn hd)
      rw [Real.log_div hn.ne' hd.ne'] at ht
      rw [Real.log_div hd.ne' hA.ne'] at ih
      rw [Nat.cast_succ, Real.log_div hn.ne' hA.ne',Finset.sum_range_succ]
      have hE : (A+16*((t:ℝ)+1))/(A+16*(t:ℝ))-1 = 16/(A+16*(t:ℝ)) := by
        field_simp; ring
      rw [hE] at ht
      simp only [div_eq_mul_inv,one_mul] at ih ht ⊢
      linarith
  have hp : Real.pi^2 ≠ 0 := by positivity
  have hE : 1+4*(T:ℝ)/Real.pi^2 = (A+16*(T:ℝ))/A := by
    dsimp [A]; field_simp; ring
  rw [hE]
  apply (div_le_iff₀ (show 0 < 128*Real.pi^2 by positivity)).mpr
  calc
    _ ≤ _ := hh T
    _ = _ := by dsimp [A]; field_simp; ring

theorem iid_lower_from_information (T : ℕ) (risk posteriorVar : ℕ → ℝ)
    (risk_floor : ∀ n < T, posteriorVar n/(8*Real.pi^2) ≤ risk n)
    (vanTrees : ∀ n < T, 1/(4*Real.pi^2+16*(n:ℝ)) ≤ posteriorVar n) :
    Real.log (1+4*(T:ℝ)/Real.pi^2)/(128*Real.pi^2) ≤ ∑ n ∈ Finset.range T, risk n := by
  apply (lower_log_sum T).trans
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  have ht := Finset.mem_range.mp hi
  have h := mul_le_mul_of_nonneg_left (vanTrees i ht) (show 0 ≤ 1/(8*Real.pi^2) by positivity)
  exact h.trans (by simpa [div_eq_mul_inv,mul_comm] using risk_floor i ht)

end SequentialRanks
