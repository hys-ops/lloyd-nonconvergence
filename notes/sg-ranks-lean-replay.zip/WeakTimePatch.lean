import WeakTime

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

abbrev SpaceTime := ℝ × Space

def timeDirection (w : SpaceTime → H) (s : SpaceTime) : SpaceTime := (1,(w s,0))

/-- Distributional continuity equation on [0,T) for the mass density ρ 1_E. The endpoint T
does not occur in the equation. Compact spacetime tests can meet the initial time. -/
def DistributionalPatch (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (w : SpaceTime → H) : Prop :=
  ∀ f : SpaceTime → ℝ, ContDiff ℝ ∞ f → HasCompactSupport f →
    (∃ b < T, ∀ s : SpaceTime, b < s.1 → f s=0) →
    ρ*(∫ t in (0:ℝ)..T, ∫ y in E t, fderiv ℝ f (t,y) (timeDirection w (t,y))) =
      -(ρ*(∫ y in E0, f (0,y)))

theorem occupation_mono_time (E : ℝ → Set Space) {s t : ℝ} (h : s ≤ t) :
    occupation E s ≤ occupation E t :=
  Measure.restrict_mono_set _ fun _ hx => ⟨⟨hx.1.1,hx.1.2.trans h⟩,hx.2⟩

private theorem sliced_integrable (E : ℝ → Set Space) (t : ℝ) (ht : 0 ≤ t)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) (f : SpaceTime → ℝ)
    (hf : Integrable f (occupation E t)) :
    IntervalIntegrable (fun u => ∫ y in E u, f (u,y)) volume 0 t := by
  let A := {s : SpaceTime | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1}
  have ha : MeasurableSet A := (measurable_fst measurableSet_Icc).inter moving
  have hprod : Integrable (A.indicator f) ((volume : Measure ℝ).prod (volume : Measure Space)) :=
    (integrable_indicator_iff ha).mpr hf
  apply (intervalIntegrable_iff_integrableOn_Ioc_of_le ht).mpr
  apply hprod.integral_prod_left.integrableOn.congr_fun _ measurableSet_Ioc
  intro u hu
  have hu' := Ioc_subset_Icc_self hu
  have mE : MeasurableSet (E u) := moving.preimage (measurable_const.prodMk measurable_id)
  change (∫ y, A.indicator f (u,y)) = ∫ y in E u,f (u,y)
  rw [← integral_indicator mE]
  congr 1
  funext y
  by_cases hy : y ∈ E u <;> simp [A,hu'.1,hu'.2,hy]

theorem timeDirection_bound (w : SpaceTime → H) (s : SpaceTime) :
    ‖timeDirection w s‖ ≤ 1+‖w s‖ := by
  simp [timeDirection,Prod.norm_def]

private theorem timeDirection_meas {μ : Measure SpaceTime} (w : SpaceTime → H)
    (hw : AEStronglyMeasurable w μ) : AEStronglyMeasurable (timeDirection w) μ :=
  aestronglyMeasurable_const.prodMk (hw.prodMk aestronglyMeasurable_const)

theorem spaceTime_test_integrable (E : ℝ → Set Space) (T : ℝ) [IsFiniteMeasure (occupation E T)]
    (w : SpaceTime → H) (hw : Integrable w (occupation E T)) (f : SpaceTime → ℝ)
    (hf : ContDiff ℝ ∞ f) (hc : HasCompactSupport f) :
    Integrable f (occupation E T) ∧
    Integrable (fun s => fderiv ℝ f s (timeDirection w s)) (occupation E T) := by
  obtain ⟨A,ha⟩ := hc.exists_bound_of_continuous hf.continuous
  obtain ⟨B,hb⟩ := (hc.fderiv ℝ).exists_bound_of_continuous (hf.continuous_fderiv (by simp))
  have B0 : 0 ≤ B := (norm_nonneg _).trans (hb 0)
  refine ⟨(integrable_const A).mono' hf.continuous.aestronglyMeasurable (.of_forall ha),?_⟩
  apply (((integrable_const 1).add hw.norm).const_mul B).mono'
    ((ContinuousLinearMap.apply ℝ ℝ).flip.aestronglyMeasurable_comp₂
      (hf.continuous_fderiv (by simp)).aestronglyMeasurable (timeDirection_meas w hw.aestronglyMeasurable))
  filter_upwards with s
  exact ((fderiv ℝ f s).le_opNorm _).trans
    (mul_le_mul (hb s) (timeDirection_bound w s) (norm_nonneg _) B0)

private theorem deriv_time_product (f : SpaceTime → ℝ) (hf : ContDiff ℝ ∞ f)
    (η : ℝ → ℝ) (hη : ContDiff ℝ ∞ η) (w : SpaceTime → H) (s : SpaceTime) :
    fderiv ℝ (fun r : SpaceTime => η r.1*f r) s (timeDirection w s) =
      deriv η s.1*f s + η s.1*fderiv ℝ f s (timeDirection w s) := by
  change fderiv ℝ ((η ∘ Prod.fst)*f) s _ = _
  have he := hη.differentiable (by simp)
  rw [fderiv_mul ((he.comp differentiable_fst).differentiableAt) (hf.differentiable (by simp)).differentiableAt,
    fderiv_comp s he.differentiableAt differentiableAt_fst,fderiv_fst]
  change η s.1 * (fderiv ℝ f s) (timeDirection w s) + f s * deriv η s.1 = _
  rw [add_comm,mul_comm (f s)]

/-- An individual spacetime observable has its absolutely continuous time representative,
obtained directly by applying the distributional patch equation to a time multiplier times
the observable. Both the signed endpoint coefficient and the current come from the actual patch. -/
theorem patch_test_time_representative (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (hT : 0 ≤ T) (hρ : 0 < ρ) (w : SpaceTime → H)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) [IsFiniteMeasure (occupation E T)]
    (hw : Integrable w (occupation E T)) (weak : DistributionalPatch E0 E T ρ w)
    (f : SpaceTime → ℝ) (hf : ContDiff ℝ ∞ f) (hc : HasCompactSupport f) :
    let F := fun t => (∫ y in E0, f (0,y)) +
      ∫ u in (0:ℝ)..t, ∫ y in E u, fderiv ℝ f (u,y) (timeDirection w (u,y))
    AbsolutelyContinuousOnInterval F 0 T ∧ F 0 = (∫ y in E0, f (0,y)) ∧
    (fun t => ∫ y in E t, f (t,y)) =ᵐ[volume.restrict (Icc 0 T)] F := by
  let G := fun s : SpaceTime => fderiv ℝ f s (timeDirection w s)
  let A := fun t => ∫ y in E t,f (t,y)
  let g := fun t => ∫ y in E t,G (t,y)
  obtain ⟨hi,hg⟩ := spaceTime_test_integrable E T w hw f hf hc
  have ai := sliced_integrable E T hT moving f hi
  have gi := sliced_integrable E T hT moving G hg
  apply scalar_time_representative hT ai gi
  intro η hη cut
  obtain ⟨b,hb,hcut⟩ := cut
  let ψ := fun s : SpaceTime => η s.1*f s
  have hψ := weak ψ ((hη.comp contDiff_fst).mul hf) hc.mul_left
    ⟨b,hb,fun s hs => by simp [ψ,hcut _ hs]⟩
  have split : (∫ t in (0:ℝ)..T, ∫ y in E t, fderiv ℝ ψ (t,y) (timeDirection w (t,y))) =
      (∫ t in (0:ℝ)..T, A t * deriv η t) + (∫ t in (0:ℝ)..T, g t * η t) := by
    rw [← intervalIntegral.integral_add (ai.mul_continuousOn (hη.continuous_deriv (by simp)).continuousOn)
      (gi.mul_continuousOn hη.continuous.continuousOn)]
    apply intervalIntegral.integral_congr_ae
    have a := (occupation_fubini E moving T f hi).2
    have b' := (occupation_fubini E moving T G hg).2
    rw [ae_restrict_iff' measurableSet_Icc] at a b'
    filter_upwards [a,b'] with t ha hb' ht
    have htm : t ∈ Icc 0 T := by simpa [uIcc_of_le hT] using uIoc_subset_uIcc ht
    simp_rw [show ∀ y, fderiv ℝ ψ (t,y) (timeDirection w (t,y)) =
      deriv η t*f (t,y)+η t*G (t,y) from fun y => deriv_time_product f hf η hη w (t,y)]
    rw [integral_add ((ha htm).const_mul _) ((hb' htm).const_mul _),
      integral_const_mul,integral_const_mul]
    change _ = _*deriv η t + _*η t
    ring
  rw [split] at hψ
  change ρ*_ = -(ρ*(∫ y in E0, η 0 * f (0,y))) at hψ
  rw [integral_const_mul] at hψ
  change _ = -(∫ y in E0,f (0,y)) * η 0
  apply mul_left_cancel₀ hρ.ne'
  convert hψ using 1
  ring

end
end Vortex
