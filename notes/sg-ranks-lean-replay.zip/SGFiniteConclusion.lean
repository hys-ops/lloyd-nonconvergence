import SGFiniteHarmonic

open MeasureTheory Set Filter Function
open scoped ENNReal BigOperators
namespace Vortex
noncomputable section

private def radiusSq (x : Space) := x.1.1^2+x.1.2^2+x.2^2
private def radiusDeficit (C : ℝ) (x : Space) := max (C-radiusSq x) 0

private theorem coord_norm {J : Set Space} [CompactSpace J] (x : J) :
    ‖stretchedCoordinates J 1 x‖^2 = radiusSq x.val := by
  rw [EuclideanSpace.real_norm_sq_eq,Fin.sum_univ_three]
  change x.val.1.1^2+x.val.1.2^2+(1*x.val.2)^2 = _
  simp [radiusSq]

private theorem mid_norm {J : Set Space} [CompactSpace J] (z : J × J) :
    ‖(1/2 : ℝ) • (stretchedCoordinates J 1 z.1+stretchedCoordinates J 1 z.2)‖^2 =
      radiusSq ((1/2:ℝ) • (z.1.val+z.2.val)) := by
  rw [EuclideanSpace.real_norm_sq_eq,Fin.sum_univ_three]
  change ((1/2:ℝ)*(z.1.val.1.1+z.2.val.1.1))^2+((1/2:ℝ)*(z.1.val.1.2+z.2.val.1.2))^2+
      ((1/2:ℝ)*((1*z.1.val.2)+(1*z.2.val.2)))^2 = _
  simp [radiusSq,smul_eq_mul,mul_add]

private theorem radiusDeficit_integrable (C : ℝ) (μ : Measure Space) [IsFiniteMeasure μ] :
    Integrable (radiusDeficit C) μ := by
  have cont : Continuous (radiusDeficit C) := by unfold radiusDeficit radiusSq; fun_prop
  refine (integrable_const (max C 0)).mono' cont.aestronglyMeasurable (.of_forall fun x => ?_)
  rw [Real.norm_eq_abs,abs_of_nonneg (le_max_right _ _)]
  have pos : 0 ≤ radiusSq x := by unfold radiusSq; positivity
  exact max_le ((sub_le_self C pos).trans (le_max_left _ _)) (le_max_right _ _)

private theorem normalized_fiber_integral {J : Set Space} [CompactSpace J] {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [SecondCountableTopology E]
    (W : ProbabilityMeasure J) (γ : ProbabilityMeasure (J × J)) (p : J × J → J) (cp : Continuous p)
    (A : Set J) (eqm : (W : Measure J) A • (γ : Measure (J × J)).map p = (W : Measure J).restrict A)
    (g : J → E) (cg : Continuous g) :
    (W : Measure J).real A • (∫ z, g (p z) ∂(γ : Measure (J × J))) = ∫ z in A, g z ∂(W : Measure J) := by
  rw [← eqm,integral_smul_measure,integral_map cp.aemeasurable cg.aestronglyMeasurable]
  rfl

private theorem sum_fiber_test {J : Set Space} {N : ℕ} (W : ProbabilityMeasure J)
    (a : J → Fin N) (ma : Measurable a) (f : J → ℝ) (hf : Integrable f (W : Measure J)) :
    (∑ i,∫ y in a ⁻¹' {i},f y ∂(W : Measure J)) = ∫ y,f y ∂(W : Measure J) := by
  rw [← integral_iUnion_fintype (fun i => ma (measurableSet_singleton i)) _ (fun _ => hf.integrableOn)]
  · have full : (⋃ i,a ⁻¹' {i}) = univ := by ext x; simp
    rw [full,setIntegral_univ]
  · intro i j h; exact Disjoint.preimage a (Set.disjoint_singleton.mpr h)

/-- Sum the exact finite coupling inequality over disjoint midpoint winner
cells. The endpoint integrals are the original raw power-cell moments and the
nonnegative radius deficit is integrated only once under the physical law. -/
theorem finite_endpoint_from_label_couplings (J : Set Space) [CompactSpace J]
    (W : ProbabilityMeasure J) (C : ℝ) (radius : ∀ x ∈ J, x.1.1^2+x.1.2^2+x.2^2 ≤ C)
    {N : ℕ} (a b : J → Fin N) (ma : Measurable a) (mb : Measurable b)
    (γ : Fin N → ProbabilityMeasure (J × J)) (winner : Fin N → Set Space)
    (mw : ∀ i, MeasurableSet (winner i)) (dw : Pairwise (Disjoint on winner))
    (ha : ∀ i, (W : Measure J) (a ⁻¹' {i}) • (γ i : Measure (J × J)).map Prod.fst =
      (W : Measure J).restrict (a ⁻¹' {i}))
    (hb : ∀ i, (W : Measure J) (b ⁻¹' {i}) • (γ i : Measure (J × J)).map Prod.snd =
      (W : Measure J).restrict (b ⁻¹' {i}))
    (dom : ∀ i, ENNReal.ofReal (harmonicMass ((W:Measure J).real (a ⁻¹' {i})) ((W:Measure J).real (b ⁻¹' {i}))) •
      (γ i : Measure (J × J)).map (fun z => (1/2:ℝ) • (z.1.val+z.2.val)) ≤
      ((W:Measure J).map Subtype.val).restrict (winner i)) :
    (∑ i, ‖rawMoment W a (stretchedCoordinates J 1) i-rawMoment W b (stretchedCoordinates J 1) i‖^2 /
      ((W : Measure J).real (a ⁻¹' {i})+(W : Measure J).real (b ⁻¹' {i}))) ≤
      C*∑ i, discr ((W : Measure J).real (a ⁻¹' {i})) ((W : Measure J).real (b ⁻¹' {i})) := by
  let I := Fin N
  let A (i : I) := (W : Measure J).real (a ⁻¹' {i})
  let B (i : I) := (W : Measure J).real (b ⁻¹' {i})
  let h (i : I) := harmonicMass (A i) (B i)
  let k := stretchedCoordinates J 1
  let Y (z : J × J) := (1/2:ℝ) • (z.1.val+z.2.val)
  let raw (x : J) := C-‖k x‖^2
  let Ψ := radiusDeficit C
  let T := (W : Measure J).map Subtype.val
  have hn (i : I) : 0 ≤ h i := harmonic_nonneg measureReal_nonneg measureReal_nonneg
  have cY : Continuous Y := by unfold Y; fun_prop
  have cΨ : Continuous Ψ := by unfold Ψ radiusDeficit radiusSq; fun_prop
  have cr : Continuous raw := continuous_const.sub (k.continuous.norm.pow 2)
  have Ψi : Integrable Ψ T := radiusDeficit_integrable C T
  have Ψn (x) : 0 ≤ Ψ x := le_max_right _ _
  have eqr (z : J) : Ψ z.val = raw z := by
    change max _ _ = _
    have bound : radiusSq z.val ≤ C := radius z z.property
    rw [max_eq_left (sub_nonneg.mpr bound)]
    simp [raw,k,coord_norm]
  have intRaw : Integrable raw (W : Measure J) := cr.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  have int_eq : (∫ x, Ψ x ∂T) = ∫ x,raw x ∂(W : Measure J) := by
    rw [integral_map measurable_subtype_coe.aemeasurable cΨ.aestronglyMeasurable]
    simp only [eqr]
  let E (i : I) := ‖rawMoment W a k i-rawMoment W b k i‖^2/(A i+B i)
  let F (i : I) := ∫ x in a ⁻¹' {i},raw x ∂(W : Measure J)
  let H (i : I) := ∫ x in b ⁻¹' {i},raw x ∂(W : Measure J)
  let M (i : I) := ∫ y in winner i, Ψ y ∂T
  have restrictBound (i : I) :
      h i * (∫ z, C-‖(1/2:ℝ) • (k z.1+k z.2)‖^2 ∂(γ i : Measure (J × J))) ≤ M i := by
    let g := fun z : J × J => C-‖(1/2:ℝ) • (k z.1+k z.2)‖^2
    have cg : Continuous g := by unfold g; fun_prop
    have gi : Integrable g (γ i : Measure (J × J)) := cg.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
    have up : Integrable (fun z => Ψ (Y z)) (γ i : Measure (J × J)) := (cΨ.comp cY).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
    have cmp : (∫ z, g z ∂(γ i : Measure (J × J))) ≤ ∫ z, Ψ (Y z) ∂(γ i : Measure (J × J)) := by
      apply integral_mono gi up
      intro z
      change C-‖(1/2:ℝ) • (stretchedCoordinates J 1 z.1+stretchedCoordinates J 1 z.2)‖^2 ≤ max _ _
      rw [mid_norm]; exact le_max_left _ _
    apply (mul_le_mul_of_nonneg_left cmp (hn i)).trans
    have hd := integral_mono_measure (dom i) (.of_forall Ψn) (Ψi.integrableOn (s := winner i))
    rw [integral_smul_measure,ENNReal.toReal_ofReal (hn i),integral_map cY.aemeasurable cΨ.aestronglyMeasurable] at hd
    exact hd
  have frame (i : I) : E i+F i+H i-2*M i ≤ C*discr (A i) (B i) := by
    let g := γ i
    have a1 := normalized_fiber_integral W g _ continuous_fst _ (ha i) k k.continuous
    have b1 := normalized_fiber_integral W g _ continuous_snd _ (hb i) k k.continuous
    have a2 := normalized_fiber_integral W g _ continuous_fst _ (ha i) raw cr
    have b2 := normalized_fiber_integral W g _ continuous_snd _ (hb i) raw cr
    change A i • (∫ z,k z.1 ∂(g : Measure (J × J))) = rawMoment W a k i at a1
    change B i • (∫ z,k z.2 ∂(g : Measure (J × J))) = rawMoment W b k i at b1
    change A i*(∫ z,C-‖k z.1‖^2 ∂(g : Measure (J × J))) = F i at a2
    change B i*(∫ z,C-‖k z.2‖^2 ∂(g : Measure (J × J))) = H i at b2
    have hstep := harmonic_coupling_step g (fun z => k z.1) (fun z => k z.2)
      (k.continuous.comp continuous_fst) (k.continuous.comp continuous_snd)
      (A i) (B i) C measureReal_nonneg measureReal_nonneg
    simp only [a1,b1,a2,b2] at hstep
    change E i + F i + H i - 2*(h i)*(∫ z,C-‖(1/2:ℝ) • (k z.1+k z.2)‖^2 ∂(g : Measure (J × J))) ≤ _ at hstep
    have hr := restrictBound i
    linarith only [hstep,hr]
  have total := Finset.sum_le_sum (s := Finset.univ) (fun i _ => frame i)
  simp only [Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.mul_sum] at total
  have fal : (∑ i,F i) = ∫ x,raw x ∂(W : Measure J) := sum_fiber_test W a ma raw intRaw
  have hal : (∑ i,H i) = ∫ x,raw x ∂(W : Measure J) := sum_fiber_test W b mb raw intRaw
  have msum : (∑ i,M i) ≤ ∫ x,raw x ∂(W : Measure J) := by
    rw [← int_eq,← integral_iUnion_fintype mw dw (fun _ => Ψi.integrableOn)]
    exact setIntegral_le_integral Ψi (.of_forall Ψn)
  change ∑ i,E i ≤ C*∑ i,discr (A i) (B i)
  rw [fal,hal] at total; linarith only [total,msum]

end
end Vortex
