import FiniteCatalogSquare
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

def rankBox := Icc (0 : RankPoint 2) 1
theorem rankBox_compact : IsCompact rankBox := isCompact_Icc
private theorem vec_pair (v : RankPoint 2) : obsVector (vectorObs v)=v := by ext i; fin_cases i <;> rfl
private theorem pair_vec (z : SquareObs) : vectorObs (obsVector z)=z := rfl
private theorem mvect : Continuous obsVector := by
  apply continuous_pi; intro i; fin_cases i <;> simp [obsVector] <;> fun_prop
private theorem mpair : Continuous vectorObs := (continuous_apply 0).prodMk (continuous_apply 1)
private theorem in_box (z : SquareObs) : obsVector z ∈ rankBox ↔ z ∈ unitSquare := by
  change ( (0:RankPoint 2) ≤ obsVector z ∧ obsVector z≤1 ) ↔ _
  constructor
  · rintro ⟨l,h⟩; exact ⟨⟨l 0,h 0⟩,⟨l 1,h 1⟩⟩
  · rintro ⟨l,h⟩
    constructor <;> intro i <;> fin_cases i
    · exact l.1
    · exact h.1
    · exact l.2
    · exact h.2
private theorem clip_in (z : SquareObs) : squareClipObs z ∈ unitSquare := by
  by_cases h : z ∈ unitSquare
  · simp [squareClipObs,h]
  · have e : squareClipObs z=0 := by simp [squareClipObs,h]
    rw [e]; exact ⟨⟨le_rfl,zero_le_one⟩,⟨le_rfl,zero_le_one⟩⟩
private theorem mc : Measurable squareClipObs := by
  classical
  exact measurable_id.piecewise (show MeasurableSet unitSquare from measurableSet_Icc.prod measurableSet_Icc) measurable_const

def encodeSquare (z : SquareObs) : rankBox := ⟨obsVector (squareClipObs z),(in_box _).2 (clip_in z)⟩
def decodeSquare (x : rankBox) := vectorObs x.val
theorem encode_square_meas : Measurable encodeSquare := (mvect.measurable.comp mc).subtype_mk
private theorem mdecode : Continuous decodeSquare := mpair.comp continuous_subtype_val
private theorem decode_in (x : rankBox) : decodeSquare x ∈ unitSquare := by
  apply (in_box _).mp; unfold decodeSquare; rw [vec_pair]; exact x.property
private theorem encdec (x : rankBox) : encodeSquare (decodeSquare x)=x := by
  apply Subtype.ext
  change obsVector (squareClipObs (decodeSquare x))=x.val
  rw [show squareClipObs (decodeSquare x)=decodeSquare x by simp [squareClipObs,decode_in]]
  exact vec_pair _
private theorem decenc (z : SquareObs) (h : z∈unitSquare) : decodeSquare (encodeSquare z)=z := by
  change vectorObs (obsVector (squareClipObs z))=z
  simp [pair_vec,squareClipObs,h]
private theorem square_full : ∀ᵐ z ∂squareBase,z∈unitSquare :=
  ae_restrict_mem (measurableSet_Icc.prod measurableSet_Icc)

def rankBoxBase := squareBase.map encodeSquare
instance squareBox_prob : IsProbabilityMeasure rankBoxBase := by
  have e : squareLaw 0=squareBase := by simp [squareLaw,density]
  have : IsProbabilityMeasure squareBase := e ▸ square_law_probability (θ:=0) (by norm_num)
  constructor; simp [rankBoxBase,Measure.map_apply encode_square_meas MeasurableSet.univ]

theorem box_base_is_lebesgue : rankBoxBase.map Subtype.val=volume.restrict rankBox := by
  rw [rankBoxBase,Measure.map_map measurable_subtype_coe encode_square_meas]
  have h : (fun x => (encodeSquare x).val) =ᵐ[squareBase] obsVector := by
    filter_upwards [square_full] with x hx; simp [encodeSquare,squareClipObs,hx]
  change squareBase.map (fun x => (encodeSquare x).val)=_
  rw [Measure.map_congr h]
  have m : MeasurePreserving obsVector volume volume := by
    let e : (Fin 2 → ℝ) ≃ᵐ ℝ × ℝ := MeasurableEquiv.finTwoArrow
    have he := (volume_preserving_finTwoArrow ℝ).symm e
    exact he
  have t : obsVector ⁻¹' rankBox = unitSquare := Set.ext in_box
  have restricted := m.restrict_preimage (show MeasurableSet rankBox from measurableSet_Icc)
  rw [t] at restricted; exact restricted.map_eq

def boxDensity (θ : ℝ) (y : rankBox) := density θ (decodeSquare y)
private theorem mboxd (θ) : Continuous (boxDensity θ) := (by unfold density; fun_prop : Continuous (density θ)).comp mdecode
def boxForecast (θ : ℕ → ℝ) (ht : ∀ t, |θ t|≤1/2) : Predictions rankBox rankBoxBase := fun t => {
  f := fun q => boxDensity (θ t) q.2
  measurable := (mboxd _).measurable.comp measurable_snd
  nonneg := fun z => (by norm_num : (0:ℝ)≤1/4).trans (actual_density_floor _ _ _ (ht t))
  integrable := by
    intro h
    let _ : CompactSpace rankBox := isCompact_iff_compactSpace.mp rankBox_compact
    exact (mboxd _).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  mass := by
    intro h
    change (∫ z,boxDensity (θ t) z ∂squareBase.map encodeSquare)=1
    rw [integral_map encode_square_meas.aemeasurable (mboxd _).aestronglyMeasurable,←square_density_normalized (θ t)]
    apply integral_congr_ae
    filter_upwards [square_full] with z hz
    rw [boxDensity,decenc z hz] }

private theorem weighted_map_square (θ : ℝ) :
    (squareLaw θ).map encodeSquare = rankBoxBase.withDensity (fun y => ENNReal.ofReal (boxDensity θ y)) := by
  apply Measure.ext_of_lintegral
  intro f mf
  have md : Measurable (fun z => ENNReal.ofReal (density θ z)) := by unfold density; fun_prop
  have mb := (mboxd θ).measurable.ennreal_ofReal
  have g : Measurable (fun z => f (encodeSquare z)) := mf.comp encode_square_meas
  rw [lintegral_map mf encode_square_meas,squareLaw,lintegral_withDensity_eq_lintegral_mul _ md g,
    lintegral_withDensity_eq_lintegral_mul _ mb mf,rankBoxBase,lintegral_map (mb.mul mf) encode_square_meas]
  apply lintegral_congr_ae; filter_upwards [square_full] with z hz
  simp only [Pi.mul_apply,boxDensity,decenc z hz]

/-- Relabel all chronological observations using the compact chart. -/
def encodeHistory : (n : ℕ) → History SquareObs n → History rankBox n
  | 0, _ => PUnit.unit
  | n+1, x => (encodeHistory n x.1,encodeSquare x.2)
private theorem mencHist : ∀ n, Measurable (encodeHistory n)
  | 0 => measurable_const
  | n+1 => ((mencHist n).comp measurable_fst).prodMk (encode_square_meas.comp measurable_snd)

private theorem box_paths_succ (θ : ℕ → ℝ) (hθ) (n : ℕ) :
    pathMeasure (boxForecast θ hθ) (n+1) = (pathMeasure (boxForecast θ hθ) n).prod ((squareLaw (θ n)).map encodeSquare) := by
  let a := boxForecast θ hθ
  obtain ⟨m,nn,_,_⟩ := history_is_density a n
  have mb := (mboxd (θ n)).measurable.ennreal_ofReal
  rw [weighted_map_square]
  change ((historyBase rankBoxBase n).prod rankBoxBase).withDensity
    (fun z : History rankBox n × rankBox => ENNReal.ofReal (historyDensity a n z.1*boxDensity (θ n) z.2)) =
    ((historyBase rankBoxBase n).withDensity (fun x => ENNReal.ofReal (historyDensity a n x))).prod _
  rw [prod_withDensity m.ennreal_ofReal mb]
  congr 1; funext z; exact ENNReal.ofReal_mul (nn z.1)

theorem hard_history_preserving (θ : ℕ → ℝ) (hθ : ∀ t, |θ t|≤1/2) :
    ∀ n,MeasurePreserving (encodeHistory n) (pathMeasure (squareSequence θ hθ) n) (pathMeasure (boxForecast θ hθ) n)
  | 0 => by
    refine ⟨measurable_const,?_⟩
    change ((@Measure.dirac PUnit ⊤ PUnit.unit).withDensity (fun _ => ENNReal.ofReal 1)).map _ =
      (@Measure.dirac PUnit ⊤ PUnit.unit).withDensity (fun _ => ENNReal.ofReal 1)
    simp only [ENNReal.ofReal_one,withDensity_const,one_smul]; exact Measure.map_dirac' (mencHist 0) _
  | n+1 => by
    let _ : IsProbabilityMeasure (squareLaw (θ n)) := square_law_probability (hθ n)
    have : IsProbabilityMeasure squareBase := by
      rw [←show squareLaw 0=squareBase by simp [squareLaw,density]]; exact square_law_probability (by norm_num)
    rw [square_sequence_paths_succ,box_paths_succ]
    exact (hard_history_preserving θ hθ n).prod (⟨encode_square_meas,rfl⟩ : MeasurePreserving encodeSquare (squareLaw (θ n)) _)

def boxRank (θ : ℝ) (x : rankBox) := obsVector (squareMap θ (decodeSquare x))
private theorem brCont (θ : ℝ) : Continuous (boxRank θ) :=
  mvect.comp ((show Continuous (squareMap θ) by unfold squareMap perturb; fun_prop).comp mdecode)
private theorem brIn (θ : ℝ) (ht : |θ|≤1/2) (x : rankBox) : boxRank θ x∈rankBox := by
  apply (in_box _).2
  exact (squareRank_bijection _ ht).2 ▸ mem_image_of_mem _ (decode_in x)
def boxTarget : ProbabilityMeasure rankBox := ⟨rankBoxBase,inferInstance⟩

theorem boxRank_cert (θ : ℕ → ℝ) (ht : ∀ t, |θ t|≤1/2) (t : ℕ) (h : History rankBox t) :
    CertifiedRank (((boxForecast θ ht) t).law h) boxTarget (boxRank (θ t)) := by
  classical
  let g : rankBox → rankBox := fun x => ⟨boxRank (θ t) x,brIn _ (ht t) x⟩
  let P := ((boxForecast θ ht) t).law h
  have cG : Continuous g := (brCont _).subtype_mk _
  have mG := cG.measurable
  let π := P.map (fun y => (y,g y))
  have cg : Measurable (fun y : rankBox => (y,g y)) := measurable_id.prodMk mG
  have graph : (π : Measure (rankBox × rankBox))=(P : Measure rankBox).map (fun y => (y,g y)) := rfl
  have psrc : (P : Measure rankBox)=(squareLaw (θ t)).map encodeSquare := (weighted_map_square _).symm
  have mm : Measurable (squareMap (θ t)) := by unfold squareMap perturb; fun_prop
  have mapg : (P : Measure rankBox).map g=rankBoxBase := by
    rw [psrc,Measure.map_map mG encode_square_meas]
    have e : g ∘ encodeSquare =ᵐ[squareLaw (θ t)] encodeSquare ∘ squareMap (θ t) := by
      filter_upwards [(withDensity_absolutelyContinuous _ _).ae_le square_full] with z hz
      apply Subtype.ext
      have bz : squareMap (θ t) z ∈ unitSquare := (squareRank_bijection _ (ht t)).2 ▸ mem_image_of_mem _ hz
      change obsVector (squareMap _ (decodeSquare (encodeSquare z))) = obsVector (squareClipObs (squareMap _ z))
      simp [decenc z hz,squareClipObs,bz]
    have push : (squareLaw (θ t)).map (squareMap (θ t))=squareBase := squareRank_pushforward _ (ht t)
    rw [Measure.map_congr e,← Measure.map_map encode_square_meas mm,push]
    rfl
  let graphSet := {z : rankBox × rankBox | z.2=g z.1}
  have closed : IsClosed graphSet := isClosed_eq continuous_snd (cG.comp continuous_fst)
  have aegraph : graphSet ∈ ae (π : Measure (rankBox × rankBox)) := by
    rw [graph]
    exact (ae_map_iff cg.aemeasurable closed.measurableSet).mpr (.of_forall (fun _ => rfl))
  have ongraph : ∀ z∈(π : Measure (rankBox × rankBox)).support,z.2=g z.1 :=
    fun _ hz => Measure.support_subset_of_isClosed closed aegraph hz
  have cyc : cyclicSupport squareCost π := by
    intro k σ z supp
    obtain ⟨φ,tangent⟩ := square_rank_support (θ t) (ht t)
    let X (i : Fin k) := decodeSquare (z i).1
    let V (i : Fin k) := squareRank (θ t) (X i)
    let F (i : Fin k) := 2*φ (X i)-2*((X i).1*(V i).1+(X i).2*(V i).2)+(V i).1^2+(V i).2^2
    have v z' (hz : z' ∈ (π : Measure (rankBox × rankBox)).support) : z'.2.val = obsVector (squareRank (θ t) (decodeSquare z'.1)) :=
      congrArg Subtype.val (ongraph z' hz)
    have row (i j : Fin k) : squareCost ((z i).1,(z j).2) = squareCost2 (X i) (V j) := by
      unfold squareCost normSq diff; rw [Fin.sum_univ_two,v _ (supp j)]; rfl
    have bound (i : Fin k) : squareCost (z i) ≤ squareCost ((z i).1,(z (σ i)).2) + (F i - F (σ i)) := by
      rw [← Prod.eta (z i),row i i,row]
      unfold F squareCost2
      have low := tangent (X i) (X (σ i))
      change (V (σ i)).1*((X i).1-(X (σ i)).1)+(V (σ i)).2*((X i).2-(X (σ i)).2) ≤ _ at low
      nlinarith only [low]
    have b := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => bound i)
    simpa only [Finset.sum_add_distrib,Finset.sum_sub_distrib,Equiv.sum_comp σ F,sub_self,add_zero] using b
  refine ⟨π,⟨?_,?_,cyc⟩,?_⟩
  · apply ProbabilityMeasure.toMeasure_injective
    change ((π : Measure (rankBox × rankBox)).map Prod.fst)=P
    rw [graph,Measure.map_map measurable_fst cg]; exact Measure.map_id
  · apply ProbabilityMeasure.toMeasure_injective
    change ((π : Measure (rankBox × rankBox)).map Prod.snd)=rankBoxBase
    rw [graph,Measure.map_map measurable_snd cg]; exact mapg
  · have inc : Measurable (fun z : rankBox × rankBox => (z.1,z.2.val)) :=
      measurable_fst.prodMk (measurable_subtype_coe.comp measurable_snd)
    rw [graph,Measure.map_map inc cg]
    rfl

def boxedCatalog {l M : ℕ} (index : Fin M → Word l) : RankCatalog rankBox rankBoxBase 2 M where
  forecast j := boxForecast (wordParameter l (index j)) (word_parameter_bound l (index j))
  rank j n z := boxRank (wordParameter l (index j) n) z.2

/-- The hard catalog lives on the identical compact square used in the upper
bound. Every compact-chart policy pulls back to an ambient policy with the
same expected loss at every member. -/
theorem box_catalog_minimax_lower_of_ambient {M l : ℕ} (index : Fin M → Word l) (T : ℕ) :
    catalogMinimax (squareWordCatalog index) T ≤ catalogMinimax (boxedCatalog index) T := by
  apply le_iInf; intro e
  let pull : CatalogPolicy SquareObs 2 := ⟨fun n z => e.val n (encodeHistory n z.1,encodeSquare z.2),
    fun n => (e.property n).comp (((mencHist n).comp measurable_fst).prodMk (encode_square_meas.comp measurable_snd))⟩
  apply iInf_le_of_le pull
  apply iSup_le; intro j
  apply le_iSup_of_le j
  apply le_of_eq; apply Finset.sum_congr rfl; intro n _
  let θ := wordParameter l (index j)
  let ht := word_parameter_bound l (index j)
  let f (p : History rankBox n × rankBox) :=
    ENNReal.ofReal (normSq (diff (boxRank (θ n) p.2) (e.val n p)))
  have mf : Measurable f := by
    unfold f
    apply ENNReal.measurable_ofReal.comp
    unfold normSq diff
    apply Finset.measurable_sum; intro i _
    exact (((measurable_pi_apply i).comp ((brCont _).measurable.comp measurable_snd)).sub
      ((measurable_pi_apply i).comp (e.property n))).pow_const 2
  have transport := lintegral_map (f:=f) (μ:=pathMeasure (squareSequence θ ht) (n+1)) mf (mencHist (n+1))
  have move := congrArg (fun m : Measure (History rankBox (n+1)) => ∫⁻ z,f z ∂m)
    (hard_history_preserving θ ht (n+1)).map_eq
  exact transport.symm.trans move

theorem rankBox_radius (u : rankBox) : normSq u.val≤2 := by
  have h := u.property
  change (0:RankPoint 2)≤u.val ∧ u.val≤1 at h
  obtain ⟨a,b⟩ := h
  have i (j : Fin 2) : (u.val j)^2 ≤ 1 := by simpa only [sq,one_mul,Pi.one_apply] using mul_self_le_mul_self (a j) (b j)
  unfold normSq; rw [Fin.sum_univ_two]; linarith [i 0,i 1]

/-- The statistical problem consists of all M-tuples of normalized predictable
densities on the compact square and bounded certified versions of their ranks. -/
def AdmissibleSquareCatalog (M : ℕ) := {C : RankCatalog rankBox rankBoxBase 2 M //
    (∀ j n,Measurable (C.rank j n)) ∧ (∀ j n z,normSq (C.rank j n z)≤2) ∧
    ∀ j n h,CertifiedRank ((C.forecast j n).law h) boxTarget (fun y => C.rank j n (h,y))}

theorem boxed_catalog_admissible {M l : ℕ} (index : Fin M → Word l) :
    ∃ C : AdmissibleSquareCatalog M,C.val=boxedCatalog index := by
  refine ⟨⟨boxedCatalog index,?_,?_,?_⟩,rfl⟩
  · intro j n; exact (brCont _).measurable.comp measurable_snd
  · intro j n z; exact rankBox_radius ⟨_,brIn _ (word_parameter_bound l (index j) n) z.2⟩
  · intro j n h; exact boxRank_cert _ (word_parameter_bound l (index j)) n h

end
end SequentialRanks
