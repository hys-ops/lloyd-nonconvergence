import ConditionalRank
import Mathlib.MeasureTheory.Measure.Support

open MeasureTheory ProbabilityTheory Filter Set
open scoped Topology BigOperators
namespace SequentialRanks
noncomputable section

/-- A closed constraint on n-tuples from a support defines a weakly closed
class of probability measures. A tuple outside the constraint is detected by
n open balls of positive mass. -/
theorem closed_support_tuple {Z : Type*} [MetricSpace Z] [SecondCountableTopology Z]
    [MeasurableSpace Z] [BorelSpace Z] (n : ℕ) (F : Set (Fin n → Z)) (closedF : IsClosed F) :
    IsClosed {π : ProbabilityMeasure Z | ∀ z : Fin n → Z,
      (∀ i, z i ∈ (π : Measure Z).support) → z ∈ F} := by
  classical
  apply isOpen_compl_iff.mp
  apply isOpen_iff_mem_nhds.mpr
  intro π hπ
  change ¬ (∀ z : Fin n → Z, (∀ i, z i ∈ (π : Measure Z).support) → z ∈ F) at hπ
  push Not at hπ
  obtain ⟨z,source,hz⟩ := hπ
  obtain ⟨r,hr,off⟩ := Metric.mem_nhds_iff.mp (closedF.isOpen_compl.mem_nhds hz)
  let N (i : Fin n) : Set (ProbabilityMeasure Z) := {q | 0 < (q : Measure Z) (Metric.ball (z i) r)}
  have openN (i : Fin n) : IsOpen (N i) := by
    have ls : LowerSemicontinuous (fun q : ProbabilityMeasure Z => (q : Measure Z) (Metric.ball (z i) r)) :=
      lowerSemicontinuous_iff_le_liminf.mpr fun q =>
        ProbabilityMeasure.le_liminf_measure_open_of_tendsto (tendsto_id (x := nhds q)) Metric.isOpen_ball
    exact ls.isOpen_preimage 0
  have member : π ∈ ⋂ i, N i := mem_iInter.mpr fun i =>
    (Measure.mem_support_iff_forall _).mp (source i) _ (Metric.ball_mem_nhds _ hr)
  filter_upwards [(isOpen_iInter_of_finite openN).mem_nhds member] with q hq
  change ¬ (∀ z : Fin n → Z, (∀ i, z i ∈ (q : Measure Z).support) → z ∈ F)
  intro assumed
  have ex (i : Fin n) := Measure.nonempty_inter_support_of_pos (mem_iInter.mp hq i : q ∈ N i)
  choose v hv using ex
  have near : v ∈ Metric.ball z r := (dist_pi_lt_iff hr).mpr (fun i => (hv i).1)
  exact off near (assumed v (fun i => (hv i).2))

def cyclicSupport {Y K : Type*} [TopologicalSpace Y] [TopologicalSpace K]
    [MeasurableSpace Y] [MeasurableSpace K] (c : Y × K → ℝ) (π : ProbabilityMeasure (Y × K)) : Prop :=
  ∀ (n : ℕ) (σ : Equiv.Perm (Fin n)) (z : Fin n → Y × K),
    (∀ i, z i ∈ (π : Measure (Y × K)).support) →
    ∑ i, c (z i) ≤ ∑ i, c ((z i).1,(z (σ i)).2)

/-- Stability of cyclical monotonicity under weak convergence for continuous
costs. This is used for the squared Euclidean cost on compact supports. -/
theorem closed_cyclicSupport {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [SecondCountableTopology Y] [SecondCountableTopology K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) :
    IsClosed {π : ProbabilityMeasure (Y × K) | cyclicSupport c π} := by
  let F (n : ℕ) (σ : Equiv.Perm (Fin n)) : Set (Fin n → Y × K) :=
    {z | ∑ i, c (z i) ≤ ∑ i, c ((z i).1,(z (σ i)).2)}
  have closedF (n : ℕ) (σ : Equiv.Perm (Fin n)) : IsClosed (F n σ) := by
    apply isClosed_le <;> fun_prop
  convert! isClosed_iInter (fun n => isClosed_iInter (fun σ =>
    closed_support_tuple n (F n σ) (closedF n σ))) using 1
  ext π
  simp [cyclicSupport,F]

def certifiedPlan {Y K : Type*} [MetricSpace Y] [MetricSpace K]
    [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (c : Y × K → ℝ) (source : ProbabilityMeasure Y) (target : ProbabilityMeasure K)
    (π : ProbabilityMeasure (Y × K)) : Prop :=
  π.map Prod.fst = source ∧
  π.map Prod.snd = target ∧ cyclicSupport c π

/-- From the static existence and uniqueness of a cyclically monotone coupling
for each marginal pair, derive continuity of the chosen plans. -/
theorem continuous_cyclic_selector {L Y K : Type*} [TopologicalSpace L]
    [MetricSpace Y] [MetricSpace K] [SecondCountableTopology Y] [SecondCountableTopology K]
    [CompactSpace Y] [CompactSpace K] [MeasurableSpace Y] [MeasurableSpace K] [BorelSpace Y] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) (source : L → ProbabilityMeasure Y)
    (hs : Continuous source) (target : ProbabilityMeasure K)
    (uniquePlan : ∀ ℓ, ∃! π, certifiedPlan c (source ℓ) target π) :
    ∃ π : L → ProbabilityMeasure (Y × K), Continuous π ∧ ∀ ℓ, certifiedPlan c (source ℓ) target (π ℓ) := by
  classical
  choose π cert unique using uniquePlan
  refine ⟨π,continuous_of_isClosed_graph ?_,cert⟩
  have a := (ProbabilityMeasure.continuous_map (f := (Prod.fst : Y × K → Y)) continuous_fst)
  have b := (ProbabilityMeasure.continuous_map (f := (Prod.snd : Y × K → K)) continuous_snd)
  have closed := (isClosed_eq (a.comp (continuous_snd : Continuous (Prod.snd : L × ProbabilityMeasure (Y × K) → _)))
    (hs.comp continuous_fst)).inter ((isClosed_eq (b.comp continuous_snd) (continuous_const (y := target))).inter
    ((closed_cyclicSupport c hc).preimage continuous_snd))
  convert! closed using 1
  ext z
  change π z.1 = z.2 ↔ certifiedPlan c (source z.1) target z.2
  exact ⟨fun h => h ▸ cert z.1,fun h => (unique z.1 z.2 h).symm⟩

end
end SequentialRanks
