import FiniteCatalogChart
import StaticRankSubtype
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

/-- Uniform finite-catalog minimax upper bound, using only the original static
log-concave reference geometry and the normalized predictive laws. The bounded
certified ranks appearing here specify the loss, i.e. the decision problem. -/
theorem public_catalog_minimax_upper {d M : ℕ} [Nonempty (Fin M)] (A B : Set (RankPoint d))
    (ha : IsCompact A) (hb : IsCompact B) [Nonempty B] (ν : Measure A) [SFinite ν]
    (base : ν.map Subtype.val = volume.restrict A) (target : ProbabilityMeasure B)
    (w : RankPoint d → ℝ) (wn : ∀ x,0≤w x)
    (conc : ConcaveOn ℝ {x | 0<w x} (fun x => Real.log (w x)))
    (ref : (target : Measure B).map Subtype.val=weighted volume w)
    (R : ℝ) (ball : ∀ k ∈ B,normSq k≤R^2)
    (C : RankCatalog A ν d M) (T : ℕ)
    (mr : ∀ j t, Measurable (C.rank j t)) (br : ∀ j t z,normSq (C.rank j t z) ≤ R^2)
    (cert : ∀ j t h,CertifiedRank ((C.forecast j t).law h) target (fun y => C.rank j t (h,y))) :
    ∃ e : CatalogPolicy A d,
      (∀ t h,CertifiedRank ((listForecast C.forecast t).law h) target (fun y => e.val t (h,y))) ∧
      (∀ j,catalogRisk C e T j ≤ ENNReal.ofReal (min (4*R^2*T) (16*R^2*Real.log M))) ∧
      catalogMinimax C T ≤ ENNReal.ofReal (min (4*R^2*T) (16*R^2*Real.log M)) := by
  apply catalog_minimax_upper A B ha hb ν target R ball C T
    (base ▸ Measure.restrict_le_self.absolutelyContinuous) mr br cert
  intro j t _ h _ v mv cv
  exact subtype_rank_midpoint A B ha hb ν base target w wn conc ref (C.forecast j t) (listForecast C.forecast t)
    h h _ _ ((mr j t).comp (measurable_const.prodMk measurable_id)) mv (cert j t h) cv

/-- Every list of predictive densities in the square model has a bounded
jointly measurable certified version, so admissibility loses no catalog of laws. -/
theorem square_catalog_versions {M : ℕ} (a : Fin M → Predictions rankBox rankBoxBase) :
    ∃ C : AdmissibleSquareCatalog M,C.val.forecast=a := by
  let _ : Nonempty rankBox := nonempty_of_isProbabilityMeasure rankBoxBase
  have ball (k : RankPoint 2) (hk : k∈rankBox) : normSq k ≤ (Real.sqrt 2)^2 := by
    rw [Real.sq_sqrt (by norm_num : (0:ℝ)≤2)]; exact rankBox_radius ⟨k,hk⟩
  choose u mu bu cert using fun j n => forecast_rank_selector rankBox rankBox
    rankBox_compact rankBox_compact rankBoxBase boxTarget (Real.sqrt 2) ball (a j n)
    (box_base_is_lebesgue ▸ Measure.restrict_le_self.absolutelyContinuous)
  let C : RankCatalog rankBox rankBoxBase 2 M := ⟨a,u⟩
  refine ⟨⟨C,mu,?_,cert⟩,rfl⟩
  intro j n z
  exact (bu j n z).trans_eq (Real.sq_sqrt (by norm_num : (0:ℝ)≤2))

/-- Worst admissible list on the fixed square, then best policy knowing the
catalog, then worst member of the chosen catalog. -/
def worstSquareCatalogRisk (T M : ℕ) : ℝ≥0∞ :=
  ⨆ C : AdmissibleSquareCatalog M,catalogMinimax C.val T

/-- Both directions refer to exactly the same worst-catalog decision problem,
all normalized sequential densities on the same square, and its uniform
reference. The ambient radius is √2, including boundary points. -/
theorem worst_square_catalog_minimax (T M : ℕ) (pos : M ≠ 0) :
    (↑(min T (Nat.log 2 M)) : ℝ≥0∞)*singleFloor ≤ worstSquareCatalogRisk T M ∧
    worstSquareCatalogRisk T M ≤ ENNReal.ofReal (min (8*(T:ℝ)) (32*Real.log M)) := by
  let _ : Nonempty (Fin M) := ⟨⟨0,Nat.pos_of_ne_zero pos⟩⟩
  let _ : Nonempty rankBox := nonempty_of_isProbabilityMeasure rankBoxBase
  constructor
  · obtain ⟨index,_,lb⟩ := square_catalog_minimax_lower T M pos
    obtain ⟨C,eq⟩ := boxed_catalog_admissible index
    apply le_iSup_of_le C
    rw [eq]; exact lb.trans (box_catalog_minimax_lower_of_ambient index T)
  · apply iSup_le; intro C
    let w : RankPoint 2 → ℝ := rankBox.indicator (fun _ => 1)
    have wn x : 0 ≤ w x := Set.indicator_nonneg (fun _ _ => zero_le_one) x
    have positive : {x | 0<w x}=rankBox := by
      ext x; by_cases hx : x∈rankBox <;> simp [w,hx]
    have conc : ConcaveOn ℝ {x | 0<w x} (fun x => Real.log (w x)) := by
      have eg : (fun x => Real.log (w x)) = fun _ => (0:ℝ) := by
        ext x; by_cases hx : x∈rankBox <;> simp [w,hx]
      rw [positive,eg]; exact concaveOn_const 0 (convex_Icc _ _)
    have ref : (boxTarget : Measure rankBox).map Subtype.val=weighted volume w := by
      change rankBoxBase.map Subtype.val=volume.withDensity (fun x => ENNReal.ofReal (w x))
      rw [box_base_is_lebesgue,←withDensity_indicator_one (μ:=volume) (s:=rankBox) measurableSet_Icc]
      congr 1; funext x; by_cases hx : x∈rankBox <;> simp [w,hx]
    have ball (k : RankPoint 2) (hk : k∈rankBox) : normSq k ≤ (Real.sqrt 2)^2 := by
      rw [Real.sq_sqrt (by norm_num : (0:ℝ)≤2)]; exact rankBox_radius ⟨k,hk⟩
    obtain ⟨_,_,_,ub⟩ := public_catalog_minimax_upper rankBox rankBox rankBox_compact rankBox_compact
      rankBoxBase box_base_is_lebesgue boxTarget w wn conc ref (Real.sqrt 2) ball C.val T
      C.property.1 (fun j n z => (C.property.2.1 j n z).trans_eq (Real.sq_sqrt (by norm_num : (0:ℝ)≤2)).symm)
      C.property.2.2
    simpa only [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),show (4:ℝ)*2=8 by norm_num,show (16:ℝ)*2=32 by norm_num] using ub
end
end SequentialRanks
