import StaticRankBridge
import RankMintyConvex

open MeasureTheory Set Matrix Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The midpoint of the identity and an optimal map between two bounded densities.
This is the estimate used for a single pair of uniform power cells. -/
theorem cell_midpoint_density_area {d : ℕ} (p q : RankPoint d → ℝ) (U : RankPoint d → RankPoint d)
    (C D : ℝ) (mp : Measurable p) (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x)
    (pc : ∀ x, p x ≤ C) (qd : ∀ x, q x ≤ D) (mu : Measurable U)
    (law : (weighted volume p).map U = weighted volume q)
    (G : Set (RankPoint d)) (mg : MeasurableSet G) (cover : ∀ᵐ x ∂volume, 0 < p x → x ∈ G)
    (a : RankPoint d → RankDifferential d) (reg : ∀ x ∈ G, HasFDerivWithinAt U (a x) G x)
    (iu : InjOn U G) (monoG : RankMonotoneOn U G)
    (psd : ∀ x ∈ G, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef) :
    (weighted volume p).map (fun x => mid x (U x)) ≤ ENNReal.ofReal (Real.sqrt C*Real.sqrt D) • volume := by
  let M := fun x => mid x (U x)
  let I : RankDifferential d := ContinuousLinearMap.id ℝ _
  let F := fun x => (1/2:ℝ) • (I+a x)
  have mm : Measurable M := by unfold M mid; fun_prop
  have de (x) (hx : x∈G) : HasFDerivWithinAt M (F x) G x := by
    have mEq : M = fun x => (1/2:ℝ) • (x+U x) := by ext x j; dsimp [M,mid]; ring
    rw [mEq]; exact ((hasFDerivWithinAt_id x G).add (reg x hx)).const_smul (1/2:ℝ)
  obtain ⟨back,_,inv⟩ := minty_inverse_extension U G monoG
  have im : InjOn M G := by
    intro x hx y hy same
    have eqn : x+U x = y+U y := by funext j; have h := congrFun same j; change (x j+U x j)/2=(y j+U y j)/2 at h; change x j+U x j=y j+U y j; linarith only [h]
    rw [←inv x hx,eqn,inv y hy]
  have eqA := endpoint_density_le_jacobian p q U a G mg mp mu qn law reg iu
  have point : ∀ᵐ x ∂volume.restrict G, p x ≤ (Real.sqrt C*Real.sqrt D)*|(F x).det| := by
    filter_upwards [eqA,ae_restrict_mem (μ := volume) mg] with x hx g
    have ps := psd x g
    have hdet := determinant_midpoint (Matrix.PosSemidef.one (n := Fin d) (R := ℝ)) ps
    have eqF : (F x).det = ((1/2:ℝ) • (1+LinearMap.toMatrix' (a x).toLinearMap)).det := by
      change LinearMap.det ((1/2:ℝ) • (I+a x)).toLinearMap = _
      rw [←LinearMap.det_toMatrix']
      change (((1/2:ℝ) • (LinearMap.toMatrix' (LinearMap.id : RankPoint d →ₗ[ℝ] RankPoint d)+_))).det=_
      rw [LinearMap.toMatrix'_id]; congr 3
    rw [←eqF,Matrix.det_one,Real.sqrt_one,one_mul,LinearMap.det_toMatrix'] at hdet
    have non : 0 ≤ (a x).det := by simpa only [LinearMap.det_toMatrix'] using ps.det_nonneg
    rw [abs_of_nonneg non] at hx
    have d1 := Real.sqrt_le_sqrt (pc x)
    have d2 := Real.sqrt_le_sqrt (hx.trans (mul_le_mul_of_nonneg_left (qd _) non))
    rw [Real.sqrt_mul non] at d2
    have k := mul_le_mul d1 d2 (Real.sqrt_nonneg _) (Real.sqrt_nonneg C)
    rw [←Real.sq_sqrt (pn x)]
    calc
      _ ≤ Real.sqrt C*(Real.sqrt (a x).det * Real.sqrt D) := by simpa [pow_two] using k
      _ = (Real.sqrt C*Real.sqrt D)*Real.sqrt (a x).det := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (hdet.trans (le_abs_self _)) (by positivity)
  apply Measure.le_iff.mpr
  intro s ms
  rw [Measure.map_apply mm ms,weighted,withDensity_apply _ (mm ms),Measure.smul_apply,smul_eq_mul]
  let f := fun x => ENNReal.ofReal (p x)
  have cut : f =ᵐ[volume] G.indicator f := by
    classical
    filter_upwards [cover] with x hx
    by_cases h : x∈G
    · simp [h]
    · simp [h,f,ENNReal.ofReal_eq_zero.mpr (le_of_not_gt fun hp => h (hx hp))]
  change (∫⁻ x in M ⁻¹' s, f x) ≤ _
  rw [lintegral_congr_ae (ae_restrict_of_ae cut),lintegral_indicator mg,Measure.restrict_restrict mg]
  let T := G ∩ M ⁻¹' s
  have mt : MeasurableSet T := mg.inter (mm ms)
  have tg : T ⊆ G := inter_subset_left
  have hh := lintegral_abs_det_fderiv_eq_addHaar_image volume mt (fun x hx => (de x (tg hx)).mono tg) (im.mono tg)
  let k := ENNReal.ofReal (Real.sqrt C*Real.sqrt D)
  calc
    _ ≤ ∫⁻ x in T,k*ENNReal.ofReal |(F x).det| := by
      apply lintegral_mono_ae
      filter_upwards [ae_mono (Measure.restrict_mono_set _ tg) point] with x hx
      exact (ENNReal.ofReal_le_ofReal hx).trans_eq (ENNReal.ofReal_mul (by positivity))
    _ = k * volume (M '' T) := by rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top,hh]
    _ ≤ _ := mul_le_mul_right (measure_mono (image_subset_iff.mpr (show T ⊆ M ⁻¹' s from inter_subset_right))) _
end
end SequentialRanks
