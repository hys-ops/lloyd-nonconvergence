import SliceTransport

open MeasureTheory Set
open scoped Topology ContDiff
namespace Vortex
noncomputable section

/-- Unweighted patch occupation on the physical spacetime slab. Multiplication
by the single positive patch density gives the mass occupation measure. -/
def occupation (E : ℝ → Set Space) (t : ℝ) : Measure (ℝ × Space) :=
  volume.restrict {s | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1}

private def timeBump (t : ℝ) : ContDiffBump (0 : ℝ) :=
  ⟨|t|+1,|t|+2,by positivity,by linarith⟩

private theorem time_flat {s t : ℝ} (hs : s ∈ Icc 0 t) :
    (timeBump t : ℝ → ℝ) =ᶠ[nhds s] fun _ => (1:ℝ) := by
  apply (timeBump t).eventuallyEq_one_of_mem_ball
  rw [Metric.mem_ball,Real.dist_eq,sub_zero,abs_of_nonneg hs.1]
  change s < |t|+1
  linarith [hs.2,le_abs_self t]

/-- The full two-trace spacetime weak equation. Its tests may depend on time
and on all three spatial coordinates. The velocity has zero vertical component. -/
def WeakPatchEquation (E0 : Set Space) (E : ℝ → Set Space) (t : ℝ) (ρ : ℝ)
    (w : ℝ × Space → H) : Prop :=
  ∀ f : ℝ × Space → ℝ, ContDiff ℝ ∞ f → HasCompactSupport f →
    ρ*(∫ y in E t, f (t,y)) - ρ*(∫ y in E0, f (0,y)) =
      ρ*(∫ s, fderiv ℝ f s ((1:ℝ),(w s,0)) ∂occupation E t)

private theorem tensor_compact {α β : Type*} [TopologicalSpace α] [TopologicalSpace β]
    {a : α → ℝ} {b : β → ℝ} (ha : HasCompactSupport a) (hb : HasCompactSupport b) :
    HasCompactSupport (fun s : α × β => a s.1*b s.2) := by
  apply (ha.prod hb).of_isClosed_subset (isClosed_tsupport _)
  apply closure_minimal _ (isClosed_tsupport a |>.prod (isClosed_tsupport b))
  intro s hs
  exact ⟨subset_tsupport a (left_ne_zero_of_mul (show a s.1*b s.2 ≠ 0 from hs)),
    subset_tsupport b (right_ne_zero_of_mul (show a s.1*b s.2 ≠ 0 from hs))⟩

/-- Remove the time cutoff on the actual slab and cancel the common density. -/
theorem horizontal_trace_of_weak_patch (E0 : Set Space) (E : ℝ → Set Space) (t ρ : ℝ)
    (ht : 0 ≤ t) (hρ : 0 < ρ) (w : ℝ × Space → H)
    (moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1})
    (eqn : WeakPatchEquation E0 E t ρ w) : HorizontalTrace E0 (E t) (occupation E t) w := by
  intro f hf hc
  let d := timeBump t
  let F := fun s : ℝ × Space => d s.1*f s.2
  have smooth : ContDiff ℝ ∞ F := (d.contDiff.comp contDiff_fst).mul (hf.comp contDiff_snd)
  have h := eqn F smooth (tensor_compact d.hasCompactSupport hc)
  have a0 : d 0=1 := (time_flat (t := t) (s := 0) ⟨le_rfl,ht⟩).eq_of_nhds
  have at' : d t=1 := (time_flat (t := t) (s := t) ⟨ht,le_rfl⟩).eq_of_nhds
  have dm : MeasurableSet {s : ℝ × Space | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1} :=
    (measurable_fst measurableSet_Icc).inter moving
  have hi : (∫ s, fderiv ℝ F s ((1:ℝ),(w s,0)) ∂occupation E t) =
      ∫ s, fderiv ℝ f s.2 (w s,0) ∂occupation E t := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem dm] with s hs
    have flat := time_flat hs.1
    have near : F =ᶠ[nhds s] (f ∘ Prod.snd) := by
      filter_upwards [continuous_fst.continuousAt.tendsto.eventually flat] with y hy
      change d y.1*f y.2 = f y.2
      rw [show d y.1=1 from hy,one_mul]
    rw [near.fderiv_eq,fderiv_comp s (hf.differentiable (by simp)).differentiableAt
      differentiableAt_snd, fderiv_snd]
    rfl
  rw [hi] at h
  simp only [F,at',a0,one_mul,← mul_sub] at h
  exact mul_left_cancel₀ hρ.ne' h

/-- Physical inputs still needed after removing the old 'sliceLaw' equality. -/
structure TraceFoundation (E0 : Set Space) (E : ℝ → Set Space) (t ρ R a b : ℝ)
    (U V : Space → H) (w : ℝ × Space → H) : Prop where
  timeNonneg : 0 ≤ t
  moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1}
  measurableInitial : MeasurableSet E0
  finiteCurrent : volume (E t) ≠ ⊤
  finiteInitial : volume E0 ≠ ⊤
  velocityInt : Integrable w (occupation E t)
  weakEq : WeakPatchEquation E0 E t ρ w
  sliceMoment : ∀ᵐ z : ℝ, IntegrableOn areaCoord (slice (E t) z)
  initialSlab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z) = 0
  l1 : Integrable (fun y => |patch (E t) ρ y-patch (circular E0) ρ y|)
  impulseInt : Integrable (fun y : Space => (y.1.1^2+y.1.2^2)*
    (patch (E t) ρ y-patch (circular E0) ρ y))
  ovInt : Integrable (overlap (E t) (circular E0) ρ Prod.fst U V)
  fluxInt : Integrable (fun y => flux (patch (E t) ρ y) (patch (circular E0) ρ y) (U y) (V y))
  endpoint : (∫ y, flux (patch (E t) ρ y) (patch (circular E0) ρ y) (U y) (V y)) ≤
    R^2*∫ y, (patch (E t) ρ y-patch (circular E0) ρ y)^2/(patch (E t) ρ y+patch (circular E0) ρ y)

structure TracePatchInputs (E0 : Set Space) (E : ℝ → Set Space) (t ρ R a b : ℝ)
    (U V : Space → H) (w : ℝ × Space → H) : Prop
    extends TraceFoundation E0 E t ρ R a b U V w where
  conservedImpulse : impulse (E t) (circular E0) ρ = impulse E0 (circular E0) ρ

theorem physical_from_trace {E0 : Set Space} {E : ℝ → Set Space} {t ρ R a b : ℝ}
    {U V : Space → H} {w : ℝ × Space → H} (hρ : 0 < ρ)
    (h : TracePatchInputs E0 E t ρ R a b U V w) : PhysicalInputs E0 (E t) ρ R a b U V := by
  have me : MeasurableSet (E t) := h.moving.preimage (measurable_const.prodMk measurable_id)
  have eqarea := slice_area_from_horizontal_transport E0 (E t) h.measurableInitial me
    h.finiteInitial h.finiteCurrent _ w h.velocityInt
    (horizontal_trace_of_weak_patch E0 E t ρ h.timeNonneg hρ w h.moving h.weakEq)
  have hs : (∫⁻ z, volume (slice (E t) z)) ≠ ⊤ := by
    change (∫⁻ z, volume ((fun x : H => (x,z)) ⁻¹' (E t))) ≠ ⊤
    rw [← Measure.prod_apply_symm me]; exact h.finiteCurrent
  have fin := ae_lt_top (measurable_measure_prodMk_right (μ := (volume : Measure H)) me) hs
  refine ⟨⟨me,h.measurableInitial,h.l1,?_,h.initialSlab,h.impulseInt,h.conservedImpulse,h.ovInt,h.fluxInt⟩,
    h.endpoint⟩
  filter_upwards [eqarea,h.sliceMoment,fin] with z hz hm hf
  exact ⟨hf.ne,hz,hm⟩

theorem overlap_from_weak_patch (times : Set ℝ) (E0 : Set Space) (E : ℝ → Set Space)
    (U : ℝ → Space → H) (V : Space → H) (w : ℝ × Space → H) (ρ R a b : ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (h : ∀ᵐ t ∂volume.restrict times, TracePatchInputs E0 E t ρ R a b (U t) V w) :
    ∀ᵐ t ∂volume.restrict times,
      ρ*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y)) (vel y.1 (V y))) ≤
      4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 (circular E0) ρ) :=
  published_overlap times E0 E U V ρ R a b hρ hab (h.mono fun _ ht => physical_from_trace hρ ht)
end
end Vortex
