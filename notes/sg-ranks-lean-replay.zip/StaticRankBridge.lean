import StaticRankConvex
import MinimaxUpperRanks

open MeasureTheory Set Matrix
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- Midpoint log-concavity also holds when one endpoint is outside the
positive-density set. The finite logarithm is used only on that set. -/
theorem log_concave_density_midpoint {d : ℕ} (w : RankPoint d → ℝ) (wn : ∀ y, 0 ≤ w y)
    (conc : ConcaveOn ℝ {z | 0 < w z} (fun z => Real.log (w z))) (u v : RankPoint d) :
    Real.sqrt (w u)*Real.sqrt (w v) ≤ w (mid u v) := by
  by_cases hu : 0 < w u
  · by_cases hv : 0 < w v
    · have m : (1/2:ℝ) • u + (1/2:ℝ) • v = mid u v := by funext i; change (1/2:ℝ) * u i + (1/2:ℝ) * v i = (u i+v i)/2; ring
      have pos := conc.1 (show u ∈ {z | 0 < w z} from hu) (show v ∈ {z | 0 < w z} from hv)
        (show (0:ℝ) ≤ 1/2 by norm_num) (show (0:ℝ) ≤ 1/2 by norm_num) (by norm_num)
      have l := conc.2 (show u ∈ {z | 0 < w z} from hu) (show v ∈ {z | 0 < w z} from hv)
        (show (0:ℝ) ≤ 1/2 by norm_num) (show (0:ℝ) ≤ 1/2 by norm_num) (by norm_num)
      rw [m] at l pos
      apply (Real.log_le_log_iff (mul_pos (Real.sqrt_pos.mpr hu) (Real.sqrt_pos.mpr hv)) pos).mp
      rw [Real.log_mul (Real.sqrt_pos.mpr hu).ne' (Real.sqrt_pos.mpr hv).ne',
        Real.log_sqrt hu.le,Real.log_sqrt hv.le]
      simpa [smul_eq_mul,div_eq_inv_mul] using l
    · simpa [Real.sqrt_eq_zero_of_nonpos (le_of_not_gt hv)] using wn (mid u v)
  · simpa [Real.sqrt_eq_zero_of_nonpos (le_of_not_gt hu)] using wn (mid u v)

/-- The static nonsmooth input is an a.e. overlap cover by regular endpoints
of the two convex gradients. Essential injectivity can be supplied by their
a.e. inverse transports. No condition is imposed on the complement. -/
structure RegularRankGradients {d : ℕ} (p q : RankPoint d → ℝ)
    (U V : RankPoint d → RankPoint d) where
  good : Set (RankPoint d)
  measurableGood : MeasurableSet good
  cover : ∀ᵐ x ∂volume, 0 < p x → 0 < q x → x ∈ good
  φ : RankPoint d → ℝ
  ψ : RankPoint d → ℝ
  convexφ : ConvexOn ℝ univ φ
  convexψ : ConvexOn ℝ univ ψ
  gradientφ : ∀ x ∈ good, HasFDerivAt φ (rankCovector (U x)) x
  gradientψ : ∀ x ∈ good, HasFDerivAt ψ (rankCovector (V x)) x
  a : RankPoint d → RankDifferential d
  b : RankPoint d → RankDifferential d
  derivativeU : ∀ x ∈ good, HasFDerivWithinAt U (a x) good x
  derivativeV : ∀ x ∈ good, HasFDerivWithinAt V (b x) good x
  positiveU : ∀ x ∈ good, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef
  positiveV : ∀ x ∈ good, (LinearMap.toMatrix' (b x).toLinearMap).PosSemidef
  injectiveU : InjOn U good
  injectiveV : InjOn V good

/-- From the two endpoint marginals and their regular convex-gradient data,
prove domination of the midpoint measure, including zeros of all densities. -/
theorem midpoint_from_convex_gradients {d : ℕ} (p q w : RankPoint d → ℝ)
    (U V : RankPoint d → RankPoint d) (hp : Measurable p) (hq : Measurable q)
    (hu : Measurable U) (hv : Measurable V) (wn : ∀ y, 0 ≤ w y)
    (conc : ConcaveOn ℝ {z | 0 < w z} (fun z => Real.log (w z)))
    (pu : (weighted volume p).map U = weighted volume w)
    (qv : (weighted volume q).map V = weighted volume w) (g : RegularRankGradients p q U V) :
    (weighted volume (fun x => Real.sqrt (p x)*Real.sqrt (q x))).map
      (fun x => mid (U x) (V x)) ≤ weighted volume w :=
  midpoint_domination_of_regular_set p q w U V g.a g.b g.good g.measurableGood g.cover hu hv wn
    (log_concave_density_midpoint w wn conc) g.derivativeU g.derivativeV g.positiveU g.positiveV
    hp hq pu qv g.injectiveU g.injectiveV
    (midpoint_injective_of_convex_gradients g.φ g.ψ U V g.good g.convexφ g.convexψ
      g.gradientφ g.gradientψ g.injectiveU)

/-- The published squared rank loss-to-Hellinger estimate. The only geometric
input beyond measurable bounded endpoint transports is their regular-set data. -/
theorem one_step_from_regular_gradients {d : ℕ} (p q w : RankPoint d → ℝ)
    (U V : RankPoint d → RankPoint d) (R : ℝ)
    (hp : Measurable p) (hq : Measurable q) (pn : ∀ y, 0 ≤ p y) (qn : ∀ y, 0 ≤ q y)
    (ip : Integrable p) (iq : Integrable q) (hu : Measurable U) (hv : Measurable V)
    (ub : ∀ y, normSq (U y) ≤ R^2) (vb : ∀ y, normSq (V y) ≤ R^2)
    (wn : ∀ y, 0 ≤ w y) [IsProbabilityMeasure (weighted volume w)]
    (refball : ∀ᵐ k ∂weighted volume w, normSq k ≤ R^2)
    (conc : ConcaveOn ℝ {z | 0 < w z} (fun z => Real.log (w z)))
    (pu : (weighted volume p).map U = weighted volume w)
    (qv : (weighted volume q).map V = weighted volume w) (g : RegularRankGradients p q U V) :
    (∫ x, p x * normSq (diff (U x) (V x))) ≤
      16*R^2*∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2 :=
  one_step_from_geometry volume (weighted volume w) R p q hp hq pn qn ip iq U V hu hv ub vb refball
    pu qv (midpoint_from_convex_gradients p q w U V hp hq hu hv wn conc pu qv g)

end
end SequentialRanks
