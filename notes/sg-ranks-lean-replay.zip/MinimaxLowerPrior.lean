import MinimaxLowerInformation

open MeasureTheory Set
namespace SequentialRanks
noncomputable section

def parameterInterval := Icc (-(1/2):ℝ) (1/2)
def parameterBase : Measure ℝ := volume.restrict parameterInterval
def priorScore (θ : ℝ) := priorDerivative θ / priorWeight θ

def jointWeight : (n : ℕ) → Past n → ℝ → ℝ
  | 0, _ => priorWeight
  | n+1, x => fun θ => jointWeight n x.1 θ * density θ x.2
def jointSlope : (n : ℕ) → Past n → ℝ → ℝ
  | 0, _ => priorDerivative
  | n+1, x => fun θ => jointSlope n x.1 θ*density θ x.2+jointWeight n x.1 θ*densityDerivative θ x.2

private theorem joint_deriv : ∀ n (x : Past n) θ,
    HasDerivAt (jointWeight n x) (jointSlope n x θ) θ
  | 0, _, θ => prior_derivative θ
  | n+1, x, θ => (joint_deriv n x.1 θ).fun_mul (density_derivative θ x.2)

private theorem continuous_joint : ∀ n (x : Past n), Continuous (jointWeight n x)
  | n, x => continuous_iff_continuousAt.mpr (fun θ => (joint_deriv n x θ).continuousAt)
private theorem continuous_slope : ∀ n (x : Past n), Continuous (jointSlope n x)
  | 0, x => by change Continuous priorDerivative; unfold priorDerivative; fun_prop
  | n+1, x => by
    change Continuous (fun θ => jointSlope n x.1 θ * density θ x.2 + jointWeight n x.1 θ*densityDerivative θ x.2)
    exact ((continuous_slope n x.1).mul (by unfold density; fun_prop)).add
      ((continuous_joint n x.1).mul (by unfold densityDerivative; fun_prop))

private theorem boundary_joint : ∀ n (x : Past n),
    jointWeight n x (-(1/2))=0 ∧ jointWeight n x (1/2)=0
  | 0, x => by
    change priorWeight _=0 ∧ priorWeight _=0
    have h : Real.pi*(1/2)=Real.pi/2 := by ring
    simp only [priorWeight,mul_neg,h,Real.cos_neg,Real.cos_pi_div_two,zero_pow (by decide : 2≠0),mul_zero,and_self]
  | n+1, x => by
    obtain ⟨ha,hb⟩ := boundary_joint n x.1
    exact ⟨by simp only [jointWeight,ha,zero_mul],by simp only [jointWeight,hb,zero_mul]⟩

/-- For every fixed sample and every estimator value a (constant in θ), perform
integration by parts against the actual prior times the i.i.d. likelihood. -/
theorem iid_score_parts (n : ℕ) (x : Past n) (a : ℝ) :
    (∫ θ,(a-θ)*jointSlope n x θ ∂parameterBase)=∫ θ,jointWeight n x θ ∂parameterBase := by
  let lo : ℝ := -(1/2)
  let hi : ℝ := 1/2
  have hu (θ : ℝ) : HasDerivAt (fun t => a-t) (-1) θ := HasDerivAt.const_sub a (hasDerivAt_id θ)
  have hp := intervalIntegral.integral_mul_deriv_eq_deriv_mul (a:=lo) (b:=hi)
    (fun θ _ => hu θ) (fun θ _ => joint_deriv n x θ)
    (continuous_const.intervalIntegrable lo hi) ((continuous_slope n x).intervalIntegrable lo hi)
  have law := boundary_joint n x
  have hb : jointWeight n x hi=0 := law.2
  have ha : jointWeight n x lo=0 := law.1
  rw [hb,ha] at hp
  simp only [mul_zero,sub_zero,zero_sub,neg_one_mul,intervalIntegral.integral_neg,neg_neg] at hp
  change (∫ θ in Icc lo hi,(a-θ)*jointSlope n x θ) = ∫ θ in Icc lo hi,jointWeight n x θ
  simpa only [intervalIntegral.integral_of_le (show lo≤hi by norm_num [lo,hi]),
    integral_Icc_eq_integral_Ioc] using hp

theorem iid_score_parts_scaled (n : ℕ) (x : Past n) (a b : ℝ) :
    (∫ θ,(a-b*θ)*jointSlope n x θ ∂parameterBase)=b*(∫ θ,jointWeight n x θ ∂parameterBase) := by
  let lo : ℝ := -(1/2)
  let hi : ℝ := 1/2
  have hu (θ : ℝ) : HasDerivAt (fun t => a-b*t) (-b) θ := by
    simpa using HasDerivAt.const_sub a (HasDerivAt.const_mul b (hasDerivAt_id θ))
  have hp := intervalIntegral.integral_mul_deriv_eq_deriv_mul (a:=lo) (b:=hi)
    (fun θ _ => hu θ) (fun θ _ => joint_deriv n x θ)
    (continuous_const.intervalIntegrable lo hi) ((continuous_slope n x).intervalIntegrable lo hi)
  have law := boundary_joint n x
  have hb : jointWeight n x hi=0 := law.2
  have ha : jointWeight n x lo=0 := law.1
  rw [hb,ha,intervalIntegral.integral_const_mul] at hp
  simp only [mul_zero,sub_zero,zero_sub,neg_mul,neg_neg] at hp
  change (∫ θ in Icc lo hi,(a-b*θ)*jointSlope n x θ) = b*(∫ θ in Icc lo hi,jointWeight n x θ)
  simpa only [intervalIntegral.integral_of_le (show lo≤hi by norm_num [lo,hi]),
    integral_Icc_eq_integral_Ioc] using hp

private theorem prior_score_identity (θ : ℝ) : priorWeight θ*priorScore θ=priorDerivative θ := by
  by_cases h : Real.cos (Real.pi*θ)=0
  · simp [priorWeight,priorDerivative,priorScore,h]
  · unfold priorScore; have nz : priorWeight θ ≠ 0 := by unfold priorWeight; positivity
    field_simp

theorem iid_score_factor (n : ℕ) (x : Past n) (θ : ℝ) (hθ : |θ| ≤ 1/2) :
    jointSlope n x θ = jointWeight n x θ * (priorScore θ+allScore θ n x) := by
  induction n with
  | zero => simpa [jointWeight,jointSlope,allScore] using (prior_score_identity θ).symm
  | succ n ih =>
    have p : 0<density θ x.2 := (by norm_num : (0:ℝ)<1/4).trans_le (actual_density_floor _ _ _ hθ)
    have dx : density θ x.2*obsScore θ x.2=densityDerivative θ x.2 := by unfold obsScore; field_simp [p.ne']
    change jointSlope n x.1 θ*density θ x.2+jointWeight n x.1 θ*densityDerivative θ x.2 = _
    rw [ih x.1,←dx]
    dsimp [jointWeight,allScore]; ring

private theorem trig_square_integrals :
    (∫ θ in (-(1/2):ℝ)..(1/2), Real.cos (Real.pi*θ)^2)=1/2 ∧
    (∫ θ in (-(1/2):ℝ)..(1/2), Real.sin (Real.pi*θ)^2)=1/2 := by
  constructor
  · rw [intervalIntegral.integral_comp_mul_left (fun t => Real.cos t^2) Real.pi_ne_zero,integral_cos_sq]
    simp [smul_eq_mul]; field_simp; rw [Real.cos_pi_div_two]; ring
  · rw [intervalIntegral.integral_comp_mul_left (fun t => Real.sin t^2) Real.pi_ne_zero,integral_sin_sq]
    simp [smul_eq_mul]; field_simp; rw [Real.cos_pi_div_two]; ring

theorem prior_mass_and_information : (∫ θ,priorWeight θ ∂parameterBase)=1 ∧
    (∫ θ,priorEnergy θ ∂parameterBase)=4*Real.pi^2 := by
  change (∫ θ in Icc (-(1/2):ℝ) (1/2),priorWeight θ)=1 ∧ (∫ θ in Icc (-(1/2):ℝ) (1/2),priorEnergy θ)=_
  simp only [integral_Icc_eq_integral_Ioc,←intervalIntegral.integral_of_le (by norm_num : (-(1/2):ℝ) ≤ 1/2)]
  unfold priorWeight priorEnergy
  rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul,
    trig_square_integrals.1,trig_square_integrals.2]
  constructor <;> ring

private theorem prior_bound (θ : ℝ) : priorWeight θ*(priorScore θ)^2 ≤ priorEnergy θ := by
  by_cases h : Real.cos (Real.pi*θ)=0
  · simp [priorWeight,h,priorEnergy]; positivity
  · apply le_of_eq
    unfold priorScore priorWeight priorDerivative priorEnergy
    field_simp [h]; ring

/-- Prior-averaged information of the actual joint score. No Fisher bound or
one-observation score centering is assumed. -/
theorem iid_joint_information (n : ℕ) :
    (∫ θ,priorWeight θ*(∫ x,(priorScore θ+allScore θ n x)^2 ∂iidPastLaw θ n) ∂parameterBase) ≤
      4*Real.pi^2+16*(n:ℝ) := by
  have wp (θ : ℝ) : 0 ≤ priorWeight θ := by unfold priorWeight; positivity
  have ip : Integrable priorWeight parameterBase :=
    (show Continuous priorWeight by unfold priorWeight; fun_prop).continuousOn.integrableOn_Icc
  have ei : Integrable priorEnergy parameterBase :=
    (show Continuous priorEnergy by unfold priorEnergy; fun_prop).continuousOn.integrableOn_Icc
  have ae : ∀ᵐ θ ∂parameterBase, |θ| ≤ 1/2 := by
    filter_upwards [ae_restrict_mem (μ:=volume) (s:=parameterInterval) measurableSet_Icc] with θ hθ
    exact abs_le.mpr hθ
  have upper := integral_mono_of_nonneg (μ:=parameterBase)
    (Filter.Eventually.of_forall fun θ => mul_nonneg (wp θ) (integral_nonneg fun x : Past n => sq_nonneg (priorScore θ+allScore θ n x)))
    (show Integrable (fun θ => priorEnergy θ + (16*(n:ℝ))*priorWeight θ) parameterBase from
      ei.add (ip.const_mul _)) (by
      filter_upwards [ae] with θ hθ
      have step := mul_le_mul_of_nonneg_left (iid_score_information θ hθ (priorScore θ) n) (wp θ)
      nlinarith only [step,prior_bound θ])
  rw [integral_add ei (ip.const_mul (16*(n:ℝ))),integral_const_mul,prior_mass_and_information.1,prior_mass_and_information.2,mul_one] at upper
  exact upper

end
end SequentialRanks
