"""Cleanly compile the local proof graph and replay its declarations against their imports."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "logs"
MODULE = re.compile(r"^import (\S+)", re.M)
DECL = re.compile(r"^(?:theorem|lemma) ([\w'.]+)", re.M)
NS = re.compile(r"^namespace ([\w.]+)", re.M)
AX = re.compile(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)")
STANDARD = {"Classical.choice", "propext", "Quot.sound"}


def proof_modules():
    files = {p.stem: p for p in ROOT.glob("*.lean") if p.stem not in {"Audit", "Statements"}}
    parents = {m: set(MODULE.findall(p.read_text())) & files.keys() for m, p in files.items()}
    ordered = []
    while parents:
        ready = sorted(m for m, deps in parents.items() if not deps)
        if not ready:
            raise ValueError("Local import cycle")
        ordered.extend(ready)
        for m in ready:
            del parents[m]
        for deps in parents.values():
            deps.difference_update(ready)
    return ordered


def names(paths):
    for f in paths:
        s = f.read_text()
        ns = NS.findall(s)
        if len(ns) != 1:
            raise ValueError(f"Expected exactly one named namespace in {f.name}: {ns}")
        for name in DECL.findall(s):
            yield f"{ns[0]}.{name}"


def check_axioms(paths, filename):
    expected = list(names(paths))
    if len(set(expected)) != len(expected):
        raise ValueError("Repeated theorem within this source group")
    dependencies = {}
    for name, deps in AX.findall((LOGS / filename).read_text()):
        if name in dependencies:
            raise ValueError(f"Duplicate axiom record {name}")
        dependencies[name] = set(filter(None, (v.strip() for v in deps.split(","))))
    if set(dependencies) != set(expected):
        raise ValueError(f"Mismatch in {filename}: {set(expected) ^ set(dependencies)}")
    union = set().union(*dependencies.values())
    if not union <= STANDARD:
        raise ValueError(f"Unexpected axioms: {union-STANDARD}")
    return f"{len(expected)} declarations in {filename}; union = {', '.join(sorted(union))}"


def run(cmd, log, loud=True):
    log.write("$ " + " ".join(cmd) + "\n")
    log.flush()
    p = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert p.stdout
    for line in p.stdout:
        log.write(line)
        if loud:
            print(line, end="", flush=True)
    if p.wait():
        raise SystemExit(f"Failure: {cmd}")
    log.flush()


def check_dependency_sources():
    """Check the pinned source checkouts used with the precompiled external imports."""
    with (LOGS / "dependency-source-status.log").open("w") as f:
        for dep in json.loads((ROOT / "lake-manifest.json").read_text())["packages"]:
            directory = str(ROOT / ".lake/packages" / dep["name"])
            git = ["git", "-C", directory]
            rev = subprocess.check_output(git + ["rev-parse", "HEAD"], text=True).strip()
            if rev != dep["rev"]:
                raise SystemExit("Dependency mismatch: " + dep["name"])
            subprocess.run(git + ["diff", "--quiet", "HEAD", "--"], check=True)
            extra = subprocess.check_output(git + ["ls-files", "--others", "--exclude-standard",
                "--", "*.lean", "lean-toolchain", "lakefile.toml", "lakefile.lean"], text=True)
            if extra:
                raise SystemExit("Unexpected Lean sources in " + dep["name"])
            f.write(f"{dep['name']} {rev} -- tracked tree clean; no untracked Lean sources or Lake configuration.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--start-clean", action="store_true", help="Compile the first frozen batch and record its source hashes.")
    ap.add_argument("--finish-clean", action="store_true", help="Continue the same clean run after checking first-batch hashes.")
    args = ap.parse_args()
    os.chdir(ROOT)
    mods = proof_modules()
    files = [ROOT / f"{m}.lean" for m in mods]
    legacy = [ROOT / "legacy" / "SGModulation.lean"]
    LOGS.mkdir(exist_ok=True)
    if not args.check_only:
        check_dependency_sources()
        with (LOGS / "versions.log").open("w") as f:
            for cmd in (["lean", "--version"], ["lake", "--version"]):
                run(cmd, f)
            for dep in json.loads((ROOT / "lake-manifest.json").read_text())["packages"]:
                rev = subprocess.check_output(["git", "-C", str(ROOT / ".lake/packages" / dep["name"]),
                                               "rev-parse", "HEAD"], text=True).strip()
                if rev != dep["rev"]:
                    raise SystemExit("Dependency mismatch: " + dep["name"])
                f.write(f"{dep['name']} {rev}\n")
        build = ROOT / ".lake/build"
        previous = {}
        if args.finish_clean:
            previous = json.loads((LOGS/"first-batch.json").read_text())
            for m, h in previous.items():
                if m not in mods or hashlib.sha256((ROOT/(m+".lean")).read_bytes()).hexdigest() != h:
                    raise SystemExit(f"Clean-run checkpoint does not match final source: {m}")
        else:
            if build.exists():
                shutil.rmtree(build)
            assert not build.exists()
        with (LOGS / "clean-build.log").open("a" if args.finish_clean else "w") as f:
            if not args.finish_clean:
                f.write("Project build directory is absent. Pinned external imports may use the mathlib cache.\n")
            pending = [m for m in mods if m not in previous]
            for n in range(0, len(pending), 4):
                run(["lake", "build", *pending[n:n+4]], f)
            if args.start_clean:
                (LOGS/"first-batch.json").write_text(json.dumps({
                    m:hashlib.sha256((ROOT/(m+".lean")).read_bytes()).hexdigest() for m in mods},
                    sort_keys=True,indent=2)+"\n")
                return
            run(["lake", "build"], f, loud=False)
        for file, log in [("Audit.lean", "axioms.log"), ("legacy/SGModulation.lean", "legacy-recheck.log"),
                          ("Statements.lean", "statements.log"), ("audit/DeclarationAudit.lean","declarations.log"),
                          ("audit/PublicStatements.lean","public-statements.log")]:
            with (LOGS / log).open("w") as f:
                run(["lake", "env", "lean", "-DwarningAsError=true", file], f, loud=False)
        with (LOGS / "kernel-replay.log").open("w") as f:
            for n in range(0,len(mods),4):
                run(["lake","env","leanchecker","-v",*mods[n:n+4]],f)
    buildlog = (LOGS / "clean-build.log").read_text()
    if re.search(r"(^|\s)(warning|error):", buildlog):
        raise SystemExit("Unexpected Lean warning/error in clean build")
    absent = [m for m in mods if not re.search(r"\bBuilt "+re.escape(m)+r"(?:\s|$)",buildlog)]
    if absent:
        raise SystemExit(f"No fresh build record: {absent}")
    replay = (LOGS / "kernel-replay.log").read_text()
    got = re.findall(r"^replaying (\S+)$", replay, re.M)
    if sorted(mods) != sorted(got):
        raise SystemExit("Incomplete kernel replay")
    reports = [f"{len(mods)} proof modules freshly compiled and replayed.",
               check_axioms(files,"axioms.log"), check_axioms(legacy,"legacy-recheck.log"), "PASS"]
    for p in files + legacy:
        s = re.sub(r"/-.*?-/", "", p.read_text(), flags=re.S)
        s = re.sub(r"--[^\n]*", "", s)
        if re.search(r"^\s*(?:(?:private|protected)\s+)?(?:axiom|opaque)\s|\b(?:sorry|admit|sorryAx|native_decide)\b",s,re.M):
            raise SystemExit(f"Unsupported declaration or placeholder in {p.name}")
    whole = re.search(r"DECLARATION AUDIT PASS: (\d+) constants, (\d+) theorems, (\d+) private names. Axioms \[([^\]]+)\]", (LOGS/"declarations.log").read_text())
    if not whole or set(re.split(r",\s*", whole[4].strip())) != STANDARD:
        raise SystemExit("Incomplete declaration-wide audit")
    reports.insert(-1, " ".join(whole.group(0).split()))
    print("\n".join(reports))
    if not args.check_only:
        (LOGS/"audit-summary.log").write_text("\n".join(reports)+"\n")
if __name__=="__main__":
    main()
