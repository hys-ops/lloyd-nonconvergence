import RankPath

open MeasureTheory Set
namespace SequentialRanks
noncomputable section

def density (θ : ℝ) (z : ℝ × ℝ) : ℝ :=
  (1-θ*Real.cos (Real.pi*(z.1+z.2)))*(1-θ*Real.cos (Real.pi*(z.1-z.2)))

def pairLoss (e : ℝ × ℝ → ℝ × ℝ) (z : ℝ × ℝ) : ℝ :=
  let v := perturb z
  let loss := fun (θ : ℝ) =>
    ((e z).1-(z.1+θ*v.1))^2 + ((e z).2-(z.2+θ*v.2))^2
  (density (1/2) z*loss (1/2)+density (-(1/2)) z*loss (-(1/2)))/2

/-- The two squared errors are evaluated at the same observed z.
The estimator can be an arbitrary function of the current observation. -/
theorem pair_pointwise (e : ℝ × ℝ → ℝ × ℝ) (z : ℝ × ℝ) :
    speed z / 16 ≤ pairLoss e z := by
  have hp := actual_density_floor (1/2) z.1 z.2 (by norm_num)
  have hm := actual_density_floor (-(1/2)) z.1 z.2 (by norm_num)
  change 1/4 ≤ density (1/2) z at hp
  change 1/4 ≤ density (-(1/2)) z at hm
  have nonneg (θ : ℝ) : 0 ≤ ((e z).1-(z.1+θ*(perturb z).1))^2 +
      ((e z).2-(z.2+θ*(perturb z).2))^2 := by positivity
  have plus := mul_nonneg (sub_nonneg.mpr hp) (nonneg (1/2))
  have minus := mul_nonneg (sub_nonneg.mpr hm) (nonneg (-(1/2)))
  rw [← speed_id]
  unfold pairLoss
  dsimp only
  nlinarith only [plus,minus,sq_nonneg ((e z).1-z.1),sq_nonneg ((e z).2-z.2)]

/-- Explicit one-date Bayes risk of the hard sign pair, for finite risk. -/
theorem square_pair_lower (e : ℝ × ℝ → ℝ × ℝ)
    (h : IntegrableOn (pairLoss e) ((Icc (0:ℝ) 1) ×ˢ (Icc (0:ℝ) 1))) :
    1/(32*Real.pi^2) ≤ ∫ z in (Icc (0:ℝ) 1) ×ˢ (Icc (0:ℝ) 1), pairLoss e z := by
  let D := (Icc (0:ℝ) 1) ×ˢ (Icc (0:ℝ) 1)
  have cs : Continuous speed := by unfold speed S2 C2; fun_prop
  have hs : IntegrableOn speed D := (cs.continuousOn.integrableOn_compact (isCompact_Icc.prod isCompact_Icc))
  have hle := integral_mono (μ := volume.restrict D) (hs.div_const 16) h (pair_pointwise e)
  rw [integral_div] at hle
  change (∫ z in (Icc (0:ℝ) 1) ×ˢ (Icc (0:ℝ) 1), speed z)/16 ≤ _ at hle
  rw [square_energy] at hle
  calc
    _ = (1/(2*Real.pi^2))/16 := by ring
    _ ≤ _ := hle
end
end SequentialRanks
