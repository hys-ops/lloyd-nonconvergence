import ContinuumCells

open MeasureTheory Filter Set
open scoped Topology BigOperators
namespace Vortex
noncomputable section

/-- Power-cell labels are allowed to choose arbitrarily among tied minimizers.
Their joint transport automatically has cyclical monotonicity on its *support*,
including support points reached only in the closure of a cell. -/
theorem cellFit_of_power_cells {Y K : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) (G : CommonGrid Y) (P : ProbabilityMeasure Y)
    (T : ProbabilityMeasure K) (tag : K → Fin G.size) (ht : Measurable tag)
    (mass : T.map tag = P.map G.label) (w : Fin G.size → ℝ)
    (power : ∀ᵐ x ∂(T : Measure K), ∀ j, c (G.site (tag x),x)-w (tag x) ≤ c (G.site j,x)-w j) :
    CellFit c G P T tag := by
  let C (i : Fin G.size) : Set (Y × K) :=
    {z | z.1 = G.site i} ∩ ⋂ j, {z | c (G.site i,z.2)-w i ≤ c (G.site j,z.2)-w j}
  have closed (i : Fin G.size) : IsClosed (C i) := by
    refine (isClosed_eq continuous_fst continuous_const).inter (isClosed_iInter (fun j => ?_))
    apply isClosed_le <;> fun_prop
  have mz : Measurable (fun x => (G.site (tag x),x)) :=
    ((measurable_of_finite G.site).comp ht).prodMk measurable_id
  have ae : (⋃ i, C i) ∈ ae (labelPlan G T tag : Measure (Y × K)) := by
    apply (mem_ae_map_iff mz.aemeasurable (isClosed_iUnion_of_finite closed).measurableSet).mpr
    filter_upwards [power] with x hx
    exact mem_iUnion.mpr ⟨tag x,rfl,mem_iInter.mpr hx⟩
  have support := Measure.support_subset_of_isClosed (isClosed_iUnion_of_finite closed) ae
  refine ⟨ht,mass,?_⟩
  intro n σ z hz
  have cells (i : Fin n) := mem_iUnion.mp (support (hz i))
  choose widx hw using cells
  have left (i : Fin n) : (z i).1 = G.site (widx i) := (hw i).1
  have ineq (i : Fin n) := (mem_iInter.mp (hw (σ i)).2) (widx i)
  have each (i : Fin n) : c (z (σ i))-w (widx (σ i)) ≤ c ((z i).1,(z (σ i)).2) - w (widx i) := by
    have hi := ineq i
    change c (G.site (widx (σ i)),(z (σ i)).2) - _ ≤ c (G.site (widx i),(z (σ i)).2) - _ at hi
    simpa only [← left,Prod.mk.eta] using hi
  have total := Finset.sum_le_sum (s := Finset.univ) (fun i _ => each i)
  rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib,
    Equiv.sum_comp σ (fun i => c (z i)), Equiv.sum_comp σ (fun i => w (widx i))] at total
  linarith

end
end Vortex
