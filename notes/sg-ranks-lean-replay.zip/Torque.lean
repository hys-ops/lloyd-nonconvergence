import ImpulseTransport

open MeasureTheory Set
namespace Vortex
noncomputable section
def rotateMap (θ : ℝ) (x : Space) : Space :=
  ((Real.cos θ*x.1.1-Real.sin θ*x.1.2,Real.sin θ*x.1.1+Real.cos θ*x.1.2),x.2)
def quadraticCost (y x : Space) : ℝ := distSq y.1 x.1 + (y.2-x.2)^2
private def baseCost (y x : Space) := radialSquare y+radialSquare x+(y.2-x.2)^2
private def corr (y x : Space) := horizontalWork y x.1
private def twist (y x : Space) := y.1.2*x.1.1-y.1.1*x.1.2

/-- Every competitor pushes the same spatial source to the same target. -/
structure SymmetricMonge (ν target : Measure Space) (S : Space → Space) : Prop where
  measurableMap : Measurable S
  marginal : ν.map S = target
  invariant : ∀ θ : ℝ, target.map (rotateMap θ) = target
  optimal : ∀ F : Space → Space, Measurable F → ν.map F = target →
    Integrable (fun y => quadraticCost y (F y)) ν →
    (∫ y, quadraticCost y (S y) ∂ν) ≤ ∫ y, quadraticCost y (F y) ∂ν

private theorem expanded (θ : ℝ) (y x : Space) :
    quadraticCost y (rotateMap θ x) =
    baseCost y x - 2*(Real.cos θ*corr y x+Real.sin θ*twist y x) := by
  unfold quadraticCost rotateMap distSq baseCost corr twist horizontalWork radialSquare
  dsimp
  nlinarith only [congrArg (fun t : ℝ => t*x.1.1^2) (Real.sin_sq_add_cos_sq θ),
    congrArg (fun t : ℝ => t*x.1.2^2) (Real.sin_sq_add_cos_sq θ)]

private theorem coordinate_bounds (x : Space) :
    |x.1.1| ≤ ‖x‖ ∧ |x.1.2| ≤ ‖x‖ ∧ |x.2| ≤ ‖x‖ :=
  ⟨(norm_fst_le x.1).trans (norm_fst_le x),(norm_snd_le x.1).trans (norm_fst_le x),norm_snd_le x⟩

/-- Rotating the *actual* optimal destination and using its invariant marginal
makes the space-integrated horizontal work vanish. Finite second moments suffice. -/
theorem torque_of_optimal_map (ν target : Measure Space) (S : Space → Space)
    (opt : SymmetricMonge ν target S)
    (leftMoment : Integrable (fun y : Space => ‖y‖^2) ν)
    (rightMoment : Integrable (fun y => ‖S y‖^2) ν) :
    (∫ y, 2*horizontalWork y (vel y.1 (S y).1) ∂ν) = 0 := by
  have ms := opt.measurableMap
  let budget := fun y : Space => ‖y‖^2+‖S y‖^2
  have hi : Integrable budget ν := leftMoment.add rightMoment
  have product_bound (u v : ℝ) (x y : Space) (hu : |u| ≤ ‖x‖) (hv : |v| ≤ ‖y‖) :
      |u*v| ≤ (‖x‖^2+‖y‖^2)/2 := by
    rw [abs_mul]
    have h := mul_le_mul hu hv (abs_nonneg _) (norm_nonneg _)
    nlinarith [sq_nonneg (‖x‖-‖y‖)]
  have iA : Integrable (fun y => corr y (S y)) ν := by
    apply hi.mono' (by unfold corr horizontalWork; fun_prop)
    filter_upwards with y
    have a := coordinate_bounds y
    have b := coordinate_bounds (S y)
    have left := product_bound _ _ _ _ a.1 b.1
    have right := product_bound _ _ _ _ a.2.1 b.2.1
    rw [Real.norm_eq_abs]; unfold corr horizontalWork budget
    exact (abs_add_le _ _).trans (by linarith)
  have iB : Integrable (fun y => twist y (S y)) ν := by
    apply hi.mono' (by unfold twist; fun_prop)
    filter_upwards with y
    have a := coordinate_bounds y
    have b := coordinate_bounds (S y)
    have left := product_bound _ _ _ _ a.2.1 b.1
    have right := product_bound _ _ _ _ a.1 b.2.1
    rw [Real.norm_eq_abs]; unfold twist budget
    exact (abs_sub _ _).trans (by linarith)
  have ik : Integrable (fun y => baseCost y (S y)) ν := by
    apply (hi.const_mul 4).mono' (by unfold baseCost radialSquare; fun_prop)
    filter_upwards with y
    have a := coordinate_bounds y
    have b := coordinate_bounds (S y)
    have squares (u : ℝ) (x : Space) (h : |u| ≤ ‖x‖) : u^2 ≤ ‖x‖^2 := by
      simpa only [sq_abs] using pow_le_pow_left₀ (abs_nonneg u) h 2
    change ‖baseCost y (S y)‖ ≤ 4*budget y
    unfold baseCost radialSquare budget
    rw [Real.norm_eq_abs,abs_of_nonneg (by positivity)]
    nlinarith only [squares _ _ a.1,squares _ _ a.2.1,squares _ _ a.2.2,
      squares _ _ b.1,squares _ _ b.2.1,squares _ _ b.2.2,sq_nonneg (y.2+(S y).2)]
  have finite (θ : ℝ) : Integrable (fun y => quadraticCost y (rotateMap θ (S y))) ν := by
    simp_rw [expanded]
    exact ik.sub (((iA.const_mul _).add (iB.const_mul _)).const_mul _)
  have reduced (θ : ℝ) : (∫ y, quadraticCost y (rotateMap θ (S y)) ∂ν) =
    (∫ y, baseCost y (S y) ∂ν) - 2*(Real.cos θ*(∫ y, corr y (S y) ∂ν)+
      Real.sin θ*(∫ y, twist y (S y) ∂ν)) := by
    simp_rw [expanded]
    have iSum : Integrable (fun y => 2*(Real.cos θ*corr y (S y)+Real.sin θ*twist y (S y))) ν :=
      ((iA.const_mul (Real.cos θ)).add (iB.const_mul (Real.sin θ))).const_mul 2
    rw [integral_sub ik iSum,integral_const_mul,
      integral_add (iA.const_mul (Real.cos θ)) (iB.const_mul (Real.sin θ)),integral_const_mul,integral_const_mul]
  have htor := zero_torque (∫ y, corr y (S y) ∂ν) (∫ y, twist y (S y) ∂ν) (by
    intro θ
    have mr : Measurable (rotateMap θ) := by unfold rotateMap; fun_prop
    have marg : ν.map (rotateMap θ ∘ S) = target := by
      rw [← Measure.map_map mr ms,opt.marginal,opt.invariant]
    have hh := opt.optimal (rotateMap θ ∘ S) (mr.comp ms) marg (finite θ)
    have h0 := reduced 0
    simp [rotateMap] at h0
    change (∫ y, quadraticCost y (S y) ∂ν) ≤ ∫ y, quadraticCost y (rotateMap θ (S y)) ∂ν at hh
    rw [reduced] at hh
    linarith)
  have pt (y : Space) : 2*horizontalWork y (vel y.1 (S y).1) = -2*twist y (S y) := by
    unfold horizontalWork vel twist; dsimp; ring
  simp_rw [pt]
  rw [integral_const_mul,htor,mul_zero]
end
end Vortex
