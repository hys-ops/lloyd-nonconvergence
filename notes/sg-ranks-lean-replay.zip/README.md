# Lean proofs: semi-geostrophic patches and sequential multivariate ranks

This archive contains the proof sources, pinned toolchain and dependencies, and
archived replay logs accompanying these research notes:

- [Semi-geostrophic vortex patches](https://github.com/hys-ops/lloyd-nonconvergence/blob/main/notes/semigeostrophic-vortex-patches.md).
  Start with `Vortex.sg_public_patch` in `SGClosureComplete.lean`. The
  velocity inequality is for a given renormalized probability patch solution;
  existence of that evolving solution is not proved.
- [Sequential multivariate ranks](https://github.com/hys-ops/lloyd-nonconvergence/blob/main/notes/sequential-multivariate-ranks.md).
  Start with `SequentialRanks.compact_rank_hellinger`,
  `SequentialRanks.worst_square_catalog_minimax`, and
  `SequentialRanks.square_iid_minimax_log`. The minimax results quantify
  over measurable deterministic estimators that can see the current observation.

To reproduce, extract this archive into a fresh directory. You need Python 3,
Git, the pinned Lean 4.34.1 toolchain (e.g. via elan), and network access for
the pinned Lean dependencies and mathlib cache. Run from the extracted directory:

```sh
sha256sum -c SHA256SUMS
bash verify.sh
```

To check the bundled logs against the source module list without rebuilding,
run `python3 verify_release.py --check-only`. Actual theorem statements are in
`logs/public-statements.log`. The archived run built and replayed 122 proof
modules; the audit of 1,660 declarations reports only `propext`,
`Classical.choice`, and `Quot.sound`. The formal statements and their
correspondence to the written notes are available for independent review.
