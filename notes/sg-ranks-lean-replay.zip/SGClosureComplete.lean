import SGClosureSolution
import SGFiniteBrenier
import SGCellMidpoints

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Public SG result on an arbitrary bounded time interval. Starting with a
renormalized probability patch whose horizontal velocity is defined by the
quadratic Monge problem, construct the optimal map of its circular rearrangement,
prove the rearrangement stationary, and bound the common-mass velocity error
at almost every time. In particular no finite or continuum transport theorem,
rearrangement conservation, or trace identity is included as an input. -/
theorem sg_public_patch (E0 : Set Space) (E : ℝ → Set Space) (D : Set Space)
    [CompactSpace D] (target : ProbabilityMeasure D) (conv : Convex ℝ D)
    (bodySymm : ∀ θ y, rotateMap θ y ∈ D ↔ y∈D) (unif : UniformBodyLaw D target)
    (d : ℝ≥0) (hd : 0<d) (T a b R : ℝ) (ht : 0≤T) (hab : a≤b)
    (horizontal : ∀ x∈D, x.1.1^2+x.1.2^2 ≤ R^2) (U : ℝ → Space → D)
    (me0 : MeasurableSet E0) (mass0 : (d : ℝ≥0∞)*volume E0=1)
    (slab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z)=0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity (fun t y => (U t y).val)) (occupation E T))
    (mass : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*volume (E t)=1)
    (M : ℝ≥0) (moment0 : (d : ℝ≥0∞)*(∫⁻ y in E0, ‖y‖ₑ^2)≤M)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*(∫⁻ y in E t, ‖y‖ₑ^2)≤M)
    (sol : RenormalizedPatch E0 E T d (flowVelocity (fun t y => (U t y).val)))
    (actual : ∀ᵐ t ∂volume.restrict (Icc 0 T), ∀ h : (d : ℝ≥0∞)*volume (E t)=1,
      IsQuadraticMap D (patchProbability (E t) d h) target (U t))
    :
    ∃ mB : (d : ℝ≥0∞)*volume (circular E0)=1, ∃ V : Space → D,
      PhysicalBrenierGraph D (patchProbability (circular E0) d mB) target V ∧
      (∀ s : ℝ, 0≤s → WeakPatchEquation (circular E0) (fun _ => circular E0) s d
        (fun z => vel z.2.1 (V z.2).val.1)) ∧
      ∀ᵐ t ∂volume.restrict (Icc 0 T),
        (d:ℝ)*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y).val.1) (vel y.1 (V y).val.1)) ≤
          4*R^2*Real.sqrt (Real.pi*d*(b-a)*impulse E0 (circular E0) d) := by
  exact sg_public_from_monge_solution E0 E D target conv bodySymm unif d hd T a b R ht hab
    horizontal U me0 mass0 slab moving mw mass M moment0 moment sol actual
    (finite_brenier_from_cell_midpoints uniform_cell_midpoints)

/-- The identical bound holds for *every* measurable quadratic optimal representative
chosen for the circular reference, in addition to the constructed map above. -/
theorem sg_public_for_every_reference (E0 : Set Space) (E : ℝ → Set Space) (D : Set Space)
    [CompactSpace D] (target : ProbabilityMeasure D) (conv : Convex ℝ D)
    (bodySymm : ∀ θ y, rotateMap θ y ∈ D ↔ y∈D) (unif : UniformBodyLaw D target)
    (d : ℝ≥0) (hd : 0<d) (T a b R : ℝ) (ht : 0≤T) (hab : a≤b)
    (horizontal : ∀ x∈D, x.1.1^2+x.1.2^2 ≤ R^2) (U : ℝ → Space → D)
    (me0 : MeasurableSet E0) (mass0 : (d : ℝ≥0∞)*volume E0=1)
    (slab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z)=0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity (fun t y => (U t y).val)) (occupation E T))
    (mass : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*volume (E t)=1)
    (M : ℝ≥0) (moment0 : (d : ℝ≥0∞)*(∫⁻ y in E0, ‖y‖ₑ^2)≤M)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*(∫⁻ y in E t, ‖y‖ₑ^2)≤M)
    (sol : RenormalizedPatch E0 E T d (flowVelocity (fun t y => (U t y).val)))
    (actual : ∀ᵐ t ∂volume.restrict (Icc 0 T), ∀ h : (d : ℝ≥0∞)*volume (E t)=1,
      IsQuadraticMap D (patchProbability (E t) d h) target (U t))
     (mB : (d : ℝ≥0∞)*volume (circular E0)=1) (V : Space → D)
    (reference : IsQuadraticMap D (patchProbability (circular E0) d mB) target V) :
    (∀ s : ℝ, 0≤s → WeakPatchEquation (circular E0) (fun _ => circular E0) s d
      (fun z => vel z.2.1 (V z.2).val.1)) ∧
    ∀ᵐ t ∂volume.restrict (Icc 0 T),
      (d:ℝ)*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y).val.1) (vel y.1 (V y).val.1)) ≤
        4*R^2*Real.sqrt (Real.pi*d*(b-a)*impulse E0 (circular E0) d) := by
  have compact : IsCompact D := isCompact_iff_compactSpace.mpr inferInstance
  obtain ⟨c,uniform⟩ := unif
  have fin := finite_of_patch_mass E0 d hd mass0
  have b2 := circular_second_moment E0 me0 fin (public_patch_second_moment E0 d M hd moment0)
  have ac (A : Set Space) (h : (d:ℝ≥0∞)*volume A=1) : (patchProbability A d h : Measure Space) ≪ volume :=
    (Measure.absolutelyContinuous_of_le Measure.restrict_le_self).smul_left _
  apply sg_public_from_finite_tool E0 E D target conv bodySymm c uniform d hd
    T a b R ht hab horizontal U V me0 mass0 slab moving mw mass M moment0 moment sol
    _ _ (finite_brenier_from_cell_midpoints uniform_cell_midpoints)
  · filter_upwards [moment,actual] with t ht ha
    intro h
    exact current_of_physical_graph D (E t) compact.measurableSet target d hd h (U t)
      (quadratic_map_unique_graph D _ target (U t) (ha h) (ac _ h) (public_patch_second_moment (E t) d M hd ht).smul_measure_nnreal)
  · intro h
    exact reference_of_physical_graph D _ compact.measurableSet target d hd h V
      (quadratic_map_unique_graph D _ target V reference (ac _ h) b2.smul_measure_nnreal)
end
end Vortex
