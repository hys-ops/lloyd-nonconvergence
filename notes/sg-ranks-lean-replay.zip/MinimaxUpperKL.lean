import MinimaxUpper
open MeasureTheory Set Filter InformationTheory
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The single public assumption expressed with mathlib's extended-real KL gives
all three finite-density facts in the statistical theorem, including when the
alternative density vanishes. -/
theorem finite_kl_density_conditions {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (p q : X → ℝ) (mp : Measurable p) (mq : Measurable q) (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x)
    [IsProbabilityMeasure (weighted μ p)] [IsProbabilityMeasure (weighted μ q)]
    {K : ℝ} (hK : 0 ≤ K) (localBound : klDiv (weighted μ p) (weighted μ q) ≤ ENNReal.ofReal K) :
    (∀ᵐ x ∂μ, 0 < p x → 0 < q x) ∧ Integrable (fun x => klTerm (p x) (q x)) μ ∧
      (∫ x,klTerm (p x) (q x) ∂μ) ≤ K := by
  let P := weighted μ p
  let Q := weighted μ q
  have finite : klDiv P Q ≠ ⊤ := (localBound.trans_lt ENNReal.ofReal_lt_top).ne
  obtain ⟨ac,hi⟩ := klDiv_ne_top_iff.mp finite
  let r := fun x => ENNReal.ofReal (p x/q x)
  have mr : Measurable r := ENNReal.measurable_ofReal.comp (mp.div mq)
  have pp := ENNReal.measurable_ofReal.comp mp
  have qq := ENNReal.measurable_ofReal.comp mq
  have qpos : ∀ᵐ x ∂Q, 0 < q x := (ae_withDensity_iff qq).2 <| .of_forall fun x h =>
    (ENNReal.ofReal_pos.mp (pos_iff_ne_zero.mpr h))
  have support := (ae_withDensity_iff pp).1 (ac.ae_le qpos)
  have good : ∀ᵐ x ∂μ, 0 < p x → 0 < q x :=
    support.mono fun x h hx => h (ENNReal.ofReal_pos.mpr hx).ne'
  have densityEq : Q.withDensity r = P := by
    unfold Q P weighted
    rw [← withDensity_mul μ (f := fun x => ENNReal.ofReal (q x)) (g := r) qq mr]
    apply withDensity_congr_ae
    filter_upwards [good] with x hx
    change ENNReal.ofReal (q x)*ENNReal.ofReal (p x/q x) = ENNReal.ofReal (p x)
    rw [← ENNReal.ofReal_mul (qn x)]
    rcases eq_or_lt_of_le (pn x) with z|h
    · simp [← z]
    · rw [mul_comm,div_mul_cancel₀ _ (hx h).ne']
  have der := Measure.rnDeriv_withDensity Q mr
  rw [densityEq] at der
  have underP : P.rnDeriv Q =ᵐ[P] r := ac.ae_le der
  have ll : llr P Q =ᵐ[P] fun x => Real.log (p x/q x) := underP.mono fun x hx =>
    by rw [llr_def]; dsimp only; rw [hx]; dsimp [r]; rw [ENNReal.toReal_ofReal (div_nonneg (pn x) (qn x))]
  have logI : Integrable (fun x => Real.log (p x/q x)) P := hi.congr ll
  have raw := (integrable_withDensity_iff_integrable_smul' (μ := μ) (f := fun x => ENNReal.ofReal (p x)) pp
    (.of_forall (fun x => ENNReal.ofReal_lt_top))).1 logI
  have kI : Integrable (fun x => klTerm (p x) (q x)) μ := by
    simpa only [ENNReal.toReal_ofReal (pn _),smul_eq_mul,klTerm] using raw
  have integralEq := integral_withDensity_eq_integral_toReal_smul (μ := μ) (f := fun x => ENNReal.ofReal (p x))
    pp (.of_forall fun _ => ENNReal.ofReal_lt_top) (fun x => Real.log (p x/q x))
  have klid := toReal_klDiv ac hi
  rw [probReal_univ,probReal_univ,add_sub_cancel_right,integral_congr_ae ll] at klid
  have e : (klDiv P Q).toReal = ∫ x,klTerm (p x) (q x) ∂μ := by
    simpa only [ENNReal.toReal_ofReal (pn _),smul_eq_mul,klTerm] using klid.trans integralEq
  exact ⟨good,kI,e.ge.trans (by simpa only [ENNReal.toReal_ofReal hK] using ENNReal.toReal_mono ENNReal.ofReal_ne_top localBound)⟩

end
end SequentialRanks
