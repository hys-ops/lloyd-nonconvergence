import StaticRankFinish
import CellMidpointArea

open Set MeasureTheory
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- A cell-pair coupling for the overlap estimate. Its mass bound uses the
two density bounds and holds on the ambient space, including at zero density. -/
theorem cell_midpoint_coupling {d} (K : Set (RankPoint d)) (hk : IsCompact K) [Nonempty K]
    (p q : RankPoint d → ℝ) (C D : ℝ) (mp : Measurable p) (pn : ∀ x,0 ≤ p x)
    (qn : ∀ x,0 ≤ q x) (pc : ∀ x,p x ≤ C) (qd : ∀ x,q x ≤ D)
    [IsProbabilityMeasure (weighted volume p)] [IsProbabilityMeasure (weighted volume q)]
    (sp : ∀ᵐ x ∂weighted volume p,x∈K) (sq : ∀ᵐ x ∂weighted volume q,x∈K) :
    ∃ π : ProbabilityMeasure (K × K),
      (π : Measure (K × K)).map (fun z => z.1.val) = weighted volume p ∧
      (π : Measure (K × K)).map (fun z => z.2.val) = weighted volume q ∧
      (π : Measure (K × K)).map (fun z => mid z.1.val z.2.val) ≤ ENNReal.ofReal (Real.sqrt C*Real.sqrt D) • volume := by
  obtain ⟨U,mu,_,law,gr⟩ := compact_rank_graph_exists K K hk hk p q sp sq
  obtain ⟨φ,G,a,conv,mg,full,inj,grad,der,psd⟩ := good_hessian_set K K hk hk p q U mp mu law gr
  have mon := rank_monotone_of_supporting φ U G (fun x hx y => rank_convex_support conv (grad x hx) y)
  have dom := cell_midpoint_density_area p q U C D mp pn qn pc qd mu law G mg full a der inj mon psd
  obtain ⟨π,_,graph⟩ := gr
  let emb (z : K×K) := (z.1.val,z.2.val)
  have me : Measurable emb := (measurable_subtype_coe.comp measurable_fst).prodMk (measurable_subtype_coe.comp measurable_snd)
  let f := fun x => (x,U x)
  have mf : Measurable f := measurable_id.prodMk mu
  have mapEq (g : RankPoint d × RankPoint d → RankPoint d) (m : Measurable g) :
      (π : Measure (K × K)).map (g ∘ emb) = (weighted volume p).map (g ∘ f) := by
    rw [←Measure.map_map m me,←Measure.map_map m mf]
    exact congrArg (Measure.map g) graph.symm
  refine ⟨π,?_,?_,?_⟩
  · exact (mapEq Prod.fst measurable_fst).trans Measure.map_id
  · exact (mapEq Prod.snd measurable_snd).trans law
  · exact le_trans (mapEq (fun z => mid z.1 z.2) (by unfold mid; fun_prop)).le dom
end
end SequentialRanks
