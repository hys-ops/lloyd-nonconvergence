import RankPotential
import StaticRankGraph
import StaticRankDual

open Set MeasureTheory Filter
open scoped ENNReal NNReal BigOperators
namespace SequentialRanks
noncomputable section

private def extDual {d} (φ : RankPoint d → ℝ) (y : RankPoint d) : ℝ≥0∞ :=
  ⨆ x, ENNReal.ofReal (rankCovector y x-φ x+φ 0)

private theorem dual_meas {d} (φ : RankPoint d → ℝ) : Measurable (extDual φ) := by
  apply LowerSemicontinuous.measurable
  apply lowerSemicontinuous_iSup
  intro x
  apply Continuous.lowerSemicontinuous
  apply ENNReal.continuous_ofReal.comp
  simp only [rankCovector,sum_apply,smul_apply,ContinuousLinearMap.proj_apply,smul_eq_mul]
  fun_prop

private theorem dual_contact {d} (φ : RankPoint d → ℝ) (a y : RankPoint d)
    (h : globalSupports φ a y) :
    extDual φ y = ENNReal.ofReal (rankCovector y a-φ a+φ 0) ∧ 0 ≤ rankCovector y a-φ a+φ 0 := by
  have above (x) := h x
  simp only [map_sub] at above
  refine ⟨le_antisymm (iSup_le (fun x => ENNReal.ofReal_le_ofReal (by linarith only [above x]))) (le_iSup (fun x => ENNReal.ofReal (rankCovector y x-φ x+φ 0)) a),?_⟩
  have o := above 0; rw [map_zero] at o; linarith only [o]

private theorem dual_ineq {d} (φ : RankPoint d → ℝ) (x y : RankPoint d)
    (hy : extDual φ y ≠ ⊤) : rankCovector y x-φ x+φ 0 ≤ (extDual φ y).toReal := by
  have b := (ENNReal.toReal_le_toReal ENNReal.ofReal_ne_top hy).mpr
    (le_iSup (fun k => ENNReal.ofReal (rankCovector y k-φ k+φ 0)) x)
  by_cases h : 0 ≤ rankCovector y x-φ x+φ 0
  · rwa [ENNReal.toReal_ofReal h] at b
  · exact (le_of_not_ge h).trans ENNReal.toReal_nonneg

private theorem cost_formula {d} {A B : Set (RankPoint d)} (z : A × B) :
    squareCost z = normSq z.1.val + normSq z.2.val-2*rankCovector z.2.val z.1.val := by
  unfold squareCost normSq diff rankCovector
  simp only [sum_apply,smul_apply,ContinuousLinearMap.proj_apply,smul_eq_mul]
  rw [Finset.mul_sum,←Finset.sum_add_distrib,←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl; intro i _; ring

private theorem take_marginal {X Z : Type*} [MeasurableSpace X] [MeasurableSpace Z]
    (μ : Measure X) (ν : Measure Z) (q : X → Z) (mq : Measurable q) (h : μ.map q = ν)
    (f : Z → ℝ) (mf : Measurable f) :
    (Integrable (f ∘ q) μ ↔ Integrable f ν) ∧ (∫ z,f (q z) ∂μ) = ∫ y,f y ∂ν := by
  rw [← h]
  exact ⟨(integrable_map_measure mf.aestronglyMeasurable mq.aemeasurable).symm,
    (integral_map mq.aemeasurable mf.aestronglyMeasurable).symm⟩

/-- A cyclic quadratic coupling with unbounded, square-integrable source and
compact destination minimizes among all plans. Equality forces every competing
plan onto the same potential's contact set. The unbounded conjugate is finite
and integrable almost everywhere under the destination marginal. -/
theorem unbounded_square_contact {d : ℕ} (A B : Set (RankPoint d)) (hb : IsCompact B)
    (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B)
    (moment1 : Integrable (fun x : A => ‖x.val‖) (P : Measure A))
    (moment2 : Integrable (fun x : A => normSq x.val) (P : Measure A))
    (π : ProbabilityMeasure (A × B)) (cert : certifiedPlan squareCost P Q π) :
    ∃ (φ : RankPoint d → ℝ) (L : ℝ≥0), LipschitzWith L φ ∧
      ∀ γ : ProbabilityMeasure (A × B), γ.map Prod.fst=P → γ.map Prod.snd=Q →
        (∫ z,squareCost z ∂(π : Measure (A × B))) ≤ ∫ z,squareCost z ∂(γ : Measure (A × B)) ∧
        ((∫ z,squareCost z ∂(γ : Measure (A × B))) = ∫ z,squareCost z ∂(π : Measure (A × B)) →
          ∀ᵐ z ∂(γ : Measure (A × B)), IsLocalMin (fun x => φ x-rankCovector z.2.val x) z.1.val) := by
  obtain ⟨φ,L,lip,_,sup⟩ := square_cyclic_potential A B hb π cert.2.2
  let a (x : A) := φ x.val
  let v (k : B) := (extDual φ k.val).toReal - φ 0
  let w (z : A × B) := rankCovector z.2.val z.1.val
  let gap (z : A × B) := a z.1 + v z.2 - w z
  have ma : Continuous a := lip.continuous.comp continuous_subtype_val
  have mv : Measurable v := (((dual_meas φ).comp measurable_subtype_coe).ennreal_toReal).sub measurable_const
  have mw : Continuous w := by
    unfold w rankCovector; simp only [sum_apply,smul_apply,ContinuousLinearMap.proj_apply,smul_eq_mul]
    exact continuous_finsetSum _ fun i _ => ((continuous_apply i).comp (continuous_subtype_val.comp continuous_snd)).mul
      ((continuous_apply i).comp (continuous_subtype_val.comp continuous_fst))
  have cv : Continuous (rankCovector : RankPoint d → (RankPoint d →L[ℝ] ℝ)) := by unfold rankCovector; fun_prop
  obtain ⟨K,hK⟩ := hb.bddAbove_image cv.norm.continuousOn
  have ia : Integrable a (P : Measure A) := by
    apply ((moment1.const_mul (L:ℝ)).add (integrable_const |φ 0|)).mono' ma.aestronglyMeasurable
    filter_upwards with x
    have dx := lip.dist_le_mul x.val 0
    rw [Real.dist_eq,dist_zero_right] at dx
    change |φ x.val| ≤ (L:ℝ)*‖x.val‖+|φ 0|
    have eqn : φ x.val=(φ x.val-φ 0)+φ 0 := by ring
    calc |φ x.val| = |(φ x.val-φ 0)+φ 0| := congrArg abs eqn
         _ ≤ _ := (abs_add_le ..).trans (add_le_add_left dx _)
  have pNon (z : A × B) (hz : z ∈ (π : Measure (A × B)).support) := dual_contact φ z.1.val z.2.val (sup z hz)
  have aeFin : ∀ᵐ k ∂(Q : Measure B), extDual φ k.val ≠ ⊤ := by
    have law : (π : Measure (A × B)).map Prod.snd = (Q : Measure B) := congrArg Subtype.val cert.2.1
    apply (congrArg (fun μ : Measure B => ∀ᵐ k : B ∂μ, extDual φ k.val ≠ ⊤) law).mp
    apply (ae_map_iff measurable_snd.aemeasurable ((measurableSet_eq_fun ((dual_meas φ).comp measurable_subtype_coe) measurable_const).compl)).mpr
    filter_upwards [Measure.support_mem_ae (μ := (π : Measure (A × B)))] with z hz
    change extDual φ z.2.val ≠ ⊤
    rw [(pNon z hz).1]; exact ENNReal.ofReal_ne_top
  have iw (γ : ProbabilityMeasure (A × B)) (src : γ.map Prod.fst=P) : Integrable w (γ : Measure (A × B)) := by
    have src' := (congrArg Subtype.val src : (γ : Measure (A × B)).map Prod.fst = (P : Measure A))
    have i := ((take_marginal _ _ _ measurable_fst src' (fun x : A => ‖x.val‖)
      (continuous_norm.comp continuous_subtype_val).measurable).1.mpr moment1).const_mul K
    apply i.mono' mw.aestronglyMeasurable
    filter_upwards with z
    exact ((rankCovector z.2.val).le_opNorm z.1.val).trans
      (mul_le_mul_of_nonneg_right (hK (mem_image_of_mem _ z.2.property)) (norm_nonneg _))
  have p_eq : ∀ᵐ z ∂(π : Measure (A × B)), v z.2 = w z-a z.1 := by
    filter_upwards [Measure.support_mem_ae (μ := (π : Measure (A × B)))] with z hz
    unfold v w a; rw [(pNon z hz).1,ENNReal.toReal_ofReal (pNon z hz).2]; ring
  have ipi := take_marginal _ _ _ measurable_fst
    (congrArg Subtype.val cert.1 : (π : Measure (A × B)).map Prod.fst = _) a ma.measurable
  have iv : Integrable v (Q : Measure B) := by
    apply (take_marginal _ _ _ measurable_snd
      (congrArg Subtype.val cert.2.1 : (π : Measure (A × B)).map Prod.snd = _) v mv).1.mp
    exact ((iw π cert.1).sub (ipi.1.mpr ia)).congr (p_eq.mono (fun z h => h.symm))
  let k := (∫ x,normSq x.val ∂(P : Measure A))+(∫ y,normSq y.val ∂(Q : Measure B))-
    2*((∫ x,a x ∂(P : Measure A))+(∫ y,v y ∂(Q : Measure B)))
  have relation (γ : ProbabilityMeasure (A × B)) (src : γ.map Prod.fst=P) (dst : γ.map Prod.snd=Q) :
      Integrable gap (γ : Measure (A × B)) ∧ (∀ᵐ z ∂(γ : Measure (A × B)), 0 ≤ gap z) ∧
      (∫ z,squareCost z ∂(γ : Measure (A × B))) = k+2*(∫ z,gap z ∂(γ : Measure (A × B))) := by
    have s := (congrArg Subtype.val src : (γ : Measure (A × B)).map Prod.fst = _)
    have t := (congrArg Subtype.val dst : (γ : Measure (A × B)).map Prod.snd = _)
    have ga := take_marginal _ _ _ measurable_fst s a ma.measurable
    have gv := take_marginal _ _ _ measurable_snd t v mv
    have gs (z : A × B) : squareCost z = normSq z.1.val+normSq z.2.val-2*w z := cost_formula z
    have cNorm : Continuous (normSq : RankPoint d → ℝ) := by unfold normSq; fun_prop
    have ax := take_marginal _ _ _ measurable_fst s (fun x : A => normSq x.val) (cNorm.comp continuous_subtype_val).measurable
    have by' := take_marginal _ _ _ measurable_snd t (fun y : B => normSq y.val) (cNorm.comp continuous_subtype_val).measurable
    let _ : CompactSpace B := isCompact_iff_compactSpace.mp hb
    have ib : Integrable (fun y : B => normSq y.val) (Q : Measure B) :=
      (cNorm.comp continuous_subtype_val).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
    refine ⟨((ga.1.mpr ia).add (gv.1.mpr iv)).sub (iw γ src),?_,?_⟩
    · have fin : ∀ᵐ k ∂(γ : Measure (A × B)).map Prod.snd, extDual φ k.val ≠ ⊤ := (congrArg (fun μ : Measure B => ∀ᵐ k : B ∂μ, extDual φ k.val ≠ ⊤) t).mpr aeFin
      filter_upwards [ae_of_ae_map measurable_snd.aemeasurable fin] with z hz
      have b := dual_ineq φ z.1.val z.2.val hz
      unfold gap a v w; linarith only [b]
    · have e1 := integral_add (ax.1.mpr moment2) (by'.1.mpr ib)
      have e2 := integral_sub ((ax.1.mpr moment2).add (by'.1.mpr ib)) ((iw γ src).const_mul 2)
      have e3 := integral_add (ga.1.mpr ia) (gv.1.mpr iv)
      have e4 := integral_sub ((ga.1.mpr ia).add (gv.1.mpr iv)) (iw γ src)
      simp only [Function.comp_apply,Pi.add_apply] at e1 e2 e3 e4
      simp_rw [gs]; unfold gap k
      rw [e2,e1,e4,e3,integral_const_mul,ax.2,by'.2,ga.2,gv.2]; ring!
  have zero : (∫ z,gap z ∂(π : Measure (A × B))) = 0 := by
    apply integral_eq_zero_of_ae
    filter_upwards [p_eq] with z hz; change a z.1 + v z.2 - w z = 0; rw [hz]; ring
  have pCost := (relation π cert.1 cert.2.1).2.2
  rw [zero,mul_zero,add_zero] at pCost
  refine ⟨φ,L,lip,fun γ src dst => ?_⟩
  obtain ⟨ig,ng,hg⟩ := relation γ src dst
  rw [pCost,hg]
  refine ⟨by linarith only [integral_nonneg_of_ae ng],fun eqn => ?_⟩
  have zg := (integral_eq_zero_iff_of_nonneg_ae ng ig).mp (by linarith only [eqn])
  have targetEq : (γ : Measure (A × B)).map Prod.snd = (Q : Measure B) := congrArg Subtype.val dst
  have finiteγ : ∀ᵐ k ∂(γ : Measure (A × B)).map Prod.snd, extDual φ k.val ≠ ⊤ := (congrArg (fun μ : Measure B => ∀ᵐ k : B ∂μ, extDual φ k.val ≠ ⊤) targetEq).mpr aeFin
  filter_upwards [zg,ae_of_ae_map measurable_snd.aemeasurable finiteγ] with z hz fin
  apply Filter.Eventually.of_forall
  intro x
  have hh := dual_ineq φ x z.2.val fin
  change a z.1+v z.2-w z = 0 at hz
  unfold a v w at hz
  change φ z.1.val - rankCovector z.2.val z.1.val ≤ φ x - rankCovector z.2.val x
  linarith only [hh,hz]
/-- Static uniqueness and optimality with noncompact observations. The source
has a finite first and second moment. The only existence input is one cyclic
coupling, which can also be obtained as a tight limit of finite problems. -/
theorem unbounded_brenier_from_cyclic {d : ℕ} (A B : Set (RankPoint d)) (hb : IsCompact B) [Nonempty B]
    (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B)
    (ac : (P : Measure A).map Subtype.val ≪ volume)
    (m1 : Integrable (fun x : A => ‖x.val‖) (P : Measure A))
    (m2 : Integrable (fun x : A => normSq x.val) (P : Measure A))
    (existsPlan : ∃ π, certifiedPlan squareCost P Q π) :
    ∃ (f : A → B) (π : ProbabilityMeasure (A × B)), Measurable f ∧
      certifiedPlan squareCost P Q π ∧ P.map (fun x => (x,f x)) = π ∧
      (∀ γ, certifiedPlan squareCost P Q γ → γ=π) ∧
      ∀ γ : ProbabilityMeasure (A × B), γ.map Prod.fst=P → γ.map Prod.snd=Q →
        (∫ z,squareCost z ∂(π : Measure (A × B))) ≤ ∫ z,squareCost z ∂(γ : Measure (A × B)) ∧
        ((∫ z,squareCost z ∂(γ : Measure (A × B))) = ∫ z,squareCost z ∂(π : Measure (A × B)) → γ=π) := by
  obtain ⟨π,hπ⟩ := existsPlan
  obtain ⟨φ,L,lip,comp⟩ := unbounded_square_contact A B hb P Q m1 m2 π hπ
  let f := supportGradient (A := A) (B := B) φ
  have mB := hb.isClosed.measurableSet
  have graph (η : ProbabilityMeasure (A × B)) (a : η.map Prod.fst=P) (b : η.map Prod.snd=Q)
      (eq : (∫ z,squareCost z ∂(η : Measure (A × B))) = ∫ z,squareCost z ∂(π : Measure (A × B))) :
      P.map (fun x => (x,f x)) = η :=
    graph_of_lipschitz_contact mB η P a ac φ lip ((comp η a b).2 eq)
  have gen := graph π hπ.1 hπ.2.1 rfl
  refine ⟨f,π,measurable_supportGradient mB φ,hπ,gen,?_,?_⟩
  · intro η cert
    obtain ⟨_,_,_,back⟩ := unbounded_square_contact A B hb P Q m1 m2 η cert
    have eq := le_antisymm (back π hπ.1 hπ.2.1).1 (comp η cert.1 cert.2.1).1
    exact (graph η cert.1 cert.2.1 eq).symm.trans gen
  · intro γ a b
    exact ⟨(comp γ a b).1,fun eq => (graph γ a b eq).symm.trans gen⟩

end
end SequentialRanks
