import ContinuumUniform
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

open MeasureTheory Set Filter
open scoped ENNReal
namespace Vortex
noncomputable section

/-- The equal-score set of two distinct power sites is a proper affine
hyperplane. This holds for all choices of the two additive intercepts. -/
theorem affine_score_tie_null {a b : Space} (ne : a ≠ b) (u v : ℝ) :
    (volume : Measure Space) {x | linearScore a x + u = linearScore b x + v} = 0 := by
  let F : Space →ₗ[ℝ] ℝ :=
    { toFun := fun x => linearScore a x-linearScore b x
      map_add' := by rintro ⟨⟨x,y⟩,z⟩ ⟨⟨x',y'⟩,z'⟩; dsimp [linearScore]; ring
      map_smul' := by rintro r ⟨⟨x,y⟩,z⟩; dsimp [linearScore]; ring }
  let S : AffineSubspace ℝ Space :=
    { carrier := {x | F x = v-u}
      smul_vsub_vadd_mem' := by
        intro r x y z hx hy hz
        change F x = v-u at hx; change F y = v-u at hy; change F z = v-u at hz
        change F (r • (x-y)+z) = _
        rw [map_add,map_smul,map_sub,hx,hy,hz,sub_self,smul_zero,zero_add] }
  have proper : S ≠ ⊤ := by
    intro all
    have same (x : Space) : F x = v-u := (show x ∈ S by rw [all]; trivial)
    have zero := same 0
    rw [map_zero] at zero
    have x := same ((1,0),0)
    have y := same ((0,1),0)
    have z := same ((0,0),1)
    change linearScore a ((1,0),0)-linearScore b ((1,0),0) = v-u at x
    change linearScore a ((0,1),0)-linearScore b ((0,1),0) = v-u at y
    change linearScore a ((0,0),1)-linearScore b ((0,0),1) = v-u at z
    norm_num [linearScore] at x y z
    apply ne; refine Prod.ext (Prod.ext ?_ ?_) ?_ <;> linarith
  have : (volume : Measure Space).IsAddHaarMeasure := by
    rw [Measure.volume_eq_prod H ℝ,Measure.volume_eq_prod ℝ ℝ]
    exact Measure.prod.instIsAddHaarMeasure ((volume : Measure ℝ).prod (volume : Measure ℝ)) (volume : Measure ℝ)
  apply measure_mono_null ?_ (Measure.addHaar_affineSubspace volume S proper)
  intro x hx; change (_:ℝ) = _ at hx
  change linearScore a x - linearScore b x = v-u; linarith

/-- A uniform physical body assigns zero mass to equality of the two
power scores, in its compact carrier as well as in its ambient law. -/
theorem uniform_tie_null {J : Set Space} (W : ProbabilityMeasure J) (unif : UniformBodyLaw J W)
    {N : ℕ} (site : Fin N → Space) (inj : Function.Injective site) (w : Fin N → ℝ)
    {i j : Fin N} (ne : i ≠ j) :
    (W : Measure J).map Subtype.val {x | linearScore (site i) x + w i = linearScore (site j) x + w j} = 0 ∧
    (W : Measure J) {x | linearScore (site i) x.val + w i = linearScore (site j) x.val + w j} = 0 := by
  have m : MeasurableSet {x | linearScore (site i) x + w i = linearScore (site j) x + w j} := by
    apply measurableSet_eq_fun <;> unfold linearScore <;> fun_prop
  obtain ⟨d,h⟩ := unif
  have ac : (W : Measure J).map Subtype.val ≪ volume := h ▸ (Measure.absolutelyContinuous_of_le Measure.restrict_le_self).smul_left d
  have amb := ac (affine_score_tie_null (inj.ne ne) (w i) (w j))
  refine ⟨amb,?_⟩
  rw [Measure.map_apply measurable_subtype_coe m] at amb; exact amb

end
end Vortex
