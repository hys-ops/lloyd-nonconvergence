import StationaryGeometry

open MeasureTheory Set Filter
namespace Vortex
noncomputable section

private def τ : ℝ := 2*Real.pi
private theorem posτ : 0 < τ := by unfold τ; positivity

private def angularMean (f : Space → ℝ) (y : Space) : ℝ :=
  ∫ a in Ioc 0 τ, f (rotateMap a y)

private theorem shift_mean (f : Space → ℝ) (y : Space) (b : ℝ) :
    angularMean f (rotateMap b y) = angularMean f y := by
  let g : ℝ → ℝ := fun a => f (rotateMap a y)
  have periodic : Function.Periodic g τ := by
    intro a; simp [g,rotateMap,τ]
  unfold angularMean
  simp_rw [rotate_compose]
  rw [← intervalIntegral.integral_of_le posτ.le,← intervalIntegral.integral_of_le posτ.le]
  change (∫ a in 0..τ, g (a+b)) = ∫ a in 0..τ, g a
  rw [intervalIntegral.integral_comp_add_right]
  simpa [add_comm] using periodic.intervalIntegral_add_eq b 0

private theorem invariant_average (ν : Measure Space) [IsFiniteMeasure ν]
    (rot : ∀ a, ν.map (rotateMap a) = ν)
    (f : Space → ℝ) (hf : Measurable f) (C : ℝ) (bound : ∀ y, ‖f y‖ ≤ C) :
    (∫ y, angularMean f y ∂ν) = τ * ∫ y, f y ∂ν := by
  let angles := (volume : Measure ℝ).restrict (Ioc 0 τ)
  have hangles : IsFiniteMeasure angles := isFiniteMeasure_restrict.mpr (by simp [Real.volume_Ioc])
  let F (y : Space) (a : ℝ) := f (rotateMap a y)
  have mF : Measurable (Function.uncurry F) := by
    apply hf.comp
    unfold rotateMap
    fun_prop
  have iF : Integrable (Function.uncurry F) (ν.prod angles) :=
    (integrable_const C).mono' mF.aestronglyMeasurable (ae_of_all _ fun _ => bound _)
  have each (a : ℝ) : (∫ y, f (rotateMap a y) ∂ν) = ∫ y, f y ∂ν := by
    have mr : Measurable (rotateMap a) := by unfold rotateMap; fun_prop
    rw [← integral_map mr.aemeasurable hf.aestronglyMeasurable,rot]
  change (∫ y, ∫ a, F y a ∂angles ∂ν) = _
  rw [integral_integral_swap iF]
  simp only [F,each]
  rw [integral_const,smul_eq_mul]
  congr 1
  simp [angles,Measure.real,Real.volume_Ioc,ENNReal.toReal_ofReal posτ.le]

private theorem mean_meas (f : Space → ℝ) (hf : Measurable f) : Measurable (angularMean f) := by
  let angles := (volume : Measure ℝ).restrict (Ioc 0 τ)
  have : IsFiniteMeasure angles := isFiniteMeasure_restrict.mpr (by simp [Real.volume_Ioc])
  apply StronglyMeasurable.measurable
  apply StronglyMeasurable.integral_prod_right (ν := angles)
  apply Measurable.stronglyMeasurable
  apply hf.comp
  unfold rotateMap
  fun_prop

/-- Every finite axially invariant spatial law is invariant when a bounded observable
is reflected in a vertical plane, including laws without a density. -/
theorem mirror_integral_from_rotations (ν : Measure Space) [IsFiniteMeasure ν]
    (rot : ∀ a, ν.map (rotateMap a) = ν)
    (f : Space → ℝ) (hf : Measurable f) (C : ℝ) (bound : ∀ y, ‖f y‖ ≤ C) :
    (∫ y, f (mirrorMap y) ∂ν) = ∫ y, f y ∂ν := by
  let ν' := ν.map mirrorMap
  have mm := mirror_volume.measurable
  have rot' (a : ℝ) : ν'.map (rotateMap a) = ν' := by
    have comm : rotateMap a ∘ mirrorMap = mirrorMap ∘ rotateMap (-a) := by
      funext y; ext <;> simp [rotateMap,mirrorMap]; try ring
    unfold ν'
    rw [Measure.map_map (rotation_volume a).measurable mm,comm,← Measure.map_map mm (rotation_volume (-a)).measurable,rot]
  have eqmean (y : Space) : angularMean f (mirrorMap y) = angularMean f y := by
    obtain ⟨a,h⟩ := mirror_on_orbit y
    rw [h,shift_mean]
  have x := invariant_average ν rot f hf C bound
  have y := invariant_average ν' rot' f hf C bound
  change (∫ z, angularMean f z ∂ν.map mirrorMap)=τ*(∫ z, f z ∂ν.map mirrorMap) at y
  rw [integral_map mm.aemeasurable (mean_meas _ hf).aestronglyMeasurable,
    integral_map mm.aemeasurable hf.aestronglyMeasurable] at y
  simp_rw [eqmean] at y
  exact mul_left_cancel₀ posτ.ne' (y.symm.trans x)
end
end Vortex
