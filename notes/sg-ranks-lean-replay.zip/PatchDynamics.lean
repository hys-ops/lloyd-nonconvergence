import Torque

open MeasureTheory Set Filter
namespace Vortex
noncomputable section

def flowVelocity (S : ℝ → Space → Space) (s : ℝ × Space) : H :=
  vel s.2.1 (S s.1 s.2).1

private theorem in_slice (E : ℝ → Set Space) (moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1})
    (u : ℝ) : MeasurableSet (E u) := moving.preimage (measurable_const.prodMk measurable_id)

private theorem slab_set (E : ℝ → Set Space) (moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1})
    (t : ℝ) : MeasurableSet {s : ℝ × Space | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1} :=
  (measurable_fst measurableSet_Icc).inter moving

private theorem sliced_indicator (E : ℝ → Set Space) (t u : ℝ) (hu : u ∈ Icc 0 t)
    (f : ℝ × Space → ℝ) :
    (fun y => ({s : ℝ × Space | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1}).indicator f (u,y)) =
    (E u).indicator (fun y => f (u,y)) := by
  classical
  funext y; by_cases hy : y ∈ E u <;> simp [indicator,hu.1,hu.2,hy]

/-- Integration and slice integrability on the actual moving occupation measure. -/
theorem occupation_fubini (E : ℝ → Set Space) (moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1})
    (t : ℝ) (f : ℝ × Space → ℝ) (hf : Integrable f (occupation E t)) :
    (∫ s, f s ∂occupation E t) = (∫ u in Icc 0 t, ∫ y in E u, f (u,y)) ∧
    ∀ᵐ u ∂volume.restrict (Icc 0 t), IntegrableOn (fun y => f (u,y)) (E u) := by
  let A := {s : ℝ × Space | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1}
  have hA := slab_set E moving t
  have hprod : Integrable (A.indicator f) ((volume : Measure ℝ).prod (volume : Measure Space)) :=
    (integrable_indicator_iff hA).mpr hf
  constructor
  · change (∫ s in A, f s) = _
    rw [← integral_indicator hA,Measure.volume_eq_prod ℝ Space,integral_prod _ hprod,
      ← integral_indicator measurableSet_Icc]
    apply integral_congr_ae
    filter_upwards with u
    by_cases hu : u ∈ Icc 0 t
    · rw [indicator_of_mem hu,sliced_indicator E t u hu,integral_indicator (in_slice E moving u)]
    · rw [indicator_of_notMem hu]
      apply integral_eq_zero_of_ae
      filter_upwards with y
      exact indicator_of_notMem (fun (h : (u,y) ∈ A) => hu h.1) _
  · apply (ae_restrict_iff' measurableSet_Icc).mpr
    filter_upwards [hprod.prod_right_ae] with u hi
    intro hu
    rw [sliced_indicator E t u hu] at hi
    exact (integrable_indicator_iff (in_slice E moving u)).mp hi

private theorem velocity_growth (y x : Space) : ‖vel y.1 x.1‖ ≤ ‖y‖+‖x‖ := by
  have h : ‖y.1-x.1‖ ≤ ‖y‖+‖x‖ := (norm_sub_le ..).trans (add_le_add (norm_fst_le y) (norm_fst_le x))
  have same : ‖vel y.1 x.1‖ = ‖y.1-x.1‖ := by
    change max ‖-(y.1.2-x.1.2)‖ ‖y.1.1-x.1.1‖ = max ‖y.1.1-x.1.1‖ ‖y.1.2-x.1.2‖
    rw [norm_neg,max_comm]
  rwa [same]

private theorem mixed_integrable (S : ℝ → Space → Space) (μ : Measure (ℝ × Space))
    (hw : Integrable (flowVelocity S) μ)
    (left : Integrable (fun s : ℝ × Space => ‖s.2‖^2) μ)
    (right : Integrable (fun s : ℝ × Space => ‖S s.1 s.2‖^2) μ) :
    Integrable (fun s : ℝ × Space => ‖s.2‖*‖flowVelocity S s‖) μ := by
  apply ((left.add right).const_mul 2).mono' (continuous_snd.norm.aestronglyMeasurable.mul hw.norm.aestronglyMeasurable)
  filter_upwards with s
  change ‖‖s.2‖*‖flowVelocity S s‖‖ ≤ _
  rw [Real.norm_of_nonneg (mul_nonneg (norm_nonneg _) (norm_nonneg _))]
  have h := mul_le_mul_of_nonneg_left (velocity_growth s.2 (S s.1 s.2)) (norm_nonneg s.2)
  change ‖s.2‖*‖vel s.2.1 (S s.1 s.2).1‖ ≤ 2*(‖s.2‖^2+‖S s.1 s.2‖^2)
  nlinarith only [h,sq_nonneg (‖s.2‖-‖S s.1 s.2‖),sq_nonneg ‖s.2‖,sq_nonneg ‖S s.1 s.2‖]

/-- Horizontal impulse conservation from the actual two-trace weak equation
and rotational invariance of the optimal transport marginal at almost every time. -/
theorem radial_conservation (E0 : Set Space) (E : ℝ → Set Space) (t ρ : ℝ) (ht : 0 ≤ t)
    (hρ : 0 < ρ) (S : ℝ → Space → Space) (target : Measure Space)
    (moving : MeasurableSet {s : ℝ × Space | s.2 ∈ E s.1})
    (hw : Integrable (flowVelocity S) (occupation E t))
    (left : Integrable (fun s : ℝ × Space => ‖s.2‖^2) (occupation E t))
    (right : Integrable (fun s : ℝ × Space => ‖S s.1 s.2‖^2) (occupation E t))
    (momentInitial : IntegrableOn radialSquare E0) (momentNow : IntegrableOn radialSquare (E t))
    (eqn : WeakPatchEquation E0 E t ρ (flowVelocity S))
    (optimal : ∀ᵐ u ∂volume.restrict (Icc 0 t), SymmetricMonge (volume.restrict (E u)) target (S u)) :
    (∫ y in E t, radialSquare y) = ∫ y in E0, radialSquare y := by
  let μ := occupation E t
  have mixed := mixed_integrable S μ hw left right
  let f := fun s : ℝ × Space => 2*horizontalWork s.2 (flowVelocity S s)
  have hwork : Integrable f μ := by
    apply (mixed.const_mul 4).mono' ?_
    · filter_upwards with s
      change ‖2*horizontalWork s.2 (flowVelocity S s)‖ ≤ 4*(‖s.2‖*‖flowVelocity S s‖)
      rw [norm_mul,Real.norm_of_nonneg (by norm_num : 0 ≤ (2:ℝ))]
      linarith [work_bound s.2 (flowVelocity S s)]
    · have hm := hw.aestronglyMeasurable
      unfold f horizontalWork
      exact (((continuous_fst.comp (continuous_fst.comp continuous_snd)).aestronglyMeasurable.mul
        (continuous_fst.comp_aestronglyMeasurable hm)).add
        ((continuous_snd.comp (continuous_fst.comp continuous_snd)).aestronglyMeasurable.mul
        (continuous_snd.comp_aestronglyMeasurable hm))).const_mul 2
  have fub := (occupation_fubini E moving t f hwork).1
  have l := (occupation_fubini E moving t _ left).2
  have r := (occupation_fubini E moving t _ right).2
  have result := impulse_balance_from_trace E0 (E t) μ (flowVelocity S) hw.aestronglyMeasurable
    mixed momentInitial momentNow (horizontal_trace_of_weak_patch E0 E t ρ ht hρ _ moving eqn)
  apply sub_eq_zero.mp
  calc
    _ = ∫ s, f s ∂μ := result
    _ = _ := fub
    _ = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [optimal,l,r] with u hu hl hr
      exact torque_of_optimal_map (volume.restrict (E u)) target (S u) hu hl hr

private def momentDensity (E : Set Space) (ρ : ℝ) (y : Space) := radialSquare y * patch E ρ y
private theorem moment_as_indicator (E : Set Space) (ρ : ℝ) :
    momentDensity E ρ = E.indicator (fun y => ρ*radialSquare y) := by
  classical funext y; by_cases hy : y ∈ E <;> simp [momentDensity,indicator,patch,hy,mul_comm]

theorem excess_of_radial_conservation (E0 E B : Set Space) (ρ : ℝ)
    (m0 : MeasurableSet E0) (me : MeasurableSet E) (h0 : IntegrableOn radialSquare E0)
    (he : IntegrableOn radialSquare E)
    (signed : Integrable (fun y : Space => radialSquare y*(patch E ρ y-patch B ρ y)))
    (same : (∫ y in E,radialSquare y) = ∫ y in E0,radialSquare y) :
    impulse E B ρ = impulse E0 B ρ := by
  have ii (A : Set Space) (ma : MeasurableSet A) (hi : IntegrableOn radialSquare A) :
      Integrable (momentDensity A ρ) := by
    rw [moment_as_indicator]; exact (integrable_indicator_iff ma).mpr (hi.const_mul ρ)
  have iv (A : Set Space) (ma : MeasurableSet A) :
      (∫ y, momentDensity A ρ y) = ρ*(∫ y in A, radialSquare y) := by
    rw [moment_as_indicator,integral_indicator ma,integral_const_mul]
  have identity (y : Space) : radialSquare y*(patch E0 ρ y - patch B ρ y) =
      radialSquare y*(patch E ρ y-patch B ρ y)+(momentDensity E0 ρ y-momentDensity E ρ y) := by
    unfold momentDensity; ring
  change (∫ y, radialSquare y*(patch E ρ y-patch B ρ y)) =
    ∫ y,radialSquare y*(patch E0 ρ y-patch B ρ y)
  simp_rw [identity]
  have diffInt : Integrable (fun y => momentDensity E0 ρ y - momentDensity E ρ y) :=
    (ii E0 m0 h0).sub (ii E me he)
  rw [integral_add signed diffInt,integral_sub (ii E0 m0 h0) (ii E me he),
    iv E0 m0,iv E me,same,sub_self,add_zero]

structure DynamicInputs (E0 : Set Space) (E : ℝ → Set Space) (t ρ R a b : ℝ)
    (S : ℝ → Space → Space) (V : Space → H) (target : Measure Space) : Prop
    extends TraceFoundation E0 E t ρ R a b (fun y => (S t y).1) V (flowVelocity S) where
  spaceMoment : Integrable (fun s : ℝ × Space => ‖s.2‖^2) (occupation E t)
  mapMoment : Integrable (fun s : ℝ × Space => ‖S s.1 s.2‖^2) (occupation E t)
  momentInitial : IntegrableOn radialSquare E0
  momentNow : IntegrableOn radialSquare (E t)
  optimal : ∀ᵐ u ∂volume.restrict (Icc 0 t), SymmetricMonge (volume.restrict (E u)) target (S u)

/-- Both conservation laws are derived. Only the continuum endpoint estimate,
weak solution, rotational optimality and the listed analytic bounds are supplied. -/
theorem overlap_from_dynamics (times : Set ℝ) (E0 : Set Space) (E : ℝ → Set Space)
    (S : ℝ → Space → Space) (V : Space → H) (target : Measure Space) (ρ R a b : ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (h : ∀ᵐ t ∂volume.restrict times, DynamicInputs E0 E t ρ R a b S V target) :
    ∀ᵐ t ∂volume.restrict times,
      ρ*(∫ y in E t ∩ circular E0, distSq (vel y.1 (S t y).1) (vel y.1 (V y))) ≤
      4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 (circular E0) ρ) := by
  apply overlap_from_weak_patch times E0 E (fun t y => (S t y).1) V (flowVelocity S) ρ R a b hρ hab
  filter_upwards [h] with t ht
  have rad := radial_conservation E0 E t ρ ht.timeNonneg hρ S target ht.moving ht.velocityInt
    ht.spaceMoment ht.mapMoment ht.momentInitial ht.momentNow ht.weakEq ht.optimal
  exact ⟨ht.toTraceFoundation,excess_of_radial_conservation E0 (E t) (circular E0) ρ
    ht.measurableInitial (in_slice E ht.moving t) ht.momentInitial ht.momentNow ht.impulseInt rad⟩
end
end Vortex
