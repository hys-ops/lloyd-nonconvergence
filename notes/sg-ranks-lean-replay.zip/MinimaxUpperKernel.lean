import MinimaxUpperSelection
import Mathlib.Probability.Kernel.RadonNikodym

open MeasureTheory ProbabilityTheory Set Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- Conditional laws need only have densities at almost every realized history.
For a compact observation set of positive Lebesgue measure, normalization on
null histories and conversion from extended densities to real densities is automatic. -/
theorem forecast_of_ac_kernel {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    [MeasurableSpace.CountableOrCountablyGenerated H Y] (ν : Measure Y) [IsFiniteMeasure ν] [NeZero ν]
    (κ : Kernel H Y) [IsMarkovKernel κ] :
    ∃ f : Forecast H Y ν, ∀ h, κ h ≪ ν → (f.law h : Measure Y)=κ h := by
  let base := Kernel.const H ν
  let p := fun z : H × Y => κ.rnDeriv base z.1 z.2
  let valid := fun h => (∫⁻ y,p (h,y) ∂ν) = 1
  have mp : Measurable p := κ.measurable_rnDeriv _
  have mv : MeasurableSet {h | valid h} := measurableSet_eq_fun (mp.lintegral_prod_right' (ν := ν)) measurable_const
  have mright h : AEMeasurable (fun y => p (h,y)) ν := (mp.comp (measurable_const.prodMk measurable_id)).aemeasurable
  have fin h (v : valid h) : (∫⁻ y,p (h,y) ∂ν) ≠ ∞ := by rw [v]; exact ENNReal.one_ne_top
  let d : ℝ := (ν.real univ)⁻¹
  let f : Forecast H Y ν :=
    { f := fun z => if valid z.1 then (p z).toReal else d
      measurable := Measurable.ite (measurable_fst mv) mp.ennreal_toReal measurable_const
      nonneg := fun z => by split_ifs; exact ENNReal.toReal_nonneg; exact inv_nonneg.mpr (by positivity)
      integrable := fun h => by
        dsimp only; split_ifs with v
        · exact integrable_toReal_of_lintegral_ne_top (mright h) (fin h v)
        · exact integrable_const _
      mass := fun h => by
        dsimp only; split_ifs with v
        · rw [integral_toReal (mright h) (ae_lt_top' (mright h) (fin h v)),v,ENNReal.toReal_one]
        · simp [d,integral_const,smul_eq_mul,measureReal_univ_ne_zero] }
  refine ⟨f,?_⟩
  intro h hac
  have good : valid h := by
    have v := Kernel.lintegral_rnDeriv (η := base) (κ := κ) (a := h) (show κ h ≪ base h from hac)
    simpa [valid,p,base] using v
  change ν.withDensity (fun y => ENNReal.ofReal (if valid h then (p (h,y)).toReal else d)) = _
  simp only [good,ite_true]
  have es := ae_lt_top' (mright h) (fin h good)
  have raw : ν.withDensity (fun y => p (h,y)) = κ h := by
    have ok := Kernel.withDensity_rnDeriv_eq (η := base) (κ := κ) (a := h) (show κ h ≪ base h from hac)
    rw [Kernel.withDensity_apply _ mp] at ok
    exact ok
  exact (withDensity_congr_ae (es.mono fun y hy => ENNReal.ofReal_toReal hy.ne)).trans raw

end
end SequentialRanks
