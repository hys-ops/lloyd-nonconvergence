import SGCellChartLaws
import SGFiniteMidpointInput
import CellMidpointDensity

open MeasureTheory Set Filter
open scoped ENNReal
namespace Vortex
noncomputable section
open SequentialRanks

private def physMid (x y : Space) := (1/2 : ℝ) • (x+y)
private theorem chart_mid (x y : Space) : sgChart (physMid x y) = mid (sgChart x) (sgChart y) := by
  ext i; fin_cases i
  · change (1/2:ℝ)*(x.1.1+y.1.1)=(x.1.1+y.1.1)/2; ring
  · change (1/2:ℝ)*(x.1.2+y.1.2)=(x.1.2+y.1.2)/2; ring
  · change (1/2:ℝ)*(x.2+y.2)=(x.2+y.2)/2; ring

/-- Normalized restrictions of one uniform compact convex body have a common
midpoint coupling. The construction also checks the square-root mass factor
when returning from probability normalization to the uniform physical law. -/
theorem uniform_cell_midpoints : CellMidpoints := by
  classical
  intro J instJ conv W unif A B ma mb ap bp
  have hJ : IsCompact J := isCompact_iff_compactSpace.mpr instJ
  have mJ := hJ.isClosed.measurableSet
  obtain ⟨d,hd⟩ := unif
  let K := sgChart '' J
  have hK : IsCompact K := hJ.image sgChart.continuous
  let e : J ≃ₜ K := sgChart.image J
  have neA : ((W : Measure J) A) ≠ 0 := (ENNReal.toReal_pos_iff.mp ap).1.ne'
  obtain ⟨x,_⟩ := nonempty_of_measure_ne_zero neA
  have : Nonempty K := ⟨e x⟩
  let p := cellDensity W d A
  let q := cellDensity W d B
  let C := cellConst W d A
  let D := cellConst W d B
  obtain ⟨mp,pn,pc,pP,sP⟩ := chart_normalized_cell_data mJ W d hd A ma ap
  obtain ⟨_,qn,qd,pQ,sQ⟩ := chart_normalized_cell_data mJ W d hd B mb bp
  obtain ⟨π,first,second,middle⟩ := cell_midpoint_coupling K hK p q C D mp pn qn pc qd sP sQ
  let back : K × K → J × J := fun z => (e.symm z.1,e.symm z.2)
  have mback : Measurable back := (e.symm.measurable.comp measurable_fst).prodMk (e.symm.measurable.comp measurable_snd)
  let γ := π.map back
  let f := chartVal J
  have em := chartVal_embedding mJ
  have val (z : K) : f (e.symm z) = z.val := congrArg Subtype.val (e.apply_symm_apply z)
  have marginal (g : J × J → J) (i : K × K → K) (mg : Measurable g) (μ : Measure J)
      (co : ∀ z, f (g (back z)) = (i z).val) (law : (π : Measure (K × K)).map (fun z => (i z).val) = μ.map f) :
      (γ : Measure (J × J)).map g = μ := by
    apply em.map_injective
    change (((π : Measure (K × K)).map back).map g).map f = _
    rw [Measure.map_map em.measurable mg,Measure.map_map (em.measurable.comp mg) mback]
    exact (Measure.map_congr (.of_forall co)).trans law
  have eqA := chart_normalized_cell mJ W d hd A ma ap
  have eqB := chart_normalized_cell mJ W d hd B mb bp
  refine ⟨γ,marginal Prod.fst Prod.fst measurable_fst (cellLaw W A) (fun z => val z.1) (first.trans eqA.symm),
      marginal Prod.snd Prod.snd measurable_snd (cellLaw W B) (fun z => val z.2) (second.trans eqB.symm),?_⟩
  let physical := fun z : J × J => physMid z.1.val z.2.val
  let euclid := fun z : K × K => mid z.1.val z.2.val
  have mphys : Measurable physical := by unfold physical physMid; fun_prop
  have meu : Measurable euclid := by
    apply Measurable.of_eval; intro i
    exact (((measurable_pi_apply i).comp (measurable_subtype_coe.comp measurable_fst)).add
      ((measurable_pi_apply i).comp (measurable_subtype_coe.comp measurable_snd))).div_const 2
  let η := (γ : Measure (J × J)).map physical
  let c := ENNReal.ofReal (Real.sqrt C*Real.sqrt D)
  let weight := ENNReal.ofReal (Real.sqrt ((W : Measure J).real A * (W : Measure J).real B))
  have identified : η = ((π : Measure (K × K)).map euclid).map sgChart.symm := by
    change ((π : Measure (K × K)).map back).map physical = _
    rw [Measure.map_map mphys mback,Measure.map_map sgChart.symm.measurable meu]
    apply Measure.map_congr
    filter_upwards with z
    apply sgChart.injective
    change sgChart (physMid (e.symm z.1).val (e.symm z.2).val) = sgChart (sgChart.symm (euclid z))
    rw [chart_mid,sgChart.apply_symm_apply]
    exact congrArg₂ mid (val z.1) (val z.2)
  have invVol : (volume : Measure (RankPoint 3)).map sgChart.symm = volume := by
    rw [← sgChart_volume.map_eq,Measure.map_map sgChart.symm.measurable sgChart.measurable]
    simp
  have ambient : η ≤ c • (volume : Measure Space) := by
    rw [identified]
    have lifted := Measure.map_mono middle sgChart.symm.measurable
    simpa only [Measure.map_smul _ sgChart.symm.measurable.aemeasurable,invVol] using lifted
  have weightedDom : weight • η ≤ d • volume := by
    have h : weight • η ≤ weight • (c • volume) := by
      intro s; exact mul_le_mul_of_nonneg_left (ambient s) (show 0 ≤ weight from bot_le)
    rwa [smul_smul,show weight*c = d from cell_sqrt_scale W d (body_density_finite W d hd) A B ap bp] at h
  have keep : η.restrict J = η := Measure.restrict_eq_self_of_ae_mem (by
    apply (ae_map_iff (p := fun x => x ∈ J) mphys.aemeasurable mJ).2
    filter_upwards with z
    simpa only [physical,physMid,midpoint_eq_smul_add,invOf_eq_inv,one_div] using (conv.midpoint_mem z.1.property z.2.property))
  change weight • η ≤ _
  rw [hd]
  have r := Measure.restrict_mono (Subset.rfl : J ⊆ J) weightedDom
  simpa only [Measure.restrict_smul,keep] using r
end
end Vortex
