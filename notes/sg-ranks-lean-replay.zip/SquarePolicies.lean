import SquareIIDUpper
import MinimaxLowerInformation
open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- Chronological coordinate list for the nested product used for sequential policies. -/
def pastEntries : (n : ℕ) → Past n → Fin n → SquareObs
  | 0, _ => Fin.elim0
  | n+1, x => (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => SquareObs) (Fin.last n)).symm
    (x.2,pastEntries n x.1)

private theorem iidPast_prob (θ : ℝ) (hθ : |θ|≤1/2) : ∀ n, IsProbabilityMeasure (iidPastLaw θ n)
  | 0 => (inferInstance : IsProbabilityMeasure (Measure.dirac ()))
  | n+1 => by
    let _ := iidPast_prob θ hθ n
    let _ := square_law_probability hθ
    change IsProbabilityMeasure ((iidPastLaw θ n).prod (squareLaw θ)); infer_instance

theorem pastEntries_preserving (θ : ℝ) (ht : |θ|≤1/2) : ∀ n,
    MeasurePreserving (pastEntries n) (iidPastLaw θ n) (iidSampleLaw n θ)
  | 0 => by
    refine ⟨measurable_const,?_⟩
    change (Measure.dirac ()).map (fun _ => Fin.elim0) = Measure.pi _
    rw [Measure.map_dirac,Measure.pi_of_empty _ Fin.elim0]
  | n+1 => by
    let _ := iidPast_prob θ ht n
    let _ := square_law_probability ht
    let _ : IsProbabilityMeasure (iidSampleLaw n θ) := (inferInstance : IsProbabilityMeasure (Measure.pi _))
    let join := MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => SquareObs) (Fin.last n)
    have j := MeasurePreserving.symm join (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => squareLaw θ) (Fin.last n))
    exact j.comp (Measure.measurePreserving_swap.comp ((pastEntries_preserving θ ht n).prod (MeasurePreserving.id (squareLaw θ))))

def iidClippedPolicy (n : ℕ) (p : Past n × SquareObs) :=
  estimatedRank n (pastEntries n p.1) p.2

set_option maxHeartbeats 1300000 in
private theorem square_exp_loss (n : ℕ) (θ : ℝ) (ht : |θ| ≤ 1/2) :
    (∫⁻ x, lossE θ (iidClippedPolicy n x) x.2 ∂(iidPastLaw θ n).prod (squareLaw θ)) =
    ENNReal.ofReal (squareDateRisk n θ) := by
  let _ := square_law_probability ht
  let _ := iidPast_prob θ ht n
  let _ : IsProbabilityMeasure (iidSampleLaw n θ) := (inferInstance : IsProbabilityMeasure (Measure.pi _))
  let E (z : (Fin n → SquareObs) × SquareObs) := squareCost2 (estimatedRank n z.1 z.2) (squareMap θ z.2)
  have mp := (pastEntries_preserving θ ht n).prod (MeasurePreserving.id (squareLaw θ))
  have me := (square_iid_uniform_upper 0).1 n
  have mS : Measurable (fun z : (Fin n → SquareObs) × SquareObs => squareMap θ z.2) := by unfold squareMap perturb; fun_prop
  have mE : Measurable E := ((me.fst.sub mS.fst).pow_const 2).add ((me.snd.sub mS.snd).pow_const 2)
  have nn (z) : 0 ≤ E z := by unfold E squareCost2; positivity
  have bd (z : (Fin n → SquareObs) × SquareObs) : E z ≤ 4 := by
    let a := clipParam (sampleMean n z.1)
    have ha : |a| ≤ 1/2 := abs_le.mpr ⟨le_max_left _ _, max_le (by norm_num) (min_le_left _ _)⟩
    have hab : |a-θ| ≤ 1 := by grw [abs_sub,ha,ht]; norm_num
    have v1 : |(perturb z.2).1| ≤ 1 := by
      unfold perturb; simp only [abs_div,abs_mul,abs_neg,abs_of_pos Real.pi_pos]
      apply (div_le_one Real.pi_pos).mpr
      exact (mul_le_mul (Real.abs_sin_le_one _) (Real.abs_cos_le_one _) (abs_nonneg _) (by norm_num)).trans (by linarith [Real.two_le_pi])
    have v2 : |(perturb z.2).2| ≤ 1 := by
      unfold perturb; simp only [abs_div,abs_mul,abs_neg,abs_of_pos Real.pi_pos]
      apply (div_le_one Real.pi_pos).mpr
      exact (mul_le_mul (Real.abs_cos_le_one _) (Real.abs_sin_le_one _) (abs_nonneg _) (by norm_num)).trans (by linarith [Real.two_le_pi])
    have coord (v : ℝ) (hv : |v| ≤ 1) : ((a-θ)*v)^2 ≤ 1 := by
      have b := mul_le_mul hab hv (abs_nonneg _) (by norm_num)
      rw [←abs_mul] at b
      nlinarith [sq_abs ((a-θ)*v),mul_nonneg (show 0≤1-|(a-θ)*v| by linarith) (show 0≤1+|(a-θ)*v| by positivity)]
    have eq : E z = ((a-θ)*(perturb z.2).1)^2+((a-θ)*(perturb z.2).2)^2 := by
      unfold E squareCost2 estimatedRank squareMap a; ring
    rw [eq]; linarith [coord _ v1,coord _ v2]
  have ii : Integrable E ((iidSampleLaw n θ).prod (squareLaw θ)) :=
    .of_bound mE.aestronglyMeasurable 4 (ae_of_all _ fun x => (Real.norm_of_nonneg (nn x)).le.trans (bd x))
  rw [squareDateRisk,ofReal_integral_eq_lintegral_ofReal ii (ae_of_all _ nn)]
  have changeVar := lintegral_map (μ := (iidPastLaw θ n).prod (squareLaw θ)) (f := fun x => ENNReal.ofReal (E x)) (g := Prod.map (pastEntries n) (id : SquareObs → SquareObs)) (ENNReal.measurable_ofReal.comp mE) mp.measurable
  rw [mp.map_eq] at changeVar
  exact changeVar.symm

set_option maxHeartbeats 500000 in
/-- A single measurable policy in the same nested-history model and nonnegative
extended-valued loss convention used by the minimax lower bounds. -/
theorem iid_clipped_upper (T : ℕ) :
    (∀ n, Measurable (iidClippedPolicy n)) ∧
    ∀ θ, |θ| ≤ 1/2 → (∑ n ∈ Finset.range T,
      ∫⁻ x, lossE θ (iidClippedPolicy n x) x.2 ∂(iidPastLaw θ n).prod (squareLaw θ)) ≤
      ENNReal.ofReal ((8/Real.pi^2)*(1+Real.log T)) := by
  constructor
  · intro n
    have m : Measurable (pastEntries n) := (pastEntries_preserving 0 (by norm_num) n).measurable
    have m' : Measurable (fun z : Past n × SquareObs => (pastEntries n z.1,z.2)) :=
      (m.comp measurable_fst).prodMk measurable_snd
    change Measurable ((fun z : (Fin n → SquareObs) × SquareObs => estimatedRank n z.1 z.2) ∘ (fun z : Past n × SquareObs => (pastEntries n z.1,z.2)))
    apply Measurable.comp (g := fun z : (Fin n → SquareObs) × SquareObs => estimatedRank n z.1 z.2) _ m'
    exact (square_iid_uniform_upper T).1 n
  · intro θ ht
    rw [Finset.sum_congr rfl (fun n (_ : n ∈ Finset.range T) => square_exp_loss n θ ht)]
    rw [← ENNReal.ofReal_sum_of_nonneg (fun i _ => show 0 ≤ squareDateRisk i θ from
      integral_nonneg fun z => by unfold squareCost2; positivity)]
    exact ENNReal.ofReal_le_ofReal ((square_iid_uniform_upper T).2 θ ht)

end
end SequentialRanks
