import WeakTimeMoments

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

/-- A single measurable full-measure set of dates works simultaneously for every
test and every ordered or reverse-ordered pair. The interval integral is oriented.
Initial traces below refer to the specified initial patch E₀. -/
def CommonTwoDateTraces (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ) (w : SpaceTime → H) : Prop :=
  ∃ G : Set ℝ, MeasurableSet G ∧ G ⊆ Icc 0 T ∧ G ∈ ae (volume.restrict (Icc 0 T)) ∧
    (∀ t ∈ G, WeakPatchEquation E0 E t ρ w) ∧
    ∀ s ∈ G, ∀ t ∈ G, ∀ f : SpaceTime → ℝ, ContDiff ℝ ∞ f → HasCompactSupport f →
      ρ*(∫ y in E t, f (t,y)) - ρ*(∫ y in E s, f (s,y)) =
        ρ*(∫ u in s..t, ∫ y in E u, fderiv ℝ f (u,y) (timeDirection w (u,y)))

private theorem date_flux_integrable (E : ℝ → Set Space) (t : ℝ) (ht : 0≤t)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) (f : SpaceTime → ℝ)
    (hf : Integrable f (occupation E t)) :
    IntervalIntegrable (fun u => ∫ y in E u, f (u,y)) volume 0 t := by
  let A := {s : SpaceTime | s.1 ∈ Icc 0 t ∧ s.2 ∈ E s.1}
  have ma : MeasurableSet A := (measurable_fst measurableSet_Icc).inter moving
  have prodInt : Integrable (A.indicator f) ((volume : Measure ℝ).prod (volume : Measure Space)) :=
    (integrable_indicator_iff ma).mpr hf
  apply (intervalIntegrable_iff_integrableOn_Ioc_of_le ht).mpr
  apply prodInt.integral_prod_left.integrableOn.congr_fun _ measurableSet_Ioc
  intro u hu
  have intv := Ioc_subset_Icc_self hu
  have mE : MeasurableSet (E u) := moving.preimage (show Measurable (fun y : Space => (u,y)) from measurable_const.prodMk measurable_id)
  change (∫ y, A.indicator f (u,y))=∫ y in E u, f (u,y)
  rw [← integral_indicator mE]
  congr 1; funext y
  by_cases hy : y ∈ E u <;> simp [A,intv.1,intv.2,hy]

theorem two_dates_from_renormalized (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (hT : 0 ≤ T) (hρ : 0 < ρ) (w : SpaceTime → H) (me0 : MeasurableSet E0)
    (finite0 : volume E0 ≠ ⊤) (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    [IsFiniteMeasure (occupation E T)] (hw : Integrable w (occupation E T))
    (sol : RenormalizedPatch E0 E T ρ w) : CommonTwoDateTraces E0 E T ρ w := by
  let μ := (volume : Measure ℝ).restrict (Icc 0 T)
  have h := weak_patch_of_renormalized E0 E T ρ hT hρ w me0 finite0 moving hw sol
  obtain ⟨N,sub,mN,zero⟩ := exists_measurable_superset_of_null (ae_iff.mp h)
  let G := Icc 0 T \ N
  have full : G ∈ ae μ := by
    filter_upwards [ae_restrict_mem (μ := volume) (measurableSet_Icc (a := 0) (b := T)),
      (ae_iff.mpr (by simpa [μ] using zero) : ∀ᵐ t ∂μ, t ∉ N)] with t inside off
    exact ⟨inside,off⟩
  have law (t : ℝ) (ht : t ∈ G) : WeakPatchEquation E0 E t ρ w :=
    not_not.mp (fun hn => ht.2 (sub hn))
  refine ⟨G,measurableSet_Icc.diff mN,sdiff_subset,full,law,?_⟩
  intro s hs t ht f mf cf
  let j := fun z : SpaceTime => fderiv ℝ f z (timeDirection w z)
  let g := fun u : ℝ => ∫ y in E u, j (u,y)
  have ij := (spaceTime_test_integrable E T w hw f mf cf).2
  have i (a : ℝ) (ha : a∈G) : Integrable j (occupation E a) :=
    ij.mono_measure (occupation_mono_time E ha.1.2)
  have atDate (a : ℝ) (ha : a∈G) :
      ρ*(∫ y in E a,f (a,y))-ρ*(∫ y in E0,f (0,y)) = ρ*(∫ u in (0:ℝ)..a,g u) := by
    have v := law a ha f mf cf
    have id := (occupation_fubini E moving a j (i a ha)).1
    rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le ha.1.1] at id
    change _ = ρ*(∫ z,j z ∂occupation E a) at v
    rwa [id] at v
  have is := date_flux_integrable E s hs.1.1 moving j (i s hs)
  have it' := date_flux_integrable E t ht.1.1 moving j (i t ht)
  have delta := intervalIntegral.integral_interval_sub_left it' is
  change (∫ u in (0:ℝ)..t,g u)-(∫ u in (0:ℝ)..s,g u)=(∫ u in s..t,g u) at delta
  change _ = ρ*(∫ u in s..t,g u)
  rw [← delta,mul_sub]
  linarith only [atDate t ht,atDate s hs]

/-- The public probability and moment bounds, bounded destination, its marginal
identity and the renormalized patch equation supply every analytic input. -/
theorem two_dates_from_probability_dynamics (E0 : Set Space) (E : ℝ → Set Space)
    (T ρ : ℝ) (hT : 0 ≤ T) (hρ : 0 < ρ) (S : ℝ → Space → Space) (target : Measure Space)
    (K M : NNReal) (me0 : MeasurableSet E0) (p0 : ENNReal.ofReal ρ * volume E0 = 1)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity S) (occupation E T))
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * (∫⁻ y in E t, ‖y‖ₑ^2) ≤ M)
    (radius : ∀ᵐ x ∂target, ‖x‖ ≤ K)
    (transport : ∀ᵐ t ∂volume.restrict (Icc 0 T), Measurable (S t) ∧ (volume.restrict (E t)).map (S t)=target)
    (sol : RenormalizedPatch E0 E T ρ (flowVelocity S)) : CommonTwoDateTraces E0 E T ρ (flowVelocity S) := by
  let _ := finite_occupation_of_probability E T ρ hρ moving normMass
  have finite0 : volume E0 ≠ ⊤ := ((unweight_patch_bound hρ p0.le).trans_lt (by simpa using hρ)).ne
  exact two_dates_from_renormalized E0 E T ρ hT hρ _ me0 finite0 moving
    (patch_velocity_integrable E T ρ hρ S target K M moving mw normMass moment radius transport) sol
end
end Vortex
