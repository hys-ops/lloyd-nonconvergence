import PatchDynamics
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

/-- Scalar distributional evolution on a finite time interval, including its initial datum.
Time tests may have a nonzero initial value and vanish before the final time. -/
def ScalarWeakEvolution (T A₀ : ℝ) (A G : ℝ → ℝ) : Prop :=
  ∀ η : ℝ → ℝ, ContDiff ℝ ∞ η → (∃ b < T, ∀ t, b < t → η t = 0) →
    (∫ t in (0:ℝ)..T, A t * deriv η t) + (∫ t in (0:ℝ)..T, G t * η t) = -A₀ * η 0

private theorem primitive_test {T : ℝ} (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g)
    (hc : HasCompactSupport g) (hs : tsupport g ⊆ Ioo 0 T) :
    let η := fun t => ∫ s in T..t, g s
    ContDiff ℝ ∞ η ∧ deriv η = g ∧ η T = 0 ∧ (∃ b < T, ∀ t, b < t → η t = 0) := by
  let η := fun t => ∫ s in T..t, g s
  have hd : deriv η = g := funext (Continuous.deriv_integral g hg.continuous T)
  refine ⟨contDiff_infty_iff_deriv.mpr ⟨intervalIntegral.differentiable_integral_of_continuous
    hg.continuous,by change ContDiff ℝ ∞ (deriv η); rwa [hd]⟩,hd,by simp,?_⟩
  obtain ⟨b,hb,hcut⟩ : ∃ b < T, ∀ s, b < s → g s=0 := by
    by_cases ne : (tsupport g).Nonempty
    · obtain ⟨b,hb,hm⟩ := hc.exists_isMaxOn ne continuous_id.continuousOn
      exact ⟨b,(hs hb).2,fun s h => by
        by_contra hn
        exact (not_le.mpr h) (hm (subset_tsupport g hn))⟩
    · exact ⟨T-1,by linarith,fun s _ => by
        by_contra hn
        exact ne ⟨s,subset_tsupport g hn⟩⟩
  refine ⟨b,hb,fun t ht => ?_⟩
  calc
    (∫ s in T..t,g s) = ∫ _ in T..t,(0:ℝ) := by
      apply intervalIntegral.integral_congr
      intro s h
      exact hcut s ((lt_min hb ht).trans_le h.1)
    _ = 0 := by simp

/-- The distributional initial-value identity determines the actual absolutely continuous
representative of each observable. No continuity or trace of the observable is assumed. -/
theorem scalar_time_representative {T A₀ : ℝ} {A G : ℝ → ℝ} (hT : 0 ≤ T)
    (hA : IntervalIntegrable A volume 0 T) (hG : IntervalIntegrable G volume 0 T)
    (weak : ScalarWeakEvolution T A₀ A G) :
    let F := fun t => A₀ + ∫ s in (0:ℝ)..t, G s
    AbsolutelyContinuousOnInterval F 0 T ∧ F 0 = A₀ ∧ A =ᵐ[volume.restrict (Icc 0 T)] F := by
  let F := fun t => A₀ + ∫ s in (0:ℝ)..t, G s
  have ac₀ : AbsolutelyContinuousOnInterval (fun _ : ℝ => A₀) 0 T :=
    (contDiffOn_const (c := A₀) (n := 1)).absolutelyContinuousOnInterval
  have ac : AbsolutelyContinuousOnInterval F 0 T := ac₀.add
    (hG.absolutelyContinuousOnInterval_intervalIntegral (by simp))
  have h0 : F 0 = A₀ := by simp [F]
  refine ⟨ac,h0,?_⟩
  have hfI := ac.continuousOn.intervalIntegrable (μ := volume)
  have same := isOpen_Ioo.ae_eq_zero_of_integral_contDiff_smul_eq_zero
    (((intervalIntegrable_iff_integrableOn_Ioc_of_le hT).mp (hA.sub hfI)).mono_set
      Ioo_subset_Ioc_self).locallyIntegrableOn
    (f := fun t => A t - F t) (μ := volume) (by
      intro g hg hc hsupport
      let η := fun t => ∫ s in T..t, g s
      obtain ⟨heta,hd,hend,admiss⟩ := primitive_test g hg hc hsupport
      have eqn := weak η heta admiss
      have ip := ac.integral_mul_deriv_eq_deriv_mul (heta.of_le (by simp : (1 : ℕ∞ω) ≤ ∞)
        |>.contDiffOn.absolutelyContinuousOnInterval)
      have grad : (∫ t in (0:ℝ)..T, deriv F t * η t) = ∫ t in (0:ℝ)..T,G t * η t := by
        apply intervalIntegral.integral_congr_ae
        filter_upwards [hG.ae_hasDerivAt_integral] with t ht htmem
        have d := (ht (uIoc_subset_uIcc htmem) 0 (by simp)).const_add A₀
        rw [show deriv F t = G t from d.deriv]
      change (∫ t in (0:ℝ)..T,F t * deriv η t) =
        F T * η T - F 0 * η 0 - ∫ t in (0:ℝ)..T,deriv F t * η t at ip
      change η T = 0 at hend
      change deriv η = g at hd
      rw [grad,hd,hend,h0] at ip
      rw [hd] at eqn
      have complement : ∀ t ∉ Ioc (0:ℝ) T, g t • (A t - F t) = 0 := by
        intro t ht
        have ge : g t=0 := by
          by_contra hh
          exact ht (Ioo_subset_Ioc_self (hsupport (subset_tsupport g hh)))
        simp [ge]
      rw [← setIntegral_eq_integral_of_forall_compl_eq_zero complement,
        ← intervalIntegral.integral_of_le hT]
      simp only [smul_eq_mul]
      simp_rw [mul_sub, mul_comm (g _)]
      rw [intervalIntegral.integral_sub (hA.mul_continuousOn hg.continuous.continuousOn)
        (hfI.mul_continuousOn hg.continuous.continuousOn)]
      linarith)
  rw [Measure.restrict_congr_set (Ioo_ae_eq_Icc (μ := (volume : Measure ℝ))).symm]
  apply (ae_restrict_iff' measurableSet_Ioo).mpr
  filter_upwards [same] with t ht hi
  exact sub_eq_zero.mp (ht hi)

end
end Vortex
