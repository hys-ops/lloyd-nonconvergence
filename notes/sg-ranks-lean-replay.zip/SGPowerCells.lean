import StaticRankBrenier
import ContinuumUniform
import SGClosureChart

open MeasureTheory Set Filter
namespace Vortex
noncomputable section
open SequentialRanks
/-- A finite target supported on distinct sites admits true semi-discrete power
labels for any absolutely continuous compactly supported source. An intercept
for every site, including sites of zero mass, comes from the same compact
c-transform of the convex transport potential. -/
theorem finite_power_labels {d N : ℕ} [Nonempty (Fin N)] (A : Set (RankPoint d)) (hA : IsCompact A)
    (P : ProbabilityMeasure A) (ac : (P : Measure A).map Subtype.val ≪ volume)
    (site : Fin N → RankPoint d) (inj : Function.Injective site) (Q : ProbabilityMeasure (Fin N)) :
    ∃ tag : A → Fin N, Measurable tag ∧ P.map tag = Q ∧
      ∃ w : Fin N → ℝ, ∀ᵐ x ∂(P : Measure A), ∀ j,
        rankCovector (site j) x.val+w j ≤ rankCovector (site (tag x)) x.val+w (tag x) := by
  classical
  let B := range site
  let e : Fin N ≃ B := Equiv.ofInjective site inj
  let _ : Fintype B := Fintype.ofEquiv (Fin N) e
  have : Nonempty B := Nonempty.map e ‹Nonempty (Fin N)›
  let _ : CompactSpace A := isCompact_iff_compactSpace.mp hA
  have hB : IsCompact B := (finite_range site).isCompact
  have me : Measurable e := measurable_of_finite _
  have mi : Measurable e.symm := measurable_of_finite _
  obtain ⟨φ,L,π,lip,_,cert,_,support,graph,_⟩ := compact_brenier A B hA hB P (Q.map e) ac
  let g := supportGradient (A := A) (B := B) φ
  have mg : Measurable g := measurable_supportGradient hB.isClosed.measurableSet φ
  let tag := fun x => e.symm (g x)
  have mt : Measurable tag := mi.comp mg
  have G : (P : Measure A).map (fun x => (x,g x)) = (π : Measure (A × B)) :=
    congrArg (fun γ : ProbabilityMeasure (A × B) => (γ : Measure (A × B))) graph
  have GM := congrArg (fun γ : Measure (A × B) => γ.map Prod.snd) G
  have mGraph : Measurable (fun x : A => (x,g x)) := measurable_id.prodMk mg
  rw [Measure.map_map measurable_snd mGraph] at GM
  have marginal := congrArg (fun q : ProbabilityMeasure B => (q : Measure B)) cert.2.1
  have actual : (P : Measure A).map g = (Q : Measure (Fin N)).map e := GM.trans marginal
  have labelLaw : P.map tag = Q := by
    apply ProbabilityMeasure.toMeasure_injective
    change (P : Measure A).map (e.symm ∘ g) = Q
    rw [← Measure.map_map mi mg,actual,Measure.map_map mi me]
    simp
  refine ⟨tag,mt,labelLaw,?_⟩
  let cost := fun (i : Fin N) (x : A) => φ x.val - rankCovector (site i) x.val
  let w := fun i => sInf (range (cost i))
  have cb (i) : BddBelow (range (cost i)) :=
    (isCompact_range ((lip.continuous.comp continuous_subtype_val).sub ((rankCovector (site i)).continuous.comp continuous_subtype_val))).bddBelow
  have each (i) (x : A) : w i ≤ cost i x := csInf_le (cb i) (mem_range_self x)
  have sg : ∀ᵐ x ∂(P : Measure A), (x,g x) ∈ (π : Measure (A × B)).support := by
    apply ae_of_ae_map mGraph.aemeasurable
    rw [G]; exact (π : Measure (A × B)).support_mem_ae
  refine ⟨w,?_⟩
  filter_upwards [sg] with x hx
  have atSite : site (tag x) = (g x).val := congrArg Subtype.val (e.apply_symm_apply (g x))
  have attain : cost (tag x) x ≤ w (tag x) := by
    apply le_csInf ⟨cost (tag x) x,mem_range_self x⟩
    rintro _ ⟨y,rfl⟩
    have h := support (x,g x) hx y.val
    rw [map_sub] at h
    dsimp [cost]; rw [atSite]
    linarith
  intro j
  have hj := each j x
  dsimp [cost] at hj attain
  linarith

/-- Transfer the cell labels to the physical body through a measure-preserving
Euclidean chart, using its exact dot-product pairing. -/
theorem power_realization_in_chart (K : Set Space) (hK : IsCompact K) (T : ProbabilityMeasure K)
    (ac : (T : Measure K).map Subtype.val ≪ volume) (P : ProbabilityMeasure Space)
    (e : Space ≃ₜ RankPoint 3) (vol : MeasurePreserving e volume volume)
    (pair : ∀ y x, linearScore y x = rankCovector (e y) (e x)) :
    PowerRealization K T P := by
  classical
  intro G
  let A := e '' K
  let k : K → A := fun x => ⟨e x.val,mem_image_of_mem _ x.property⟩
  have mk : Measurable k := (e.continuous.measurable.comp measurable_subtype_coe).subtype_mk
  have ha : IsCompact A := hK.image e.continuous
  have hmap : ((T.map k : ProbabilityMeasure A) : Measure A).map Subtype.val =
      ((T : Measure K).map Subtype.val).map e := by
    rw [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_subtype_coe mk,
      Measure.map_map e.continuous.measurable measurable_subtype_coe]; rfl
  have ac' : ((T.map k : ProbabilityMeasure A) : Measure A).map Subtype.val ≪ volume := by
    rw [hmap,← vol.map_eq]
    exact ac.map e.continuous.measurable
  have : Nonempty (Fin G.size) := ⟨G.label 0⟩
  obtain ⟨g,mg,law,w,score⟩ := finite_power_labels A ha (T.map k) ac' (e ∘ G.site)
    (e.injective.comp G.injective) (P.map G.label)
  refine ⟨g ∘ k,mg.comp mk,?_,w,?_⟩
  · apply ProbabilityMeasure.toMeasure_injective
    have l := congrArg (fun γ : ProbabilityMeasure (Fin G.size) => (γ : Measure (Fin G.size))) law
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map mg mk] using l
  · have ps := ae_of_ae_map mk.aemeasurable score
    filter_upwards [ps] with x hx
    intro j; simpa only [pair,Function.comp_apply,k] using hx j

/-- A uniform compact physical body realizes the rounded target of every grid,
whether or not some cells have zero prescribed mass. -/
theorem uniform_power_realization (K : Set Space) (hK : IsCompact K) (T : ProbabilityMeasure K)
    (unif : UniformBodyLaw K T) (P : ProbabilityMeasure Space) : PowerRealization K T P := by
  obtain ⟨d,hd⟩ := unif
  apply power_realization_in_chart K hK T _ P sgChart sgChart_volume sgChart_score
  rw [hd]
  exact (Measure.absolutelyContinuous_of_le Measure.restrict_le_self).smul_left d

end
end Vortex
