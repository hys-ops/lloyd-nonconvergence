import SGClosureData
import WeakTimeBounds

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Equal horizontal section areas give the same vertical marginal, also when
the zero-radius disk contributes a single point outside the initial height slab. -/
theorem circular_vertical_marginal (A : Set Space) (mA : MeasurableSet A) (fin : volume A ≠ ⊤) :
    (volume.restrict (circular A)).map Prod.snd = (volume.restrict A).map Prod.snd := by
  let B := circular A
  have mb := measurable_circular A mA
  have av : Measurable (fun z => volume (slice A z)) := measurable_measure_prodMk_right mA
  have fa : ∀ᵐ z : ℝ, volume (slice A z)<⊤ := ae_lt_top av (by
    change (∫⁻ z, volume ((fun x : H => (x,z)) ⁻¹' A)) ≠ ⊤
    rwa [← Measure.prod_apply_symm mA])
  ext W mW
  rw [Measure.map_apply measurable_snd mW,Measure.map_apply measurable_snd mW,
    Measure.restrict_apply (measurable_snd mW),Measure.restrict_apply (measurable_snd mW)]
  have sections (X : Set Space) (m : MeasurableSet X) :
      volume X = ∫⁻ z, volume (slice X z) := Measure.prod_apply_symm m
  rw [sections _ ((measurable_snd mW).inter mb),sections _ ((measurable_snd mW).inter mA)]
  apply lintegral_congr_ae
  filter_upwards [fa] with z hz
  by_cases h : z∈W
  · have sec (X : Set Space) : slice (Prod.snd ⁻¹' W ∩ X) z = slice X z := by
      ext x; simp [slice,h]
    rw [sec,sec,circular_slice,disk,disk_area,Measure.real,ENNReal.ofReal_toReal hz.ne]
  · have sec (X : Set Space) : slice (Prod.snd ⁻¹' W ∩ X) z = ∅ := by
      ext x; simp [slice,h]
    rw [sec,sec]

private theorem hsq_bound (y : Space) : ‖y‖^2 ≤ radialSquare y+‖y.2‖^2 := by
  rcases y with ⟨⟨u,v⟩,z⟩
  change (max (max ‖u‖ ‖v‖) ‖z‖)^2 ≤ u^2+v^2+‖z‖^2
  rcases le_total ‖u‖ ‖v‖ with huv|hvu
  · rw [max_eq_right huv]
    rcases le_total ‖v‖ ‖z‖ with hvz|hzv
    · rw [max_eq_right hvz]; nlinarith [sq_nonneg u,sq_nonneg v]
    · rw [max_eq_left hzv,Real.norm_eq_abs,sq_abs]; nlinarith [sq_nonneg u,sq_nonneg ‖z‖]
  · rw [max_eq_left hvu]
    rcases le_total ‖u‖ ‖z‖ with huz|hzu
    · rw [max_eq_right huz]; nlinarith [sq_nonneg u,sq_nonneg v]
    · rw [max_eq_left hzu,Real.norm_eq_abs,sq_abs]; nlinarith [sq_nonneg v,sq_nonneg ‖z‖]

theorem public_patch_second_moment (A : Set Space) (d M : ℝ≥0) (hd : 0<d)
    (m : (d : ℝ≥0∞)*(∫⁻ y in A, ‖y‖ₑ^2)≤M) :
    IntegrableOn (fun y : Space => ‖y‖^2) A := by
  have hρ : 0 < (d:ℝ) := hd
  have upper := unweight_patch_bound hρ (show ENNReal.ofReal (d:ℝ)*(∫⁻ y in A, ‖y‖ₑ^2) ≤ M from by simpa using m)
  have f : (ENNReal.ofReal (d:ℝ))⁻¹ ≠ ⊤ := ENNReal.inv_ne_top.mpr (ENNReal.ofReal_ne_zero_iff.mpr hρ)
  have aim := upper.trans_lt (ENNReal.mul_lt_top f.lt_top (ENNReal.coe_lt_top (r := M)))
  refine ⟨(continuous_norm.pow 2).aestronglyMeasurable,(hasFiniteIntegral_iff_norm _).mpr ?_⟩
  simpa [Real.norm_of_nonneg (sq_nonneg _),ENNReal.ofReal_pow (norm_nonneg _)] using aim

theorem circular_second_moment (A : Set Space) (mA : MeasurableSet A) (fin : volume A ≠ ⊤)
    (m : IntegrableOn (fun y : Space => ‖y‖^2) A) : IntegrableOn (fun y : Space => ‖y‖^2) (circular A) := by
  have h1 : IntegrableOn radialSquare A := by
    apply (m.const_mul 2).mono' (by unfold radialSquare; fun_prop)
    filter_upwards with y
    have a := pow_le_pow_left₀ (norm_nonneg y.1.1) ((norm_fst_le y.1).trans (norm_fst_le y)) 2
    have b := pow_le_pow_left₀ (norm_nonneg y.1.2) ((norm_snd_le y.1).trans (norm_fst_le y)) 2
    rw [Real.norm_eq_abs,sq_abs] at a b
    rw [show ‖radialSquare y‖=radialSquare y from Real.norm_of_nonneg (by unfold radialSquare; positivity)]
    unfold radialSquare; linarith
  have iz : IntegrableOn (fun y : Space => ‖y.2‖^2) A := by
    apply m.mono' (continuous_snd.norm.pow 2).aestronglyMeasurable
    filter_upwards with y
    change ‖‖y.2‖^2‖ ≤ ‖y‖^2
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    exact pow_le_pow_left₀ (norm_nonneg _) (norm_snd_le _) 2
  have lift (X : Set Space) : Integrable (fun z : ℝ => ‖z‖^2) ((volume.restrict X).map Prod.snd) ↔
      IntegrableOn (fun y : Space => ‖y.2‖^2) X :=
    integrable_map_measure (continuous_norm.pow 2).aestronglyMeasurable measurable_snd.aemeasurable
  have mz : IntegrableOn (fun y : Space => ‖y.2‖^2) (circular A) := by
    apply (lift _).mp; rw [circular_vertical_marginal A mA fin]; exact (lift _).mpr iz
  apply ((circular_radial_integrable A mA fin h1).add mz).mono' (continuous_norm.pow 2).aestronglyMeasurable
  filter_upwards with y
  change ‖‖y‖^2‖ ≤ radialSquare y+‖y.2‖^2
  rw [Real.norm_of_nonneg (sq_nonneg _)]; exact hsq_bound y
end
end Vortex
