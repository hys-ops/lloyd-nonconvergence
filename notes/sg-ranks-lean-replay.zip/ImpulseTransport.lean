import ConservedPatch

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

def radialSquare (y : Space) : ℝ := y.1.1^2+y.1.2^2
def horizontalWork (y : Space) (v : H) : ℝ := y.1.1*v.1+y.1.2*v.2

private def axis1 : Space →L[ℝ] ℝ := (ContinuousLinearMap.fst ℝ ℝ ℝ).comp
  (ContinuousLinearMap.fst ℝ H ℝ)
private def axis2 : Space →L[ℝ] ℝ := (ContinuousLinearMap.snd ℝ ℝ ℝ).comp
  (ContinuousLinearMap.fst ℝ H ℝ)

private theorem radial_smooth : ContDiff ℝ ∞ radialSquare := by unfold radialSquare; fun_prop

private theorem radial_deriv (y : Space) (v : H) :
    fderiv ℝ radialSquare y (v,0) = 2*horizontalWork y v := by
  have d1 := axis1.hasFDerivAt (x := y)
  have d2 := axis2.hasFDerivAt (x := y)
  have h := congrArg (fun L : Space →L[ℝ] ℝ => L (v,0)) ((d1.mul d1).add (d2.mul d2)).fderiv
  rw [show radialSquare = ((axis1 : Space → ℝ)*axis1+(axis2 : Space → ℝ)*axis2) by
    funext x; simp [radialSquare,axis1,axis2,sq]]
  simpa [radialSquare,sq,axis1,axis2,horizontalWork, two_mul,add_mul,
    mul_add,add_comm,add_left_comm,add_assoc] using h

private theorem coords_bound (y : Space) :
    ‖y.1.1‖ ≤ ‖y‖ ∧ ‖y.1.2‖ ≤ ‖y‖ :=
  ⟨(norm_fst_le y.1).trans (norm_fst_le y),(norm_snd_le y.1).trans (norm_fst_le y)⟩

private theorem radial_bound (y : Space) : ‖radialSquare y‖ ≤ 2*‖y‖^2 := by
  have h1 := pow_le_pow_left₀ (norm_nonneg _) (coords_bound y).1 2
  have h2 := pow_le_pow_left₀ (norm_nonneg _) (coords_bound y).2 2
  simp only [Real.norm_eq_abs,sq_abs] at h1 h2
  rw [Real.norm_eq_abs,abs_of_nonneg (show 0 ≤ radialSquare y by unfold radialSquare; positivity)]
  unfold radialSquare
  linarith

theorem work_bound (y : Space) (v : H) : ‖horizontalWork y v‖ ≤ 2*(‖y‖*‖v‖) := by
  have h1 := mul_le_mul (coords_bound y).1 (norm_fst_le v) (norm_nonneg _) (norm_nonneg y)
  have h2 := mul_le_mul (coords_bound y).2 (norm_snd_le v) (norm_nonneg _) (norm_nonneg y)
  unfold horizontalWork
  calc
    _ ≤ ‖y.1.1*v.1‖+‖y.1.2*v.2‖ := norm_add_le _ _
    _ ≤ _ := by simp only [norm_mul]; linarith

private def cutMoment (n : ℕ) (y : Space) : ℝ := traceBump (traceScale n • y)*radialSquare y
private def dilation (n : ℕ) : Space →L[ℝ] Space := traceScale n • ContinuousLinearMap.id ℝ Space
private theorem cut_smooth (n : ℕ) : ContDiff ℝ ∞ (cutMoment n) :=
  (traceBump.contDiff.comp (dilation n).contDiff).mul radial_smooth
private theorem cut_compact (n : ℕ) : HasCompactSupport (cutMoment n) :=
  (traceBump.hasCompactSupport.comp_homeomorph
    (Homeomorph.smulOfNeZero (α := Space) (traceScale n) (traceScale_pos n).ne')).mul_right

private theorem cut_local (y : Space) : ∀ᶠ n in atTop, cutMoment n =ᶠ[nhds y] radialSquare := by
  have lim : Tendsto (fun n => traceScale n • y) atTop (𝓝 (0:Space)) := by
    simpa using traceScale_tendsto.smul_const y
  filter_upwards [lim (Metric.ball_mem_nhds _ traceBump.rIn_pos)] with n hn
  have near := ((dilation n).continuous.tendsto y).eventually
    (traceBump.eventuallyEq_one_of_mem_ball hn)
  filter_upwards [near] with z hz
  change traceBump (traceScale n • z)*radialSquare z = radialSquare z
  rw [show traceBump (traceScale n • z)=1 from hz,one_mul]

private theorem cut_deriv (n : ℕ) (y : Space) (v : H) :
    fderiv ℝ (cutMoment n) y (v,0) =
      traceBump (traceScale n • y)*(2*horizontalWork y v) +
      radialSquare y * (fderiv ℝ (traceBump : Space → ℝ) (traceScale n • y)) (traceScale n • (v,0)) := by
  change fderiv ℝ (((traceBump : Space → ℝ) ∘ dilation n) * radialSquare) y (v,0) = _
  have db := (traceBump.contDiff (n := ⊤)).differentiable (by simp)
  rw [fderiv_mul (db.comp (dilation n).differentiable).differentiableAt
    (radial_smooth.differentiable (by simp)).differentiableAt,
    fderiv_comp y db.differentiableAt (dilation n).differentiableAt,(dilation n).fderiv]
  change traceBump (traceScale n • y)*fderiv ℝ radialSquare y (v,0)+_ = _
  rw [radial_deriv]
  rfl

private theorem cut_deriv_bound :
    ∃ C : ℝ, ∀ (n : ℕ) (y : Space) (v : H), ‖fderiv ℝ (cutMoment n) y (v,0)‖ ≤ C*(‖y‖*‖v‖) := by
  obtain ⟨K,hK⟩ := (traceBump.hasCompactSupport.fderiv ℝ).exists_bound_of_continuous
    ((traceBump.contDiff (n := ⊤)).continuous_fderiv (by simp))
  have k0 := (norm_nonneg _).trans (hK 0)
  refine ⟨4+4*K,fun n y v => ?_⟩
  have bnd : ‖traceBump (traceScale n • y)‖ ≤ 1 := by
    rw [Real.norm_eq_abs,abs_of_nonneg traceBump.nonneg]; exact traceBump.le_one
  have hw : ‖traceBump (traceScale n • y)*(2*horizontalWork y v)‖ ≤ 4*(‖y‖*‖v‖) := by
    rw [norm_mul,norm_mul]
    calc
      _ ≤ 1*(‖(2:ℝ)‖*(2*(‖y‖*‖v‖))) :=
        mul_le_mul bnd (mul_le_mul_of_nonneg_left (work_bound y v) (norm_nonneg _))
          (by positivity) zero_le_one
      _ = _ := by norm_num; ring
  let D := fderiv ℝ (traceBump : Space → ℝ) (traceScale n • y)
  have he : ‖radialSquare y*D (traceScale n • (v,0))‖ ≤ (4*K)*(‖y‖*‖v‖) := by
    by_cases hy : traceScale n • y ∈ tsupport (traceBump : Space → ℝ)
    · rw [traceBump.tsupport_eq,Metric.mem_closedBall,dist_zero_right,norm_smul,
        Real.norm_of_nonneg (traceScale_pos n).le] at hy
      change traceScale n * ‖y‖ ≤ 2 at hy
      have hd := (D.le_opNorm (traceScale n • (v,0))).trans
        (mul_le_mul_of_nonneg_right (hK _) (norm_nonneg _))
      rw [norm_smul,Real.norm_of_nonneg (traceScale_pos n).le,
        show ‖((v,0) : Space)‖ = ‖v‖ by simp [Prod.norm_def]] at hd
      rw [norm_mul]
      calc
        _ ≤ (2*‖y‖^2)*(K*(traceScale n*‖v‖)) :=
          mul_le_mul (radial_bound y) hd (norm_nonneg _) (by positivity)
        _ = (2*K*(‖y‖*‖v‖))*(traceScale n*‖y‖) := by ring
        _ ≤ (2*K*(‖y‖*‖v‖))*2 := mul_le_mul_of_nonneg_left hy (by positivity)
        _ = _ := by ring
    · have zero : D=0 := fderiv_of_notMem_tsupport ℝ hy
      simp only [zero,zero_apply,mul_zero,norm_zero]
      positivity
  rw [cut_deriv]
  exact (norm_add_le _ _).trans (by dsimp only [D] at he; linarith [add_mul (4:ℝ) (4*K) (‖y‖*‖v‖)])

private theorem moment_trace_limit (A : Set Space) (h : IntegrableOn radialSquare A) :
    Tendsto (fun n => ∫ y in A, cutMoment n y) atTop (𝓝 (∫ y in A, radialSquare y)) := by
  apply tendsto_integral_of_dominated_convergence (fun y => ‖radialSquare y‖)
    (fun n => (cut_smooth n).continuous.aestronglyMeasurable) h.norm
  · intro n
    filter_upwards with y
    unfold cutMoment
    rw [norm_mul,Real.norm_eq_abs,abs_of_nonneg traceBump.nonneg]
    exact (mul_le_mul_of_nonneg_right traceBump.le_one (norm_nonneg _)).trans_eq (one_mul _)
  · filter_upwards with y
    exact tendsto_const_nhds.congr' ((cut_local y).mono fun n hn => hn.eq_of_nhds.symm)

/-- Test the weak horizontal equation with the unbounded squared horizontal
radius. The boundary term is dominated by |y| |w|, so only a mixed second
moment is needed. -/
theorem impulse_balance_from_trace (E0 E : Set Space) (μ : Measure (ℝ × Space))
    (w : ℝ × Space → H) (hm : AEStronglyMeasurable w μ)
    (mix : Integrable (fun s => ‖s.2‖*‖w s‖) μ)
    (h0 : IntegrableOn radialSquare E0) (hE : IntegrableOn radialSquare E)
    (eqn : HorizontalTrace E0 E μ w) :
    (∫ y in E, radialSquare y) - (∫ y in E0, radialSquare y) =
      ∫ s, 2*horizontalWork s.2 (w s) ∂μ := by
  have lhs := (moment_trace_limit E hE).sub (moment_trace_limit E0 h0)
  obtain ⟨C,hC⟩ := cut_deriv_bound
  have rhs : Tendsto (fun n => ∫ s, fderiv ℝ (cutMoment n) s.2 (w s,0) ∂μ) atTop
      (𝓝 (∫ s, 2*horizontalWork s.2 (w s) ∂μ)) := by
    refine tendsto_integral_of_dominated_convergence (fun s => C*(‖s.2‖*‖w s‖)) ?_ (mix.const_mul _) ?_ ?_
    · intro n
      have df := (((cut_smooth n).continuous_fderiv (by simp)).comp
        (continuous_snd : Continuous (Prod.snd : ℝ × Space → Space))).aestronglyMeasurable (μ := μ)
      exact (ContinuousLinearMap.apply ℝ ℝ).flip.aestronglyMeasurable_comp₂ df (hm.prodMk aestronglyMeasurable_const)
    · intro n; exact Filter.Eventually.of_forall (fun s => hC n s.2 (w s))
    · filter_upwards with s
      apply tendsto_const_nhds.congr'
      filter_upwards [cut_local s.2] with n hn
      rw [hn.fderiv_eq,radial_deriv]
  apply tendsto_nhds_unique lhs
  exact rhs.congr (fun n => (eqn _ (cut_smooth n) (cut_compact n)).symm)
end
end Vortex
