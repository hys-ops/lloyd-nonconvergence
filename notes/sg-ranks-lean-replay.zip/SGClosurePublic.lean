import SGClosure
import SGPowerCells

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- The SG note's two conclusions on a bounded time interval. The finite input is the
ordinary three-dimensional finite theorem for uniform convex bodies. Compactness supplies
the auxiliary vertical radius; only the given horizontal squared radius remains in the
conclusion. The separately named remaining inputs are the static Brenier characterization
of the individual maps. Power diagrams with prescribed masses are constructed in Lean. -/
theorem sg_public_from_finite_tool (E0 : Set Space) (E : ℝ → Set Space) (D : Set Space)
    [CompactSpace D] (target : ProbabilityMeasure D)
    (conv : Convex ℝ D) (bodySymm : ∀ θ y, rotateMap θ y ∈ D ↔ y∈D) (c : ℝ≥0∞)
    (uniform : (target : Measure D).map Subtype.val = c • volume.restrict D)
    (d : ℝ≥0) (hd : 0<d) (T a b R : ℝ) (ht : 0≤T) (hab : a≤b)
    (horizontal : ∀ x∈D, x.1.1^2+x.1.2^2 ≤ R^2)
    (U : ℝ → Space → D) (V : Space → D)
    (me0 : MeasurableSet E0) (mass0 : (d : ℝ≥0∞)*volume E0=1)
    (slab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z)=0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity (fun t y => (U t y).val)) (occupation E T))
    (mass : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*volume (E t)=1)
    (M : ℝ≥0) (moment0 : (d : ℝ≥0∞)*(∫⁻ y in E0, ‖y‖ₑ^2)≤M)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*(∫⁻ y in E t, ‖y‖ₑ^2)≤M)
    (sol : RenormalizedPatch E0 E T d (flowVelocity (fun t y => (U t y).val)))
    (cur : ∀ᵐ t ∂volume.restrict (Icc 0 T), ∀ m : (d : ℝ≥0∞)*volume (E t)=1,
      CurrentBrenier D target (E t) d m (U t))
    (ref : ∀ m : (d : ℝ≥0∞)*volume (circular E0)=1,
      ReferenceBrenier D target (circular E0) d m V)
    (finite : OrdinaryFiniteBrenier) :
    (∀ t : ℝ, 0≤t → WeakPatchEquation (circular E0) (fun _ => circular E0) t d
      (fun s => vel s.2.1 (V s.2).val.1)) ∧
    ∀ᵐ t ∂volume.restrict (Icc 0 T),
      (d:ℝ)*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y).val.1) (vel y.1 (V y).val.1)) ≤
        4*R^2*Real.sqrt (Real.pi*d*(b-a)*impulse E0 (circular E0) d) := by
  have comp : IsCompact D := isCompact_iff_compactSpace.mpr inferInstance
  obtain ⟨v,bv⟩ := comp.bddAbove_image continuous_snd.norm.continuousOn
  have height (x : Space) (hx : x∈D) : x.2^2 ≤ v^2 := by
    have hh := pow_le_pow_left₀ (norm_nonneg x.2) (bv (mem_image_of_mem _ hx)) 2
    simpa [Real.norm_eq_abs] using hh
  have tool := ordinary_tool_supplies_stretches finite D conv target ⟨c,uniform⟩ R v horizontal height
  exact sg_overlap_and_stationarity E0 E D target comp.measurableSet bodySymm c uniform
    d hd T a b R v ht hab U V me0 mass0 slab moving mw mass M moment0 moment sol
    (cur.mono (fun _ h m => ⟨h m, uniform_power_realization D comp target ⟨c,uniform⟩ _⟩))
    (fun m => ⟨ref m,uniform_power_realization D comp target ⟨c,uniform⟩ _⟩) tool
end
end Vortex
