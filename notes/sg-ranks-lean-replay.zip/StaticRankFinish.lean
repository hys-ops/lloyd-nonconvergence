import StaticRankExistence
import RankMintyPSDLimit
import StaticRankBridge
import StaticRankKL

open MeasureTheory Filter Set
open scoped ENNReal Topology
namespace SequentialRanks
noncomputable section

theorem good_hessian_set {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p w : RankPoint d → ℝ) (U : RankPoint d → RankPoint d) (mp : Measurable p) (mu : Measurable U)
    (law : (weighted volume p).map U = weighted volume w) (rank : compactRankGraph A B p U) :
    ∃ (φ : RankPoint d → ℝ) (G : Set (RankPoint d)) (a : RankPoint d → RankDifferential d),
      ConvexOn ℝ univ φ ∧ MeasurableSet G ∧ (∀ᵐ x ∂volume, 0 < p x → x ∈ G) ∧ InjOn U G ∧
      (∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x) ∧ (∀ x ∈ G, HasFDerivWithinAt U (a x) G x) ∧
      ∀ x ∈ G, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef := by
  obtain ⟨φ,S,cv,ms,fullS,onS,inj,grad⟩ := compact_rank_good_set A B ha hb p w U mp mu law rank
  obtain ⟨N,mn,n0,der⟩ := rank_gradient_regular φ U S B hb onS cv grad
  let T := S \ N
  let a := fun x => fderivWithin ℝ U S x
  have mt : MeasurableSet T := ms.diff mn
  have sub : T ⊆ S := sdiff_subset
  have dt (x) (hx : x ∈ T) : HasFDerivWithinAt U (a x) T x := (der x hx.1 hx.2).mono sub
  have pos := (ae_restrict_iff' mt).mp (convex_gradient_derivative_psd_ae T mt U a φ
    (fun y hy z _ => rank_convex_support cv (grad y hy.1) z) dt)
  obtain ⟨E,bad,me,e0⟩ := exists_measurable_superset_of_null (ae_iff.mp pos)
  let G := T \ E
  have gt : G ⊆ T := sdiff_subset
  have hn : ∀ᵐ x ∂volume, x ∉ N := ae_iff.mpr (by simpa using n0)
  have he : ∀ᵐ x ∂volume, x ∉ E := ae_iff.mpr (by simpa using e0)
  refine ⟨φ,G,a,cv,mt.diff me,?_,inj.mono (gt.trans sub),fun x hx => grad x hx.1.1,
    fun x hx => (dt x hx.1).mono gt,?_⟩
  · filter_upwards [fullS,hn,he] with x h xn xe px using ⟨⟨h px,xn⟩,xe⟩
  · intro x hx
    by_contra h
    exact hx.2 (bad (show ¬ (x ∈ T → (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef) from fun h' => h (h' hx.1)))

/-- The entire common regular-set witness is *derived* from the actual
absolutely continuous endpoint transports, including the endpoints' essential
injectivity, within derivatives and positive semidefinite Hessians. -/
theorem regular_gradients_of_rank_maps {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p q w : RankPoint d → ℝ) (U V : RankPoint d → RankPoint d)
    (mp : Measurable p) (mq : Measurable q) (mu : Measurable U) (mv : Measurable V)
    (pu : (weighted volume p).map U = weighted volume w) (qv : (weighted volume q).map V = weighted volume w)
    (ru : compactRankGraph A B p U) (rv : compactRankGraph A B q V) : Nonempty (RegularRankGradients p q U V) := by
  obtain ⟨φ,S,a,cf,ms,fs,is,gs,ds,ps⟩ := good_hessian_set A B ha hb p w U mp mu pu ru
  obtain ⟨ψ,T,b,cg,mt,ft,it,gt,dt,pt⟩ := good_hessian_set A B ha hb q w V mq mv qv rv
  refine ⟨⟨S ∩ T,ms.inter mt,?_,φ,ψ,cf,cg,fun x hx => gs x hx.1,fun x hx => gt x hx.2,
    a,b,fun x hx => (ds x hx.1).mono inter_subset_left,fun x hx => (dt x hx.2).mono inter_subset_right,
    fun x hx => ps x hx.1,fun x hx => pt x hx.2,is.mono inter_subset_left,it.mono inter_subset_right⟩⟩
  filter_upwards [fs,ft] with x pS qT px qx using ⟨pS px,qT qx⟩

/-- Geometric midpoint domination for the actual quadratic ranks of the
public compactly supported laws and a log-concave reference, with zeros allowed.
The graph arguments specify what the optimal maps U and V mean; existence
from the normalized original densities is proved in compact_rank_graph_exists. -/
theorem midpoint_of_rank_maps {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p q w : RankPoint d → ℝ) (U V : RankPoint d → RankPoint d)
    (mp : Measurable p) (mq : Measurable q) (mu : Measurable U) (mv : Measurable V)
    (wn : ∀ x, 0 ≤ w x) (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (pu : (weighted volume p).map U = weighted volume w) (qv : (weighted volume q).map V = weighted volume w)
    (ru : compactRankGraph A B p U) (rv : compactRankGraph A B q V) :
    (weighted volume (fun x => Real.sqrt (p x)*Real.sqrt (q x))).map
      (fun x => mid (U x) (V x)) ≤ weighted volume w :=
  midpoint_from_convex_gradients p q w U V mp mq mu mv wn conc pu qv
    (regular_gradients_of_rank_maps A B ha hb p q w U V mp mq mu mv pu qv ru rv).some

private theorem integrable_probability_density {d : ℕ} (p : RankPoint d → ℝ)
    (mp : Measurable p) (pn : ∀ x, 0 ≤ p x) [IsProbabilityMeasure (weighted volume p)] : Integrable p := by
  apply (lintegral_ofReal_ne_top_iff_integrable mp.aestronglyMeasurable (.of_forall pn)).mp
  have mass : (weighted volume p) univ = 1 := measure_univ
  unfold weighted at mass
  rw [withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ] at mass
  rw [mass]
  norm_num

/-- The estimate for every pair of bounded representatives of the prescribed
rank maps, including arbitrary choices on their own source-null sets. -/
theorem rank_bound_for_maps {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p q w : RankPoint d → ℝ) (U V : RankPoint d → RankPoint d) (R : ℝ)
    (mp : Measurable p) (mq : Measurable q) (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x)
    [IsProbabilityMeasure (weighted volume p)] [IsProbabilityMeasure (weighted volume q)]
    [IsProbabilityMeasure (weighted volume w)] (mu : Measurable U) (mv : Measurable V)
    (ub : ∀ x, normSq (U x) ≤ R^2) (vb : ∀ x, normSq (V x) ≤ R^2)
    (refball : ∀ᵐ x ∂weighted volume w, normSq x ≤ R^2) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (pu : (weighted volume p).map U = weighted volume w) (qv : (weighted volume q).map V = weighted volume w)
    (ru : compactRankGraph A B p U) (rv : compactRankGraph A B q V) :
    (∫ x,p x*normSq (diff (U x) (V x))) ≤ 16*R^2*∫ x,(Real.sqrt (p x)-Real.sqrt (q x))^2 :=
  one_step_from_geometry volume (weighted volume w) R p q mp mq pn qn
    (integrable_probability_density p mp pn) (integrable_probability_density q mq qn) U V mu mv
    ub vb refball pu qv (midpoint_of_rank_maps A B ha hb p q w U V mp mq mu mv wn conc pu qv ru rv)

/-- One-observation theorem from the two original probability densities, a
common compact observation set and a ball-supported log-concave reference.
No optimizer, regularity theorem, Jacobian identity, midpoint domination, or
nonsmooth change-of-variables result is a hypothesis. -/
theorem compact_rank_hellinger {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    [Nonempty B] (p q w : RankPoint d → ℝ) (mp : Measurable p) (mq : Measurable q)
    (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x)
    [IsProbabilityMeasure (weighted volume p)] [IsProbabilityMeasure (weighted volume q)]
    [IsProbabilityMeasure (weighted volume w)] (sp : ∀ᵐ x ∂weighted volume p, x ∈ A)
    (sq : ∀ᵐ x ∂weighted volume q, x ∈ A) (sw : ∀ᵐ x ∂weighted volume w, x ∈ B)
    (wn : ∀ x, 0 ≤ w x) (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ x ∈ B, normSq x ≤ R^2) :
    ∃ U V : RankPoint d → RankPoint d, Measurable U ∧ Measurable V ∧
      compactRankGraph A B p U ∧ compactRankGraph A B q V ∧
      (weighted volume p).map U = weighted volume w ∧ (weighted volume q).map V = weighted volume w ∧
      (∫ x, p x*normSq (diff (U x) (V x))) ≤ 16*R^2*(∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2) ∧
      ENNReal.ofReal (∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2) ≤
        InformationTheory.klDiv (weighted volume p) (weighted volume q) := by
  obtain ⟨U,mu,bu,pu,ru⟩ := compact_rank_graph_exists A B ha hb p w sp sw
  obtain ⟨V,mv,bv,qv,rv⟩ := compact_rank_graph_exists A B ha hb q w sq sw
  refine ⟨U,V,mu,mv,ru,rv,pu,qv,?_,hellinger_le_measure_kl volume p q mp mq pn qn
    (integrable_probability_density p mp pn) (integrable_probability_density q mq qn)⟩
  exact rank_bound_for_maps A B ha hb p q w U V R mp mq pn qn mu mv (fun x => ball _ (bu x))
    (fun x => ball _ (bv x)) (sw.mono fun x hx => ball x hx) wn conc pu qv ru rv

end
end SequentialRanks
