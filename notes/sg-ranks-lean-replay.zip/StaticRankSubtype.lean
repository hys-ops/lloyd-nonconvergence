import StaticRankFinish
import MinimaxUpperSelection

open MeasureTheory Filter Set
open scoped ENNReal NNReal
namespace SequentialRanks
noncomputable section

/-- Canonical, unnormalized Lebesgue measure in the compact observation subtype. -/
def compactObservationVolume {d : ℕ} (A : Set (RankPoint d)) (_ha : IsCompact A) : Measure A :=
  Measure.comap Subtype.val volume

instance compactObservationFinite {d : ℕ} {A : Set (RankPoint d)} {ha : IsCompact A} :
    IsFiniteMeasure (compactObservationVolume A ha) := ⟨by
  apply (Measure.comap_apply_le _ _ nullMeasurableSet_univ).trans_lt
  simpa using (ha.measure_lt_top (μ := (volume : Measure (RankPoint d))))⟩

private theorem lift_weight {d : ℕ} {A : Set (RankPoint d)} (ma : MeasurableSet A) (μ : Measure A)
    (base : μ.map Subtype.val = volume.restrict A) (r : RankPoint d → A)
    (mr : Measurable r) (ret : ∀ x : A, r x.val = x) (p : A → ℝ) (mp : Measurable p) :
    (weighted μ p).map Subtype.val = weighted volume (A.indicator (fun x => p (r x))) := by
  classical
  have mg : Measurable (fun x => ENNReal.ofReal (p (r x))) := ENNReal.measurable_ofReal.comp (mp.comp mr)
  ext s hs
  rw [Measure.map_apply measurable_subtype_coe hs]
  unfold weighted
  rw [withDensity_apply _ (measurable_subtype_coe hs),withDensity_apply _ hs]
  have ei (x : RankPoint d) : ENNReal.ofReal (A.indicator (fun y => p (r y)) x) =
      A.indicator (fun y => ENNReal.ofReal (p (r y))) x := by
    by_cases hx : x ∈ A <;> simp [hx]
  simp_rw [ei]
  rw [lintegral_indicator ma,Measure.restrict_restrict ma,inter_comm A s,← Measure.restrict_restrict hs,
    ← base,setLIntegral_map hs mg measurable_subtype_coe]
  simp_rw [ret]

/-- Midpoint bound on the observation subtype for jointly chosen rank versions.
U and V may be any bounded or unbounded representatives of their graph laws;
the domination itself is insensitive to changes on the source-null sets. -/
theorem subtype_rank_midpoint {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (μ : Measure A) (base : μ.map Subtype.val = volume.restrict A)
    (target : ProbabilityMeasure B) (w : RankPoint d → ℝ) (wn : ∀x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (ref : (target : Measure B).map Subtype.val = weighted volume w)
    {H J : Type*} [MeasurableSpace H] [MeasurableSpace J]
    (p : Forecast H A μ) (q : Forecast J A μ) (h : H) (j : J)
    (U V : A → RankPoint d) (mu : Measurable U) (mv : Measurable V)
    (ru : CertifiedRank (p.law h) target U) (rv : CertifiedRank (q.law j) target V) :
    (weighted μ (fun y => Real.sqrt (p.f (h,y))*Real.sqrt (q.f (j,y)))).map (fun y => mid (U y) (V y))
      ≤ (target : Measure B).map Subtype.val := by
  classical
  let ma := ha.isClosed.measurableSet
  obtain ⟨r,mr,ret⟩ := ma.exists_measurable_proj (nonempty_subtype.mp (nonempty_of_isProbabilityMeasure (p.law h : Measure A)))
  let lift := fun (f : A → ℝ) => A.indicator (fun x => f (r x))
  let P := fun x : A => p.f (h,x)
  let Q := fun x : A => q.f (j,x)
  have mp : Measurable P := p.measurable.comp (measurable_const.prodMk measurable_id)
  have mq : Measurable Q := q.measurable.comp (measurable_const.prodMk measurable_id)
  have mfl (f : A → ℝ) (mf : Measurable f) : Measurable (lift f) := (mf.comp mr).indicator ma
  have get (f : A → ℝ) (mf : Measurable f) :
      (weighted μ f).map Subtype.val = weighted volume (lift f) := lift_weight ma μ base r mr ret f mf
  have data (f : A → ℝ) (mf : Measurable f) (u : A → RankPoint d) (m : Measurable u)
      (P' : ProbabilityMeasure A) (eP : (P' : Measure A) = weighted μ f) (c : CertifiedRank P' target u) :
      (weighted volume (lift f)).map (u ∘ r) = weighted volume w ∧ compactRankGraph A B (lift f) (u ∘ r) := by
    have ce := certified_rank_endpoint m c
    rw [eP] at ce
    obtain ⟨π,cert,graph⟩ := c
    rw [eP] at graph
    have rt : (u ∘ r) ∘ Subtype.val = u := funext fun x => congrArg u (ret x)
    refine ⟨?_,π,cert.2.2,?_⟩
    · rw [← get f mf,Measure.map_map (m.comp mr) measurable_subtype_coe,rt,← ref,ce]
    · let e := fun z : A × RankPoint d => (z.1.val,z.2)
      have me : Measurable e := (measurable_subtype_coe.comp measurable_fst).prodMk measurable_snd
      have gu : Measurable (fun x : A => (x,u x)) := measurable_id.prodMk m
      have gext : Measurable (fun x : RankPoint d => (x,(u ∘ r) x)) := measurable_id.prodMk (m.comp mr)
      have gi : Measurable (fun z : A × B => (z.1,z.2.val)) := measurable_fst.prodMk (measurable_subtype_coe.comp measurable_snd)
      have eq := congrArg (fun M : Measure (A × RankPoint d) => M.map e) graph
      change ((weighted μ f).map (fun x => (x,u x))).map e = ((π : Measure (A × B)).map (fun z : A × B => (z.1,z.2.val))).map e at eq
      rw [Measure.map_map me gu,Measure.map_map me gi] at eq
      rw [← get f mf,Measure.map_map gext measurable_subtype_coe]
      convert eq using 2
      · funext x; change (x.val,u (r x.val)) = (x.val,u x); rw [ret]
      · rfl
  obtain ⟨pu,gpu⟩ := data P mp U mu (p.law h) rfl ru
  obtain ⟨qv,gqv⟩ := data Q mq V mv (q.law j) rfl rv
  have dom := midpoint_of_rank_maps A B ha hb (lift P) (lift Q) w (U ∘ r) (V ∘ r)
    (mfl _ mp) (mfl _ mq) (mu.comp mr) (mv.comp mr) wn conc pu qv gpu gqv
  let pq := fun x => Real.sqrt (P x) * Real.sqrt (Q x)
  have hPQ : (fun x => Real.sqrt (lift P x)*Real.sqrt (lift Q x)) = lift pq := by
    funext x; by_cases hx : x ∈ A <;> simp [lift,pq,hx]
  have mi : Measurable (fun x : RankPoint d => mid ((U ∘ r) x) ((V ∘ r) x)) := by unfold mid; fun_prop
  rw [hPQ,← get pq (mp.sqrt.mul mq.sqrt),Measure.map_map mi measurable_subtype_coe] at dom
  have endmap : (fun x => mid ((U ∘ r) x) ((V ∘ r) x)) ∘ Subtype.val = fun x : A => mid (U x) (V x) := by
    funext x; simp [ret]
  rw [endmap,← ref] at dom
  exact dom

end
end SequentialRanks
