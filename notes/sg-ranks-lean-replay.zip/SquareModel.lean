import RankPair
import Mathlib.MeasureTheory.Function.Jacobian
import Mathlib.Analysis.Calculus.Deriv.MeanValue

open Set MeasureTheory
namespace SequentialRanks
noncomputable section

def wave (θ t : ℝ) := t - θ * Real.sin (Real.pi*t) / Real.pi

def squareRank (θ : ℝ) (z : ℝ × ℝ) : ℝ × ℝ :=
  (z.1 + θ*(perturb z).1, z.2 + θ*(perturb z).2)

def unitSquare : Set (ℝ × ℝ) := Icc 0 1 ×ˢ Icc 0 1

private def coords : (ℝ × ℝ) ≃ₗ[ℝ] (ℝ × ℝ) where
  toFun z := (z.1+z.2,z.1-z.2)
  invFun z := ((z.1+z.2)/2,(z.1-z.2)/2)
  map_add' a b := by ext <;> dsimp <;> ring
  map_smul' c a := by ext <;> dsimp <;> ring
  left_inv a := by ext <;> dsimp <;> ring
  right_inv a := by ext <;> dsimp <;> ring

private def axes := coords.toContinuousLinearEquiv

private theorem wave_deriv (θ t : ℝ) :
    HasDerivAt (wave θ) (1-θ*Real.cos (Real.pi*t)) t := by
  have h := (hasDerivAt_id t).sub
    ((((Real.hasDerivAt_sin _).comp t ((hasDerivAt_id t).const_mul Real.pi)).const_mul θ).div_const Real.pi)
  convert h using 1
  · rfl
  · dsimp; field_simp

private theorem increasing_wave (θ : ℝ) (hθ : |θ| ≤ 1/2) : StrictMono (wave θ) := by
  apply strictMono_of_deriv_pos
  intro t
  rw [(wave_deriv θ t).deriv]
  have b := mul_le_mul hθ (Real.abs_cos_le_one (Real.pi*t)) (abs_nonneg _) (by norm_num)
  rw [← abs_mul] at b
  linarith [le_abs_self (θ*Real.cos (Real.pi*t))]

private theorem onto_wave (θ : ℝ) (hθ : |θ| ≤ 1/2) : Function.Surjective (wave θ) := by
  intro x
  have dev (t : ℝ) : |θ*Real.sin (Real.pi*t)/Real.pi| ≤ 1 := by
    rw [abs_div,abs_mul, abs_of_pos Real.pi_pos,div_le_one Real.pi_pos]
    exact (mul_le_mul hθ (Real.abs_sin_le_one _) (abs_nonneg _) (by norm_num)).trans (by linarith [Real.two_le_pi])
  have hc : Continuous (wave θ) := continuous_iff_continuousAt.mpr fun y => (wave_deriv θ y).continuousAt
  have l := (abs_le.mp (dev (x-1))).1
  have r := (abs_le.mp (dev (x+1))).2
  have ex := intermediate_value_Icc (show x-1 ≤ x+1 by linarith) hc.continuousOn
    (show x ∈ Icc (wave θ (x-1)) (wave θ (x+1)) by unfold wave; constructor <;> linarith)
  exact ⟨ex.choose,ex.choose_spec.2⟩

private theorem wave_neg (θ x : ℝ) : wave θ (-x) = -wave θ x := by
  simp [wave]; ring

private theorem wave_period (θ x : ℝ) : wave θ (2+x) = 2+wave θ x := by
  have h : Real.pi*(2+x)=Real.pi*x+2*Real.pi := by ring
  simp [wave,h,Real.sin_add_two_pi]; ring

private theorem axes_rank (θ : ℝ) (z : ℝ × ℝ) :
    axes (squareRank θ z) = (wave θ (axes z).1, wave θ (axes z).2) := by
  change ((z.1+θ*(perturb z).1)+(z.2+θ*(perturb z).2),
    (z.1+θ*(perturb z).1)-(z.2+θ*(perturb z).2)) = _
  change _ = (wave θ (z.1+z.2),wave θ (z.1-z.2))
  simp only [wave,perturb,mul_add,mul_sub,Real.sin_add,Real.sin_sub]
  ext <;> dsimp <;> ring

private theorem mem_axes (z : ℝ × ℝ) : z ∈ unitSquare ↔
    -(axes z).2 ≤ (axes z).1 ∧ (axes z).1 ≤ 2-(axes z).2 ∧
     (axes z).2 ≤ (axes z).1 ∧ (axes z).1 ≤ 2+(axes z).2 := by
  change (z.1 ∈ Icc 0 1 ∧ z.2 ∈ Icc 0 1) ↔
    -(z.1-z.2) ≤ z.1+z.2 ∧ z.1+z.2 ≤ 2-(z.1-z.2) ∧
    z.1-z.2 ≤ z.1+z.2 ∧ z.1+z.2 ≤ 2+(z.1-z.2)
  simp only [mem_Icc]; constructor
  · rintro ⟨⟨a,b⟩,c,d⟩; exact ⟨by linarith, by linarith, by linarith, by linarith⟩
  · rintro ⟨a,b,c,d⟩; exact ⟨⟨by linarith, by linarith⟩, by linarith, by linarith⟩

theorem squareRank_bijection (θ : ℝ) (hθ : |θ| ≤ 1/2) :
    Function.Bijective (squareRank θ) ∧ squareRank θ '' unitSquare = unitSquare := by
  have inc := increasing_wave θ hθ
  have surj := onto_wave θ hθ
  have onto : Function.Surjective (squareRank θ) := by
    intro z
    obtain ⟨a,ha⟩ := surj (axes z).1
    obtain ⟨b,hb⟩ := surj (axes z).2
    refine ⟨axes.symm (a,b),axes.injective ?_⟩
    rw [axes_rank,ContinuousLinearEquiv.apply_symm_apply]; simp [ha,hb]
  have mem (z) : squareRank θ z ∈ unitSquare ↔ z ∈ unitSquare := by
    rw [mem_axes,mem_axes,axes_rank]
    simp only
    rw [← wave_neg,show 2-wave θ (axes z).2 = wave θ (2+ -(axes z).2) by rw [wave_period,wave_neg];ring,
      ← wave_period]
    simp only [inc.le_iff_le,sub_eq_add_neg]
  refine ⟨⟨fun x y h => axes.injective ?_,onto⟩,?_⟩
  · have h' := congrArg axes h
    rw [axes_rank,axes_rank] at h'
    exact Prod.ext (inc.injective (congrArg Prod.fst h')) (inc.injective (congrArg Prod.snd h'))
  · ext z; constructor
    · rintro ⟨x,hx,rfl⟩; exact (mem x).mpr hx
    · intro hz; obtain ⟨x,rfl⟩ := onto z; exact ⟨x,(mem x).mp hz,rfl⟩

private def oneJac (a : ℝ) := ContinuousLinearMap.toSpanSingleton ℝ a
private def diagJac (θ : ℝ) (w : ℝ × ℝ) :=
  (oneJac (1-θ*Real.cos (Real.pi*w.1))).prodMap (oneJac (1-θ*Real.cos (Real.pi*w.2)))
private def rankJac (θ : ℝ) (z : ℝ × ℝ) :=
  axes.symm.toContinuousLinearMap.comp ((diagJac θ (axes z)).comp axes.toContinuousLinearMap)

private theorem rank_deriv (θ : ℝ) (z : ℝ × ℝ) :
    HasFDerivAt (squareRank θ) (rankJac θ z) z := by
  have hd := HasFDerivAt.prodMap (axes z)
    (wave_deriv θ (axes z).1).hasFDerivAt (wave_deriv θ (axes z).2).hasFDerivAt
  have h := axes.symm.hasFDerivAt.comp z (hd.comp z axes.hasFDerivAt)
  apply h.congr_of_eventuallyEq
  filter_upwards with w
  change squareRank θ w = axes.symm (wave θ (axes w).1,wave θ (axes w).2)
  rw [← axes_rank,ContinuousLinearEquiv.symm_apply_apply]

private theorem det_oneJac (a : ℝ) : LinearMap.det (oneJac a).toLinearMap = a := by
  have h : (oneJac a).toLinearMap = a • (LinearMap.id : ℝ →ₗ[ℝ] ℝ) := by
    apply LinearMap.ext; intro x; change x * a = a*x; ring
  simp [h]

private theorem rank_det (θ : ℝ) (z : ℝ × ℝ) : (rankJac θ z).det = density θ z := by
  change LinearMap.det (axes.symm.toLinearEquiv.toLinearMap ∘ₗ (diagJac θ (axes z)).toLinearMap ∘ₗ
    axes.toLinearEquiv.toLinearMap) = _
  have conj := LinearMap.det_conj (diagJac θ (axes z)).toLinearMap axes.symm.toLinearEquiv
  refine conj.trans ?_
  change LinearMap.det ((oneJac _).toLinearMap.prodMap (oneJac _).toLinearMap) = _
  rw [LinearMap.det_prodMap,det_oneJac,det_oneJac]; rfl

/-- The trigonometric square model in the public note pushes its explicit
density onto two-dimensional uniform measure, including the boundary. -/
theorem squareRank_pushforward (θ : ℝ) (hθ : |θ| ≤ 1/2) :
    Measure.map (squareRank θ) ((volume.restrict unitSquare).withDensity
      (fun z => ENNReal.ofReal (density θ z))) = volume.restrict unitSquare := by
  let _ : (volume : Measure (ℝ × ℝ)).IsAddHaarMeasure := by rw [Measure.volume_eq_prod ℝ ℝ]; infer_instance
  have bij := squareRank_bijection θ hθ
  have h := map_withDensity_abs_det_fderiv_eq_addHaar (s := unitSquare) (volume : Measure (ℝ × ℝ))
    ((measurableSet_Icc.prod measurableSet_Icc : MeasurableSet unitSquare).nullMeasurableSet)
    (fun z _ => (rank_deriv θ z).hasFDerivWithinAt) bij.1.1.injOn
  have pos (z : ℝ × ℝ) : 0 ≤ density θ z := le_trans (by norm_num) (actual_density_floor θ z.1 z.2 hθ)
  simpa only [bij.2,rank_det,abs_of_nonneg (pos _)] using h

private def primitive (θ t : ℝ) := t^2/2 + θ*Real.cos (Real.pi*t)/Real.pi^2

private theorem derivative_primitive (θ t : ℝ) : HasDerivAt (primitive θ) (wave θ t) t := by
  have a := (((hasDerivAt_id t).pow 2).div_const 2).add
    ((((Real.hasDerivAt_cos _).comp t ((hasDerivAt_id t).const_mul Real.pi)).const_mul θ).div_const (Real.pi^2))
  convert a using 1
  · rfl
  · dsimp [wave]; field_simp; ring

private theorem tangent (θ : ℝ) (hθ : |θ| ≤ 1/2) (x y : ℝ) :
    wave θ y * (x-y) + (x-y)^2/4 ≤ primitive θ x-primitive θ y := by
  let g := fun t => primitive θ t-t^2/4
  let d := fun t => wave θ t-t/2
  have dg (t) : HasDerivAt g (d t) t := by
    convert (derivative_primitive θ t).sub (((hasDerivAt_id t).pow 2).div_const 4) using 1
    · rfl
    · dsimp [d]; ring
  have dd (t) : HasDerivAt d (1/2-θ*Real.cos (Real.pi*t)) t := by
    convert (wave_deriv θ t).sub ((hasDerivAt_id t).div_const 2) using 1
    · rfl
    · ring
  have mon : Monotone d := by
    apply monotone_of_deriv_nonneg (fun t => (dd t).differentiableAt)
    intro t; rw [(dd t).deriv]
    have b := mul_le_mul hθ (Real.abs_cos_le_one (Real.pi*t)) (abs_nonneg _) (by norm_num)
    rw [← abs_mul] at b
    linarith [le_abs_self (θ*Real.cos (Real.pi*t))]
  have c : Continuous g := (show Differentiable ℝ g from fun t => (dg t).differentiableAt).continuous
  have slope (a b : ℝ) (hab : a<b) : d a*(b-a) ≤ g b-g a ∧ g b-g a ≤ d b*(b-a) := by
    obtain ⟨t,ht,eqn⟩ := exists_deriv_eq_slope g hab c.continuousOn
      (fun z _ => (dg z).differentiableAt.differentiableWithinAt)
    rw [(dg t).deriv,eq_div_iff (sub_ne_zero.mpr hab.ne')] at eqn
    rw [←eqn]
    exact ⟨mul_le_mul_of_nonneg_right (mon ht.1.le) (sub_nonneg.mpr hab.le),
      mul_le_mul_of_nonneg_right (mon ht.2.le) (sub_nonneg.mpr hab.le)⟩
  rcases lt_trichotomy x y with h|rfl|h
  · have e := (slope x y h).2; dsimp [g,d] at e; nlinarith only [e]
  · simp
  · have e := (slope y x h).1; dsimp [g,d] at e; nlinarith only [e]

private def potential (θ : ℝ) (x : ℝ × ℝ) :=
  (primitive θ (axes x).1 + primitive θ (axes x).2)/2
private def dot2 (x y : ℝ × ℝ) := x.1*y.1+x.2*y.2
def squareCost2 (x y : ℝ × ℝ) := (x.1-y.1)^2+(x.2-y.2)^2

private theorem tangent2 (θ : ℝ) (hθ : |θ| ≤ 1/2) (x y : ℝ × ℝ) :
    dot2 (squareRank θ y) (x-y) + squareCost2 x y/4 ≤ potential θ x-potential θ y := by
  have a := tangent θ hθ (axes x).1 (axes y).1
  have b := tangent θ hθ (axes x).2 (axes y).2
  have eq1 := congrArg Prod.fst (axes_rank θ y)
  have eq2 := congrArg Prod.snd (axes_rank θ y)
  change (squareRank θ y).1+(squareRank θ y).2 = wave θ (axes y).1 at eq1
  change (squareRank θ y).1-(squareRank θ y).2 = wave θ (axes y).2 at eq2
  rw [←eq1] at a; rw [←eq2] at b
  unfold potential dot2 squareCost2
  change _*(_-_)+_*(_-_) + _ ≤ _
  change _*((x.1+x.2)-(y.1+y.2)) + ((x.1+x.2)-(y.1+y.2))^2/4 ≤ _ at a
  change _*((x.1-x.2)-(y.1-y.2)) + ((x.1-x.2)-(y.1-y.2))^2/4 ≤ _ at b
  nlinarith only [a,b]

private def rankHomeo (θ : ℝ) (hθ : |θ| ≤ 1/2) : (ℝ × ℝ) ≃ₜ (ℝ × ℝ) :=
  let e := (StrictMono.orderIsoOfSurjective _ (increasing_wave θ hθ) (onto_wave θ hθ)).toHomeomorph
  axes.toHomeomorph.trans ((e.prodCongr e).trans axes.symm.toHomeomorph)

private theorem homeo_rank (θ : ℝ) (hθ : |θ| ≤ 1/2) (z : ℝ × ℝ) :
    rankHomeo θ hθ z = squareRank θ z := by
  change axes.symm (wave θ (axes z).1,wave θ (axes z).2) = _
  rw [←axes_rank, ContinuousLinearEquiv.symm_apply_apply]

/-- The explicit transport on the square uniquely minimizes quadratic cost, among
all couplings of its Jacobian density and the uniform reference. Equality detects
the actual graph almost everywhere. -/
theorem squareRank_unique_optimum (θ : ℝ) (hθ : |θ| ≤ 1/2)
    (γ : Measure (unitSquare × unitSquare)) [IsProbabilityMeasure γ]
    (src : γ.map (fun z => z.1.val) = (volume.restrict unitSquare).withDensity
      (fun z => ENNReal.ofReal (density θ z)))
    (tgt : γ.map (fun z => z.2.val) = volume.restrict unitSquare) :
    (∫ z, squareCost2 z.1.val (squareRank θ z.1.val) ∂γ) ≤
      (∫ z, squareCost2 z.1.val z.2.val ∂γ) ∧
    ((∫ z, squareCost2 z.1.val z.2.val ∂γ) = (∫ z, squareCost2 z.1.val (squareRank θ z.1.val) ∂γ) ↔
       ∀ᵐ z ∂γ, z.2.val = squareRank θ z.1.val) := by
  let _ : CompactSpace unitSquare := isCompact_iff_compactSpace.mp (isCompact_Icc.prod isCompact_Icc)
  let e := rankHomeo θ hθ
  let φ := potential θ
  let A (x : ℝ × ℝ) := dot2 x x-2*φ x
  let B (v : ℝ × ℝ) := dot2 v v-2*dot2 v (e.symm v)+2*φ (e.symm v)
  let X := fun z : unitSquare × unitSquare => z.1.val
  let Y := fun z : unitSquare × unitSquare => z.2.val
  have mX : Continuous X := continuous_subtype_val.comp continuous_fst
  have mY : Continuous Y := continuous_subtype_val.comp continuous_snd
  have eRank (x) : e x = squareRank θ x := homeo_rank θ hθ x
  have mR : Continuous (squareRank θ) := (show Differentiable ℝ _ from fun z => (rank_deriv θ z).differentiableAt).continuous
  have mφ : Continuous φ := by
    unfold φ potential primitive
    have h := axes.continuous
    fun_prop
  have mA : Continuous A := by unfold A dot2; fun_prop
  have mB : Continuous B := by unfold B dot2; fun_prop
  have adm : γ.map Y = γ.map (squareRank θ ∘ X) := by
    rw [←Measure.map_map mR.measurable mX.measurable,src,squareRank_pushforward θ hθ,tgt]
  have marginal : (∫ z, B (Y z) ∂γ) = (∫ z, B (squareRank θ (X z)) ∂γ) := by
    rw [←integral_map mY.measurable.aemeasurable mB.aestronglyMeasurable, adm,
      integral_map (mR.comp mX).measurable.aemeasurable mB.aestronglyMeasurable]
    rfl
  let C := fun z => squareCost2 (X z) (Y z)
  let D := fun z => squareCost2 (X z) (squareRank θ (X z))
  let L := fun z => C z - (A (X z)+B (Y z))
  have touch (x : ℝ × ℝ) : squareCost2 x (squareRank θ x) = A x+B (squareRank θ x) := by
    rw [←eRank]; unfold A B
    rw [Homeomorph.symm_apply_apply]; unfold squareCost2 dot2; ring
  have point (z) : squareCost2 (X z) (e.symm (Y z))/2 ≤ L z := by
    have h := tangent2 θ hθ (X z) (e.symm (Y z))
    rw [←eRank, Homeomorph.apply_symm_apply] at h
    dsimp only [L,C,A,B,φ]; unfold squareCost2 dot2 at *; dsimp only [Prod.fst_sub,Prod.snd_sub] at h
    nlinarith only [h]
  have posCost (x y : ℝ × ℝ) : 0 ≤ squareCost2 x y := by unfold squareCost2; positivity
  have pos (z) : 0 ≤ L z := (div_nonneg (posCost _ _) (by norm_num)).trans (point z)
  have ci : Continuous C := by unfold C squareCost2; fun_prop
  have li : Continuous L := ci.sub ((mA.comp mX).add (mB.comp mY))
  have int {f : unitSquare × unitSquare → ℝ} (hf : Continuous f) : Integrable f γ :=
    hf.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)
  have identity : (∫ z,L z ∂γ) = (∫ z,C z ∂γ)-(∫ z,D z ∂γ) := by
    have dId : D = fun z => A (X z)+B (squareRank θ (X z)) := funext fun _ => touch _
    change (∫ z,C z-(A (X z)+B (Y z)) ∂γ) = _
    have iA : Integrable (fun z => A (X z)) γ := int (mA.comp mX)
    have iB : Integrable (fun z => B (Y z)) γ := int (mB.comp mY)
    have iR : Integrable (fun z => B (squareRank θ (X z))) γ := int (mB.comp (mR.comp mX))
    have split := integral_sub (int ci) (iA.add iB)
    simp only [Pi.add_apply] at split
    rw [split,
      integral_add iA iB,marginal,dId,
      integral_add iA iR]
  refine ⟨sub_nonneg.mp (identity ▸ integral_nonneg pos),?_⟩
  constructor
  · intro eqn
    change (∫ z,C z ∂γ) = ∫ z,D z ∂γ at eqn
    have zero := (integral_eq_zero_iff_of_nonneg pos (int li)).mp (by rw [identity,eqn,sub_self])
    filter_upwards [zero] with z hz
    have b := point z
    change L z = 0 at hz
    rw [hz] at b
    unfold squareCost2 at b
    have p : X z = e.symm (Y z) := Prod.ext (by nlinarith only [b,sq_nonneg ((X z).2-(e.symm (Y z)).2),sq_nonneg ((X z).1-(e.symm (Y z)).1)]) (by nlinarith only [b,sq_nonneg ((X z).1-(e.symm (Y z)).1),sq_nonneg ((X z).2-(e.symm (Y z)).2)])
    change Y z = squareRank θ (X z)
    rw [←eRank,p,Homeomorph.apply_symm_apply]
  · intro eqn
    apply integral_congr_ae
    filter_upwards [eqn] with z hz
    rw [hz]

/-- Global supporting inequality used to certify the same square rank after
a coordinate change to the compact observation chart. -/
theorem square_rank_support (θ : ℝ) (hθ : |θ| ≤ 1/2) :
    ∃ φ : (ℝ × ℝ) → ℝ, ∀ x y,
      (squareRank θ y).1*(x.1-y.1)+(squareRank θ y).2*(x.2-y.2) ≤ φ x-φ y := by
  refine ⟨potential θ,fun x y => ?_⟩
  have h := tangent2 θ hθ x y
  change (squareRank θ y).1*(x.1-y.1)+(squareRank θ y).2*(x.2-y.2)+squareCost2 x y/4 ≤ _ at h
  linarith [show 0≤squareCost2 x y by unfold squareCost2; positivity]

end
end SequentialRanks
