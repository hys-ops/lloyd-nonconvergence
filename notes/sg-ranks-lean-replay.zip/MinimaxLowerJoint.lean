import MinimaxLowerPrior

open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def likelihood : (n : ℕ) → ℝ × Past n → ℝ
  | 0, _ => 1
  | n+1, tx => likelihood n (tx.1,tx.2.1)*density tx.1 tx.2.2

private theorem mdens : Measurable (fun tx : ℝ × SquareObs => density tx.1 tx.2) := by
  unfold density; fun_prop
private theorem mlike : ∀ n, Measurable (likelihood n)
  | 0 => measurable_const
  | n+1 => ((mlike n).comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))).mul
      (mdens.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd)))
private theorem mObs : Measurable (fun tx : ℝ × SquareObs => obsScore tx.1 tx.2) := by
  have md : Measurable (fun tx : ℝ × SquareObs => densityDerivative tx.1 tx.2) := by
    unfold densityDerivative; fun_prop
  exact md.div mdens

private theorem mscoreall (n : ℕ) : Measurable (fun tx : ℝ × Past n => allScore tx.1 n tx.2) := by
  induction n with
  | zero => exact measurable_const
  | succ n ih =>
    change Measurable (fun tx : ℝ × (Past n × SquareObs) =>
      allScore tx.1 n tx.2.1+obsScore tx.1 tx.2.2)
    have h1 : Measurable (fun tx : ℝ × (Past n × SquareObs) => (tx.1,tx.2.1)) :=
      measurable_fst.prodMk (measurable_fst.comp measurable_snd)
    have h2 : Measurable (fun tx : ℝ × (Past n × SquareObs) => (tx.1,tx.2.2)) :=
      measurable_fst.prodMk (measurable_snd.comp measurable_snd)
    have left := ih.comp h1
    have right := mObs.comp h2
    simpa only [Function.comp_def,Pi.add_def] using left.add right

private theorem baseProb (n : ℕ) : IsProbabilityMeasure (iidPastLaw 0 n) := by
  induction n with
  | zero => exact (inferInstance : IsProbabilityMeasure (Measure.dirac ()))
  | succ n ih =>
    let _ := ih
    let _ := square_law_probability (θ:=0) (by norm_num)
    change IsProbabilityMeasure ((iidPastLaw 0 n).prod (squareLaw 0)); infer_instance
private theorem parProb : IsProbabilityMeasure parameterBase := by
  constructor; simp [parameterBase,parameterInterval,Real.volume_Icc]; norm_num

private theorem den_bounds {θ : ℝ} (hθ : |θ| ≤ 1/2) (z : SquareObs) : 0≤density θ z ∧ density θ z≤4 := by
  refine ⟨(by norm_num : (0:ℝ)≤1/4).trans (actual_density_floor _ _ _ hθ),?_⟩
  have f (a : ℝ) (h : |a|≤1) : |1-θ*a| ≤ 2 := by
    have hh := mul_le_mul hθ h (abs_nonneg _) (by norm_num)
    have t := abs_sub (1:ℝ) (θ*a); rw [abs_one,abs_mul] at t; linarith
  exact (le_abs_self _).trans (by
    unfold density; rw [abs_mul]
    exact (mul_le_mul (f _ (Real.abs_cos_le_one _)) (f _ (Real.abs_cos_le_one _)) (abs_nonneg _) (by norm_num)).trans (by norm_num))

private theorem like_bounds {θ : ℝ} (h : |θ|≤1/2) : ∀ n (x : Past n),
    0≤likelihood n (θ,x) ∧ likelihood n (θ,x)≤4^n
  | 0, _ => by simp [likelihood]
  | n+1, x => by
    obtain ⟨hl,hu⟩ := like_bounds h n x.1
    obtain ⟨dl,du⟩ := den_bounds h x.2
    exact ⟨mul_nonneg hl dl,(mul_le_mul hu du dl (by positivity)).trans_eq (pow_succ 4 n).symm⟩

private theorem weight_like : ∀ n (x : Past n) θ, jointWeight n x θ = priorWeight θ * likelihood n (θ,x)
  | 0, _, θ => by simp [jointWeight,likelihood]
  | n+1, x, θ => by simp only [jointWeight,likelihood,weight_like n, mul_assoc]

theorem iid_likelihood_law (n : ℕ) (θ : ℝ) (ht : |θ|≤1/2) :
    iidPastLaw θ n = (iidPastLaw 0 n).withDensity (fun x => ENNReal.ofReal (likelihood n (θ,x))) := by
  induction n with
  | zero => simp [iidPastLaw,likelihood]
  | succ n ih =>
    let _ := baseProb n
    let _ := square_law_probability (θ:=0) (by norm_num)
    have base : squareLaw 0 = squareBase := by simp [squareLaw,density]
    have hd0 : SFinite squareBase := by rw [←base]; infer_instance
    change (iidPastLaw θ n).prod (squareLaw θ) = ((iidPastLaw 0 n).prod (squareLaw 0)).withDensity
      (fun x : Past n × SquareObs => ENNReal.ofReal (likelihood n (θ,x.1)*density θ x.2))
    have ml : Measurable (fun x => ENNReal.ofReal (likelihood n (θ,x))) :=
      ((mlike n).comp (measurable_const.prodMk measurable_id)).ennreal_ofReal
    have md : Measurable (fun x => ENNReal.ofReal (density θ x)) :=
      (mdens.comp (measurable_const.prodMk measurable_id)).ennreal_ofReal
    rw [ih,base,squareLaw,prod_withDensity ml md]
    congr 1
    funext x
    exact (ENNReal.ofReal_mul (like_bounds ht n x.1).1).symm

private theorem weighted_iid (n : ℕ) (θ : ℝ) (ht : |θ| ≤ 1/2) (f : Past n → ℝ) :
    (∫ x,f x ∂iidPastLaw θ n) = ∫ x,likelihood n (θ,x)*f x ∂iidPastLaw 0 n := by
  have ml : Measurable (fun x => ENNReal.ofReal (likelihood n (θ,x))) :=
    ((mlike n).comp (measurable_const.prodMk measurable_id)).ennreal_ofReal
  rw [iid_likelihood_law n θ ht,integral_withDensity_eq_integral_toReal_smul ml
    (Filter.Eventually.of_forall (fun _ => ENNReal.ofReal_lt_top))]
  apply integral_congr_ae; filter_upwards with x
  rw [ENNReal.toReal_ofReal (like_bounds ht n x).1,smul_eq_mul]

private theorem parent_mass (n : ℕ) (θ : ℝ) (ht : |θ| ≤ 1/2) :
    (∫ x,jointWeight n x θ ∂iidPastLaw 0 n)=priorWeight θ := by
  have pp : IsProbabilityMeasure (iidPastLaw θ n) := by
    induction n with
    | zero => exact (inferInstance : IsProbabilityMeasure (Measure.dirac ()))
    | succ n ih =>
      let _ := ih; let _ := square_law_probability ht
      change IsProbabilityMeasure ((iidPastLaw θ n).prod (squareLaw θ)); infer_instance
  have h := weighted_iid n θ ht (fun _ => (1:ℝ))
  simp only [integral_const,probReal_univ,one_smul,mul_one] at h
  simp only [weight_like,integral_const_mul,←h,mul_one]

private theorem aeθ : ∀ᵐ θ ∂parameterBase, |θ|≤1/2 := by
  filter_upwards [ae_restrict_mem (μ:=volume) (s:=parameterInterval) measurableSet_Icc] with θ ht
  exact abs_le.mpr ht

private def totalScore (n : ℕ) (p : ℝ × Past n) := priorScore p.1+allScore p.1 n p.2
private theorem ms (n : ℕ) : Measurable (totalScore n) :=
  ((show Measurable priorScore by unfold priorScore priorWeight priorDerivative; fun_prop).comp measurable_fst).add (mscoreall n)
private theorem mw (n : ℕ) : Measurable (fun p : ℝ × Past n => jointWeight n p.2 p.1) := by
  simp only [weight_like]
  exact ((show Measurable priorWeight by unfold priorWeight; fun_prop).comp measurable_fst).mul (mlike n)
private theorem weight_bounds (n : ℕ) {θ : ℝ} (ht : |θ| ≤ 1/2) (x : Past n) :
    0 ≤ jointWeight n x θ ∧ jointWeight n x θ ≤ 2*4^n := by
  rw [weight_like]
  have c := Real.abs_cos_le_one (Real.pi*θ)
  have w : 0≤priorWeight θ ∧ priorWeight θ≤2 := by
    unfold priorWeight; constructor
    · positivity
    · nlinarith [sq_abs (Real.cos (Real.pi*θ)),mul_self_le_mul_self (abs_nonneg _) c]
  exact ⟨mul_nonneg w.1 (like_bounds ht n x).1,mul_le_mul w.2 (like_bounds ht n x).2 (like_bounds ht n x).1 (by norm_num)⟩

private theorem bound_all (θ : ℝ) (ht : |θ| ≤ 1/2) : ∀ n (x : Past n), |allScore θ n x| ≤ 4*(n:ℝ)
  | 0, x => by simp [allScore]
  | n+1, x => by
    change |_ + _| ≤ _
    exact (abs_add_le _ _).trans (by push_cast; linarith [bound_all θ ht n x.1,square_score_bound θ ht x.2])

private theorem infoBound (n : ℕ) {θ : ℝ} (ht : |θ|≤1/2) (x : Past n) :
    0 ≤ jointWeight n x θ * totalScore n (θ,x)^2 ∧
    jointWeight n x θ * totalScore n (θ,x)^2 ≤ 4^n*(16*Real.pi^2+4*(4*(n:ℝ))^2) := by
  refine ⟨mul_nonneg (weight_bounds n ht x).1 (sq_nonneg _),?_⟩
  let P := priorWeight θ
  have hp : 0 ≤ P := by dsimp [P,priorWeight]; positivity
  have cp := Real.abs_cos_le_one (Real.pi*θ)
  have sp := Real.abs_sin_le_one (Real.pi*θ)
  have p2 : P ≤ 2 := by
    dsimp [P,priorWeight]; nlinarith [sq_abs (Real.cos (Real.pi*θ)),mul_self_le_mul_self (abs_nonneg _) cp]
  have priorBound : P*priorScore θ^2 ≤ 8*Real.pi^2 := by
    by_cases z : Real.cos (Real.pi*θ)=0
    · simp [P,priorWeight,z]; positivity
    · have id : P*priorScore θ^2=8*Real.pi^2*Real.sin (Real.pi*θ)^2 := by
        unfold P priorScore priorWeight priorDerivative
        field_simp [z]; ring
      rw [id]; nlinarith [mul_nonneg (by positivity : 0≤8*Real.pi^2)
        (sub_nonneg.mpr (by nlinarith [sq_abs (Real.sin (Real.pi*θ)),mul_self_le_mul_self (abs_nonneg _) sp] : Real.sin (Real.pi*θ)^2 ≤ 1))]
  have ab := bound_all θ ht n x
  have z := pow_le_pow_left₀ (abs_nonneg _) ab 2
  rw [sq_abs] at z
  have b := mul_le_mul p2 z (sq_nonneg _) (by norm_num : (0:ℝ)≤2)
  have s : P*(priorScore θ + allScore θ n x)^2 ≤ 16*Real.pi^2+4*(4*(n:ℝ))^2 := by
    nlinarith only [priorBound,b,mul_nonneg hp (sq_nonneg (priorScore θ-allScore θ n x))]
  rw [weight_like]
  change P*likelihood n (θ,x)*(priorScore θ+allScore θ n x)^2 ≤ _
  rw [mul_comm P, mul_assoc]
  exact mul_le_mul (like_bounds ht n x).2 s (mul_nonneg hp (sq_nonneg _)) (by positivity)

private def productBase (n : ℕ) := parameterBase.prod (iidPastLaw 0 n)

private theorem changeOrder (n : ℕ) (f : ℝ × Past n → ℝ)
    (hf : Integrable (fun p => jointWeight n p.2 p.1*f p) (productBase n)) :
    (∫ p,jointWeight n p.2 p.1*f p ∂productBase n) =
       ∫ θ,priorWeight θ*(∫ x,f (θ,x) ∂iidPastLaw θ n) ∂parameterBase := by
  let _ := baseProb n
  let _ := parProb
  rw [productBase,integral_prod _ hf]
  apply integral_congr_ae
  filter_upwards [aeθ] with θ ht
  rw [weighted_iid n θ ht]
  simp only [weight_like,mul_assoc,integral_const_mul]

private theorem massOne (n : ℕ) : (∫ p,jointWeight n p.2 p.1 ∂productBase n)=1 := by
  let _ := baseProb n
  let _ := parProb
  have ae0 : ∀ᵐ p ∂productBase n, |p.1| ≤ 1/2 := Measure.quasiMeasurePreserving_fst.ae aeθ
  have i : Integrable (fun p : ℝ × Past n => jointWeight n p.2 p.1) (productBase n) := by
    unfold productBase
    apply Integrable.of_bound (mw n).aestronglyMeasurable (2*4^n)
    filter_upwards [ae0] with p h
    rw [Real.norm_of_nonneg (weight_bounds n h p.2).1]; exact (weight_bounds n h p.2).2
  rw [productBase,integral_prod _ i,←prior_mass_and_information.1]
  apply integral_congr_ae
  filter_upwards [aeθ] with θ ht
  exact parent_mass n θ ht

/-- The scalar van Trees bound for a bounded measurable estimate of bθ.
Both expectations are over the explicit prior and the actual i.i.d. observations. -/
theorem iid_scalar_bayes (n : ℕ) (b : ℝ) (a : Past n → ℝ) (ma : Measurable a)
    (C : ℝ) (bound : ∀ x, |a x| ≤ C) :
    b^2/(4*Real.pi^2+16*(n:ℝ)) ≤
      ∫ θ,priorWeight θ*(∫ x,(a x-b*θ)^2 ∂iidPastLaw θ n) ∂parameterBase := by
  let _ := baseProb n
  let _ := parProb
  let P := productBase n
  let W := fun p : ℝ × Past n => jointWeight n p.2 p.1
  let E := fun p : ℝ × Past n => a p.2-b*p.1
  let S := totalScore n
  let K := 4*Real.pi^2+16*(n:ℝ)
  have hK : 0<K := by dsimp [K]; positivity
  have mW := mw n
  have mE : Measurable E := (ma.comp measurable_snd).sub (measurable_const.mul measurable_fst)
  have mS := ms n
  have ht : ∀ᵐ p ∂P, |p.1|≤1/2 := Measure.quasiMeasurePreserving_fst.ae aeθ
  have : IsFiniteMeasure P := by dsimp [P,productBase]; infer_instance
  have ie : Integrable (fun p => W p*(E p)^2) P := by
    apply Integrable.of_bound (mW.mul (mE.pow_const 2)).aestronglyMeasurable (2*4^n*(C+|b|/2)^2)
    filter_upwards [ht] with p hp
    have h := weight_bounds n hp p.2
    have e : |E p| ≤ C+|b|/2 := by
      apply (abs_sub _ _).trans
      rw [abs_mul]; linarith [bound p.2,mul_le_mul_of_nonneg_left hp (abs_nonneg b)]
    change ‖jointWeight n p.2 p.1*(E p)^2‖ ≤ _
    rw [Real.norm_of_nonneg (mul_nonneg h.1 (sq_nonneg _))]
    apply mul_le_mul h.2 _ (sq_nonneg _) (by positivity)
    simpa only [sq_abs] using pow_le_pow_left₀ (abs_nonneg _) e 2
  have iS : Integrable (fun p => W p*(S p)^2) P := by
    apply Integrable.of_bound (mW.mul (mS.pow_const 2)).aestronglyMeasurable
      (4^n*(16*Real.pi^2+4*(4*(n:ℝ))^2))
    filter_upwards [ht] with p hp
    change ‖jointWeight n p.2 p.1 * totalScore n (p.1,p.2)^2‖ ≤ _
    rw [Real.norm_of_nonneg (infoBound n hp p.2).1]; exact (infoBound n hp p.2).2
  have iCross : Integrable (fun p => W p*(E p*S p)) P := by
    apply (ie.add iS).mono' ((mW.mul (mE.mul mS)).aestronglyMeasurable)
    filter_upwards [ht] with p hp
    change |W p*(E p*S p)| ≤ W p*E p^2+W p*S p^2
    have hW : 0 ≤ W p := (weight_bounds n hp p.2).1
    rw [abs_mul,abs_of_nonneg hW,abs_mul]
    calc
      _ ≤ W p*((E p)^2+(S p)^2) := mul_le_mul_of_nonneg_left (by
        nlinarith [sq_nonneg (|E p|-|S p|),sq_abs (E p),sq_abs (S p),sq_nonneg (E p),sq_nonneg (S p)]) hW
      _ = _ := by ring
  have hi : (∫ p,W p*S p^2 ∂P) ≤ K := by
    exact (changeOrder n (fun p => (S p)^2) iS).le.trans (iid_joint_information n)
  have ib : (∫ p,W p*(E p*S p) ∂P) = b := by
    have wi : Integrable W P := by
      apply Integrable.of_bound mW.aestronglyMeasurable (2*4^n)
      filter_upwards [ht] with p hp; rw [Real.norm_of_nonneg (weight_bounds n hp p.2).1]
      exact (weight_bounds n hp p.2).2
    change (∫ p,W p*(E p*S p) ∂parameterBase.prod (iidPastLaw 0 n))=_
    rw [integral_prod_symm _ iCross]
    calc
      _ = ∫ x,b*(∫ θ,W (θ,x) ∂parameterBase) ∂iidPastLaw 0 n := by
        apply integral_congr_ae; filter_upwards with x
        rw [←iid_score_parts_scaled n x (a x) b]
        apply integral_congr_ae
        filter_upwards [aeθ] with θ hθ
        rw [iid_score_factor n x θ hθ]
        dsimp [W,E,S,totalScore]; ring
      _ = b*(∫ p,W p ∂P) := by rw [integral_const_mul]; exact congrArg (b*·) (integral_prod_symm _ wi).symm
      _ = b := by rw [massOne n,mul_one]
  have hzero : 0 ≤ ∫ p,K^2*(W p*E p^2) - (2*K*b)*(W p*(E p*S p)) + b^2*(W p*S p^2) ∂P := by
    apply integral_nonneg_of_ae
    filter_upwards [ht] with p hh
    change 0 ≤ K^2*(W p*E p^2) - (2*K*b)*(W p*(E p*S p)) + b^2*(W p*S p^2)
    nlinarith only [mul_nonneg (show 0 ≤ W p from (weight_bounds n hh p.2).1) (sq_nonneg (K*E p-b*S p))]
  have combine := integral_add ((ie.const_mul (K^2)).sub (iCross.const_mul (2*K*b))) (iS.const_mul (b^2))
  simp only [Pi.sub_apply] at combine
  rw [combine,
    integral_sub (ie.const_mul (K^2)) (iCross.const_mul (2*K*b)),integral_const_mul,integral_const_mul,
    integral_const_mul,ib] at hzero
  rw [←changeOrder n (fun p : ℝ × Past n => (E p)^2) ie]
  change b^2/K ≤ ∫ p,W p*E p^2 ∂P
  apply (div_le_iff₀ hK).mpr
  apply le_of_mul_le_mul_left (a:=K) _ hK
  nlinarith only [hzero,mul_le_mul_of_nonneg_left hi (sq_nonneg b)]

/-- The joint probability measure of the prior parameter and n past observations. -/
def experiment (n : ℕ) : Measure (ℝ × Past n) :=
  (productBase n).withDensity (fun p => ENNReal.ofReal (jointWeight n p.2 p.1))

instance experimentProb (n : ℕ) : IsProbabilityMeasure (experiment n) := by
  constructor
  rw [experiment,withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ]
  let _ := baseProb n
  let _ := parProb
  have ae : ∀ᵐ p ∂productBase n, |p.1|≤1/2 := Measure.quasiMeasurePreserving_fst.ae aeθ
  have wi : Integrable (fun p : ℝ × Past n => jointWeight n p.2 p.1) (productBase n) := by
    unfold productBase; apply Integrable.of_bound (mw n).aestronglyMeasurable (2*4^n)
    filter_upwards [ae] with p hp; rw [Real.norm_of_nonneg (weight_bounds n hp p.2).1]
    exact (weight_bounds n hp p.2).2
  rw [←ofReal_integral_eq_lintegral_ofReal wi (by
    filter_upwards [ae] with p hp; exact (weight_bounds n hp p.2).1),massOne,ENNReal.ofReal_one]

theorem experiment_tonelli (n : ℕ) (f : ℝ × Past n → ℝ≥0∞) (hf : Measurable f) :
    (∫⁻ p,f p ∂experiment n)=
    ∫⁻ θ, ENNReal.ofReal (priorWeight θ)*(∫⁻ x,f (θ,x) ∂iidPastLaw θ n) ∂parameterBase := by
  let _ := baseProb n
  let _ := parProb
  let g (p : ℝ × Past n) := ENNReal.ofReal (jointWeight n p.2 p.1)*f p
  have mg : Measurable g := (mw n).ennreal_ofReal.mul hf
  change (∫⁻ p,f p ∂(productBase n).withDensity _)=_
  rw [lintegral_withDensity_eq_lintegral_mul _ (mw n).ennreal_ofReal hf]
  change (∫⁻ p,g p ∂parameterBase.prod (iidPastLaw 0 n))=_
  rw [lintegral_prod _ mg.aemeasurable]
  apply lintegral_congr_ae
  filter_upwards [aeθ] with θ ht
  have ml : Measurable (fun x => ENNReal.ofReal (likelihood n (θ,x))) :=
    ((mlike n).comp (measurable_const.prodMk measurable_id)).ennreal_ofReal
  have hfx : Measurable (fun x => f (θ,x)) := hf.comp (measurable_const.prodMk measurable_id)
  rw [iid_likelihood_law n θ ht,lintegral_withDensity_eq_lintegral_mul _ ml hfx,
    ←lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply lintegral_congr
  intro x
  dsimp only [g,Pi.mul_apply]
  rw [weight_like,ENNReal.ofReal_mul (by unfold priorWeight; positivity),mul_assoc]

private theorem realIntegral_le {X : Type*} [MeasurableSpace X] (μ : Measure X) (f : X → ℝ)
    (hf : ∀ x, 0 ≤ f x) :
    ENNReal.ofReal (∫ x,f x ∂μ) ≤ ∫⁻ x,ENNReal.ofReal (f x) ∂μ := by
  by_cases h : Integrable f μ
  · exact (ofReal_integral_eq_lintegral_ofReal h (Filter.Eventually.of_forall hf)).le
  · simp [integral_undef h]

/-- No boundedness or finite-risk assumption on the scalar estimator. -/
theorem iid_scalar_unrestricted (n : ℕ) (b : ℝ) (a : Past n → ℝ) (ma : Measurable a) :
    ENNReal.ofReal (b^2/(4*Real.pi^2+16*(n:ℝ))) ≤
      ∫⁻ p,ENNReal.ofReal ((a p.2-b*p.1)^2) ∂experiment n := by
  let C := |b|/2
  let clipped := fun x => max (-C) (min C (a x))
  have hc : 0 ≤ C := by dsimp [C]; positivity
  have m : Measurable clipped := measurable_const.max (measurable_const.min ma)
  have bound (x : Past n) : |clipped x| ≤ C := abs_le.mpr
    ⟨le_max_left _ _,max_le (by linarith) (min_le_left _ _)⟩
  have h := ENNReal.ofReal_le_ofReal (iid_scalar_bayes n b clipped m C bound)
  have pos (θ : ℝ) : 0 ≤ priorWeight θ := by unfold priorWeight; positivity
  apply h.trans
  apply (realIntegral_le parameterBase _ (fun θ =>mul_nonneg (pos θ) (integral_nonneg fun _ =>sq_nonneg _))).trans
  have mf : Measurable (fun p : ℝ × Past n => ENNReal.ofReal ((a p.2-b*p.1)^2)) :=
    (((ma.comp measurable_snd).sub (measurable_const.mul measurable_fst)).pow_const 2).ennreal_ofReal
  rw [experiment_tonelli _ _ mf]
  apply lintegral_mono_ae
  filter_upwards [aeθ] with θ ht
  rw [ENNReal.ofReal_mul (pos θ)]
  gcongr
  apply (realIntegral_le _ _ (fun _ => sq_nonneg _)).trans
  apply lintegral_mono
  intro x
  apply ENNReal.ofReal_le_ofReal
  have hh := mul_le_mul_of_nonneg_left ht (abs_nonneg b)
  rw [←abs_mul] at hh
  have hh' : |b*θ| ≤ C := by dsimp [C]; linarith
  obtain ⟨l,u⟩ := abs_le.mp hh'
  dsimp [clipped]
  rcases le_total (a x) (-C) with low|ok
  · rw [min_eq_right (by linarith),max_eq_left low]
    nlinarith only [mul_nonneg (sub_nonneg.mpr low) (by linarith : 0≤2*(b*θ)+C-a x)]
  · rcases le_total (a x) C with mid|hi
    · rw [min_eq_right mid,max_eq_right ok]
    · rw [min_eq_left hi,max_eq_right (by linarith)]
      nlinarith only [mul_nonneg (sub_nonneg.mpr hi) (by linarith : 0≤a x+C-2*(b*θ))]
end
end SequentialRanks
