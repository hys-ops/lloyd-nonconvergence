import SGClosureChart
import ContinuumUniform
import RankTransport

open MeasureTheory Set Filter
open scoped ENNReal
namespace Vortex
noncomputable section
open SequentialRanks

def chartVal (J : Set Space) (x : J) : RankPoint 3 := sgChart x.val

theorem chartVal_embedding {J : Set Space} (mJ : MeasurableSet J) : MeasurableEmbedding (chartVal J) :=
  sgChart.measurableEmbedding.comp (MeasurableEmbedding.subtype_coe mJ)

private theorem map_restr_image {X Z : Type*} [MeasurableSpace X] [MeasurableSpace Z] {f : X → Z}
    (emb : MeasurableEmbedding f) (μ : Measure X) (s : Set X) :
    (μ.restrict s).map f = (μ.map f).restrict (f '' s) := by
  rw [emb.restrict_map,Set.preimage_image_eq _ emb.injective]

theorem chart_body_law {J : Set Space} (W : ProbabilityMeasure J) (d : ℝ≥0∞)
    (unif : (W : Measure J).map Subtype.val = d • volume.restrict J) :
    (W : Measure J).map (chartVal J) = d • (volume : Measure (RankPoint 3)).restrict (sgChart '' J) := by
  change (W : Measure J).map (sgChart ∘ Subtype.val) = _
  rw [← Measure.map_map sgChart.measurable measurable_subtype_coe,unif,
    Measure.map_smul _ sgChart.measurable.aemeasurable,map_restr_image sgChart.measurableEmbedding,
    sgChart_volume.map_eq]

theorem body_density_finite {J : Set Space} (W : ProbabilityMeasure J) (d : ℝ≥0∞)
    (unif : (W : Measure J).map Subtype.val = d • volume.restrict J) : d ≠ ∞ := by
  have h := congrArg (fun m : Measure Space => m univ) unif
  have h' : (1 : ℝ≥0∞) = d*volume J := by
    simpa only [Measure.map_apply measurable_subtype_coe MeasurableSet.univ,preimage_univ,measure_univ,
      Measure.smul_apply,smul_eq_mul,Measure.restrict_apply_univ] using h
  intro hd
  by_cases v : volume J = 0
  · simp [v] at h'
  · simp [hd,ENNReal.top_mul v] at h'

def cellLaw {J : Set Space} (W : ProbabilityMeasure J) (s : Set J) : Measure J :=
  ((W : Measure J) s)⁻¹ • (W : Measure J).restrict s

theorem cell_law_probability {J : Set Space} (W : ProbabilityMeasure J) (s : Set J)
    (pos : 0 < (W : Measure J).real s) : IsProbabilityMeasure (cellLaw W s) where
  measure_univ := by
    have nz : (W : Measure J) s ≠ 0 := (ENNReal.toReal_pos_iff.mp pos).1.ne'
    simp [cellLaw,Measure.smul_apply,ENNReal.inv_mul_cancel nz (measure_ne_top _ _)]

def cellConst {J : Set Space} (W : ProbabilityMeasure J) (d : ℝ≥0∞) (s : Set J) : ℝ :=
  (((W : Measure J) s)⁻¹*d).toReal

def cellDensity {J : Set Space} (W : ProbabilityMeasure J) (d : ℝ≥0∞) (s : Set J) (z : RankPoint 3) : ℝ :=
  (chartVal J '' s).indicator (fun _ => cellConst W d s) z

theorem chart_normalized_cell {J : Set Space} (mJ : MeasurableSet J) (W : ProbabilityMeasure J) (d : ℝ≥0∞)
    (unif : (W : Measure J).map Subtype.val = d • volume.restrict J)
    (s : Set J) (ms : MeasurableSet s) (pos : 0 < (W : Measure J).real s) :
    (cellLaw W s).map (chartVal J) = weighted volume (cellDensity W d s) := by
  let f := chartVal J
  let b := f '' s
  let K := sgChart '' J
  let m : ℝ≥0∞ := (W : Measure J) s
  have mf := chartVal_embedding mJ
  have mb : MeasurableSet b := mf.measurableSet_image.mpr ms
  have sub : b ⊆ K := by rintro _ ⟨x,hx,rfl⟩; exact mem_image_of_mem _ x.property
  have notTop : m⁻¹*d ≠ ∞ := ENNReal.mul_ne_top (ENNReal.inv_ne_top.mpr (ENNReal.toReal_pos_iff.mp pos).1.ne') (body_density_finite W d unif)
  have val (x : RankPoint 3) : ENNReal.ofReal (cellDensity W d s x) = b.indicator (fun _ => m⁻¹*d) x := by
    change ENNReal.ofReal (b.indicator (fun _ => (m⁻¹*d).toReal) x) = _
    by_cases hx : x ∈ b
    · simp only [indicator_of_mem hx,ENNReal.ofReal_toReal notTop]
    · simp only [indicator_of_notMem hx,ENNReal.ofReal_zero]
  unfold cellLaw weighted
  simp_rw [val]
  rw [Measure.map_smul _ mf.measurable.aemeasurable,map_restr_image mf,chart_body_law W d unif,
    Measure.restrict_smul,Measure.restrict_restrict_of_subset sub,smul_smul,withDensity_indicator mb,withDensity_const]

theorem chart_normalized_cell_data {J : Set Space} (mJ : MeasurableSet J) (W : ProbabilityMeasure J) (d : ℝ≥0∞)
    (unif : (W : Measure J).map Subtype.val = d • volume.restrict J)
    (s : Set J) (ms : MeasurableSet s) (pos : 0 < (W : Measure J).real s) :
    Measurable (cellDensity W d s) ∧ (∀ x, 0 ≤ cellDensity W d s x) ∧
    (∀ x, cellDensity W d s x ≤ cellConst W d s) ∧ IsProbabilityMeasure (weighted volume (cellDensity W d s)) ∧
    ∀ᵐ x ∂weighted volume (cellDensity W d s), x ∈ sgChart '' J := by
  have emb := chartVal_embedding mJ
  have prob := cell_law_probability W s pos
  have M := chart_normalized_cell mJ W d unif s ms pos
  refine ⟨measurable_const.indicator (emb.measurableSet_image.mpr ms), ?_, ?_,?_,?_⟩
  · intro x; exact indicator_nonneg (fun _ _ => ENNReal.toReal_nonneg) _
  · intro x; by_cases hx : x ∈ chartVal J '' s
    · simp only [cellDensity,indicator_of_mem hx,le_refl]
    · rw [cellDensity,indicator_of_notMem hx]; exact ENNReal.toReal_nonneg
  · rw [← M]; infer_instance
  · rw [← M]
    apply (ae_map_iff (p := fun x => x ∈ sgChart '' J) emb.measurable.aemeasurable (sgChart.measurableEmbedding.measurableSet_image.mpr mJ)).2
    exact .of_forall fun x => mem_image_of_mem _ x.property

theorem cell_sqrt_scale {J : Set Space} (W : ProbabilityMeasure J) (d : ℝ≥0∞) (fd : d ≠ ∞) (s t : Set J)
    (sp : 0 < (W : Measure J).real s) (tp : 0 < (W : Measure J).real t) :
    ENNReal.ofReal (Real.sqrt ((W : Measure J).real s*(W : Measure J).real t)) *
      ENNReal.ofReal (Real.sqrt (cellConst W d s)*Real.sqrt (cellConst W d t)) = d := by
  let a := (W : Measure J).real s
  let b := (W : Measure J).real t
  have a0 : 0 < a := sp
  have b0 : 0 < b := tp
  have L : cellConst W d s = a⁻¹*d.toReal := by unfold cellConst; rw [ENNReal.toReal_mul,ENNReal.toReal_inv]; rfl
  have R : cellConst W d t = b⁻¹*d.toReal := by unfold cellConst; rw [ENNReal.toReal_mul,ENNReal.toReal_inv]; rfl
  change ENNReal.ofReal (Real.sqrt (a*b))*_ = _
  rw [← ENNReal.ofReal_mul (Real.sqrt_nonneg _),L,R,← Real.sqrt_mul (by positivity : 0 ≤ a⁻¹*d.toReal),
    ← Real.sqrt_mul (mul_nonneg a0.le b0.le)]
  have h : a*b*(a⁻¹*d.toReal*(b⁻¹*d.toReal)) = d.toReal^2 := by field_simp
  rw [h,Real.sqrt_sq ENNReal.toReal_nonneg,ENNReal.ofReal_toReal fd]

end
end Vortex
