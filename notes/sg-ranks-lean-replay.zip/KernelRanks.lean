import CyclicPlans
import Mathlib.Topology.ContinuousMap.SecondCountableSpace

open MeasureTheory ProbabilityTheory Filter Set MeasurableSpace TopologicalSpace Topology
open scoped BoundedContinuousFunction
namespace SequentialRanks
noncomputable section

private theorem continuous_evaluation {Y : Type*} [MetricSpace Y] [CompactSpace Y]
    [MeasurableSpace Y] [BorelSpace Y] (μ : ProbabilityMeasure Y) :
    Continuous (fun f : C(Y,ℝ) => ∫ y, f y ∂(μ : Measure Y)) := by
  apply LipschitzWith.continuous (K := 1)
  apply LipschitzWith.of_dist_le_mul
  intro f g
  have hi (u : C(Y,ℝ)) : Integrable (fun y => u y) (μ : Measure Y) :=
    (integrable_const ‖u‖).mono' u.continuous.aestronglyMeasurable
      (Eventually.of_forall (fun y => u.norm_coe_le_norm y))
  rw [Real.dist_eq,← integral_sub (hi f) (hi g)]
  have h := norm_integral_le_of_norm_le (μ := (μ : Measure Y))
    (f := fun y => f y-g y) (integrable_const (dist f g))
    (Eventually.of_forall (fun y => (ContinuousMap.dist_apply_le_dist (f := f) (g := g) y : dist (f y) (g y) ≤ dist f g)))
  simpa [Real.norm_eq_abs] using h

/-- Countably many continuous expectations identify a probability measure
on a compact metric space, with the weak topology induced by their values. -/
theorem compact_law_code (Y : Type*) [MetricSpace Y] [CompactSpace Y] [SecondCountableTopology Y]
    [MeasurableSpace Y] [BorelSpace Y] :
    ∃ g : ℕ → C(Y,ℝ), IsEmbedding (fun μ : ProbabilityMeasure Y => fun n =>
      ∫ y, g n y ∂(μ : Measure Y)) := by
  let g := denseSeq C(Y,ℝ)
  refine ⟨g,?_⟩
  have hc : Continuous (fun μ : ProbabilityMeasure Y => fun n => ∫ y, g n y ∂(μ : Measure Y)) :=
    continuous_pi (fun n => ProbabilityMeasure.continuous_integral_continuousMap (g n))
  apply (hc.isClosedEmbedding _).isEmbedding
  intro μ ν h
  apply ProbabilityMeasure.toMeasure_injective
  apply ext_of_forall_integral_eq_of_IsFiniteMeasure
  intro f
  have eqn := (denseRange_denseSeq C(Y,ℝ)).equalizer (continuous_evaluation μ)
    (continuous_evaluation ν) (funext (fun n => congrFun h n))
  exact congrFun eqn f.toContinuousMap

private theorem measurable_into_induced {A B C : Type*} [MeasurableSpace A] [TopologicalSpace B]
    [TopologicalSpace C] [MeasurableSpace C] [BorelSpace C] {e : B → C} (he : IsInducing e)
    {f : A → B} (hm : Measurable (e ∘ f)) : @Measurable A B _ (borel B) f := by
  rw [measurable_iff_comap_le] at hm ⊢
  have eqB : borel B = (‹MeasurableSpace C›).comap e := by
    rw [BorelSpace.measurable_eq (α := C), ← borel_comap,← he.eq_induced]
  rwa [eqB, MeasurableSpace.comap_comp]

/-- Start with the actual predictive-law kernel. The admissible source set may
have its relative topology, without any global Borel-set assumption on its image. -/
theorem kernel_conditional_ranks {H Y K : Type*} [MeasurableSpace H]
    [MetricSpace Y] [MeasurableSpace Y] [BorelSpace Y] [CompactSpace Y] [SecondCountableTopology Y]
    [MetricSpace K] [MeasurableSpace K] [BorelSpace K] [CompactSpace K] [SecondCountableTopology K]
    [Nonempty K] [StandardBorelSpace K] [CountableOrCountablyGenerated H Y]
    (P : Kernel H Y) [IsMarkovKernel P] (target : ProbabilityMeasure K)
    (c : Y × K → ℝ) (hc : Continuous c) {d : ℕ} (coord : K → Fin d → ℝ) (hm : Measurable coord)
    (R : ℝ) (bound : ∀ k, normSq (coord k) ≤ R^2)
    (uniquePlan : ∀ h, ∃! π, certifiedPlan c ⟨P h,inferInstance⟩ target π)
    (monge : ∀ h, ∃ f : Y → K, Measurable f ∧
      certifiedPlan c ⟨P h,inferInstance⟩ target
        (ProbabilityMeasure.map (⟨P h,inferInstance⟩ : ProbabilityMeasure Y) (fun y => (y,f y)))) :
    ∃ S : H × Y → Fin d → ℝ, Measurable S ∧ (∀ z, normSq (S z) ≤ R^2) ∧
      ∀ h, ∃ π : ProbabilityMeasure (Y × K), certifiedPlan c ⟨P h,inferInstance⟩ target π ∧
        (P h).map (fun y => (y,S (h,y))) = (π : Measure (Y × K)).map (fun z => (z.1,coord z.2)) := by
  classical
  let src (h : H) : ProbabilityMeasure Y := ⟨P h,inferInstance⟩
  let D := Set.range src
  let law (h : H) : D := ⟨src h,mem_range_self h⟩
  let _ : MeasurableSpace D := borel D
  let _ : BorelSpace D := ⟨rfl⟩
  obtain ⟨g,hg⟩ := compact_law_code Y
  have hcode (n : ℕ) : Measurable (fun h => ∫ y, g n y ∂P h) :=
    ((g n).continuous.stronglyMeasurable.integral_kernel).measurable
  have lawMeas : Measurable law :=
    measurable_into_induced (hg.isInducing.comp (show IsInducing (Subtype.val : D → ProbabilityMeasure Y) from ⟨rfl⟩))
      (measurable_pi_iff.mpr hcode)
  have uniqueD (ℓ : D) : ∃! π, certifiedPlan c ℓ.1 target π := by
    obtain ⟨h,hh⟩ := ℓ.property; rw [← hh]; exact uniquePlan h
  obtain ⟨π,cont,cert⟩ := continuous_cyclic_selector c hc (Subtype.val : D → ProbabilityMeasure Y)
    continuous_subtype_val target uniqueD
  obtain ⟨S,ms,ball,realizes⟩ := conditional_ranks_of_stable_plans law lawMeas π cont.isClosed_graph coord hm R
  refine ⟨S,ms,ball,fun h => ⟨π (law h),cert (law h),?_⟩⟩
  obtain ⟨f,hf,hfplan⟩ := monge h
  have pi_eq : π (law h) = ProbabilityMeasure.map (src h) (fun y => (y,f y)) :=
    (uniquePlan h).unique (cert (law h)) hfplan
  have graphLaw : (π (law h) : Measure (Y × K)) = (P h).map (fun y => (y,f y)) :=
    congrArg ProbabilityMeasure.toMeasure pi_eq
  have ae := realizes h (P h) f hf graphLaw (Eventually.of_forall (fun y => bound (f y)))
  have mF : Measurable (fun y : Y => (y,f y)) := measurable_id.prodMk hf
  have mC : Measurable (fun z : Y × K => (z.1,coord z.2)) := measurable_fst.prodMk (hm.comp measurable_snd)
  rw [graphLaw,Measure.map_map mC mF]
  exact Measure.map_congr (ae.mono fun y hy => by simp [Function.comp_apply,hy])
end
end SequentialRanks
