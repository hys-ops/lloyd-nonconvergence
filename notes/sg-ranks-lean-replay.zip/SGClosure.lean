import SGClosureData
import WeakTimeBounds
import ContinuumPhysical

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Static quadratic transport for a current patch. The geometric uniqueness clause
compares *plans*, not just costs or coordinates. Each marginal is explicitly normalized.
The minimizing clause is written in the equal-mass unnormalized convention used by
the dynamical torque lemma. -/
structure CurrentBrenier (D : Set Space) (T : ProbabilityMeasure D) (A : Set Space)
    (d : ℝ≥0) (mass : (d : ℝ≥0∞)*volume A=1) (U : Space → D) : Prop where
  measurable : Measurable U
  pushes : (patchProbability A d mass : Measure Space).map (fun y => (U y).val)
      = (T : Measure D).map Subtype.val
  minimizes : ∀ F : Space → Space, Measurable F →
    (volume.restrict A).map F = (d : ℝ≥0∞)⁻¹ • (T : Measure D).map Subtype.val →
    IntegrableOn (fun y => quadraticCost y (F y)) A →
    (∫ y in A, quadraticCost y (U y).val) ≤ ∫ y in A, quadraticCost y (F y)
  cyclic_unique : ∀ η, SequentialRanks.certifiedPlan (physicalCost D) (patchProbability A d mass) T η →
    η = (patchProbability A d mass).map (fun y => (y,U y))

/-- Static quadratic transport for the comparison patch. Equality at the minimum
identifies conjugate Monge maps, while the cyclic-plan clause identifies the continuous
limit of the finite cells. -/
structure ReferenceBrenier (D : Set Space) (T : ProbabilityMeasure D) (B : Set Space)
    (d : ℝ≥0) (mass : (d : ℝ≥0∞)*volume B=1) (V : Space → D) : Prop where
  measurable : Measurable V
  uniqueMap : UniqueMongeMap (volume.restrict B) ((d : ℝ≥0∞)⁻¹ • (T : Measure D).map Subtype.val)
    (fun y => (V y).val)
  cyclic_unique : ∀ η, SequentialRanks.certifiedPlan (physicalCost D) (patchProbability B d mass) T η →
    η = (patchProbability B d mass).map (fun y => (y,V y))

/-- A single bounded-time-interval version of both conclusions in the SG note.
The hypotheses after the distributional equation are static Brenier and finite
power-cell inputs only. The continuum endpoint, all time traces, both conservation
laws, and every ancillary integrability used by the overlap restriction are derived.
The vertical support interval may have zero width. -/
theorem sg_overlap_and_stationarity (E0 : Set Space) (E : ℝ → Set Space) (D : Set Space)
    [CompactSpace D] (target : ProbabilityMeasure D)
    (md : MeasurableSet D) (bodySymm : ∀ θ y, rotateMap θ y ∈ D ↔ y∈D) (c : ℝ≥0∞)
    (uniform : (target : Measure D).map Subtype.val = c • volume.restrict D)
    (d : ℝ≥0) (hd : 0<d) (T a b R Ht : ℝ) (ht : 0≤T) (hab : a≤b)
    (U : ℝ → Space → D) (V : Space → D)
    (me0 : MeasurableSet E0) (mass0 : (d : ℝ≥0∞)*volume E0=1)
    (slab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z)=0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity (fun t y => (U t y).val)) (occupation E T))
    (mass : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*volume (E t)=1)
    (M : ℝ≥0) (moment0 : (d : ℝ≥0∞)*(∫⁻ y in E0, ‖y‖ₑ^2)≤M)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*(∫⁻ y in E t, ‖y‖ₑ^2)≤M)
    (sol : RenormalizedPatch E0 E T d (flowVelocity (fun t y => (U t y).val)))
    (cur : ∀ᵐ t ∂volume.restrict (Icc 0 T), ∀ m : (d : ℝ≥0∞)*volume (E t)=1,
      CurrentBrenier D target (E t) d m (U t) ∧ PowerRealization D target (patchProbability (E t) d m))
    (ref : ∀ m : (d : ℝ≥0∞)*volume (circular E0)=1,
      ReferenceBrenier D target (circular E0) d m V ∧ PowerRealization D target (patchProbability (circular E0) d m))
    (finite : StretchedFiniteTool D target R Ht) :
    (∀ t : ℝ, 0≤t → WeakPatchEquation (circular E0) (fun _ => circular E0) t d
      (fun s => vel s.2.1 (V s.2).val.1)) ∧
    ∀ᵐ t ∂volume.restrict (Icc 0 T),
      (d:ℝ)*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y).val.1) (vel y.1 (V y).val.1)) ≤
        4*R^2*Real.sqrt (Real.pi*d*(b-a)*impulse E0 (circular E0) d) := by
  let S := fun t y => (U t y).val
  let B := circular E0
  let raw := (d : ℝ≥0∞)⁻¹ • (target : Measure D).map Subtype.val
  have rawEq : raw = ((d : ℝ≥0∞)⁻¹*c) • volume.restrict D := by unfold raw; rw [uniform,smul_smul]
  have f0 := finite_of_patch_mass E0 d hd mass0
  have mb := measurable_circular E0 me0
  have eqB := circular_volume_eq E0 me0 f0
  have massB : (d : ℝ≥0∞)*volume B=1 := by simpa [B,eqB] using mass0
  obtain ⟨reference,cellsB⟩ := ref massB
  have body := symmetric_body_marginals D md bodySymm
  have orbit (θ : ℝ) : raw.map (rotateMap θ)=raw := by
    rw [rawEq,Measure.map_smul _ (body.1 θ).measurable.aemeasurable,(body.1 θ).map_eq]
  have hcompact : IsCompact D := isCompact_iff_compactSpace.mpr inferInstance
  obtain ⟨r,rr⟩ := hcompact.bddAbove_image continuous_norm.continuousOn
  let K := r.toNNReal
  have kb (y : Space) (hy : y∈D) : ‖y‖ ≤ K := (rr (mem_image_of_mem _ hy)).trans (Real.le_coe_toNNReal r)
  have hb (y : Space) (hy : y∈D) : ‖y.1‖ ≤ (K:ℝ) := (norm_fst_le _).trans (kb y hy)
  have radius : ∀ᵐ x ∂raw, ‖x‖ ≤ (K:ℝ) := by
    rw [rawEq]; exact Measure.ae_smul_measure ((ae_restrict_mem md).mono kb) _
  have hρ : 0<(d : ℝ) := hd
  have optimal : ∀ᵐ t ∂volume.restrict (Icc 0 T), SymmetricMonge (volume.restrict (E t)) raw (S t) := by
    filter_upwards [mass,cur] with t mt hc
    have u := (hc mt).1
    have ms : Measurable (S t) := measurable_subtype_coe.comp u.measurable
    exact ⟨ms,raw_push_of_probability (E t) d hd mt _ _ ms u.pushes,orbit,u.minimizes⟩
  have bounds := patch_dynamic_bounds E0 E T d ht hρ S raw K M me0
    (by simpa using mass0) (by simpa using moment0) moving mw (by simpa using mass)
    (by simpa using moment) radius optimal sol
  constructor
  · intro s hs
    apply stationary_reference E0 D me0 f0 md bodySymm K hb ((d : ℝ≥0∞)⁻¹*c) (fun y => (V y).val) _ s d hs
    simpa only [← rawEq] using reference.uniqueMap
  apply overlap_from_weak_patch (Icc 0 T) E0 E (fun t y => (S t y).1) (fun y => (V y).val.1)
    (flowVelocity S) d R a b hρ hab
  filter_upwards [bounds,mass,cur] with t bd mt hc
  obtain ⟨u,cellsE⟩ := hc mt
  have mEt : MeasurableSet (E t) := moving.preimage (measurable_const.prodMk measurable_id)
  have imB := circular_radial_integrable E0 me0 f0 bd.momentInitial
  have di := patch_difference_integrals (E t) B mEt mb bd.finiteCurrent (eqB ▸ f0) d bd.momentNow imB
  have ui : Measurable (fun y => (U t y).val.1) := measurable_fst.comp (measurable_subtype_coe.comp u.measurable)
  have vi : Measurable (fun y => (V y).val.1) := measurable_fst.comp (measurable_subtype_coe.comp reference.measurable)
  have fi := patch_flux_integrals (E t) B mEt mb bd.finiteCurrent (eqB ▸ f0) d K hρ _ _ ui vi
    (ae_of_all _ (fun y => hb _ (U t y).property)) (ae_of_all _ (fun y => hb _ (V y).property))
  have ep := physical_horizontal_endpoint D (patchProbability _ _ mt) (patchProbability _ _ massB) target
    (patchNN (E t) d) (patchNN B d) (patchNN_measurable _ mEt d) (patchNN_measurable _ mb d)
    (patchProbability_density _ mEt d mt) (patchProbability_density _ mb d massB)
    (U t) V u.measurable reference.measurable u.cyclic_unique reference.cyclic_unique R Ht cellsE cellsB finite
  simp only [patchNN_toReal,discr] at ep
  exact ⟨⟨bd.timeNonneg,moving,me0,bd.finiteCurrent,bd.finiteInitial,bd.velocityInt,bd.weakEq,
    bd.sliceMoment,slab,di.1,di.2,fi.1,fi.2,ep⟩,excess_of_radial_conservation E0 (E t) B d
    me0 mEt bd.momentInitial bd.momentNow di.2 bd.sameRadial⟩
end
end Vortex
