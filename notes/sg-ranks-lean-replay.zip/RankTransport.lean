import Ranks
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.InformationTheory.KullbackLeibler.ChainRule

open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section
def weighted {X : Type*} [MeasurableSpace X] (μ : Measure X) (f : X → ℝ) :=
  μ.withDensity (fun x => ENNReal.ofReal (f x))

private theorem weighted_test {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    (μ : Measure X) (w : X → ℝ) (F : X → Y) (g : Y → ℝ) (hw : Measurable w)
    (hn : ∀ x, 0 ≤ w x) (hF : Measurable F) (hg : Measurable g) :
    (∫ x, w x*g (F x) ∂μ) = ∫ y, g y ∂(weighted μ w).map F := by
  rw [integral_map hF.aemeasurable hg.aestronglyMeasurable]
  unfold weighted
  symm
  simpa only [ENNReal.toReal_ofReal (hn _),smul_eq_mul] using
    (integral_withDensity_eq_integral_toReal_smul (μ := μ) (f := fun x => ENNReal.ofReal (w x))
      (ENNReal.measurable_ofReal.comp hw) (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)
      (fun x => g (F x)))

/-- Full loss-to-Hellinger implication for Lebesgue densities (or any base μ).
The geometric external input is exactly the domination of the rs-weighted midpoint pushforward. -/
theorem rank_from_pushforwards {X : Type*} [MeasurableSpace X] (μ : Measure X)
    {d : ℕ} (ρ : Measure (Fin d → ℝ)) (R : ℝ) (p q : X → ℝ) (U V : X → Fin d → ℝ)
    (hp : Measurable p) (hq : Measurable q) (pn : ∀ x, 0 ≤ p x) (qn : ∀ x, 0 ≤ q x)
    (hU : Measurable U) (hV : Measurable V)
    (ub : ∀ᵐ x ∂μ, normSq (U x) ≤ R^2) (vb : ∀ᵐ x ∂μ, normSq (V x) ≤ R^2)
    (refball : ∀ᵐ y ∂ρ, normSq y ≤ R^2) (igap : Integrable (gap R) ρ)
    (pu : (weighted μ p).map U = ρ) (qv : (weighted μ q).map V = ρ)
    (mid_dom : (weighted μ (fun x => Real.sqrt (p x)*Real.sqrt (q x))).map
       (fun x => mid (U x) (V x)) ≤ ρ)
    (iL : Integrable (fun x => p x*normSq (diff (U x) (V x))) μ)
    (iH : Integrable (fun x => (Real.sqrt (p x)-Real.sqrt (q x))^2) μ)
    (iM : Integrable (fun x => 2*Real.sqrt (p x)*Real.sqrt (q x)*gap R (mid (U x) (V x))) μ)
    (iu : Integrable (fun x => p x*gap R (U x)) μ)
    (iv : Integrable (fun x => q x*gap R (V x)) μ) :
    (∫ x, p x * normSq (diff (U x) (V x)) ∂μ) ≤
    16*R^2*∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2 ∂μ := by
  have hg : Measurable (gap R : (Fin d → ℝ) → ℝ) := by unfold gap normSq; fun_prop
  have hm : Measurable (fun x => mid (U x) (V x)) := by unfold mid; fun_prop
  have eu := weighted_test μ p U (gap R) hp pn hU hg
  have ev := weighted_test μ q V (gap R) hq qn hV hg
  rw [pu] at eu
  rw [qv] at ev
  have em := weighted_test μ (fun x => Real.sqrt (p x)*Real.sqrt (q x))
    (fun x => mid (U x) (V x)) (gap R) (by fun_prop)
    (fun x => mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)) hm hg
  have mm := integral_mono_measure mid_dom (show 0 ≤ᵐ[ρ] gap R by
    filter_upwards [refball] with x hx; exact sub_nonneg.mpr hx) igap
  rw [← em] at mm
  have eo : (∫ x, 2*Real.sqrt (p x)*Real.sqrt (q x)*gap R (mid (U x) (V x)) ∂μ) =
      2*(∫ x, (Real.sqrt (p x)*Real.sqrt (q x))*gap R (mid (U x) (V x)) ∂μ) := by
    simp_rw [mul_assoc]; rw [integral_const_mul]
  have ht := rank_from_midpoint_test μ R (fun x => Real.sqrt (p x)) (fun x => Real.sqrt (q x))
    U V ub vb (by simpa only [Real.sq_sqrt (pn _)] using iL) iH iM
    (by simpa only [Real.sq_sqrt (pn _)] using iu)
    (by simpa only [Real.sq_sqrt (qn _)] using iv)
    (by simp only [Real.sq_sqrt (pn _),Real.sq_sqrt (qn _)]; linarith)
  simpa only [Real.sq_sqrt (pn _)] using ht

end
end SequentialRanks
