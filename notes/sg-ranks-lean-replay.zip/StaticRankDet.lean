import Mathlib.Analysis.Matrix.Order
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

open Matrix
open scoped BigOperators MatrixOrder
namespace SequentialRanks
noncomputable section

private theorem unit_mid_det {n : Type*} [Fintype n] [DecidableEq n]
    {D : Matrix n n ℝ} (hD : D.PosSemidef) :
    Real.sqrt D.det ≤ ((1/2:ℝ) • (1+D)).det := by
  let v := hD.isHermitian.eigenvalues
  let T := Unitary.conjStarAlgAut ℝ _ hD.isHermitian.eigenvectorUnitary
  have decomp : D = T (diagonal v) := hD.isHermitian.spectral_theorem
  have ha : (1/2:ℝ) • (1 + D) = T (diagonal (fun i => (1+v i)/2)) := by
    have h : diagonal (fun i => (1+v i)/2) = (1/2:ℝ) • (1 + diagonal v) := by
      ext i j
      by_cases h : i=j
      · subst j; simp [Matrix.smul_apply]; ring
      · simp [Matrix.one_apply_ne h,Matrix.smul_apply, h]
    rw [h,map_smul,map_add,map_one,← decomp]
  rw [ha,hD.isHermitian.det_eq_prod_eigenvalues]
  change Real.sqrt (∏ i, v i) ≤ (T (diagonal (fun i => (1+v i)/2))).det
  rw [Real.sqrt_prod _ (fun i _ => hD.eigenvalues_nonneg i)]
  have hd : (T (diagonal (fun i => (1+v i)/2))).det = ∏ i, (1+v i)/2 := by
    simp [T, -Unitary.conjStarAlgAut_apply]
  rw [hd]
  apply Finset.prod_le_prod₀ (fun i _ => Real.sqrt_nonneg _) (fun i _ => ?_)
  nlinarith only [sq_nonneg (Real.sqrt (v i)-1),Real.sq_sqrt (hD.eigenvalues_nonneg i)]

/-- Geometric mean of the endpoint determinants is dominated by the determinant
of the arithmetic mean, including positive semidefinite singular endpoints. -/
theorem determinant_midpoint {n : Type*} [Fintype n] [DecidableEq n]
    {A B : Matrix n n ℝ} (ha : A.PosSemidef) (hb : B.PosSemidef) :
    Real.sqrt A.det * Real.sqrt B.det ≤ ((1/2:ℝ) • (A+B)).det := by
  by_cases hz : A.det = 0
  · rw [hz,Real.sqrt_zero,zero_mul,Matrix.det_smul]
    exact mul_nonneg (pow_nonneg (by norm_num) _) (ha.add hb).det_nonneg
  let X := CFC.sqrt A
  have xx : X*X = A := by simpa [X,pow_two] using CFC.sq_sqrt (a := A) ha.nonneg
  have xH : X.IsHermitian := (CFC.sqrt_nonneg A).posSemidef.isHermitian
  have invH : X⁻¹.IsHermitian := xH.inv
  have xd : X.det * X.det = A.det := by rw [← Matrix.det_mul,xx]
  have unit : IsUnit X.det := isUnit_iff_ne_zero.mpr (fun h => hz (by simpa [h,eq_comm] using xd))
  let D := X⁻¹ * B * X⁻¹
  have hd : D.PosSemidef := by simpa only [D,invH.eq] using hb.conjTranspose_mul_mul_same X⁻¹
  have b_eq : X*D*X = B := by
    simp only [D,← Matrix.mul_assoc, Matrix.mul_nonsing_inv X unit,Matrix.one_mul,
      Matrix.nonsing_inv_mul_cancel_right X B unit]
  have both : X*((1/2:ℝ) • (1+D))*X = (1/2:ℝ) • (A+B) := by
    rw [Matrix.mul_smul,Matrix.smul_mul,Matrix.mul_add,Matrix.add_mul,Matrix.mul_one,xx,b_eq]
  have db : X.det * D.det * X.det = B.det := by rw [← Matrix.det_mul,← Matrix.det_mul,b_eq]
  have dab : X.det * ((1/2:ℝ) • (1+D)).det * X.det = ((1/2:ℝ) • (A+B)).det := by
    rw [← Matrix.det_mul,← Matrix.det_mul,both]
  have da : B.det = A.det * D.det := by rw [← db,← xd]; ring
  have h := mul_le_mul_of_nonneg_left (unit_mid_det hd) ha.det_nonneg
  rw [da,Real.sqrt_mul ha.det_nonneg,← mul_assoc, Real.mul_self_sqrt ha.det_nonneg,← dab,← xd] at *
  linarith only [h]
end
end SequentialRanks
