import SquarePolicies
import MinimaxLowerIID
open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def SquarePolicy := {A : (n : ℕ) → Past n × SquareObs → SquareObs // ∀ n, Measurable (A n)}
def squareMinimaxRisk (T : ℕ) : ℝ≥0∞ :=
  ⨅ A : SquarePolicy, ⨆ θ : parameterInterval,
    ∑ n ∈ Finset.range T, iidDayRisk n (A.val n) θ.val

/-- Two-sided minimax guarantee in one statistical experiment. Its rank target
is the explicit unique optimal square map, as proved by squareRank_pushforward
and squareRank_unique_optimum. Histories and estimators coincide in both bounds. -/
theorem square_iid_minimax (T : ℕ) :
    ENNReal.ofReal ((1/(8*Real.pi^2))*∑ n ∈ Finset.range T, 1/(4*Real.pi^2+16*(n:ℝ)))
      ≤ squareMinimaxRisk T ∧
    squareMinimaxRisk T ≤ ENNReal.ofReal ((8/Real.pi^2)*(1+Real.log T)) := by
  constructor
  · exact le_iInf (fun A => minimax_iid_lower T A.val A.property)
  · let policy : SquarePolicy := ⟨iidClippedPolicy,(iid_clipped_upper T).1⟩
    apply (iInf_le (fun A : SquarePolicy => ⨆ θ : parameterInterval,
      ∑ n ∈ Finset.range T, iidDayRisk n (A.val n) θ.val) policy).trans
    exact iSup_le (fun θ => (iid_clipped_upper T).2 θ.val (abs_le.mpr θ.property))

theorem square_iid_minimax_log (T : ℕ) :
    ENNReal.ofReal (Real.log (1+4*(T:ℝ)/Real.pi^2)/(128*Real.pi^2)) ≤ squareMinimaxRisk T ∧
      squareMinimaxRisk T ≤ ENNReal.ofReal ((24/Real.pi^2)*Real.log (1+(T:ℝ))) := by
  have bracket := square_iid_minimax T
  refine ⟨(ENNReal.ofReal_le_ofReal (lower_log_sum T)).trans bracket.1,?_⟩
  rcases T with _|n
  · let _ : Nonempty SquarePolicy := ⟨⟨iidClippedPolicy,(iid_clipped_upper 0).1⟩⟩
    simp [squareMinimaxRisk]
  · apply bracket.2.trans
    apply ENNReal.ofReal_le_ofReal
    have a : (1:ℝ) ≤ (n.succ:ℝ) := by exact_mod_cast Nat.succ_le_succ (Nat.zero_le n)
    have b : (2:ℝ) ≤ 1+(n.succ:ℝ) := by linarith
    have c := Real.log_le_log (by norm_num : 0 < (2:ℝ)) b
    have d := Real.one_sub_inv_le_log_of_pos (by norm_num : 0 < (2:ℝ))
    have e := Real.log_le_log (by linarith : (0:ℝ)<n.succ) (show (n.succ:ℝ) ≤ 1+(n.succ:ℝ) by linarith)
    have h : 1 + Real.log (n.succ:ℝ) ≤ 3*Real.log (1+(n.succ:ℝ)) := by norm_num at d; linarith
    calc
      _ ≤ (8/Real.pi^2)*(3*Real.log (1+(n.succ:ℝ))) := mul_le_mul_of_nonneg_left h (by positivity)
      _ = _ := by ring

end
end SequentialRanks
