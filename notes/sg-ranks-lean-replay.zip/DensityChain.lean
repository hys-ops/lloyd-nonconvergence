import RankPath

open MeasureTheory
open scoped BigOperators
namespace SequentialRanks
noncomputable section

def klTerm (p q : ℝ) : ℝ := p*Real.log (p/q)

/-- Finite-KL density factorization. Zero true density contributes zero. -/
theorem factor_log (p q a b : ℝ) (hp : 0 ≤ p) (ha : 0 ≤ a)
    (hac : 0 < p → 0 < q) (hab : 0 < p → 0 < a → 0 < b) :
    klTerm (p*a) (q*b) = klTerm p q*a+p*klTerm a b := by
  rcases eq_or_lt_of_le hp with h|hp
  · simp [← h,klTerm]
  rcases eq_or_lt_of_le ha with h|ha
  · simp [← h,klTerm]
  have hq := hac hp
  have hb := hab hp ha
  unfold klTerm
  rw [show p*a/(q*b)=(p/q)*(a/b) by ring,
    Real.log_mul (div_pos hp hq).ne' (div_pos ha hb).ne']
  ring

/-- Finite-entropy chain rule for one genuine history/observation product space.
The conditional densities may depend on the entire history. -/
theorem density_chain {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    (μ : Measure H) (ν : Measure Y) [SFinite μ] [SFinite ν]
    (p q : H → ℝ) (a b : H → Y → ℝ)
    (support : ∀ᵐ z ∂μ.prod ν, 0 ≤ p z.1 ∧ 0 ≤ a z.1 z.2 ∧
      (0 < p z.1 → 0 < q z.1) ∧ (0 < p z.1 → 0 < a z.1 z.2 → 0 < b z.1 z.2))
    (mass : ∀ᵐ x ∂μ, (∫ y, a x y ∂ν)=1)
    (pastInt : Integrable (fun z : H × Y => klTerm (p z.1) (q z.1)*a z.1 z.2) (μ.prod ν))
    (nextInt : Integrable (fun z : H × Y => p z.1*klTerm (a z.1 z.2) (b z.1 z.2)) (μ.prod ν)) :
    (∫ z, klTerm (p z.1*a z.1 z.2) (q z.1*b z.1 z.2) ∂μ.prod ν) =
      (∫ x, klTerm (p x) (q x) ∂μ) + ∫ x, p x*(∫ y, klTerm (a x y) (b x y) ∂ν) ∂μ := by
  rw [integral_congr_ae (Filter.Eventually.mono support (fun z h =>
    factor_log _ _ _ _ h.1 h.2.1 h.2.2.1 h.2.2.2)),
    integral_add pastInt nextInt,integral_prod _ pastInt,integral_prod _ nextInt]
  congr 1
  · apply integral_congr_ae
    filter_upwards [mass] with x hx
    rw [integral_const_mul,hx,mul_one]
  · apply integral_congr_ae
    filter_upwards with x
    rw [integral_const_mul]

/-- Expected one-step rank loss with the same present observation.
Combine with density_chain to obtain the finite-KL path increment. -/
theorem conditional_rank_step {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    (μ : Measure H) (ν : Measure Y) [SFinite μ] [SFinite ν] (R : ℝ)
    (p : H → ℝ) (a b loss : H → Y → ℝ)
    (pn : ∀ᵐ x ∂μ, 0 ≤ p x)
    (one : ∀ᵐ x ∂μ, (∫ y, a x y*loss x y ∂ν) ≤ 16*R^2*∫ y, klTerm (a x y) (b x y) ∂ν)
    (jointInt : Integrable (fun z : H × Y => p z.1*(a z.1 z.2*loss z.1 z.2)) (μ.prod ν))
    (nextInt : Integrable (fun x => p x*(∫ y, klTerm (a x y) (b x y) ∂ν)) μ) :
    (∫ z, p z.1*(a z.1 z.2*loss z.1 z.2) ∂μ.prod ν) ≤
      16*R^2*(∫ x, p x*(∫ y, klTerm (a x y) (b x y) ∂ν) ∂μ) := by
  rw [integral_prod _ jointInt,← integral_const_mul]
  apply integral_mono_ae jointInt.integral_prod_left (nextInt.const_mul _)
  filter_upwards [pn,one] with x hp hx
  rw [integral_const_mul]
  calc
    _ ≤ p x*(16*R^2*∫ y, klTerm (a x y) (b x y) ∂ν) := mul_le_mul_of_nonneg_left hx hp
    _ = _ := by ring

/-- A single history extension of the rank-risk theorem. The right hand side is
the difference of two actual integrals for the joint and past path densities. -/
theorem rank_extension {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    (μ : Measure H) (ν : Measure Y) [SFinite μ] [SFinite ν] (R : ℝ)
    (p q : H → ℝ) (a b loss : H → Y → ℝ) (pn : ∀ᵐ x ∂μ, 0 ≤ p x)
    (support : ∀ᵐ z ∂μ.prod ν, 0 ≤ p z.1 ∧ 0 ≤ a z.1 z.2 ∧
      (0 < p z.1 → 0 < q z.1) ∧ (0 < p z.1 → 0 < a z.1 z.2 → 0 < b z.1 z.2))
    (mass : ∀ᵐ x ∂μ, (∫ y, a x y ∂ν)=1)
    (one : ∀ᵐ x ∂μ, (∫ y, a x y*loss x y ∂ν) ≤ 16*R^2*∫ y, klTerm (a x y) (b x y) ∂ν)
    (jointInt : Integrable (fun z : H × Y => p z.1*(a z.1 z.2*loss z.1 z.2)) (μ.prod ν))
    (pastInt : Integrable (fun z : H × Y => klTerm (p z.1) (q z.1)*a z.1 z.2) (μ.prod ν))
    (nextInt : Integrable (fun z : H × Y => p z.1*klTerm (a z.1 z.2) (b z.1 z.2)) (μ.prod ν)) :
    (∫ z, p z.1*(a z.1 z.2*loss z.1 z.2) ∂μ.prod ν) ≤
      16*R^2*((∫ z, klTerm (p z.1*a z.1 z.2) (q z.1*b z.1 z.2) ∂μ.prod ν)-
        ∫ x, klTerm (p x) (q x) ∂μ) := by
  rw [density_chain μ ν p q a b support mass pastInt nextInt,add_sub_cancel_left]
  apply conditional_rank_step μ ν R p a b loss pn one jointInt
  simpa only [integral_const_mul] using nextInt.integral_prod_left

/-- Expected loss cap for arbitrary ball-valued maps under a probability density. -/
theorem ball_risk_cap {Y : Type*} [MeasurableSpace Y] (ν : Measure Y) {d : ℕ} (R : ℝ)
    (p : Y → ℝ) (u v : Y → Fin d → ℝ) (hp : ∀ᵐ y ∂ν, 0 ≤ p y)
    (ub : ∀ᵐ y ∂ν, normSq (u y) ≤ R^2) (vb : ∀ᵐ y ∂ν, normSq (v y) ≤ R^2)
    (ip : Integrable p ν) (mass : (∫ y, p y ∂ν)=1)
    (il : Integrable (fun y => p y*normSq (diff (u y) (v y))) ν) :
    (∫ y, p y*normSq (diff (u y) (v y)) ∂ν) ≤ 4*R^2 := by
  have point (x y : Fin d → ℝ) : normSq (diff x y) ≤ 2*(normSq x+normSq y) := by
    have h := Finset.sum_le_sum (s := Finset.univ) (fun (i : Fin d) _ =>
      show (x i-y i)^2 ≤ 2*((x i)^2+(y i)^2) by nlinarith only [sq_nonneg (x i+y i)])
    simpa only [Finset.sum_add_distrib,← Finset.mul_sum,normSq,diff] using h
  calc
    _ ≤ ∫ y, p y*(4*R^2) ∂ν := by
      apply integral_mono_ae il (ip.mul_const _)
      filter_upwards [hp,ub,vb] with y py ux vx
      exact mul_le_mul_of_nonneg_left (by linarith [point (u y) (v y)]) py
    _ = _ := by rw [integral_mul_const,mass,one_mul]

/-- Telescoping the rank-loss increments along any finite density-factorized path. -/
theorem rank_path_increments (T : ℕ) (R : ℝ) (risk pathKL : ℕ → ℝ)
    (empty : pathKL 0=0)
    (inc : ∀ t < T, risk t ≤ 16*R^2*(pathKL (t+1)-pathKL t)) :
    ∑ t ∈ Finset.range T, risk t ≤ 16*R^2*pathKL T := by
  calc
    _ ≤ ∑ t ∈ Finset.range T, 16*R^2*(pathKL (t+1)-pathKL t) :=
      Finset.sum_le_sum (fun t ht => inc t (Finset.mem_range.mp ht))
    _ = _ := by rw [← Finset.mul_sum,Finset.sum_range_sub,empty,sub_zero]
end
end SequentialRanks
