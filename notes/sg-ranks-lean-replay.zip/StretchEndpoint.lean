import PublishedSG

open MeasureTheory Set Filter
open scoped Topology
namespace Vortex
noncomputable section

/-- Verbatim proof of the scalar limit from the archived SGVerification.Horizontal module. -/
theorem drop_vertical_radius {F D R H : ℝ}
    (hall : ∀ e : ℝ, 0 < e → F ≤ (R^2 + e^2*H^2)*D) : F ≤ R^2*D := by
  have ht : Tendsto (fun e : ℝ => (R^2 + e^2*H^2)*D) (𝓝[>] 0) (𝓝 (R^2*D)) := by
    have h : ContinuousAt (fun e : ℝ => (R^2 + e^2*H^2)*D) 0 := by fun_prop
    simpa using h.continuousWithinAt.tendsto (s := Ioi 0)
  apply le_of_tendsto_of_tendsto tendsto_const_nhds ht
  filter_upwards [self_mem_nhdsWithin] with e he
  exact hall e he

/-- Weighted three-dimensional flux after stretching the maps' vertical
components by e. The horizontal squared norm is the same as in flux. -/
def stretchedFlux (e p q : ℝ) (U V : H) (u v : ℝ) : ℝ :=
  ((p*U.1-q*V.1)^2 + (p*U.2-q*V.2)^2 + (p*(e*u)-q*(e*v))^2)/(p+q)

def discr (p q : ℝ) : ℝ := (p-q)^2/(p+q)

theorem endpoint_of_stretches {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (p q : X → ℝ) (U V : X → H) (u v : X → ℝ) (R Ht : ℝ)
    (hn : ∀ᵐ x ∂μ, 0 ≤ p x + q x)
    (higher : ∀ e : ℝ, 0 < e →
      Integrable (fun x => stretchedFlux e (p x) (q x) (U x) (V x) (u x) (v x)) μ ∧
      (∫ x, stretchedFlux e (p x) (q x) (U x) (V x) (u x) (v x) ∂μ) ≤
        (R^2+e^2*Ht^2)*(∫ x, discr (p x) (q x) ∂μ)) :
    (∫ x, flux (p x) (q x) (U x) (V x) ∂μ) ≤ R^2*(∫ x, discr (p x) (q x) ∂μ) := by
  apply drop_vertical_radius (H := Ht)
  intro e he
  apply le_trans _ (higher e he).2
  apply integral_mono_of_nonneg _ (higher e he).1
  · filter_upwards [hn] with x h
    exact div_le_div_of_nonneg_right (le_add_of_nonneg_right (sq_nonneg _)) h
  · filter_upwards [hn] with x h
    exact div_nonneg (add_nonneg (sq_nonneg _) (sq_nonneg _)) h

/-- Alternative entry point at the continuum three-dimensional OT interface. -/
theorem published_from_stretches (times : Set ℝ) (E0 : Set Space)
    (E : ℝ → Set Space) (U : ℝ → Space → H) (V : Space → H)
    (u : ℝ → Space → ℝ) (v : Space → ℝ) (ρ R Ht a b : ℝ)
    (hρ : 0 < ρ) (hab : a ≤ b)
    (h : ∀ᵐ t ∂volume.restrict times, PatchInputs E0 (E t) ρ a b (U t) V ∧
      ∀ e : ℝ, 0 < e →
      let p := patch (E t) ρ
      let q := patch (circular E0) ρ
      Integrable (fun x => stretchedFlux e (p x) (q x) (U t x) (V x) (u t x) (v x)) ∧
      (∫ x, stretchedFlux e (p x) (q x) (U t x) (V x) (u t x) (v x)) ≤
        (R^2+e^2*Ht^2)*(∫ x, discr (p x) (q x))) :
    ∀ᵐ t ∂volume.restrict times,
      ρ*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y)) (vel y.1 (V y))) ≤
      4*R^2*Real.sqrt (Real.pi*ρ*(b-a)*impulse E0 (circular E0) ρ) := by
  apply published_overlap times E0 E U V ρ R a b hρ hab
  filter_upwards [h] with t ht
  refine ⟨ht.1, endpoint_of_stretches volume _ _ _ _ (u t) v R Ht ?_ ht.2⟩
  filter_upwards with x
  unfold patch
  split_ifs <;> linarith
end
end Vortex
