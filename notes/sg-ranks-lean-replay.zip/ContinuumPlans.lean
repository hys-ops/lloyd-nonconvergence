import CyclicPlans
import Mathlib.MeasureTheory.Measure.Prokhorov

open MeasureTheory ProbabilityTheory Filter Set
open scoped Topology BoundedContinuousFunction InnerProductSpace
namespace Vortex
noncomputable section

private theorem tight_converging_marginals {Y : Type*} [MetricSpace Y]
    [SecondCountableTopology Y] [CompleteSpace Y] [MeasurableSpace Y] [BorelSpace Y]
    (p : ℕ → ProbabilityMeasure Y) {P : ProbabilityMeasure Y} (hp : Tendsto p atTop (𝓝 P)) :
    IsTightMeasureSet {((μ : ProbabilityMeasure Y) : Measure Y) | μ ∈ range p} := by
  apply isTightMeasureSet_of_isCompact_closure
  exact hp.isCompact_insert_range.closure_of_subset (subset_insert ..)

/-- In particular the quantized geostrophic marginal may converge on all of
R³, with no common compact support. Tightness of both marginals gives tight
plans. A weak limit has both limiting marginals and cyclically monotone
support, which identifies it by uniqueness of the *limiting* static problem. -/
theorem stability_of_quantized_plans {Y K : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [CompleteSpace Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [SecondCountableTopology K] [CompleteSpace K] [MeasurableSpace K] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c)
    (p : ℕ → ProbabilityMeasure Y) (k : ℕ → ProbabilityMeasure K)
    (P : ProbabilityMeasure Y) (K₀ : ProbabilityMeasure K)
    (π : ℕ → ProbabilityMeasure (Y × K)) (planLimit : ProbabilityMeasure (Y × K))
    (hp : Tendsto p atTop (𝓝 P)) (hk : Tendsto k atTop (𝓝 K₀))
    (cert : ∀ n, SequentialRanks.certifiedPlan c (p n) (k n) (π n))
    (unique : ∀ η, SequentialRanks.certifiedPlan c P K₀ η → η=planLimit) :
    Tendsto π atTop (𝓝 planLimit) := by
  let S := {((μ : ProbabilityMeasure (Y × K)) : Measure (Y × K)) | μ ∈ range π}
  have tight : IsTightMeasureSet S := by
    apply IsTightMeasureSet.prodMk
    · apply (tight_converging_marginals p hp).subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨_,⟨n,rfl⟩,(congrArg ProbabilityMeasure.toMeasure (cert n).1).symm⟩
    · apply (tight_converging_marginals k hk).subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨_,⟨n,rfl⟩,(congrArg ProbabilityMeasure.toMeasure (cert n).2.1).symm⟩
  have compact : IsCompact (closure (range π)) := isCompact_closure_of_isTightMeasureSet tight
  apply Filter.tendsto_of_subseq_tendsto
  intro φ hφ
  obtain ⟨η,_,v,vmono,hv⟩ := compact.tendsto_subseq (x := fun i => π (φ i))
    (fun i => subset_closure (mem_range_self (φ i)))
  have hι := hφ.comp vmono.tendsto_atTop
  have fst := ((ProbabilityMeasure.continuous_map (f := (Prod.fst : Y × K → Y)) continuous_fst).tendsto η).comp hv
  have snd := ((ProbabilityMeasure.continuous_map (f := (Prod.snd : Y × K → K)) continuous_snd).tendsto η).comp hv
  have cy := (SequentialRanks.closed_cyclicSupport c hc).mem_of_tendsto hv
    (Eventually.of_forall fun i => (cert (φ (v i))).2.2)
  have a : η.map Prod.fst = P := by
    apply tendsto_nhds_unique fst
    exact (hp.comp hι).congr (fun i => (cert (φ (v i))).1.symm)
  have b : η.map Prod.snd = K₀ := by
    apply tendsto_nhds_unique snd
    exact (hk.comp hι).congr (fun i => (cert (φ (v i))).2.1.symm)
  exact ⟨v,unique η ⟨a,b,cy⟩ ▸ hv⟩

/-- Narrow convergence of joint transports gives convergence of vector
moment tests, since physical endpoints have bounded coordinates. -/
theorem plan_moment_test_convergence {Y K F : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    {π : ℕ → ProbabilityMeasure (Y × K)} {planLimit : ProbabilityMeasure (Y × K)}
    (hπ : Tendsto π atTop (𝓝 planLimit)) (k : K →ᵇ F) (g : Y →ᵇ F) :
    Tendsto (fun n => ∫ z : Y × K, ⟪k z.2,g z.1⟫_ℝ ∂(π n : Measure (Y × K)))
      atTop (𝓝 (∫ z : Y × K, ⟪k z.2,g z.1⟫_ℝ ∂(planLimit : Measure (Y × K)))) := by
  let test : Y × K →ᵇ ℝ := BoundedContinuousFunction.ofNormedAddCommGroup
    (fun z => ⟪k z.2,g z.1⟫_ℝ) ((k.continuous.comp continuous_snd).inner (g.continuous.comp continuous_fst))
    (‖k‖*‖g‖) (fun z => (norm_inner_le_norm ..).trans
      (mul_le_mul (k.norm_coe_le_norm _) (g.norm_coe_le_norm _) (norm_nonneg _) (norm_nonneg _)))
  exact ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hπ test

end
end Vortex
