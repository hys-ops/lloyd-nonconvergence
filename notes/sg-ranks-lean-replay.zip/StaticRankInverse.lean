import StaticRankBrenier
import RankMintyConvex

open MeasureTheory Filter Set
open scoped BigOperators Topology ENNReal NNReal
namespace SequentialRanks
noncomputable section

private theorem swapped_cost {d : ℕ} {A B : Set (RankPoint d)} (z : A × B) :
    squareCost z.swap = squareCost z := by
  rcases z with ⟨x,y⟩
  unfold squareCost normSq diff
  apply Finset.sum_congr rfl
  intro i _; change (y.val i-x.val i)^2 = (x.val i-y.val i)^2; ring

/-- Transpose of a squared-cost cyclic coupling is cyclic. -/
theorem swap_square_cyclic {d : ℕ} {A B : Set (RankPoint d)} (π : ProbabilityMeasure (A × B))
    (hπ : cyclicSupport squareCost π) : cyclicSupport squareCost (π.map Prod.swap) := by
  have supp (z : B × A) (h : z ∈ ((π.map Prod.swap : ProbabilityMeasure (B × A)) : Measure _).support) :
      z.swap ∈ (π : Measure (A × B)).support := by
    apply (Measure.mem_support_iff_forall _).mpr
    intro s hs
    obtain ⟨o,sub,op,inside⟩ := mem_nhds_iff.mp hs
    have m := op.preimage (continuous_swap : Continuous (Prod.swap : B × A → A × B))
    have pos := (Measure.mem_support_iff_forall _).mp h _ (m.mem_nhds inside)
    change 0 < (π : Measure (A × B)).map Prod.swap (Prod.swap ⁻¹' o) at pos
    rw [Measure.map_apply measurable_swap m.measurableSet] at pos
    exact lt_of_lt_of_le pos (measure_mono fun x hx => sub (show x ∈ o from hx))
  intro n σ z hz
  have cy := hπ n σ.symm (fun i => (z i).swap) (fun i => supp _ (hz i))
  calc
    _ = ∑ i, squareCost (z i).swap := Finset.sum_congr rfl fun i _ => (swapped_cost (z i)).symm
    _ ≤ _ := cy
    _ = ∑ i, squareCost ((z i).1,(z (σ i)).2) := by
      apply Fintype.sum_equiv σ.symm
      intro i
      simpa only [Prod.fst_swap,Prod.snd_swap,Prod.swap_prod_mk,Equiv.apply_symm_apply] using swapped_cost ((z (σ.symm i)).1,(z i).2)

/-- The ambient graph of U, measured with its prescribed density, equals the
embedding of a cyclic plan on A × B. This specifies an optimal rank map up to
its source-null choices. -/
def compactRankGraph {d : ℕ} (A B : Set (RankPoint d)) (p : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) :=
  ∃ π : ProbabilityMeasure (A × B), cyclicSupport squareCost π ∧
    (weighted volume p).map (fun x => (x,U x)) =
      (π : Measure (A × B)).map (fun z => (z.1.val,z.2.val))

/-- On a Borel set exhausting almost every positive-density source point,
the actual endpoint U is injective and is the gradient of a single convex
potential. The inverse is recognized from the transpose-potential derivative
at the target; absolute continuity of the latter is used here. -/
theorem compact_rank_good_set {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (p w : RankPoint d → ℝ) (U : RankPoint d → RankPoint d)
    (mp : Measurable p) (mu : Measurable U)
    (law : (weighted volume p).map U = weighted volume w) (rank : compactRankGraph A B p U) :
    ∃ (φ : RankPoint d → ℝ) (G : Set (RankPoint d)), ConvexOn ℝ univ φ ∧ MeasurableSet G ∧
      (∀ᵐ x ∂volume, 0 < p x → x ∈ G) ∧ MapsTo U G B ∧ InjOn U G ∧
      ∀ x ∈ G, HasFDerivAt φ (rankCovector (U x)) x := by
  obtain ⟨π,cy,gr⟩ := rank
  obtain ⟨φ,L,lf,cf,sf⟩ := square_cyclic_potential A B hb π cy
  obtain ⟨ψ,K,lg,_,sg⟩ := square_cyclic_potential B A ha (π.map Prod.swap) (swap_square_cyclic π cy)
  let emb := fun z : A × B => (z.1.val,z.2.val)
  let gf := fun x : RankPoint d => (x,U x)
  have me : Measurable emb := (measurable_subtype_coe.comp measurable_fst).prodMk
    (measurable_subtype_coe.comp measurable_snd)
  have mg : Measurable gf := measurable_id.prodMk mu
  have left : (π : Measure (A × B)).map (fun z => z.1.val) = weighted volume p := by
    have e := congrArg (fun M : Measure (RankPoint d × RankPoint d) => M.map Prod.fst) gr
    change (Measure.map Prod.fst ((weighted volume p).map gf)) = Measure.map Prod.fst ((π : Measure _).map emb) at e
    rw [Measure.map_map measurable_fst mg,Measure.map_map measurable_fst me] at e
    exact e.symm.trans Measure.map_id
  have right : (π : Measure (A × B)).map (fun z => z.2.val) = weighted volume w := by
    have e := congrArg (fun M : Measure (RankPoint d × RankPoint d) => M.map Prod.snd) gr
    change (Measure.map Prod.snd ((weighted volume p).map gf)) = Measure.map Prod.snd ((π : Measure _).map emb) at e
    rw [Measure.map_map measurable_snd mg,Measure.map_map measurable_snd me] at e
    exact e.symm.trans law
  have df := (withDensity_absolutelyContinuous volume (fun x => ENNReal.ofReal (p x))).ae_le
    (lf.ae_differentiableAt (μ := volume))
  have dg := (withDensity_absolutelyContinuous volume (fun x => ENNReal.ofReal (w x))).ae_le
    (lg.ae_differentiableAt (μ := volume))
  change ∀ᵐ x ∂weighted volume p, DifferentiableAt ℝ φ x at df
  change ∀ᵐ x ∂weighted volume w, DifferentiableAt ℝ ψ x at dg
  have dfπ := ae_of_ae_map (measurable_subtype_coe.comp measurable_fst).aemeasurable (left.symm ▸ df)
  have dgπ := ae_of_ae_map (measurable_subtype_coe.comp measurable_snd).aemeasurable (right.symm ▸ dg)
  have rev := ae_of_ae_map measurable_swap.aemeasurable
    (show ∀ᵐ z ∂(π : Measure (A × B)).map Prod.swap, z ∈ ((π : Measure _).map Prod.swap).support from
      ((π : Measure (A × B)).map Prod.swap).support_mem_ae)
  have eqder (f : RankPoint d → ℝ) (x k : RankPoint d) (h : DifferentiableAt ℝ f x)
      (contact : globalSupports f x k) : fderiv ℝ f x = rankCovector k := by
    have localMin : IsLocalMin (fun z => f z-rankCovector k z) x := by
      apply Eventually.of_forall; intro z
      have e := contact z
      rw [map_sub] at e; change f x-_ ≤ f z-_; linarith
    exact sub_eq_zero.mp (localMin.hasFDerivAt_eq_zero (h.hasFDerivAt.sub (rankCovector k).hasFDerivAt))
  let T := {z : RankPoint d × RankPoint d | fderiv ℝ φ z.1 = rankCovector z.2 ∧
    fderiv ℝ ψ z.2 = rankCovector z.1 ∧ z.2 ∈ B}
  have cCov : Continuous (@rankCovector d) := by unfold rankCovector; fun_prop
  have mt : MeasurableSet T :=
    (measurableSet_eq_fun ((measurable_fderiv ℝ φ).comp measurable_fst) (cCov.measurable.comp measurable_snd)).inter
    ((measurableSet_eq_fun ((measurable_fderiv ℝ ψ).comp measurable_snd) (cCov.measurable.comp measurable_fst)).inter
      (measurable_snd hb.isClosed.measurableSet))
  have ht : ∀ᵐ z ∂(π : Measure (A × B)), emb z ∈ T := by
    filter_upwards [dfπ,dgπ,(π : Measure (A × B)).support_mem_ae,rev] with z h1 h2 s1 s2
    exact ⟨eqder φ _ _ h1 (sf z s1),eqder ψ _ _ h2 (sg z.swap s2),z.2.property⟩
  have hmap : T ∈ ae ((weighted volume p).map gf) := by
    rw [gr]; exact (mem_ae_map_iff me.aemeasurable mt).mpr ht
  let G := (gf ⁻¹' T) ∩ {x | DifferentiableAt ℝ φ x}
  have mG : MeasurableSet G := (mg mt).inter (measurableSet_of_differentiableAt ℝ φ)
  have covers : ∀ᵐ x ∂weighted volume p, x ∈ G := by
    filter_upwards [(mem_ae_map_iff mg.aemeasurable mt).mp hmap,df] with x hx dx using ⟨hx,dx⟩
  have fromp := (ae_withDensity_iff (ENNReal.measurable_ofReal.comp mp)).mp covers
  refine ⟨φ,G,cf,mG,?_,fun _ h => h.1.2.2,?_,?_⟩
  · filter_upwards [fromp] with x hx hp using hx (ENNReal.ofReal_ne_zero_iff.mpr hp)
  · intro x hx y hy eq
    exact rank_covector_injective (hx.1.2.1.symm.trans ((congrArg (fderiv ℝ ψ) eq).trans hy.1.2.1))
  · intro x hx
    exact hx.1.1 ▸ hx.2.hasFDerivAt

end
end SequentialRanks
