import MinimaxUpper

open MeasureTheory Filter Set
open scoped BigOperators
namespace SequentialRanks
noncomputable section
private theorem normSq_nonneg {d} (x : Fin d → ℝ) : 0 ≤ normSq x := Finset.sum_nonneg fun _ _ => sq_nonneg _
theorem bounded_rank_distance {d} {R : ℝ} {x y : Fin d → ℝ} (hx : normSq x ≤ R^2) (hy : normSq y ≤ R^2) :
    |normSq (diff x y)| ≤ 4*R^2 := by
  have h := Finset.sum_le_sum (s := Finset.univ) (fun (i : Fin d) _ =>
    show (x i-y i)^2 ≤ 2*((x i)^2+(y i)^2) by nlinarith only [sq_nonneg (x i+y i)])
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at h
  rw [abs_of_nonneg (normSq_nonneg _)]
  change (∑ i, (x i-y i)^2) ≤ _
  unfold normSq at hx hy; linarith

/-- Given the two actual endpoint transports and the midpoint pushforward inequality,
no density lower bound or auxiliary integrability assumptions are needed. -/
theorem one_step_from_geometry {Y : Type*} [MeasurableSpace Y] (ν : Measure Y) {d}
    (ρ : Measure (Fin d → ℝ)) [IsProbabilityMeasure ρ] (R : ℝ)
    (p q : Y → ℝ) (mp : Measurable p) (mq : Measurable q)
    (pn : ∀ y, 0 ≤ p y) (qn : ∀ y, 0 ≤ q y) (ip : Integrable p ν) (iq : Integrable q ν)
    (U V : Y → Fin d → ℝ) (mu : Measurable U) (mv : Measurable V)
    (ub : ∀ y, normSq (U y) ≤ R^2) (vb : ∀ y, normSq (V y) ≤ R^2)
    (refball : ∀ᵐ k ∂ρ, normSq k ≤ R^2)
    (pu : (weighted ν p).map U = ρ) (qv : (weighted ν q).map V = ρ)
    (dom : (weighted ν (fun y => Real.sqrt (p y)*Real.sqrt (q y))).map (fun y => mid (U y) (V y)) ≤ ρ) :
    (∫ y, p y * normSq (diff (U y) (V y)) ∂ν) ≤
      16*R^2*∫ y, (Real.sqrt (p y)-Real.sqrt (q y))^2 ∂ν := by
  have gap_bound (x : Fin d → ℝ) (h : normSq x ≤ R^2) : |gap R x| ≤ R^2 := by
    rw [gap,abs_of_nonneg (sub_nonneg.mpr h)]; linarith [normSq_nonneg x]
  have mg : Measurable (gap R : (Fin d → ℝ) → ℝ) := by unfold gap normSq; fun_prop
  have mm : Measurable (fun y => mid (U y) (V y)) := by unfold mid; fun_prop
  apply rank_from_pushforwards ν ρ R p q U V mp mq pn qn mu mv (.of_forall ub) (.of_forall vb) refball
  · apply (integrable_const (R^2)).mono' mg.aestronglyMeasurable
    filter_upwards [refball] with x hx using gap_bound x hx
  · exact pu
  · exact qv
  · exact dom
  · apply (ip.mul_const (4*R^2)).mono' (show Measurable (fun y => p y*normSq (diff (U y) (V y))) by
      unfold normSq diff; fun_prop).aestronglyMeasurable
    filter_upwards with y
    rw [norm_mul,Real.norm_of_nonneg (pn y),Real.norm_eq_abs]
    exact mul_le_mul_of_nonneg_left (bounded_rank_distance (ub y) (vb y)) (pn y)
  · apply (ip.add iq).mono' (show Measurable (fun y => (Real.sqrt (p y)-Real.sqrt (q y))^2) by fun_prop).aestronglyMeasurable
    filter_upwards with y
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    change _ ≤ p y+q y
    nlinarith only [Real.sq_sqrt (pn y), Real.sq_sqrt (qn y),mul_nonneg (Real.sqrt_nonneg (p y)) (Real.sqrt_nonneg (q y))]
  · apply ((ip.add iq).mul_const (R^2)).mono' (show Measurable
      (fun y => 2*Real.sqrt (p y)*Real.sqrt (q y)*gap R (mid (U y) (V y))) by fun_prop).aestronglyMeasurable
    filter_upwards with y
    rw [norm_mul,Real.norm_of_nonneg (by positivity : 0 ≤ 2*Real.sqrt (p y)*Real.sqrt (q y)),Real.norm_eq_abs]
    have hcross : 2*Real.sqrt (p y)*Real.sqrt (q y) ≤ p y+q y := by
      nlinarith only [Real.sq_sqrt (pn y), Real.sq_sqrt (qn y),sq_nonneg (Real.sqrt (p y)-Real.sqrt (q y))]
    exact mul_le_mul hcross (gap_bound _ (midpoint_ball R _ _ (ub y) (vb y))) (abs_nonneg _) (add_nonneg (pn y) (qn y))
  · apply (ip.mul_const (R^2)).mono' (show Measurable (fun y => p y*gap R (U y)) by fun_prop).aestronglyMeasurable
    filter_upwards with y
    rw [norm_mul,Real.norm_of_nonneg (pn y),Real.norm_eq_abs]
    exact mul_le_mul_of_nonneg_left (gap_bound _ (ub y)) (pn y)
  · apply (iq.mul_const (R^2)).mono' (show Measurable (fun y => q y*gap R (V y)) by fun_prop).aestronglyMeasurable
    filter_upwards with y
    rw [norm_mul,Real.norm_of_nonneg (qn y),Real.norm_eq_abs]
    exact mul_le_mul_of_nonneg_left (gap_bound _ (vb y)) (qn y)

/-- Cumulative risk of a single common mixture-rank estimator against every member
of a finite list; all comparison and midpoint measures are at the individual-history level. -/
theorem finite_list_rank_upper {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    {J : Type*} [Fintype J] [Nonempty J] (a : J → Predictions Y ν) (T d : ℕ) (R : ℝ)
    (ρ : Measure (Fin d → ℝ)) [IsProbabilityMeasure ρ] (refball : ∀ᵐ y ∂ρ, normSq y ≤ R^2)
    (U : J → (t : ℕ) → History Y t × Y → Fin d → ℝ)
    (V : (t : ℕ) → History Y t × Y → Fin d → ℝ)
    (mu : ∀ j t, Measurable (U j t)) (mv : ∀ t, Measurable (V t))
    (ub : ∀ j t z, normSq (U j t z) ≤ R^2) (vb : ∀ t z, normSq (V t z) ≤ R^2)
    (pu : ∀ j t h, (weighted ν (fun y => (a j t).f (h,y))).map (fun y => U j t (h,y)) = ρ)
    (qv : ∀ t h, (weighted ν (fun y => (listForecast a t).f (h,y))).map (fun y => V t (h,y)) = ρ)
    (dom : ∀ j t, t < T → ∀ h, 0 < historyDensity (a j) t h →
      (weighted ν (fun y => Real.sqrt ((a j t).f (h,y))*Real.sqrt ((listForecast a t).f (h,y)))).map
        (fun y => mid (U j t (h,y)) (V t (h,y))) ≤ ρ) :
    ∀ j, (∑ t ∈ Finset.range T, historyRisk (a j) (fun n z => normSq (diff (U j n z) (V n z))) t) ≤
      min (4*R^2*T) (16*R^2*Real.log (Fintype.card J)) := by
  apply finite_list_mixture_upper
  · intro j t; unfold normSq diff; fun_prop
  · intro j t z; exact bounded_rank_distance (ub _ _ _) (vb _ _)
  · intro j t ht h ph
    have source : Measurable (fun y : Y => (h,y)) := measurable_const.prodMk measurable_id
    exact one_step_from_geometry ν ρ R _ _ ((a j t).measurable.comp source) ((listForecast a t).measurable.comp source)
      (fun y => (a j t).nonneg _) (fun y => (listForecast a t).nonneg _) ((a j t).integrable h)
      ((listForecast a t).integrable h) _ _ ((mu j t).comp source) ((mv t).comp source)
      (fun y => ub j t (h,y)) (fun y => vb t (h,y)) refball (pu j t h) (qv t h) (dom j t ht h ph)

end
end SequentialRanks
