import MinimaxUpperPrior
open MeasureTheory Set Filter
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

structure IIDFamily (Θ Y : Type*) [MeasurableSpace Θ] [MeasurableSpace Y] (ν : Measure Y) where
  density : Θ × Y → ℝ
  measurable : Measurable density
  nonneg : ∀ z, 0 ≤ density z
  integrable : ∀ θ, Integrable (fun y => density (θ,y)) ν
  mass : ∀ θ, (∫ y,density (θ,y) ∂ν) = 1

variable {Θ Y : Type*} [MeasurableSpace Θ] [MeasurableSpace Y] {ν : Measure Y}
def IIDFamily.forecast (F : IIDFamily Θ Y ν) (θ : Θ) : Predictions Y ν := fun _ =>
  { f := fun z => F.density (θ,z.2)
    measurable := F.measurable.comp (measurable_const.prodMk measurable_snd)
    nonneg := fun _ => F.nonneg _
    integrable := fun _ => F.integrable θ
    mass := fun _ => F.mass θ }

def IIDFamily.paths (F : IIDFamily Θ Y ν) (n : ℕ) (z : Θ × History Y n) :=
  historyDensity (F.forecast z.1) n z.2

theorem iid_paths_measurable (F : IIDFamily Θ Y ν) : ∀ n, Measurable (F.paths n)
  | 0 => measurable_const
  | n+1 => by
    change Measurable (fun z : Θ × (History Y n × Y) => F.paths n (z.1,z.2.1) * F.density (z.1,z.2.2))
    exact ((iid_paths_measurable F n).comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))).mul
      (F.measurable.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd)))

/-- Tensorization for the actual i.i.d. path-density KL, in its finite branch. -/
theorem iid_path_kl [SFinite ν] (F : IIDFamily Θ Y ν) (θ η : Θ)
    (ac : ∀ᵐ y ∂ν, 0 < F.density (θ,y) → 0 < F.density (η,y))
    (finite : Integrable (fun y => klTerm (F.density (θ,y)) (F.density (η,y))) ν) : ∀ n,
    (∀ᵐ z ∂historyBase ν n, 0 < F.paths n (θ,z) → 0 < F.paths n (η,z)) ∧
    Integrable (fun z => klTerm (F.paths n (θ,z)) (F.paths n (η,z))) (historyBase ν n) ∧
    historyKL (F.forecast θ) (F.forecast η) n = n*∫ y, klTerm (F.density (θ,y)) (F.density (η,y)) ∂ν := by
  intro n; induction n with
  | zero => simp [IIDFamily.paths,historyDensity,klTerm,historyKL]
  | succ n ih =>
    obtain ⟨past,pi,iv⟩ := ih
    let p := fun h => F.paths n (θ,h)
    let q := fun h => F.paths n (η,h)
    let a := fun y => F.density (θ,y)
    let b := fun y => F.density (η,y)
    let m := historyBase ν n
    have laws := history_is_density (F.forecast θ) n
    have old : ∀ᵐ z : History Y n × Y ∂m.prod ν, 0 < p z.1 → 0 < q z.1 :=
      (Measure.quasiMeasurePreserving_fst (ν := ν)).ae past
    have newObs : ∀ᵐ z : History Y n × Y ∂m.prod ν, 0 < a z.2 → 0 < b z.2 :=
      (Measure.quasiMeasurePreserving_snd (μ := m)).ae ac
    have ident : ∀ᵐ z : History Y n × Y ∂m.prod ν, klTerm (p z.1*a z.2) (q z.1*b z.2) =
        klTerm (p z.1) (q z.1)*a z.2+p z.1*klTerm (a z.2) (b z.2) := by
      filter_upwards [old,newObs] with z h1 h2
      exact factor_log _ _ _ _ (laws.2.1 _) (F.nonneg _) h1 (fun _ => h2)
    have i1 := pi.mul_prod (F.integrable θ)
    have i2 := laws.2.2.1.mul_prod finite
    refine ⟨?_,(i1.add i2).congr (ident.mono (fun _ h => h.symm)),?_⟩
    · change ∀ᵐ z : History Y n × Y ∂m.prod ν, 0 < p z.1*a z.2 → 0 < q z.1*b z.2
      filter_upwards [old,newObs] with z hx hy
      intro h
      rcases mul_pos_iff.mp h with ⟨px,ay⟩ | ⟨px,_⟩
      · exact mul_pos (hx px) (hy ay)
      · exact (not_lt_of_ge (laws.2.1 z.1) px).elim
    · change (∫ z : History Y n × Y, klTerm (p z.1*a z.2) (q z.1*b z.2) ∂m.prod ν) = _
      rw [integral_congr_ae ident,integral_add (f := fun z : History Y n × Y => klTerm (p z.1) (q z.1)*a z.2)
        (g := fun z : History Y n × Y => p z.1*klTerm (a z.2) (b z.2)) i1 i2,
        integral_prod_mul (fun h => klTerm (p h) (q h)) a,integral_prod_mul p (fun y => klTerm (a y) (b y))]
      change (historyKL (F.forecast θ) (F.forecast η) n)*(∫ y,F.density (θ,y) ∂ν)+
        (∫ h,historyDensity (F.forecast θ) n h ∂historyBase ν n)*(∫ y,klTerm (a y) (b y) ∂ν) = _
      rw [iv,F.mass,laws.2.2.2,Nat.cast_succ]
      dsimp [a,b]; ring

def priorMixture (F : IIDFamily Θ Y ν) (π : Measure Θ) (n : ℕ) (z : History Y n) :=
  ∫ θ, F.paths n (θ,z) ∂π

private theorem prior_m (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π] (n : ℕ) :
    Measurable (priorMixture F π n) := (iid_paths_measurable F n).stronglyMeasurable.integral_prod_left'.measurable

private theorem prior_nonneg (F : IIDFamily Θ Y ν) (π : Measure Θ) [SFinite ν] (n : ℕ) (z) :
    0 ≤ priorMixture F π n z :=
  integral_nonneg fun θ => (history_is_density (F.forecast θ) n).2.1 z

private theorem prior_consistency [SFinite ν] (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π] (n : ℕ) :
    ∀ᵐ z ∂historyBase ν n, Integrable (fun y => priorMixture F π (n+1) (z,y)) ν ∧
    (∫ y,priorMixture F π (n+1) (z,y) ∂ν) = priorMixture F π n z := by
  have joint : Integrable (F.paths n) (π.prod (historyBase ν n)) := by
    refine (integrable_prod_iff (iid_paths_measurable F n).aestronglyMeasurable).2 ⟨.of_forall (fun θ => (history_is_density (F.forecast θ) n).2.2.1),?_⟩
    have hp (θ z) : 0 ≤ F.paths n (θ,z) := (history_is_density (F.forecast θ) n).2.1 z
    simp only [Real.norm_of_nonneg (hp _ _)]
    have mass (θ) : (∫ z,F.paths n (θ,z) ∂historyBase ν n)=1 := (history_is_density (F.forecast θ) n).2.2.2
    simp_rw [mass]; exact integrable_const _
  filter_upwards [joint.prod_left_ae] with z iz
  let d := fun v : Θ × Y => F.paths n (v.1,z) * F.density v
  have md : Measurable d := ((iid_paths_measurable F n).comp (measurable_id.prodMk measurable_const) |>.comp measurable_fst).mul F.measurable
  have id : Integrable d (π.prod ν) := by
    apply (integrable_prod_iff md.aestronglyMeasurable).2
    refine ⟨.of_forall (fun θ => (F.integrable θ).const_mul (F.paths n (θ,z))),?_⟩
    unfold d
    simpa only [norm_mul,Real.norm_of_nonneg (F.nonneg _),integral_const_mul,F.mass,mul_one] using iz.norm
  refine ⟨id.integral_prod_right,?_⟩
  change (∫ y,∫ θ,d (θ,y) ∂π ∂ν) = _
  rw [← integral_integral_swap (f := fun θ y => d (θ,y)) id]
  unfold d; simp only [integral_const_mul,F.mass,mul_one]; rfl

/-- The Bayesian predictive density, obtained from the actual marginal densities.
A single fixed fallback family member covers malformed or null histories. -/
def priorForecast [SFinite ν] (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π] (fallback : Θ) :
    Predictions Y ν := fun n =>
  let p := priorMixture F π n
  let q := fun z : History Y n × Y => priorMixture F π (n+1) z
  let valid := fun h => 0 < p h ∧ (∫ y,q (h,y) ∂ν)=p h
  { f := fun z => if valid z.1 then q z/p z.1 else F.density (fallback,z.2)
    measurable := by
      have mp : Measurable p := prior_m F π n
      have mq : Measurable q := prior_m F π (n+1)
      have mv : MeasurableSet {h | valid h} := (measurableSet_lt measurable_const mp).inter
        (measurableSet_eq_fun mq.stronglyMeasurable.integral_prod_right'.measurable mp)
      exact Measurable.ite (measurable_fst mv) (mq.div (mp.comp measurable_fst)) (F.measurable.comp (measurable_const.prodMk measurable_snd))
    nonneg := fun z => by split_ifs; exact div_nonneg (prior_nonneg F π _ _) (prior_nonneg F π _ _); exact F.nonneg _
    integrable := fun h => by
      dsimp only; split_ifs with hv
      · apply Integrable.div_const
        by_contra! hn
        have z := integral_undef hn
        exact hv.1.ne' (hv.2.symm.trans z)
      · exact F.integrable _
    mass := fun h => by
      dsimp only; split_ifs with hv
      · rw [integral_div,hv.2,div_self hv.1.ne']
      · exact F.mass _ }

/-- All finite-dimensional densities of the Bayesian predictive process agree with
their prior mixtures, with arbitrary singular null-history exceptions removed. -/
theorem prior_forecast_paths [SFinite ν] (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π]
    (fallback : Θ) : ∀ n, historyDensity (priorForecast F π fallback) n =ᵐ[historyBase ν n] priorMixture F π n
  | 0 => by filter_upwards with z; simp [priorMixture,IIDFamily.paths,historyDensity]
  | n+1 => by
    let b := priorForecast F π fallback
    let p := priorMixture F π n
    let q := fun z : History Y n × Y => priorMixture F π (n+1) z
    change ∀ᵐ z : History Y n × Y ∂(historyBase ν n).prod ν, historyDensity b n z.1*(b n).f z = q z
    apply (Measure.ae_prod_iff_ae_ae (p := fun z : History Y n × Y => historyDensity b n z.1*(b n).f z=q z)
      (measurableSet_eq_fun (((history_is_density b n).1.comp measurable_fst).mul (b n).measurable)
        (show Measurable q from prior_m F π (n+1)))).2
    filter_upwards [prior_forecast_paths F π fallback n,prior_consistency F π n] with h hist cs
    change historyDensity b n h = p h at hist
    change Integrable (fun y => q (h,y)) ν ∧ (∫ y,q (h,y) ∂ν)=p h at cs
    rw [hist]
    by_cases ph : 0 < p h
    · filter_upwards with y
      change p h*(if 0 < p h ∧ (∫ x,q (h,x) ∂ν)=p h then q (h,y)/p h else F.density (fallback,y)) = _
      simp only [ph,cs.2,and_self,ite_true]; rw [mul_comm,div_mul_cancel₀ _ ph.ne']
    · have zero := le_antisymm (le_of_not_gt ph) (prior_nonneg F π n h)
      have next := (integral_eq_zero_iff_of_nonneg_ae (.of_forall fun y => prior_nonneg F π (n+1) (h,y)) cs.1).mp (cs.2.trans zero)
      filter_upwards [next] with y hy
      rw [zero,zero_mul]; exact hy.symm

end
end SequentialRanks
