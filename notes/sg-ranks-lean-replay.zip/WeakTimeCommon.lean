import WeakTimePatch
import Mathlib.Topology.ContinuousMap.SecondCountableSpace

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

private abbrev Jet := C(SpaceTime,ℝ) × C(SpaceTime,SpaceTime →L[ℝ] ℝ)

private def testJet (f : SpaceTime → ℝ) (hf : ContDiff ℝ ∞ f) : Jet :=
  (⟨f,hf.continuous⟩,⟨fderiv ℝ f,hf.continuous_fderiv (by simp)⟩)

/-- A bounded class of compact smooth tests in the compact-open first-jet topology. -/
private def Jets (n : ℕ) := {j : Jet | (∀ s, ‖j.1 s‖ ≤ n ∧ ‖j.2 s‖ ≤ n) ∧
  ∃ f : SpaceTime → ℝ, ∃ hf : ContDiff ℝ ∞ f, HasCompactSupport f ∧ j = testJet f hf}

private theorem simultaneous {X Y : Type*} [MeasurableSpace X] (μ : Measure X)
    [TopologicalSpace Y] [TopologicalSpace.SeparableSpace Y] (P : X → Y → Prop)
    (closed : ∀ᵐ x ∂μ, IsClosed {y | P x y}) (every : ∀ y, ∀ᵐ x ∂μ,P x y) :
    ∀ᵐ x ∂μ, ∀ y,P x y := by
  obtain ⟨d,hd,hdense⟩ := TopologicalSpace.exists_countable_dense Y
  filter_upwards [closed,(ae_ball_iff hd).mpr (fun y _ => every y)] with x hx hc
  intro y
  exact closure_minimal (fun z hz => hc z hz) hx (hdense y)

private def value (n : ℕ) (t : ℝ) (E : Set Space) (j : Jets n) : ℝ :=
  ∫ y in E,j.1.1 (t,y)

private def current (n : ℕ) (t : ℝ) (E : ℝ → Set Space) (w : SpaceTime → H) (j : Jets n) : ℝ :=
  ∫ s, j.1.2 s (timeDirection w s) ∂occupation E t

private theorem value_continuous (n : ℕ) (t : ℝ) (E : Set Space) (fin : volume E ≠ ⊤) :
    Continuous (value n t E) := by
  apply continuous_of_dominated (bound := fun _ => (n:ℝ))
  · intro j
    exact (j.1.1.continuous.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
  · intro j
    exact .of_forall fun y => (j.2.1 (t,y)).1
  · exact integrableOn_const fin
  · filter_upwards with y
    exact (ContinuousMap.evalCLM ℝ (t,y)).continuous.comp (continuous_fst.comp continuous_subtype_val)

private theorem current_continuous (n : ℕ) (t : ℝ) (E : ℝ → Set Space) (w : SpaceTime → H)
    [IsFiniteMeasure (occupation E t)] (hw : Integrable w (occupation E t)) :
    Continuous (current n t E w) := by
  apply continuous_of_dominated (bound := fun s => (n:ℝ)*(1+‖w s‖))
  · intro j
    exact (ContinuousLinearMap.apply ℝ ℝ).flip.aestronglyMeasurable_comp₂
      j.1.2.continuous.aestronglyMeasurable
      (aestronglyMeasurable_const.prodMk (hw.aestronglyMeasurable.prodMk aestronglyMeasurable_const))
  · intro j
    exact .of_forall fun s => ((j.1.2 s).le_opNorm _).trans (mul_le_mul (j.2.1 s).2
      (timeDirection_bound w s) (norm_nonneg _) (Nat.cast_nonneg n))
  · exact (((integrable_const 1).add hw.norm).const_mul (n:ℝ))
  · filter_upwards with s
    exact ((ContinuousMap.evalCLM ℝ s).continuous.comp
      (continuous_snd.comp continuous_subtype_val)).clm_apply continuous_const

/-- From the distributional initial-value patch equation, recover the previous project's
entire spacetime two-trace identity on one common full-measure set of times. The null
set is independent of the uncountably many compact smooth spacetime tests. -/
theorem weak_patch_of_distributional (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (hT : 0 ≤ T) (hρ : 0 < ρ) (w : SpaceTime → H) (finite0 : volume E0 ≠ ⊤)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) [IsFiniteMeasure (occupation E T)]
    (hw : Integrable w (occupation E T)) (weak : DistributionalPatch E0 E T ρ w) :
    ∀ᵐ t ∂volume.restrict (Icc 0 T), WeakPatchEquation E0 E t ρ w := by
  let μ := (volume : Measure ℝ).restrict (Icc 0 T)
  have tm : ∀ᵐ t ∂μ, t ∈ Icc 0 T := ae_restrict_mem measurableSet_Icc
  have fmass := (occupation_fubini E moving T (fun _ => (1:ℝ)) (integrable_const 1)).2
  have fin : ∀ᵐ t ∂μ, volume (E t) ≠ ⊤ := by
    filter_upwards [fmass] with t ht
    exact (show volume (E t) < ⊤ by simpa [integrableOn_const_iff] using ht).ne
  have all (n : ℕ) : ∀ᵐ t ∂μ, ∀ j : Jets n,
      value n t (E t) j - value n 0 E0 j = current n t E w j := by
    apply simultaneous
    · filter_upwards [tm,fin] with t ht hfin
      have dom := occupation_mono_time E ht.2
      let _ : IsFiniteMeasure (occupation E t) := ⟨lt_of_le_of_lt (dom univ) (measure_lt_top _ _)⟩
      exact isClosed_eq ((value_continuous n t (E t) hfin).sub (value_continuous n 0 E0 finite0))
        (current_continuous n t E w (hw.mono_measure dom))
    · intro j
      obtain ⟨f,hf,hc,eqj⟩ := j.2.2
      have h := (patch_test_time_representative E0 E T ρ hT hρ w moving hw weak f hf hc).2.2
      have ig := (spaceTime_test_integrable E T w hw f hf hc).2
      filter_upwards [tm,h] with t ht hi
      have fub := (occupation_fubini E moving t _ (ig.mono_measure (occupation_mono_time E ht.2))).1
      rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le ht.1] at fub
      change (∫ y in E t,f (t,y)) = (∫ y in E0,f (0,y)) + _ at hi
      unfold value current
      rw [eqj]
      change (∫ y in E t,f (t,y)) - (∫ y in E0,f (0,y)) =
        ∫ s, fderiv ℝ f s (timeDirection w s) ∂occupation E t
      rw [fub,hi]
      ring
  filter_upwards [ae_all_iff.mpr all] with t ht
  intro f hf hc
  obtain ⟨A,hA⟩ := hc.exists_bound_of_continuous hf.continuous
  obtain ⟨B,hB⟩ := (hc.fderiv ℝ).exists_bound_of_continuous (hf.continuous_fderiv (by simp))
  obtain ⟨n,hn⟩ := exists_nat_ge (max A B)
  let j : Jets n := ⟨testJet f hf,
    ⟨fun s => ⟨(hA s).trans ((le_max_left ..).trans hn),(hB s).trans ((le_max_right ..).trans hn)⟩,
      f,hf,hc,rfl⟩⟩
  have eqn := ht n j
  change (∫ y in E t,f (t,y)) - (∫ y in E0,f (0,y)) =
    ∫ s, fderiv ℝ f s (timeDirection w s) ∂occupation E t at eqn
  change ρ*_ - ρ*_ = ρ*(∫ s, fderiv ℝ f s (timeDirection w s) ∂occupation E t)
  rw [← mul_sub,eqn]

end
end Vortex
