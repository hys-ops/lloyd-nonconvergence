import PathLawRepresentation
import StaticPathOraclePublic

open MeasureTheory InformationTheory Filter Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- Chronologically ordered prefix of any length up to the horizon. -/
def takeHistory {Y : Type*} (n T : ℕ) (h : n ≤ T) (z : History Y T) : History Y n :=
  historyPrefix n (T-n) (cast (congrArg (History Y) (show T = n+(T-n) by omega)) z)

theorem pathMeasure_take {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (a : Predictions Y ν) (n T : ℕ) (h : n ≤ T) :
    (pathMeasure a T).map (takeHistory n T h) = pathMeasure a n := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le h
  have align (m l : ℕ) (E : m = l) (z : History Y (n+l)) :
      historyPrefix n m (cast (congrArg (History Y) (show n+l=n+m by omega)) z) =
      historyPrefix n l z := by cases E; rfl
  have eq : takeHistory (Y := Y) n (n+k) h = historyPrefix n k :=
    funext (align _ _ (by omega))
  rw [eq]; exact pathMeasure_prefix a n k

/-- Expected squared rank loss is evaluated under the original terminal law, using
its marginal on the actual history and current observation at each date. -/
def terminalPathRisk {d : ℕ} {A : Type*} [MeasurableSpace A] {T : ℕ} (P : Measure (History A T))
    (U V : (t : ℕ) → History A t × A → RankPoint d) : ℝ :=
  ∑ t : Fin T, ∫ z : History A t × A, normSq (diff (U t z) (V t z))
    ∂P.map (takeHistory ((t:ℕ)+1) T t.isLt)

theorem terminalPathRisk_eq {d : ℕ} {A : Type*} [MeasurableSpace A] {ν : Measure A} [SFinite ν]
    (a : Predictions A ν) (T : ℕ) (U V : (t : ℕ) → History A t × A → RankPoint d) :
    terminalPathRisk (pathMeasure a T) U V =
      ∑ t ∈ Finset.range T, historyRisk a (fun n z => normSq (diff (U n z) (V n z))) t := by
  unfold terminalPathRisk
  rw [← Fin.sum_univ_eq_sum_range]
  apply Finset.sum_congr rfl
  intro t _
  rw [pathMeasure_take a (t+1) T t.isLt]
  have hd := history_is_density a ((t:ℕ)+1)
  exact (integral_withDensity_eq_integral_toReal_smul hd.1.ennreal_ofReal
    (Eventually.of_forall fun z => ENNReal.ofReal_lt_top) _).trans
    (integral_congr_ae (.of_forall fun z => by
      exact congrArg (fun r : ℝ => r * normSq (diff (U t z) (V t z))) (ENNReal.toReal_ofReal (hd.2.1 z))))

/-- Direct fixed-horizon oracle for arbitrary absolutely continuous terminal path laws.
The candidate determines a single predictor before the true law is selected.
Both the expectation and relative entropy are evaluated on the supplied laws. -/
theorem public_raw_path_estimator {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2) (N : ℕ)
    (Q : Measure (History A (N+1))) [IsProbabilityMeasure Q] (qac : Q ≪ historyBase (compactObservationVolume A ha) (N+1)) :
    let ν := compactObservationVolume A ha
    let target := densityReference B hb w sw
    ∃ (b : Predictions A ν) (V : (t : ℕ) → History A t × A → RankPoint d),
      pathMeasure b (N+1) = Q ∧ (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((b t).law h) target (fun y => V t (h,y))) ∧
      ∀ (P : Measure (History A (N+1))) [IsProbabilityMeasure P], P ≪ historyBase ν (N+1) →
        ∃ (a : Predictions A ν) (U : (t : ℕ) → History A t × A → RankPoint d),
          pathMeasure a (N+1) = P ∧ (∀ t, Measurable (U t)) ∧
          (∀ t h, CertifiedRank ((a t).law h) target (fun y => U t (h,y))) ∧
          ENNReal.ofReal (terminalPathRisk P U V) ≤ ENNReal.ofReal (16*R^2) * klDiv P Q := by
  obtain ⟨b,hb'⟩ := exists_predictions_path_law_succ _ N Q qac
  obtain ⟨V,mv,cv,comp⟩ := public_path_estimator A B ha hb w sw wn conc R ball b
  refine ⟨b,V,hb',mv,cv,?_⟩
  intro P _ pac
  obtain ⟨a,ha'⟩ := exists_predictions_path_law_succ _ N P pac
  obtain ⟨U,mu,cu,loss⟩ := comp a
  refine ⟨a,U,ha',mu,cu,?_⟩
  rw [← ha', ← hb', terminalPathRisk_eq]
  exact loss (N+1)

/-- A single rank predictor for the literal mixture of a finite list of path measures
works under misspecification for every true law and every listed comparator. -/
theorem public_raw_mixture_estimator {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume w)]
    (sw : ∀ᵐ x ∂weighted volume w, x ∈ B) (wn : ∀ x, 0 ≤ w x)
    (conc : ConcaveOn ℝ {x | 0 < w x} (fun x => Real.log (w x)))
    (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2) (N : ℕ)
    {J : Type*} [Fintype J] [Nonempty J] (π : J → ℝ) (pp : ∀ j, 0 < π j) (mass : ∑ j, π j = 1)
    (Q : J → ProbabilityMeasure (History A (N+1)))
    (qac : ∀ j, (Q j : Measure _) ≪ historyBase (compactObservationVolume A ha) (N+1)) :
    let ν := compactObservationVolume A ha
    let target := densityReference B hb w sw
    ∃ (b : Predictions A ν) (V : (t : ℕ) → History A t × A → RankPoint d),
      pathMeasure b (N+1) = ∑ j, ENNReal.ofReal (π j) • (Q j : Measure _) ∧
      (∀ t, Measurable (V t)) ∧ (∀ t h, CertifiedRank ((b t).law h) target (fun y => V t (h,y))) ∧
      ∀ (P : Measure (History A (N+1))) [IsProbabilityMeasure P], P ≪ historyBase ν (N+1) →
        ∃ (a : Predictions A ν) (U : (t : ℕ) → History A t × A → RankPoint d),
          pathMeasure a (N+1) = P ∧ (∀ t, Measurable (U t)) ∧
          (∀ t h, CertifiedRank ((a t).law h) target (fun y => U t (h,y))) ∧ ∀ j,
          ENNReal.ofReal (terminalPathRisk P U V) ≤ ENNReal.ofReal (16*R^2) *
            (klDiv P (Q j) + ENNReal.ofReal (Real.log (1/π j))) := by
  classical
  choose models eq using (fun j : J => exists_predictions_path_law_succ (compactObservationVolume A ha) N (Q j : Measure (History A (N+1))) (qac j))
  let i := Classical.choice ‹Nonempty J›
  let b := weightedPathForecast π pp models i
  have qeq : pathMeasure b (N+1) = ∑ j, ENNReal.ofReal (π j) • (Q j : Measure _) := by
    refine (weighted_path_law π pp mass models i (N+1)).trans ?_
    exact Finset.sum_congr rfl fun j _ => congrArg (fun μ : Measure _ => ENNReal.ofReal (π j) • μ) (eq j)
  obtain ⟨V,mv,cv,comp⟩ := misspecified_public_estimator A B ha hb w sw wn conc R ball π pp mass models
  refine ⟨b,V,qeq,mv,cv,?_⟩
  intro P _ pac
  obtain ⟨a,ha'⟩ := exists_predictions_path_law_succ _ N P pac
  obtain ⟨U,mu,cu,loss⟩ := comp a
  refine ⟨a,U,ha',mu,cu,?_⟩
  intro j
  rw [← ha', ← eq j, terminalPathRisk_eq]
  exact loss (N+1) j

end
end SequentialRanks
