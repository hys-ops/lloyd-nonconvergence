import PathLawRepresentation
import Mathlib.Probability.Kernel.Composition.WithDensity
import Mathlib.Probability.Kernel.Disintegration.Unique

open MeasureTheory ProbabilityTheory Filter Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- The transition kernel of an everywhere-normalized jointly measurable forecast. -/
def Forecast.transition {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    {ν : Measure Y} [SFinite ν] (f : Forecast H Y ν) : Kernel H Y :=
  (Kernel.const H ν).withDensity (fun h y => ENNReal.ofReal (f.f (h,y)))

theorem Forecast.transition_apply {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    {ν : Measure Y} [SFinite ν] (f : Forecast H Y ν) (h : H) :
    f.transition h = (f.law h : Measure Y) :=
  Kernel.withDensity_apply _ f.measurable.ennreal_ofReal h

instance Forecast.transitionMarkov {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    {ν : Measure Y} [SFinite ν] (f : Forecast H Y ν) : IsMarkovKernel f.transition where
  isProbabilityMeasure h := f.transition_apply h ▸ (f.law h).property

/-- The next step is exactly the composition product with the forecast kernel. -/
theorem pathMeasure_transition {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (a : Predictions Y ν) (n : ℕ) :
    (pathMeasure a n) ⊗ₘ (a n).transition = pathMeasure a (n+1) := by
  have d := history_is_density a n
  have : IsSFiniteKernel ((Kernel.const (History Y n) ν).withDensity
      (fun h y => ENNReal.ofReal ((a n).f (h,y)))) := (inferInstance : IsSFiniteKernel (a n).transition)
  have iden := Measure.withDensity_compProd_withDensity (μ := historyBase ν n)
    (κ := Kernel.const (History Y n) ν) (g := fun h y => ENNReal.ofReal ((a n).f (h,y)))
    d.1.ennreal_ofReal (a n).measurable.ennreal_ofReal
  rw [Measure.compProd_const] at iden
  refine iden.trans ?_
  apply withDensity_congr_ae
  exact Eventually.of_forall fun _ => (ENNReal.ofReal_mul (d.2.1 _) (q := (a n).f _)).symm

/-- The prefix probability viewed as a product of its past and final observation. -/
def pathStepLaw {Y : Type*} [MeasurableSpace Y] {ν : Measure Y}
    (a : Predictions Y ν) (n : ℕ) : Measure (History Y n × Y) := pathMeasure a (n+1)

instance pathStepLawProbability {Y : Type*} [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (a : Predictions Y ν) (n : ℕ) : IsProbabilityMeasure (pathStepLaw a n) := pathMeasureProb a (n+1)

/-- The forecast agrees with the standard Borel conditional distribution for almost
every realized history. Null histories can carry any normalized version. -/
theorem pathMeasure_condKernel {Y : Type*} [MeasurableSpace Y] [StandardBorelSpace Y] [Nonempty Y]
    {ν : Measure Y} [SFinite ν] (a : Predictions Y ν) (n : ℕ) :
    (pathStepLaw a n).condKernel =ᵐ[pathMeasure a n] (a n).transition := by
  have eq : (pathMeasure a n) ⊗ₘ (a n).transition = pathStepLaw a n := pathMeasure_transition a n
  have cmp := condKernel_compProd (pathMeasure a n) (a n).transition
  have kc (μ η : Measure (History Y n × Y)) [IsFiniteMeasure μ] [IsFiniteMeasure η]
      (e : μ = η) : μ.condKernel = η.condKernel := by subst η; rfl
  rw [← kc _ _ eq]
  exact cmp

end
end SequentialRanks
