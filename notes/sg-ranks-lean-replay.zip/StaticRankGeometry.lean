import StaticRankDet
import RankTransport
import Mathlib.MeasureTheory.Function.Jacobian
import Mathlib.MeasureTheory.Function.AEEqOfLIntegral

open MeasureTheory Set Matrix
open scoped ENNReal
namespace SequentialRanks
noncomputable section

abbrev RankPoint (d : ℕ) := Fin d → ℝ
abbrev RankDifferential (d : ℕ) := RankPoint d →L[ℝ] RankPoint d

private def jacMatrix {d : ℕ} (a : RankDifferential d) := LinearMap.toMatrix' a.toLinearMap

private theorem det_mean {d : ℕ} (a b : RankDifferential d) :
    (((1/2:ℝ) • (a+b)).det) = ((1/2:ℝ) • (jacMatrix a + jacMatrix b)).det := by
  change LinearMap.det (((1/2:ℝ) • (a+b)).toLinearMap) = _
  rw [← LinearMap.det_toMatrix']
  congr 1

/-- An endpoint marginal and injective differentiability on G already imply
the Jacobian inequality needed there. There is no Monge–Ampère identity among
the hypotheses, and other preimages outside G are allowed. -/
theorem endpoint_density_le_jacobian {d : ℕ} (p w : RankPoint d → ℝ)
    (U : RankPoint d → RankPoint d) (a : RankPoint d → RankDifferential d)
    (G : Set (RankPoint d)) (hG : MeasurableSet G) (hp : Measurable p)
    (hU : Measurable U) (wn : ∀ y, 0 ≤ w y)
    (push : (weighted volume p).map U = weighted volume w)
    (reg : ∀ x ∈ G, HasFDerivWithinAt U (a x) G x) (inj : InjOn U G) :
    ∀ᵐ x ∂volume.restrict G, p x ≤ |(a x).det| * w (U x) := by
  have h : (fun x => ENNReal.ofReal (p x)) ≤ᵐ[volume.restrict G]
      (fun x => ENNReal.ofReal |(a x).det| * ENNReal.ofReal (w (U x))) := by
    apply ae_le_of_forall_setLIntegral_le_of_sigmaFinite (ENNReal.measurable_ofReal.comp hp)
    intro s hs _
    rw [Measure.restrict_restrict hs]
    let T := s ∩ G
    have mT : MeasurableSet T := hs.inter hG
    have tr : T ⊆ G := inter_subset_right
    have dT := fun x hx => (reg x (tr hx)).mono tr
    have mI := measurable_image_of_fderivWithin mT dT (inj.mono tr)
    have ar := lintegral_image_eq_lintegral_abs_det_fderiv_mul volume mT dT (inj.mono tr)
      (fun y => ENNReal.ofReal (w y))
    rw [← ar]
    calc
      _ = weighted volume p T := (withDensity_apply _ mT).symm
      _ ≤ weighted volume p (U ⁻¹' (U '' T)) := measure_mono (subset_preimage_image U T)
      _ = ((weighted volume p).map U) (U '' T) := (Measure.map_apply hU mI).symm
      _ = _ := by rw [push]; exact withDensity_apply _ mI
  filter_upwards [h] with x hx
  change ENNReal.ofReal (p x) ≤ ENNReal.ofReal |(a x).det| * ENNReal.ofReal _ at hx
  rw [← ENNReal.ofReal_mul (abs_nonneg _)] at hx
  exact (ENNReal.ofReal_le_ofReal_iff (mul_nonneg (abs_nonneg _) (wn _))).mp hx

/-- The change-of-variables step on a common regular overlap. The unrestricted
source densities may vanish on arbitrary measurable sets. No positivity lower bound,
Jacobian domination, or smooth change of variables on the whole domain is assumed. -/
theorem midpoint_domination_of_regular_set {d : ℕ} (p q w : RankPoint d → ℝ)
    (U V : RankPoint d → RankPoint d) (a b : RankPoint d → RankDifferential d)
    (G : Set (RankPoint d)) (hG : MeasurableSet G)
    (cover : ∀ᵐ x ∂volume, 0 < p x → 0 < q x → x ∈ G)
    (hU : Measurable U) (hV : Measurable V) (wn : ∀ y, 0 ≤ w y)
    (logMid : ∀ u v, Real.sqrt (w u)*Real.sqrt (w v) ≤ w (mid u v))
    (regU : ∀ x ∈ G, HasFDerivWithinAt U (a x) G x)
    (regV : ∀ x ∈ G, HasFDerivWithinAt V (b x) G x)
    (hA : ∀ x ∈ G, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef)
    (hB : ∀ x ∈ G, (LinearMap.toMatrix' (b x).toLinearMap).PosSemidef)
    (hp : Measurable p) (hq : Measurable q)
    (pu : (weighted volume p).map U = weighted volume w)
    (qv : (weighted volume q).map V = weighted volume w)
    (iu : InjOn U G) (iv : InjOn V G)
    (injM : InjOn (fun x => mid (U x) (V x)) G) :
    (weighted volume (fun x => Real.sqrt (p x)*Real.sqrt (q x))).map
      (fun x => mid (U x) (V x)) ≤ weighted volume w := by
  let M := fun x => mid (U x) (V x)
  let L := fun x => (1/2:ℝ) • (a x+b x)
  have hm : Measurable M := by unfold M mid; fun_prop
  have reg (x) (hx : x ∈ G) : HasFDerivWithinAt M (L x) G x := by
    have mid_eq : M = fun x => (1/2:ℝ) • (U x + V x) := by
      funext y i; change (_ + _) / 2 = (1/2:ℝ)*(_+_); ring
    rw [mid_eq]
    exact ((regU x hx).add (regV x hx)).const_smul (1/2:ℝ)
  have point : ∀ᵐ x ∂volume, x ∈ G →
      Real.sqrt (p x)*Real.sqrt (q x) ≤ |(L x).det| * w (M x) := by
    have maU := (ae_restrict_iff' hG).mp
      (endpoint_density_le_jacobian p w U a G hG hp hU wn pu regU iu)
    have maV := (ae_restrict_iff' hG).mp
      (endpoint_density_le_jacobian q w V b G hG hq hV wn qv regV iv)
    filter_upwards [maU,maV] with x px qx
    intro hx
    have ha := hA x hx
    have hb := hB x hx
    have hd := determinant_midpoint ha hb
    simp only [LinearMap.det_toMatrix'] at hd
    have he : (L x).det = ((1/2:ℝ) • (jacMatrix (a x) + jacMatrix (b x))).det := det_mean _ _
    unfold jacMatrix at he
    rw [← he] at hd
    change Real.sqrt (a x).det * Real.sqrt (b x).det ≤ (L x).det at hd
    have hi := mul_le_mul (logMid (U x) (V x)) (hd.trans (le_abs_self _))
      (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)) (wn _)
    have da : 0 ≤ (a x).det := by simpa only [LinearMap.det_toMatrix'] using ha.det_nonneg
    have db : 0 ≤ (b x).det := by simpa only [LinearMap.det_toMatrix'] using hb.det_nonneg
    have ap := Real.sqrt_le_sqrt (px hx)
    have bp := Real.sqrt_le_sqrt (qx hx)
    rw [abs_of_nonneg da,Real.sqrt_mul da] at ap
    rw [abs_of_nonneg db,Real.sqrt_mul db] at bp
    apply le_trans (mul_le_mul ap bp (Real.sqrt_nonneg _) (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)))
    change _ ≤ _ * w (mid (U x) (V x))
    linarith only [hi]
  apply Measure.le_iff.mpr
  intro s hs
  change (weighted volume _).map M s ≤ _
  rw [Measure.map_apply hm hs]
  unfold weighted
  rw [withDensity_apply _ (hm hs),withDensity_apply _ hs]
  let F := fun x => ENNReal.ofReal (Real.sqrt (p x)*Real.sqrt (q x))
  have cut : F =ᵐ[volume] G.indicator F := by
    filter_upwards [cover] with x hx
    classical
    by_cases h : x ∈ G
    · simp [h]
    · rw [indicator_of_notMem h]
      by_cases hp : 0 < p x
      · have hq : q x ≤ 0 := le_of_not_gt (fun hq => h (hx hp hq))
        simp [F,Real.sqrt_eq_zero_of_nonpos hq]
      · simp [F,Real.sqrt_eq_zero_of_nonpos (le_of_not_gt hp)]
  change (∫⁻ x in M ⁻¹' s, F x) ≤ _
  rw [lintegral_congr_ae (ae_restrict_of_ae cut),lintegral_indicator hG,
    Measure.restrict_restrict hG]
  let T := G ∩ M ⁻¹' s
  have mT : MeasurableSet T := hG.inter (hm hs)
  have tr : T ⊆ G := inter_subset_left
  have cov := lintegral_image_eq_lintegral_abs_det_fderiv_mul volume mT
    (fun x hx => (reg x (tr hx)).mono tr) (injM.mono tr) (fun y => ENNReal.ofReal (w y))
  apply le_trans _ (lintegral_mono_set (μ := volume) (f := fun y => ENNReal.ofReal (w y))
    (show M '' T ⊆ s from image_subset_iff.mpr inter_subset_right))
  rw [cov]
  apply setLIntegral_mono_ae' mT
  filter_upwards [point] with x hx
  intro hxt
  change ENNReal.ofReal _ ≤ ENNReal.ofReal _ * ENNReal.ofReal _
  rw [← ENNReal.ofReal_mul (abs_nonneg _)]
  exact ENNReal.ofReal_le_ofReal (hx (tr hxt))

end
end SequentialRanks
