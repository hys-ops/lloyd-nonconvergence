import SGFiniteHarmonic
import SGFiniteTies

open MeasureTheory Set Filter
open scoped ENNReal NNReal BigOperators Function
namespace Vortex
noncomputable section

abbrev physicalMiddle {J : Set Space} (z : J × J) : Space := (1/2:ℝ) • (z.1.val+z.2.val)

private theorem rescale {J : Set Space} (W : ProbabilityMeasure J) (A : Set J)
    (pos : 0 < (W : Measure J).real A) :
    (W : Measure J) A • (((W : Measure J) A)⁻¹ • (W : Measure J).restrict A) = (W : Measure J).restrict A := by
  rw [smul_smul, ENNReal.mul_inv_cancel (ENNReal.toReal_pos_iff.mp pos).1.ne' (measure_ne_top (W : Measure J) A),one_smul]

private theorem fallback_cell {J : Set Space} (W : ProbabilityMeasure J) (A : Set J) :
    ∃ P : ProbabilityMeasure J, (W : Measure J) A • (P : Measure J) = (W : Measure J).restrict A := by
  by_cases h : (W : Measure J) A = 0
  · exact ⟨W,by simp [h,Measure.restrict_eq_zero.mpr h]⟩
  · have hi : IsProbabilityMeasure (((W : Measure J) A)⁻¹ • (W : Measure J).restrict A) := by
      constructor
      rw [Measure.smul_apply,smul_eq_mul,Measure.restrict_apply_univ,
        ENNReal.inv_mul_cancel h (measure_ne_top (W : Measure J) A)]
    exact ⟨⟨_,hi⟩,rescale W A (ENNReal.toReal_pos h (measure_ne_top (W : Measure J) A))⟩

/-- Drop the positive-mass restriction using an arbitrary probability for a missing
variable. The weighted marginals remain literal restricted measures in every case. -/
theorem harmonic_coupling {J : Set Space} [CompactSpace J] (mid : CellMidpoints)
    (conv : Convex ℝ J) (W : ProbabilityMeasure J) (unif : UniformBodyLaw J W)
    (A B : Set J) (mA : MeasurableSet A) (mB : MeasurableSet B) :
    ∃ γ : ProbabilityMeasure (J × J),
      (W : Measure J) A • (γ : Measure (J × J)).map Prod.fst = (W : Measure J).restrict A ∧
      (W : Measure J) B • (γ : Measure (J × J)).map Prod.snd = (W : Measure J).restrict B ∧
      ENNReal.ofReal (harmonicMass ((W : Measure J).real A) ((W : Measure J).real B)) •
          (γ : Measure (J × J)).map physicalMiddle ≤ (W : Measure J).map Subtype.val := by
  let a := (W : Measure J).real A
  let b := (W : Measure J).real B
  by_cases both : 0 < a ∧ 0 < b
  · obtain ⟨γ,fst,snd,dom⟩ := mid J conv W unif A B mA mB both.1 both.2
    refine ⟨γ,fst ▸ rescale W A both.1,snd ▸ rescale W B both.2,?_⟩
    apply le_trans ?_ dom
    intro s
    rw [Measure.smul_apply,Measure.smul_apply]
    exact mul_le_mul_of_nonneg_right (ENNReal.ofReal_le_ofReal (harmonic_le_sqrt measureReal_nonneg measureReal_nonneg)) zero_le
  · obtain ⟨P,hp⟩ := fallback_cell W A
    obtain ⟨Q,hq⟩ := fallback_cell W B
    let γ : ProbabilityMeasure (J × J) := ⟨(P : Measure J).prod (Q : Measure J),inferInstance⟩
    refine ⟨γ,?_,?_,?_⟩
    · simpa [γ] using hp
    · simpa [γ] using hq
    · have hz : a = 0 ∨ b = 0 := by
        by_contra! h
        exact both ⟨lt_of_le_of_ne measureReal_nonneg h.1.symm,lt_of_le_of_ne measureReal_nonneg h.2.symm⟩
      change ENNReal.ofReal (harmonicMass a b) • _ ≤ _
      rcases hz with ha|hb
      · rw [ha]; simp [harmonicMass]; exact bot_le
      · rw [hb]; simp [harmonicMass]; exact bot_le

def strictPower {N : ℕ} (site : Fin N → Space) (w : Fin N → ℝ) (i : Fin N) : Set Space :=
  {x | ∀ j, j ≠ i → linearScore (site j) x+w j < linearScore (site i) x+w i}

theorem strictPower_measurable {N : ℕ} (site : Fin N → Space) (w : Fin N → ℝ) (i : Fin N) :
    MeasurableSet (strictPower site w i) := by
  change MeasurableSet {x | ∀ j, j ≠ i → _}
  simp only [Set.ofPred_forall]
  apply MeasurableSet.iInter
  intro j
  exact MeasurableSet.iInter (fun _ => measurableSet_lt (by unfold linearScore; fun_prop) (by unfold linearScore; fun_prop))

theorem strictPower_disjoint {N : ℕ} (site : Fin N → Space) (w : Fin N → ℝ) :
    Pairwise (Disjoint on (strictPower site w)) := by
  intro i j hij
  apply Set.disjoint_left.mpr
  intro x hi hj
  exact (not_lt.mpr (hi j hij.symm).le) (hj i hij)

private theorem weighted_marginal_ae {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    {γ : Measure X} {μ : Measure Y} {A : Set Y} (mA : MeasurableSet A)
    {p : X → Y} (mp : Measurable p) (a : ℝ≥0∞) (nz : a ≠ 0)
    (law : a • γ.map p = μ.restrict A) {P : Y → Prop}
    (prop : ∀ᵐ y ∂μ, y ∈ A → P y) :
    ∀ᵐ x ∂γ,P (p x) := by
  apply ae_of_ae_map mp.aemeasurable
  have ch := (ae_restrict_iff' mA).mpr prop
  rw [←law] at ch
  rwa [Measure.ae_ennreal_smul_measure_iff nz] at ch

/-- The midpoint affine cell inequalities and null ties localize each weighted
law to a strictly winning label. Distinct labels then give disjoint sets. -/
theorem harmonic_cell_domination {J : Set Space} (W : ProbabilityMeasure J)
    (unif : UniformBodyLaw J W) {N : ℕ} (site : Fin N → Space) (inj : Function.Injective site)
    (w v : Fin N → ℝ) (a b : J → Fin N) (ma : Measurable a) (mb : Measurable b)
    (pa : ∀ᵐ x ∂(W:Measure J), ∀ j, linearScore (site j) x.val+w j ≤ linearScore (site (a x)) x.val+w (a x))
    (pb : ∀ᵐ x ∂(W:Measure J), ∀ j, linearScore (site j) x.val+v j ≤ linearScore (site (b x)) x.val+v (b x))
    (i : Fin N) (γ : ProbabilityMeasure (J × J))
    (la : (W : Measure J) (a ⁻¹' {i}) • (γ : Measure (J × J)).map Prod.fst = (W : Measure J).restrict (a ⁻¹' {i}))
    (lb : (W : Measure J) (b ⁻¹' {i}) • (γ : Measure (J × J)).map Prod.snd = (W : Measure J).restrict (b ⁻¹' {i}))
    (H : ℝ≥0∞) (dom : H • (γ : Measure (J × J)).map physicalMiddle ≤ (W : Measure J).map Subtype.val)
    (nonzero : H ≠ 0 → (W : Measure J) (a ⁻¹' {i}) ≠ 0 ∧ (W : Measure J) (b ⁻¹' {i}) ≠ 0) :
    H • (γ : Measure (J × J)).map physicalMiddle ≤
      ((W : Measure J).map Subtype.val).restrict (strictPower site (fun j => (w j+v j)/2) i) := by
  by_cases H0 : H=0
  · rw [H0,zero_smul]; exact bot_le
  let m := fun j => (w j+v j)/2
  let mid : J × J → Space := physicalMiddle
  have cm : Continuous mid := by unfold mid physicalMiddle; fun_prop
  obtain ⟨an,bn⟩ := nonzero H0
  have suppA := weighted_marginal_ae (ma (measurableSet_singleton i)) measurable_fst _ an la
    (P := fun x => ∀ j, linearScore (site j) x.val+w j ≤ linearScore (site i) x.val+w i)
    (pa.mono (fun x hx h => by simpa [show a x=i from h] using hx))
  have suppB := weighted_marginal_ae (mb (measurableSet_singleton i)) measurable_snd _ bn lb
    (P := fun x => ∀ j, linearScore (site j) x.val+v j ≤ linearScore (site i) x.val+v i)
    (pb.mono (fun x hx h => by simpa [show b x=i from h] using hx))
  let η := H • (γ : Measure (J × J)).map mid
  have weakcell : ∀ᵐ x ∂η, ∀ j, linearScore (site j) x+m j ≤ linearScore (site i) x+m i := by
    rw [show η = H • (γ : Measure (J × J)).map mid from rfl,Measure.ae_ennreal_smul_measure_iff H0]
    apply (ae_map_iff cm.measurable.aemeasurable ?_).mpr
    · filter_upwards [suppA,suppB] with s hx hy
      intro j
      have linear (p : Space) : linearScore p (mid s) = (linearScore p s.1.val+linearScore p s.2.val)/2 := by
        unfold mid physicalMiddle linearScore
        change p.1.1*((1/2:ℝ)*(s.1.val.1.1+s.2.val.1.1))+
          p.1.2*((1/2:ℝ)*(s.1.val.1.2+s.2.val.1.2))+p.2*((1/2:ℝ)*(s.1.val.2+s.2.val.2)) = _
        ring
      rw [linear,linear]
      dsimp [m]
      linarith [hx j,hy j]
    · simp only [Set.ofPred_forall]
      exact MeasurableSet.iInter fun j => measurableSet_le (by unfold linearScore; fun_prop)
        (by unfold linearScore; fun_prop)
  have strict : ∀ᵐ x ∂η, x ∈ strictPower site m i := by
    have tie (j : Fin N) : ∀ᵐ x ∂η, j ≠ i → linearScore (site j) x + m j ≠ linearScore (site i) x + m i := by
      by_cases h : j=i
      · simp [h]
      · have tn := (uniform_tie_null W unif site inj m h).1
        have ne : ∀ᵐ x ∂((W : Measure J).map Subtype.val), linearScore (site j) x + m j ≠ linearScore (site i) x + m i :=
          ae_iff.mpr (by simpa using tn)
        exact (ne.filter_mono (ae_mono dom)).mono fun _ hx _ => hx
    filter_upwards [weakcell,ae_all_iff.mpr tie] with x hw ht
    exact fun j hj => lt_of_le_of_ne (hw j) (ht j hj)
  exact (Measure.restrict_eq_self_of_ae_mem strict).ge.trans (Measure.restrict_mono subset_rfl dom)

/-- Choose all couplings simultaneously for two actual power partitions. The
strictly winning averaged cells are disjoint even when some endpoint mass vanishes. -/
theorem finite_power_couplings (input : CellMidpoints) (J : Set Space) [CompactSpace J]
    (conv : Convex ℝ J) (W : ProbabilityMeasure J) (unif : UniformBodyLaw J W)
    {N : ℕ} (site : Fin N → Space) (inj : Function.Injective site)
    (a b : J → Fin N) (ma : Measurable a) (mb : Measurable b)
    (pa : PowerLabels W site Subtype.val a) (pb : PowerLabels W site Subtype.val b) :
    ∃ (γ : Fin N → ProbabilityMeasure (J × J)) (S : Fin N → Set Space),
      (∀ i,MeasurableSet (S i)) ∧ Pairwise (Disjoint on S) ∧
      (∀ i,(W : Measure J) (a ⁻¹' {i}) • (γ i : Measure (J × J)).map Prod.fst =
        (W : Measure J).restrict (a ⁻¹' {i})) ∧
      (∀ i,(W : Measure J) (b ⁻¹' {i}) • (γ i : Measure (J × J)).map Prod.snd =
        (W : Measure J).restrict (b ⁻¹' {i})) ∧
      ∀ i, ENNReal.ofReal (harmonicMass ((W : Measure J).real (a ⁻¹' {i}))
          ((W : Measure J).real (b ⁻¹' {i}))) • (γ i : Measure (J × J)).map physicalMiddle ≤
            ((W : Measure J).map Subtype.val).restrict (S i) := by
  obtain ⟨w,aw⟩ := pa
  obtain ⟨v,bv⟩ := pb
  choose γ ha hb dom using fun i : Fin N => harmonic_coupling input conv W unif _ _
    (ma (measurableSet_singleton i)) (mb (measurableSet_singleton i))
  let m := fun j => (w j+v j)/2
  refine ⟨γ,strictPower site m,strictPower_measurable site m,strictPower_disjoint site m,ha,hb,?_⟩
  intro i
  apply harmonic_cell_domination W unif site inj w v a b ma mb aw bv i (γ i)
    (ha i) (hb i) _ (dom i)
  intro hn
  constructor
  · intro hz
    exact hn (by simp [harmonicMass,Measure.real,hz])
  · intro hz
    exact hn (by simp [harmonicMass,Measure.real,hz])

end
end Vortex
