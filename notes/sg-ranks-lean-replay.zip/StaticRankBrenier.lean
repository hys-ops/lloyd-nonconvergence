import StaticRankDual
import StaticRankGraph
import StaticRankCycOptimal
import RankPotential

open MeasureTheory Filter Set
open scoped NNReal ENNReal Topology
namespace SequentialRanks
noncomputable section

def minimizesSquare {d : ℕ} {A B : Set (RankPoint d)}
    (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B) (π : ProbabilityMeasure (A × B)) :=
  ∀ γ : ProbabilityMeasure (A × B), γ.map Prod.fst = P → γ.map Prod.snd = Q →
    (∫ z, squareCost z ∂(π : Measure (A × B))) ≤ ∫ z, squareCost z ∂(γ : Measure (A × B))

private theorem csquare {d : ℕ} (A B : Set (RankPoint d)) : Continuous (squareCost (A := A) (B := B)) := by
  have u (i : Fin d) : Continuous (fun z : A × B => z.1.val i) :=
    (continuous_apply i).comp (continuous_subtype_val.comp continuous_fst)
  have v (i : Fin d) : Continuous (fun z : A × B => z.2.val i) :=
    (continuous_apply i).comp (continuous_subtype_val.comp continuous_snd)
  unfold squareCost normSq diff; fun_prop

/-- A squared-cost plan on compact Euclidean supports is optimal if and only if
its support is cyclically monotone. The dual construction proves the reverse
direction without using a static transport theorem. -/
theorem cyclic_iff_optimal {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B) (π : ProbabilityMeasure (A × B))
    (mP : π.map Prod.fst = P) (mQ : π.map Prod.snd = Q) :
    cyclicSupport squareCost π ↔ minimizesSquare P Q π := by
  let _ : CompactSpace A := isCompact_iff_compactSpace.mp ha
  let _ : CompactSpace B := isCompact_iff_compactSpace.mp hb
  constructor
  · intro cy
    obtain ⟨φ,L,lip,_,support⟩ := square_cyclic_potential A B hb π cy
    obtain ⟨D,_,pos,vanish,_,k,expect⟩ := compact_support_duality A B ha hb P Q φ lip.continuous
    have ez : (∫ z, D z ∂(π : Measure _)) = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [(π : Measure (A × B)).support_mem_ae] with z hz
      exact vanish z (support z hz)
    intro γ h1 h2
    rw [expect π mP mQ,expect γ h1 h2,ez]
    linarith only [integral_nonneg (f := D) (μ := (γ : Measure (A × B))) pos]
  · exact fun h => optimal_plan_is_cyclic squareCost (csquare A B) π
      (fun γ h1 h2 => h γ (h1.trans mP) (h2.trans mQ))

/-- Static compact-support quadratic Brenier theorem, with an actual Lipschitz
convex potential and a single graph plan. Source absolute continuity is the
only density hypothesis; the target may be singular. -/
theorem compact_brenier {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    [Nonempty B] (P : ProbabilityMeasure A) (Q : ProbabilityMeasure B)
    (ac : (P : Measure A).map Subtype.val ≪ volume) :
    ∃ (φ : RankPoint d → ℝ) (L : ℝ≥0) (π : ProbabilityMeasure (A × B)), LipschitzWith L φ ∧
      ConvexOn ℝ univ φ ∧ certifiedPlan squareCost P Q π ∧ minimizesSquare P Q π ∧
      (∀ z ∈ (π : Measure (A × B)).support, globalSupports φ z.1.val z.2.val) ∧
      P.map (fun x => (x,supportGradient (A := A) (B := B) φ x)) = π ∧
      ∀ γ : ProbabilityMeasure (A × B), certifiedPlan squareCost P Q γ → γ = π := by
  let _ : CompactSpace A := isCompact_iff_compactSpace.mp ha
  let _ : CompactSpace B := isCompact_iff_compactSpace.mp hb
  obtain ⟨π,cert,opt⟩ := compact_cyclic_optimal_plan P Q squareCost (csquare A B)
  obtain ⟨φ,L,lip,conv,support⟩ := square_cyclic_potential A B hb π cert.2.2
  obtain ⟨D,cD,pos,vanish,contact,k,expect⟩ := compact_support_duality A B ha hb P Q φ lip.continuous
  have iD (γ : ProbabilityMeasure (A × B)) : Integrable D (γ : Measure _) := by
    let g : C(A × B,ℝ) := ⟨D,cD⟩
    exact (integrable_const ‖g‖).mono' cD.aestronglyMeasurable (.of_forall g.norm_coe_le_norm)
  have ez : D =ᵐ[(π : Measure _)] 0 := by
    filter_upwards [(π : Measure (A × B)).support_mem_ae] with z hz
    exact vanish z (support z hz)
  have iz := integral_eq_zero_of_ae ez
  have graph (γ : ProbabilityMeasure (A × B)) (hf : γ.map Prod.fst = P)
      (zero : D =ᵐ[(γ : Measure _)] 0) :
      P.map (fun x => (x,supportGradient (A := A) (B := B) φ x)) = γ := by
    apply graph_of_lipschitz_contact hb.isClosed.measurableSet γ P hf ac φ lip
    filter_upwards [zero] with z hz using contact z hz
  have ge := graph π cert.1 ez
  refine ⟨φ,L,π,lip,conv,cert,opt,support,ge,?_⟩
  intro γ cg
  have optγ := (cyclic_iff_optimal A B ha hb P Q γ cg.1 cg.2.1).mp cg.2.2
  have bound := optγ π cert.1 cert.2.1
  rw [expect γ cg.1 cg.2.1,expect π cert.1 cert.2.1,iz] at bound
  have zg : (∫ z, D z ∂(γ : Measure _)) = 0 :=
    le_antisymm (by linarith) (integral_nonneg pos)
  exact (graph γ cg.1 ((integral_eq_zero_iff_of_nonneg pos (iD γ)).mp zg)).symm.trans ge

/-- Jointly measurable conditional ranks directly from compactly supported
Lebesgue densities; no pointwise Brenier, selection or uniqueness premise. -/
theorem ranks_from_lebesgue_densities {H : Type*} [MeasurableSpace H] {d : ℕ}
    (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B) [Nonempty B]
    (p : H × A → ℝ≥0∞) (hp : Measurable p)
    (unit : ∀ h, (∫⁻ y, p (h,y) ∂(Measure.comap Subtype.val (volume : Measure (RankPoint d))))=1)
    (target : ProbabilityMeasure B) (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2) :
    ∃ S : H × A → RankPoint d, Measurable S ∧ (∀ z, normSq (S z) ≤ R^2) ∧
      ∀ h, ∃ π : ProbabilityMeasure (A × B),
        certifiedPlan squareCost (densityLaw (Measure.comap Subtype.val volume) p unit h) target π ∧
        ((densityLaw (Measure.comap Subtype.val volume) p unit h : Measure A).map (fun y => (y,S (h,y)))) =
          (π : Measure (A × B)).map (fun z => (z.1,z.2.1)) := by
  let μ : Measure A := Measure.comap Subtype.val volume
  let _ : IsFiniteMeasure μ := ⟨by
    apply (Measure.comap_apply_le _ _ nullMeasurableSet_univ).trans_lt
    simpa using (ha.measure_lt_top (μ := (volume : Measure (RankPoint d))))⟩
  let F := densityLaw μ p unit
  have haM := ha.isClosed.measurableSet
  have ac (h : H) : ((F h : Measure A).map Subtype.val) ≪ volume := by
    have base : μ.map Subtype.val = volume.restrict A := map_comap_subtype_coe haM _
    have dens : (F h : Measure A) ≪ μ := withDensity_absolutelyContinuous _ _
    exact (dens.map measurable_subtype_coe).trans (base ▸ Measure.restrict_le_self.absolutelyContinuous)
  have static := fun h => compact_brenier A B ha hb (F h) target (ac h)
  apply rank_selection_for_densities A B ha hb μ p hp unit target R ball
  · intro h
    obtain ⟨_,_,π,_,_,cert,_,_,_,unique⟩ := static h
    exact ⟨π,cert,unique⟩
  · intro h
    obtain ⟨φ,_,π,_,_,cert,_,_,mapEq,_⟩ := static h
    exact ⟨supportGradient φ,measurable_supportGradient hb.isClosed.measurableSet φ,mapEq ▸ cert⟩

end
end SequentialRanks
