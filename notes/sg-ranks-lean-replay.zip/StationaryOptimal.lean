import StationaryGeometry

open MeasureTheory Set Filter
namespace Vortex
noncomputable section

/-- The part of the classical static uniqueness theorem used below: any competing
transport with exactly the same quadratic cost agrees with the given minimizer. -/
structure UniqueMongeMap (ν η : Measure Space) (S : Space → Space) : Prop where
  measurable : Measurable S
  pushes : ν.map S = η
  unique_at_cost : ∀ G : Space → Space, Measurable G → ν.map G = η →
    (∫ y, quadraticCost y (G y) ∂ν) = (∫ y, quadraticCost y (S y) ∂ν) → G =ᵐ[ν] S

/-- Conjugate an actual map by a common isometry of its two marginals.
Its graph has exactly the same cost, so static uniqueness yields a.e. equivariance. -/
theorem monge_symmetry (ν η : Measure Space) (S : Space → Space) (opt : UniqueMongeMap ν η S)
    (T U : Space → Space) (mT : Measurable T) (mU : Measurable U)
    (left : ∀ y, U (T y)=y) (right : ∀ y, T (U y)=y)
    (src : ν.map T=ν) (dst : η.map U=η)
    (iso : ∀ y x, quadraticCost (U y) (U x) = quadraticCost y x) :
    ∀ᵐ y ∂ν, S (T y) = T (S y) := by
  let G := U ∘ S ∘ T
  have mG : Measurable G := mU.comp (opt.measurable.comp mT)
  have marg : ν.map G=η := by
    unfold G; rw [← Measure.map_map mU (opt.measurable.comp mT),← Measure.map_map opt.measurable mT,
      src,opt.pushes,dst]
  let c := fun y => quadraticCost y (S y)
  have mc : Measurable c := by
    have h := opt.measurable
    unfold c quadraticCost distSq
    fun_prop
  have pt (y : Space) : quadraticCost y (G y) = c (T y) := by
    simpa only [left,G,c,Function.comp_apply] using iso (T y) (S (T y))
  have val : (∫ y, quadraticCost y (G y) ∂ν) = ∫ y, quadraticCost y (S y) ∂ν := by
    simp_rw [pt]
    rw [← integral_map mT.aemeasurable mc.aestronglyMeasurable,src]
  filter_upwards [opt.unique_at_cost G mG marg val] with y hy
  change U (S (T y))=S y at hy
  rw [← hy,right]

private theorem cost_rotation (θ : ℝ) (y x : Space) :
    quadraticCost (rotateMap θ y) (rotateMap θ x) = quadraticCost y x := by
  unfold rotateMap quadraticCost distSq; dsimp
  have h := Real.sin_sq_add_cos_sq θ
  have a := congrArg (fun t : ℝ => t*(y.1.1-x.1.1)^2) h
  have b := congrArg (fun t : ℝ => t*(y.1.2-x.1.2)^2) h
  nlinarith only [a,b]

private theorem rot_inverse (θ : ℝ) (y : Space) : rotateMap (-θ) (rotateMap θ y) = y := by
  rw [rotate_compose,neg_add_cancel]; simp [rotateMap]

/-- Joint source and target symmetries give rotation and reflection covariance
of the unique quadratic Monge map without choosing a common exceptional set. -/
theorem orthogonal_covariance (ν η : Measure Space) (S : Space → Space) (opt : UniqueMongeMap ν η S)
    (src : (∀ θ, ν.map (rotateMap θ)=ν) ∧ ν.map mirrorMap=ν)
    (dst : (∀ θ, η.map (rotateMap θ)=η) ∧ η.map mirrorMap=η) :
    (∀ θ, ∀ᵐ y ∂ν, S (rotateMap θ y)=rotateMap θ (S y)) ∧
      ∀ᵐ y ∂ν, S (mirrorMap y)=mirrorMap (S y) := by
  constructor
  · intro θ
    exact monge_symmetry ν η S opt (rotateMap θ) (rotateMap (-θ))
      (rotation_volume θ).measurable (rotation_volume (-θ)).measurable
      (rot_inverse θ) (by simpa using rot_inverse (-θ)) (src.1 θ) (dst.1 (-θ)) (cost_rotation (-θ))
  · apply monge_symmetry ν η S opt mirrorMap mirrorMap mirror_volume.measurable mirror_volume.measurable
    · intro y; simp [mirrorMap]
    · intro y; simp [mirrorMap]
    · exact src.2
    · exact dst.2
    · intro y x; unfold quadraticCost distSq mirrorMap; dsimp; ring
end
end Vortex
