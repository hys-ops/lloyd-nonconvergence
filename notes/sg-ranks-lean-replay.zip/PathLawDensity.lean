import FiniteCatalogRisk

open MeasureTheory Measure Filter Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

private def uniformForecast (H Y : Type*) [MeasurableSpace H] [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] [NeZero ν] : Forecast H Y ν where
  f := fun _ => (ν.real univ)⁻¹
  measurable := measurable_const
  nonneg := fun _ => inv_nonneg.mpr (by positivity)
  integrable := fun _ => integrable_const _
  mass := fun _ => by simp [integral_const, smul_eq_mul, measureReal_univ_ne_zero]

/-- Split a joint density into its first marginal and a normalized one-step forecast.
Zero-mass sections use a fixed probability density. -/
theorem joint_density_step {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    (μ : Measure H) [SFinite μ] (ν : Measure Y) [IsFiniteMeasure ν] [NeZero ν]
    (p : H × Y → ℝ) (mp : Measurable p) (np : ∀ z, 0 ≤ p z) (ip : Integrable p (μ.prod ν)) :
    ∃ f : Forecast H Y ν, ∀ᵐ z ∂μ.prod ν, (∫ y, p (z.1,y) ∂ν) * f.f z = p z := by
  let m := fun h => ∫ y, p (h,y) ∂ν
  have mm : Measurable m := mp.stronglyMeasurable.integral_prod_right'.measurable
  have nm h : 0 ≤ m h := integral_nonneg (fun _ => np _)
  have isec h (hp : 0 < m h) : Integrable (fun y => p (h,y)) ν := by
    by_contra hh
    exact hp.ne' (integral_undef hh)
  let fallback := uniformForecast H Y ν
  let f : Forecast H Y ν :=
    { f := fun z => if 0 < m z.1 then p z / m z.1 else fallback.f z
      measurable := Measurable.ite (measurable_fst (measurableSet_lt measurable_const mm))
        (mp.div (mm.comp measurable_fst)) fallback.measurable
      nonneg := fun z => by split_ifs; exact div_nonneg (np _) (nm _); exact fallback.nonneg _
      integrable := fun h => by
        dsimp only; split_ifs with hp
        · exact (isec h hp).div_const _
        · exact fallback.integrable h
      mass := fun h => by
        dsimp only; split_ifs with hp
        · rw [integral_div]; exact div_self hp.ne'
        · exact fallback.mass h }
  refine ⟨f, (ae_prod_iff_ae_ae (measurableSet_eq_fun ((mm.comp measurable_fst).mul f.measurable) mp)).2 ?_⟩
  filter_upwards [ip.prod_right_ae] with h ih
  by_cases hp : 0 < m h
  · exact Eventually.of_forall fun y => by
      change m h * (if 0 < m h then _ else _) = _
      simp only [hp, ite_true, mul_comm (m h), div_mul_cancel₀ _ hp.ne']
  · have hm : m h = 0 := le_antisymm (not_lt.mp hp) (nm h)
    have hz := (integral_eq_zero_iff_of_nonneg_ae (Eventually.of_forall fun y => np (h,y)) ih).mp hm
    filter_upwards [hz] with y hy
    change m h * _ = _
    rw [hm, zero_mul]; exact hy.symm

private theorem prefix_density_congr {Y : Type*} [MeasurableSpace Y] {ν : Measure Y}
    (a b : Predictions Y ν) (n : ℕ) (same : ∀ t, t < n → a t = b t) :
    historyDensity a n = historyDensity b n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    funext z
    change historyDensity a n z.1 * (a n).f z = historyDensity b n z.1 * (b n).f z
    rw [ih (fun t ht => same t (by omega)), same n (by omega)]

/-- Every normalized finite-horizon joint density is the product of measurable forecasts
which are probability densities at every history, including histories of zero probability. -/
theorem exists_predictions_joint_density {Y : Type*} [MeasurableSpace Y]
    (ν : Measure Y) [IsFiniteMeasure ν] [NeZero ν] (T : ℕ)
    (p : History Y T → ℝ) (mp : Measurable p) (np : ∀ z, 0 ≤ p z)
    (ip : Integrable p (historyBase ν T)) (mass : (∫ z, p z ∂historyBase ν T) = 1) :
    ∃ a : Predictions Y ν, historyDensity a T =ᵐ[historyBase ν T] p := by
  classical
  induction T with
  | zero =>
    let a : Predictions Y ν := fun n => uniformForecast (History Y n) Y ν
    refine ⟨a, Eventually.of_forall ?_⟩
    intro z
    cases z
    change (∫ z, p z ∂Measure.dirac PUnit.unit) = 1 at mass
    have hdir : (∫ z, p z ∂historyBase ν 0) = p PUnit.unit := integral_dirac' p _ mp.stronglyMeasurable
    rw [← hdir]
    exact mass.symm

  | succ n ih =>
    let m := fun h => ∫ y, p (h,y) ∂ν
    have mp' : Measurable (p : History Y n × Y → ℝ) := mp
    have ip' : Integrable (p : History Y n × Y → ℝ) ((historyBase ν n).prod ν) := ip
    obtain ⟨a, ha⟩ := ih m mp'.stronglyMeasurable.integral_prod_right'.measurable
      (fun h => integral_nonneg (fun y => np (h,y))) ip'.integral_prod_left
      ((integral_prod p ip').symm.trans mass)
    obtain ⟨f, hf⟩ := joint_density_step (historyBase ν n) ν p mp' np ip'
    let b := Function.update a n f
    have same : historyDensity b n = historyDensity a n :=
      prefix_density_congr b a n (fun t ht => Function.update_of_ne (Nat.ne_of_lt ht) f a)
    have last : b n = f := Function.update_self n f a
    refine ⟨b, ?_⟩
    change ∀ᵐ z ∂(historyBase ν n).prod ν, historyDensity b n z.1 * (b n).f z = p z
    filter_upwards [quasiMeasurePreserving_fst.ae ha, hf] with z hprev hstep
    rw [same, last, hprev]
    exact hstep

end
end SequentialRanks
