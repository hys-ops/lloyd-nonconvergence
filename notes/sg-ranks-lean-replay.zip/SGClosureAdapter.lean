import SGClosure
import SGClosureBrenierDef

open MeasureTheory Filter Set
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

private theorem physical_graph_marginals {D : Set Space} (P : ProbabilityMeasure Space)
    (U : Space → D) (mU : Measurable U) :
    (physicalGraph P U).map Prod.fst = P ∧ (physicalGraph P U).map Prod.snd = P.map U := by
  have m : Measurable (fun y => (y,U y)) := measurable_id.prodMk mU
  constructor <;> apply ProbabilityMeasure.toMeasure_injective
  · change ((P : Measure Space).map _).map Prod.fst = _
    rw [Measure.map_map measurable_fst m]; exact Measure.map_id
  · change ((P : Measure Space).map _).map Prod.snd = _
    rw [Measure.map_map measurable_snd m]; rfl

private theorem physical_graph_pushes {D : Set Space} {P : ProbabilityMeasure Space}
    {T : ProbabilityMeasure D} {U : Space → D} (g : PhysicalBrenierGraph D P T U) :
    (P : Measure Space).map (fun y => (U y).val) = (T : Measure D).map Subtype.val := by
  have law := (physical_graph_marginals P U g.measurable).2.symm.trans g.certified.2.1
  have orig := congrArg (fun l : ProbabilityMeasure D => (l : Measure D).map Subtype.val) law
  change (P : Measure Space).map (Subtype.val ∘ U) = _
  simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_subtype_coe g.measurable] using orig

private theorem graph_cost_on_patch {D : Set Space} (A : Set Space) (d : ℝ≥0)
    (mass : (d : ℝ≥0∞)*volume A=1) (U : Space → D) (mu : Measurable U) :
    (∫ z, physicalCost D z ∂(physicalGraph (patchProbability A d mass) U : Measure _)) =
      (d : ℝ)*(∫ y in A, quadraticCost y (U y).val) := by
  have mg : Measurable (fun y => (y,U y)) := measurable_id.prodMk mu
  have continuousCost : Continuous (physicalCost D) := by unfold physicalCost quadraticCost distSq; fun_prop
  change (∫ z, physicalCost D z ∂Measure.map (fun y => (y,U y)) ((d : ℝ≥0∞) • volume.restrict A)) = _
  rw [integral_map mg.aemeasurable continuousCost.aestronglyMeasurable,integral_smul_measure]
  rfl

private theorem raw_competitor_from_graph (D A : Set Space) (hD : MeasurableSet D) (T : ProbabilityMeasure D)
    (d : ℝ≥0) (hd : 0<d) (mass : (d : ℝ≥0∞)*volume A=1) (U : Space → D)
    (g : PhysicalBrenierGraph D (patchProbability A d mass) T U)
    (F : Space → Space) (mf : Measurable F)
    (moves : (volume.restrict A).map F = (d : ℝ≥0∞)⁻¹ • (T : Measure D).map Subtype.val) :
    ((∫ y in A, quadraticCost y (U y).val) ≤ ∫ y in A, quadraticCost y (F y)) ∧
    ((∫ y in A, quadraticCost y (F y)) = (∫ y in A, quadraticCost y (U y).val) →
       F =ᵐ[volume.restrict A] (fun y => (U y).val)) := by
  classical
  let P := patchProbability A d mass
  have ne : (d : ℝ≥0∞) ≠ 0 := by exact_mod_cast hd.ne'
  have positive : 0 < (d : ℝ) := by exact_mod_cast hd
  have law : (P : Measure Space).map F = (T : Measure D).map Subtype.val := by
    change ((d : ℝ≥0∞) • volume.restrict A).map F = _
    rw [Measure.map_smul _ mf.aemeasurable,moves,smul_smul,
      ENNReal.mul_inv_cancel ne ENNReal.coe_ne_top,one_smul]
  have entire : ∀ᵐ y ∂(P : Measure Space), F y ∈ D := by
    apply (ae_map_iff mf.aemeasurable hD).mp
    rw [law]
    exact (ae_map_iff measurable_subtype_coe.aemeasurable hD).mpr (.of_forall (fun z => z.property))
  let safe := (F ⁻¹' D).piecewise F (fun _ => (U 0).val)
  have sm : Measurable safe := mf.piecewise (mf hD) measurable_const
  have contained (y : Space) : safe y ∈ D := by
    by_cases h : F y ∈ D
    · simp [safe,mem_preimage,h]
    · simp [safe,mem_preimage,h]
  let W : Space → D := fun y => ⟨safe y,contained y⟩
  have mw : Measurable W := sm.subtype_mk
  have same : (fun y => (W y).val) =ᵐ[(P : Measure Space)] F :=
    entire.mono (fun y hy => Set.piecewise_eq_of_mem (F ⁻¹' D) F (fun _ => (U 0).val) (show y ∈ F ⁻¹' D from hy))
  have sameRaw : (fun y => (W y).val) =ᵐ[volume.restrict A] F := (Measure.ae_ennreal_smul_measure_iff ne).mp same
  have second : P.map W = T := by
    apply ProbabilityMeasure.toMeasure_injective
    apply (MeasurableEmbedding.subtype_coe hD).map_injective
    change ((P : Measure Space).map W).map Subtype.val = _
    rw [Measure.map_map measurable_subtype_coe mw]
    exact (Measure.map_congr same).trans law
  have marg := physical_graph_marginals P W mw
  have opt := g.optimal (physicalGraph P W) marg.1 (marg.2.trans second)
  have vcost := graph_cost_on_patch A d mass U g.measurable
  have wcost := (graph_cost_on_patch A d mass W mw).trans
    (congrArg (fun c : ℝ => (d : ℝ)*c) (integral_congr_ae
      (sameRaw.mono (fun y hy => congrArg (quadraticCost y) hy))))
  refine ⟨?_,fun eq => ?_⟩
  · have le := opt.1
    rw [vcost,wcost] at le
    exact (mul_le_mul_iff_right₀ positive).mp le
  · have plans := opt.2 (wcost.trans ((congrArg (fun c : ℝ => (d : ℝ)*c) eq).trans vcost.symm))
    let B := {z : Space × D | z.2=U z.1}
    have mB : MeasurableSet B := measurableSet_eq_fun measurable_snd (g.measurable.comp measurable_fst)
    have ones : ∀ᵐ z ∂(physicalGraph P U : Measure (Space × D)), z ∈ B :=
      (ae_map_iff (measurable_id.prodMk g.measurable).aemeasurable mB).mpr (.of_forall (fun _ => rfl))
    have wf : ∀ᵐ z ∂(physicalGraph P W : Measure (Space × D)), z ∈ B := plans ▸ ones
    have wU : W =ᵐ[(P : Measure Space)] U := (ae_map_iff (measurable_id.prodMk mw).aemeasurable mB).mp wf
    apply (Measure.ae_ennreal_smul_measure_iff (μ := volume.restrict A) ne).mp
    exact same.symm.trans (wU.mono (fun y hy => congrArg Subtype.val hy))

/-- A static proof at probability mass yields the precise unnormalized
minimization input of the torque/conservation argument. -/
theorem current_of_physical_graph (D A : Set Space) (hD : MeasurableSet D) (T : ProbabilityMeasure D)
    (d : ℝ≥0) (hd : 0<d) (mass : (d : ℝ≥0∞)*volume A=1) (U : Space → D)
    (g : PhysicalBrenierGraph D (patchProbability A d mass) T U) :
    CurrentBrenier D T A d mass U :=
  ⟨g.measurable,physical_graph_pushes g,fun F mf moves _ =>
    (raw_competitor_from_graph D A hD T d hd mass U g F mf moves).1,g.cyclic_unique⟩

/-- A competing ambient map of equal cost agrees on the raw reference patch
almost everywhere, even if its chosen representative leaves D on a null set. -/
theorem reference_of_physical_graph (D A : Set Space) (hD : MeasurableSet D) (T : ProbabilityMeasure D)
    (d : ℝ≥0) (hd : 0<d) (mass : (d : ℝ≥0∞)*volume A=1) (U : Space → D)
    (g : PhysicalBrenierGraph D (patchProbability A d mass) T U) :
    ReferenceBrenier D T A d mass U :=
  ⟨g.measurable,⟨measurable_subtype_coe.comp g.measurable,
    raw_push_of_probability A d hd mass _ _ (measurable_subtype_coe.comp g.measurable) (physical_graph_pushes g),
    fun F mf moves => (raw_competitor_from_graph D A hD T d hd mass U g F mf moves).2⟩,g.cyclic_unique⟩

end
end Vortex
