import Audit
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command

run_cmd do
  let env ← getEnv
  let modules := #[`CellMidpointArea, `CellMidpointDensity, `ConditionalRank, `ConservedPatch, `ContinuumCells, `ContinuumDensity, `ContinuumGrid, `ContinuumLimit, `ContinuumPhysical, `ContinuumPlans, `ContinuumPower, `ContinuumUniform, `CyclicPlans, `DensityChain, `DiskArea, `DiskRearrangement, `FiniteCatalogChart, `FiniteCatalogMinimax, `FiniteCatalogRisk, `FiniteCatalogSquare, `Geometry, `ImpulseTransport, `KernelRanks, `MinimaxLowerIID, `MinimaxLowerInformation, `MinimaxLowerJoint, `MinimaxLowerPaths, `MinimaxLowerPrior, `MinimaxLowerSquare, `MinimaxUpper, `MinimaxUpperIID, `MinimaxUpperJoint, `MinimaxUpperKL, `MinimaxUpperKernel, `MinimaxUpperParametric, `MinimaxUpperPrior, `MinimaxUpperRanks, `MinimaxUpperSelection, `PatchDynamics, `PatchTheorem, `PathLawConditional, `PathLawDensity, `PathLawPublic, `PathLawRepresentation, `PredictiveRanks, `PublishedSG, `RankExamples, `RankFenchel, `RankMinty, `RankMintyConvex, `RankMintyDirections, `RankMintyPSDLimit, `RankMintyPSDLinear, `RankPair, `RankPath, `RankPotential, `RankSquare, `RankTransport, `Ranks, `SG, `SGCellChartLaws, `SGCellMidpoints, `SGClosure, `SGClosureAdapter, `SGClosureBrenier, `SGClosureBrenierDef, `SGClosureChart, `SGClosureChartPlans, `SGClosureComplete, `SGClosureCyclic, `SGClosureData, `SGClosureFlux, `SGClosureIntegrals, `SGClosureMoments, `SGClosurePublic, `SGClosureSolution, `SGEndpointPublic, `SGFiniteBrenier, `SGFiniteConclusion, `SGFiniteCoupling, `SGFiniteHarmonic, `SGFiniteMidpointInput, `SGFiniteTies, `SGPowerCells, `SliceTransport, `SquareIIDUpper, `SquareMinimax, `SquareModel, `SquarePolicies, `StaticPathOracle, `StaticPathOracleMixture, `StaticPathOraclePublic, `StaticRankBrenier, `StaticRankBridge, `StaticRankConvex, `StaticRankCycOptimal, `StaticRankDet, `StaticRankDual, `StaticRankExistence, `StaticRankFinish, `StaticRankGeometry, `StaticRankGraph, `StaticRankInverse, `StaticRankKL, `StaticRankPlans, `StaticRankPublicUpper, `StaticRankSubtype, `StationaryAverage, `StationaryFlux, `StationaryGeometry, `StationaryOptimal, `StationaryPatch, `StationaryReference, `StretchEndpoint, `Torque, `WeakTime, `WeakTimeBounds, `WeakTimeCommon, `WeakTimeMoments, `WeakTimePatch, `WeakTimeRenormalized, `WeakTimeTwoDates]
  let moduleNames := env.header.moduleNames
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  let mut counts : Std.HashMap Name Nat := {}
  let mut allAx : NameSet := {}
  let mut numPriv : Nat := 0
  let mut numThms : Nat := 0
  for (decl, ci) in env.constants.toList do
    let some idx := env.getModuleIdxFor? decl | continue
    let modName := moduleNames[idx.toNat]!
    unless modules.contains modName do continue
    let ax ← collectAxioms decl
    for a in ax do
      unless allowed.contains a do throwError "Unexpected axiom {a} for {decl} in {modName}"
      allAx := allAx.insert a
    counts := counts.insert modName (counts.getD modName 0 + 1)
    if isPrivateName decl then numPriv := numPriv + 1
    if ci.isTheorem then numThms := numThms + 1
  for m in modules do
    unless counts.contains m do throwError "No kernel declarations found for {m}"
    logInfo m!"{m} {counts.getD m 0}"
  let total := counts.toList.foldl (fun n p => n+p.2) 0
  logInfo m!"DECLARATION AUDIT PASS: {total} constants, {numThms} theorems, {numPriv} private names. Axioms {allAx.toArray.qsort Name.lt}."
