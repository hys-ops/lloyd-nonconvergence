import StationaryPatch

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

/-- Circularization retains the total mass of every finite measurable input patch. -/
theorem circular_volume_eq (E : Set Space) (me : MeasurableSet E) (fin : volume E ≠ ⊤) :
    volume (circular E) = volume E := by
  have ms : Measurable (fun z => volume (slice E z)) := measurable_measure_prodMk_right me
  have mb : MeasurableSet (circular E) := measurableSet_le (areaCoord_meas.comp measurable_fst)
    ((ENNReal.measurable_toReal.comp ms).comp measurable_snd)
  have sections (A : Set Space) (ma : MeasurableSet A) :
      volume A = ∫⁻ z, volume (slice A z) := Measure.prod_apply_symm ma
  have fe : ∀ᵐ z : ℝ, volume (slice E z) < ⊤ := ae_lt_top ms (by rwa [← sections E me])
  rw [sections _ mb,sections _ me]
  apply lintegral_congr_ae
  filter_upwards [fe] with z hz
  rw [circular_slice,disk,disk_area,Measure.real,ENNReal.ofReal_toReal hz.ne]

private theorem radial_rotate (a : ℝ) (y : Space) : radialSquare (rotateMap a y)=radialSquare y := by
  unfold rotateMap radialSquare; dsimp
  nlinarith only [congrArg (fun t : ℝ => t*y.1.1^2) (Real.sin_sq_add_cos_sq a),
    congrArg (fun t : ℝ => t*y.1.2^2) (Real.sin_sq_add_cos_sq a)]

private theorem norm_velocity_bound (y x : H) : ‖(vel y x,(0:ℝ))‖ ≤ ‖y‖+‖x‖ := by
  have eq : ‖vel y x‖ = ‖y-x‖ := by
    change max ‖-(y.2-x.2)‖ ‖y.1-x.1‖ = max ‖y.1-x.1‖ ‖y.2-x.2‖
    rw [norm_neg,max_comm]
  simpa [eq] using norm_sub_le y x

private theorem coordinate_bound (y : Space) : ‖y.1‖ ≤ 1+radialSquare y := by
  change max |y.1.1| |y.1.2| ≤ 1 + (y.1.1^2+y.1.2^2)
  apply max_le <;> apply abs_le.mpr <;> constructor <;>
    nlinarith [sq_nonneg (y.1.1+1/2),sq_nonneg (y.1.1-1/2),sq_nonneg (y.1.2+1/2),sq_nonneg (y.1.2-1/2),
      sq_nonneg y.1.1,sq_nonneg y.1.2]

/-- The reference patch solves the original time-dependent weak equation at every
nonnegative endpoint. Only static Monge uniqueness remains as transport input.
Finite mass is required of the initial patch, and the horizontal radius bounds the
actual target body. No spatial first-moment, speed, smoothness or bounded-support
hypothesis on the rearranged patch is required. -/
theorem stationary_reference (E D : Set Space) (me : MeasurableSet E) (fin : volume E ≠ ⊤)
    (md : MeasurableSet D) (symm : ∀ θ y, rotateMap θ y ∈ D ↔ y ∈ D)
    (R : ℝ) (bound : ∀ y ∈ D, ‖y.1‖ ≤ R)
    (c : ENNReal) (S : Space → Space)
    (opt : UniqueMongeMap (volume.restrict (circular E)) (c • volume.restrict D) S)
    (t ρ : ℝ) (ht : 0 ≤ t) :
    WeakPatchEquation (circular E) (fun _ => circular E) t ρ (fun s => vel s.2.1 (S s.2).1) := by
  classical
  intro f hf cf
  let ν := (volume : Measure Space).restrict (circular E)
  have finB : volume (circular E) ≠ ⊤ := (circular_volume_eq E me fin) ▸ fin
  have : IsFiniteMeasure ν := isFiniteMeasure_restrict.mpr finB
  have src := circular_invariant E me
  have body := symmetric_body_marginals D md symm
  have dst : (∀ θ, (c • volume.restrict D).map (rotateMap θ)=c • volume.restrict D) ∧
      (c • volume.restrict D).map mirrorMap=c • volume.restrict D :=
    ⟨fun θ => by rw [Measure.map_smul c (body.1 θ).measurable.aemeasurable,(body.1 θ).map_eq],
      by rw [Measure.map_smul c body.2.measurable.aemeasurable,body.2.map_eq]⟩
  have cov := orthogonal_covariance ν _ S opt ⟨fun θ => (src.1 θ).map_eq,src.2.map_eq⟩ dst
  have imageD : ∀ᵐ y ∂ν, S y ∈ D := by
    apply (ae_map_iff opt.measurable.aemeasurable md).mp
    rw [show ν.map S = _ from opt.pushes]
    exact Measure.ae_smul_measure (ae_restrict_mem md) c
  have cr : Continuous (fun s : ℝ × Space => radialSquare s.2) := by unfold radialSquare; fun_prop
  obtain ⟨L,hL⟩ := cf.bddAbove_image cr.continuousOn
  let core := {y : Space | radialSquare y ≤ L}
  have hcore : MeasurableSet core := by unfold core radialSquare; apply measurableSet_le <;> fun_prop
  let G := core.piecewise S id
  have mg : Measurable G := Measurable.piecewise hcore opt.measurable measurable_id
  have g_on (y : Space) (h : y ∈ core) : G y = S y := piecewise_eq_of_mem _ _ _ h
  have g_off (y : Space) (h : y ∉ core) : G y = y := piecewise_eq_of_notMem _ _ _ h
  have rotcore (a : ℝ) (y : Space) : rotateMap a y ∈ core ↔ y ∈ core := by
    change radialSquare _ ≤ _ ↔ _; rw [radial_rotate]; rfl
  have mircore (y : Space) : mirrorMap y ∈ core ↔ y ∈ core := by simp [core,mirrorMap,radialSquare]
  have gr (a : ℝ) : ∀ᵐ y ∂ν, G (rotateMap a y) = rotateMap a (G y) := by
    filter_upwards [cov.1 a] with y hy
    by_cases h : y ∈ core
    · rw [g_on _ h,g_on _ ((rotcore a y).mpr h),hy]
    · rw [g_off _ h,g_off _ (fun k => h ((rotcore a y).mp k))]
  have gm : ∀ᵐ y ∂ν, G (mirrorMap y) = mirrorMap (G y) := by
    filter_upwards [cov.2] with y hy
    by_cases h : y ∈ core
    · rw [g_on _ h,g_on _ ((mircore y).mpr h),hy]
    · rw [g_off _ h,g_off _ (fun k => h ((mircore y).mp k))]
  have gv : Integrable (fun y => (vel y.1 (G y).1,(0:ℝ))) ν := by
    apply (integrable_const (1+|L|+|R|)).mono' (by unfold vel; fun_prop)
    filter_upwards [imageD] with y hy
    by_cases h : y ∈ core
    · rw [g_on _ h]
      have a : ‖y.1‖ ≤ 1+L := (coordinate_bound y).trans (add_le_add_right (show radialSquare y ≤ L from h) 1)
      exact (norm_velocity_bound _ _).trans (by linarith [bound _ hy,le_abs_self L,le_abs_self R])
    · rw [g_off _ h]
      simp [vel]; positivity
  have spatial := stationary_flux_of_symmetry ν G mg (fun a => (src.1 a).map_eq) src.2.map_eq gr gm gv
  have eq := stationary_weak_of_flux _ G mg finB gv spatial t ρ ht f hf cf
  convert eq using 2
  apply integral_congr_ae
  filter_upwards with s
  by_cases h : s.2 ∈ core
  · rw [g_on _ h]
  · have hs : s ∉ tsupport f := fun hs => h (hL (mem_image_of_mem _ hs))
    simp [fderiv_of_notMem_tsupport ℝ hs]
end
end Vortex
