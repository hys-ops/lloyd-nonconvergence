import ContinuumGrid
import StaticRankCycOptimal
import ContinuumPlans

open MeasureTheory ProbabilityTheory Set Filter
open scoped Topology
namespace Vortex
noncomputable section

private theorem discrete_cyclic {Y K : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [CompactSpace K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) (P : ProbabilityMeasure Y) (T : ProbabilityMeasure K)
    (G : CommonGrid Y) :
    ∃ π : ProbabilityMeasure (Y × K), SequentialRanks.certifiedPlan c (P.map G.round) T π := by
  classical
  let A := range G.site
  have : CompactSpace A := isCompact_iff_compactSpace.mp (finite_range G.site).isCompact
  let u : Y → A := fun y => ⟨G.round y, ⟨G.label y,rfl⟩⟩
  have mu : Measurable u := G.measurable_round.subtype_mk
  let j : A × K → Y × K := fun z => (z.1.val,z.2)
  have cj : Continuous j := (continuous_subtype_val.comp continuous_fst).prodMk continuous_snd
  obtain ⟨γ,cert,_⟩ := SequentialRanks.compact_cyclic_optimal_plan (P.map u) T (c ∘ j) (hc.comp cj)
  refine ⟨γ.map j,?_,?_,?_⟩
  · apply ProbabilityMeasure.toMeasure_injective
    have law := congrArg (fun v : ProbabilityMeasure A => (v : Measure A).map Subtype.val) cert.1
    simp only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_subtype_coe measurable_fst,
      Measure.map_map measurable_subtype_coe mu] at law
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst cj.measurable,Function.comp_def,j,u] using law
  · apply ProbabilityMeasure.toMeasure_injective
    have law := congrArg ProbabilityMeasure.toMeasure cert.2.1
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_snd cj.measurable,Function.comp_def,j] using law
  · let C := (γ : Measure (A × K)).support
    have compact : IsCompact C := (Measure.isClosed_support (μ := (γ : Measure (A × K)))).isCompact
    have mimage : MeasurableSet (j '' C) := (compact.image cj).measurableSet
    have hfull : j '' C ∈ ae (γ.map j : Measure (Y × K)) := by
      rw [ProbabilityMeasure.toMeasure_map, mem_ae_map_iff cj.measurable.aemeasurable mimage]
      filter_upwards [Measure.support_mem_ae (μ := (γ : Measure (A × K)))] with x hx
      exact mem_image_of_mem j hx
    have contained := Measure.support_subset_of_isClosed (compact.image cj).isClosed hfull
    intro n σ z hz
    choose x hx ex using fun i => contained (hz i)
    have cyc := cert.2.2 n σ x hx
    simpa only [Function.comp_apply,← ex] using cyc

/-- Existence of a cyclic plan for a continuous cost with an arbitrary Polish source
and compact metric destination. Compact discrete transport solves rounded marginals;
tightness, Prokhorov and closed cyclical monotonicity give a limit. Integrability or
boundedness of the cost is not required to state the cyclic conclusion. -/
theorem cyclic_plan_polish_compact {Y K : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [CompleteSpace Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [CompactSpace K] [SecondCountableTopology K] [MeasurableSpace K] [BorelSpace K]
    (c : Y × K → ℝ) (hc : Continuous c) (P : ProbabilityMeasure Y) (T : ProbabilityMeasure K) :
    ∃ π : ProbabilityMeasure (Y × K), SequentialRanks.certifiedPlan c P T π := by
  classical
  obtain ⟨G,grid⟩ := common_grids_for_all_laws (Y := Y)
  let p := fun n => P.map (G n).round
  have hp : Tendsto p atTop (𝓝 P) := grid P
  choose π cert using fun n => discrete_cyclic c hc P T (G n)
  let S := {((μ : ProbabilityMeasure (Y × K)) : Measure (Y × K)) | μ ∈ range π}
  have tightP : IsTightMeasureSet {((m : ProbabilityMeasure Y) : Measure Y) | m ∈ range p} :=
    isTightMeasureSet_of_isCompact_closure (hp.isCompact_insert_range.closure_of_subset (subset_insert ..))
  have tightQ : IsTightMeasureSet {((m : ProbabilityMeasure K) : Measure K) | m ∈ ({T}:Set (ProbabilityMeasure K))} :=
    isTightMeasureSet_of_isCompact_closure (isCompact_singleton.closure)
  have tight : IsTightMeasureSet S := by
    apply IsTightMeasureSet.prodMk
    · apply tightP.subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨_,⟨n,rfl⟩,(congrArg ProbabilityMeasure.toMeasure (cert n).1).symm⟩
    · apply tightQ.subset
      rintro _ ⟨_,⟨μ,⟨n,rfl⟩,rfl⟩,rfl⟩
      exact ⟨T,mem_singleton _,(congrArg ProbabilityMeasure.toMeasure (cert n).2.1).symm⟩
  have compact : IsCompact (closure (range π)) := isCompact_closure_of_isTightMeasureSet tight
  obtain ⟨η,_,u,mono,hu⟩ := compact.tendsto_subseq (x := π) (fun i => subset_closure (mem_range_self i))
  refine ⟨η,?_,?_,(SequentialRanks.closed_cyclicSupport c hc).mem_of_tendsto hu
    (Eventually.of_forall fun i => (cert (u i)).2.2)⟩
  · have fst := ((ProbabilityMeasure.continuous_map (f := (Prod.fst : Y × K → Y)) continuous_fst).tendsto η).comp hu
    apply tendsto_nhds_unique fst
    exact (hp.comp mono.tendsto_atTop).congr (fun i => (cert (u i)).1.symm)
  · have snd := ((ProbabilityMeasure.continuous_map (f := (Prod.snd : Y × K → K)) continuous_snd).tendsto η).comp hu
    apply tendsto_nhds_unique snd
    exact (tendsto_const_nhds (x := T)).congr (fun i => (cert (u i)).2.1.symm)
end
end Vortex
