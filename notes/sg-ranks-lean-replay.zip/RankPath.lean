import RankTransport
import RankSquare
open Set MeasureTheory
open scoped BigOperators
namespace SequentialRanks
noncomputable section
/-- The two integrated one-observation comparisons compose with the public constant. -/
theorem rank_kl {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (p q : Ω → ℝ) (L R : ℝ)
    (hp : ∀ᵐ x ∂μ, 0 ≤ p x) (hq : ∀ᵐ x ∂μ, 0 ≤ q x) (ac : ∀ᵐ x ∂μ, q x=0 → p x=0)
    (iH : Integrable (fun x => (Real.sqrt (p x)-Real.sqrt (q x))^2) μ)
    (iK : Integrable (fun x => p x*Real.log (p x/q x)) μ) (ip : Integrable p μ)
    (iq : Integrable q μ) (mass : (∫ x,p x ∂μ) = ∫ x,q x ∂μ)
    (one : L ≤ 16*R^2*∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2 ∂μ) :
    L ≤ 16*R^2*∫ x, p x*Real.log (p x/q x) ∂μ :=
  one.trans (mul_le_mul_of_nonneg_left
    (hellinger_kl_integral μ p q hp hq ac iH iK ip iq mass) (by positivity))

/-- Density domination by a positive Bayesian component on the path space.
The finiteness/absolute-continuity interface makes explicit which KL branch is used. -/
theorem mixture_oracle {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (p q s : Ω → ℝ) (w : ℝ) (hw : 0 < w) (hp : ∀ᵐ x ∂μ, 0 ≤ p x)
    (hac : ∀ᵐ x ∂μ, 0 < p x → 0 < s x) (dom : ∀ᵐ x ∂μ, w*s x ≤ q x)
    (hq : Integrable (fun x => p x*Real.log (p x/q x)) μ)
    (hs : Integrable (fun x => p x*Real.log (p x/s x)) μ)
    (ip : Integrable p μ) (mass : (∫ x,p x ∂μ) = 1) :
    (∫ x, p x*Real.log (p x/q x) ∂μ) ≤ (∫ x, p x*Real.log (p x/s x) ∂μ)+Real.log (1/w) := by
  have iR : Integrable (fun x => p x*Real.log (p x/s x)+p x*Real.log (1/w)) μ :=
    hs.add (ip.mul_const _)
  have h := integral_mono_ae hq iR (by
    filter_upwards [hp,hac,dom] with x px ac hx
    change p x*Real.log (p x/q x) ≤ _
    rcases eq_or_lt_of_le px with z|z
    · simp [← z]
    · have hpos := ac z
      have hprod := mul_pos hw hpos
      have hqpos := hprod.trans_le hx
      have ht := Real.log_le_log hprod hx
      rw [Real.log_mul hw.ne' hpos.ne'] at ht
      rw [Real.log_div z.ne' hqpos.ne',Real.log_div z.ne' hpos.ne',Real.log_div one_ne_zero hw.ne',
        Real.log_one,← mul_add]
      exact mul_le_mul_of_nonneg_left (by linarith) px)
  rw [integral_add hs (ip.mul_const _),integral_mul_const,mass,one_mul] at h
  exact h

/-- Finite mixtures automatically dominate each weighted candidate, for arbitrary nonnegative
path densities and nonnegative weights. -/
theorem finite_mix_dominates {J : Type*} [Fintype J] (w f : J → ℝ) (j : J)
    (hw : ∀ i, 0 ≤ w i) (hf : ∀ i, 0 ≤ f i) :
    w j*f j ≤ ∑ i, w i*f i :=
  Finset.single_le_sum (fun i _ => mul_nonneg (hw i) (hf i)) (Finset.mem_univ j)

/-- van Trees' final Cauchy-Schwarz step for the actual joint integrals. The
score integration-by-parts identity and its information bound are explicit premises. -/
theorem risk_from_score {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (e S : Ω → ℝ)
    (K : ℝ) (hK : 0 < K) (he : Integrable (fun x => e x^2) μ)
    (hm : Integrable (fun x => e x*S x) μ) (hs : Integrable (fun x => S x^2) μ)
    (identity : (∫ x, e x*S x ∂μ)=1) (info : (∫ x, S x^2 ∂μ) ≤ K) :
    1/K ≤ ∫ x, e x^2 ∂μ := by
  have hi : Integrable (fun x => K^2*e x^2-(2*K)*(e x*S x)) μ :=
    (he.const_mul _).sub (hm.const_mul _)
  have hn : 0 ≤ ∫ x, (K^2*e x^2-(2*K)*(e x*S x)+S x^2) ∂μ :=
    integral_nonneg fun x => by change 0 ≤ _; nlinarith only [sq_nonneg (K*e x-S x)]
  rw [integral_add hi hs, integral_sub (he.const_mul _) (hm.const_mul _),
    integral_const_mul,integral_const_mul,identity,mul_one] at hn
  apply (div_le_iff₀ hK).mpr
  apply le_of_mul_le_mul_left (a := K) _ hK
  nlinarith only [hn,info]

theorem finite_list_lower (T : ℕ) (risk : Fin T → ℝ) (early : Finset (Fin T))
    (floor : ∀ i ∈ early, 1/(32*Real.pi^2) ≤ risk i) (nonneg : ∀ i, 0 ≤ risk i) :
    (early.card:ℝ)/(32*Real.pi^2) ≤ ∑ i, risk i := by
  calc
    _ = ∑ _i ∈ early, 1/(32*Real.pi^2) := by simp [div_eq_mul_inv]
    _ ≤ ∑ i ∈ early, risk i := Finset.sum_le_sum floor
    _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _ => nonneg i)
end
end SequentialRanks
