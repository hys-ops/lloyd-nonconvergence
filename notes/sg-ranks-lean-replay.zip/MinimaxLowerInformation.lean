import MinimaxLowerPaths
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def priorWeight (θ : ℝ) := 2*Real.cos (Real.pi*θ)^2
def priorDerivative (θ : ℝ) := -4*Real.pi*Real.cos (Real.pi*θ)*Real.sin (Real.pi*θ)
def priorEnergy (θ : ℝ) := 8*Real.pi^2*Real.sin (Real.pi*θ)^2

def densityDerivative (θ : ℝ) (z : SquareObs) :=
  let c := Real.cos (Real.pi*(z.1+z.2))
  let d := Real.cos (Real.pi*(z.1-z.2))
  (-c)*(1-θ*d) - (1-θ*c)*d
def obsScore (θ : ℝ) (z : SquareObs) := densityDerivative θ z / density θ z

theorem prior_derivative (θ : ℝ) : HasDerivAt priorWeight (priorDerivative θ) θ := by
  have c := (Real.hasDerivAt_cos _).comp θ (HasDerivAt.const_mul Real.pi (hasDerivAt_id θ))
  apply ((c.fun_pow 2).const_mul 2).congr_deriv
  simp [priorDerivative]; ring

theorem density_derivative (θ : ℝ) (z : SquareObs) :
    HasDerivAt (fun t => density t z) (densityDerivative θ z) θ := by
  let c := Real.cos (Real.pi*(z.1+z.2))
  let d := Real.cos (Real.pi*(z.1-z.2))
  have h (a : ℝ) := HasDerivAt.const_sub 1 ((hasDerivAt_id θ).mul_const a)
  apply ((h c).fun_mul (h d)).congr_deriv
  dsimp [densityDerivative,c,d]; ring

theorem square_density_derivative_mean (θ : ℝ) : (∫ z,densityDerivative θ z ∂squareBase)=0 := by
  have di (a : ℝ) : Integrable (density a) squareBase :=
    (show Continuous (density a) by unfold density; fun_prop).continuousOn.integrableOn_compact
      (isCompact_Icc.prod isCompact_Icc)
  have algebra (z : SquareObs) : densityDerivative θ z =
      (density 1 z-density (-1) z)/2 + θ*(density 1 z+density (-1) z-2*density 0 z) := by
    unfold densityDerivative density; dsimp; ring
  have m1 : Integrable (fun z => (density 1 z-density (-1) z)/2) squareBase := ((di 1).sub (di (-1))).div_const 2
  have m2 : Integrable (fun z => density 1 z+density (-1) z-2*density 0 z) squareBase :=
    ((di 1).add (di (-1))).sub ((di 0).const_mul 2)
  simp_rw [algebra]
  rw [integral_add m1 (m2.const_mul θ),integral_div,integral_const_mul,
    integral_sub (di 1) (di (-1)),integral_sub (show Integrable (fun z => density 1 z + density (-1) z) squareBase from (di 1).add (di (-1))) ((di 0).const_mul 2),
    integral_add (di 1) (di (-1)),integral_const_mul]
  norm_num [square_density_normalized]

theorem square_score_bound (θ : ℝ) (ht : |θ| ≤ 1/2) (z : SquareObs) :
    |obsScore θ z| ≤ 4 := by
  let c := Real.cos (Real.pi*(z.1+z.2))
  let d := Real.cos (Real.pi*(z.1-z.2))
  have den (x : ℝ) (hx : |x| ≤ 1) : 1/2 ≤ 1-θ*x := by
    have h := mul_le_mul ht hx (abs_nonneg _) (by norm_num)
    rw [←abs_mul] at h; linarith [le_abs_self (θ*x)]
  have cc := Real.abs_cos_le_one (Real.pi*(z.1+z.2))
  have dd := Real.abs_cos_le_one (Real.pi*(z.1-z.2))
  have b (x : ℝ) (hx : |x| ≤ 1) : |x/(1-θ*x)| ≤ 2 := by
    have d0 := den x hx
    rw [abs_div,abs_of_pos (by linarith : 0<1-θ*x)]
    apply (div_le_iff₀ (by linarith)).mpr; linarith
  have dc : 0<1-θ*c := by linarith [den c cc]
  have dd' : 0<1-θ*d := by linarith [den d dd]
  have id : obsScore θ z = -(c/(1-θ*c)+d/(1-θ*d)) := by
    change (-c*(1-θ*d)-(1-θ*c)*d)/((1-θ*c)*(1-θ*d))=_
    let u := 1-θ*c
    let v := 1-θ*d
    change (-c*v-u*d)/(u*v) = -(c/u+d/v)
    apply (div_eq_iff (mul_ne_zero dc.ne' dd'.ne')).mpr
    have h1 : c/u*u=c := div_mul_cancel₀ c dc.ne'
    have h2 : d/v*v=d := div_mul_cancel₀ d dd'.ne'
    linear_combination v*h1+u*h2
  rw [id,abs_neg]
  exact (abs_add_le _ _).trans (by linarith [b c cc,b d dd])

private theorem densityPositive {θ : ℝ} (ht : |θ| ≤ 1/2) (z : SquareObs) : 0<density θ z :=
  (by norm_num : (0:ℝ)<1/4).trans_le (actual_density_floor _ _ _ ht)

theorem square_score_mean (θ : ℝ) (ht : |θ| ≤ 1/2) : (∫ z,obsScore θ z ∂squareLaw θ)=0 := by
  unfold squareLaw
  have md : Measurable (fun z => ENNReal.ofReal (density θ z)) := by unfold density; fun_prop
  rw [integral_withDensity_eq_integral_toReal_smul md (Filter.Eventually.of_forall (fun _ => ENNReal.ofReal_lt_top))]
  have eq (z : SquareObs) : (ENNReal.ofReal (density θ z)).toReal • obsScore θ z = densityDerivative θ z := by
    rw [ENNReal.toReal_ofReal (densityPositive ht z).le,smul_eq_mul,obsScore]
    field_simp [(densityPositive ht z).ne']
  simp_rw [eq]
  exact square_density_derivative_mean θ

def iidPastLaw (θ : ℝ) : (n : ℕ) → Measure (Past n)
  | 0 => Measure.dirac ()
  | n+1 => (iidPastLaw θ n).prod (squareLaw θ)

private theorem iidProb (θ : ℝ) (ht : |θ| ≤ 1/2) : (n : ℕ) → IsProbabilityMeasure (iidPastLaw θ n)
  | 0 => (inferInstance : IsProbabilityMeasure (Measure.dirac ()))
  | n+1 => by
    let _ := iidProb θ ht n; let _ := square_law_probability ht
    change IsProbabilityMeasure ((iidPastLaw θ n).prod (squareLaw θ)); infer_instance

def allScore (θ : ℝ) : (n : ℕ) → Past n → ℝ
  | 0, _ => 0
  | n+1, x => allScore θ n x.1 + obsScore θ x.2

private theorem mScore (θ : ℝ) : Measurable (obsScore θ) := by unfold obsScore densityDerivative density; fun_prop
private theorem mAll (θ : ℝ) : (n : ℕ) → Measurable (allScore θ n)
  | 0 => measurable_const
  | n+1 => ((mAll θ n).comp measurable_fst).add ((mScore θ).comp measurable_snd)

private theorem allBound (θ : ℝ) (ht : |θ| ≤ 1/2) : ∀ n (x : Past n), |allScore θ n x| ≤ 4*(n:ℝ)
  | 0, x => by simp [allScore]
  | n+1, x => by
    change |_ + _| ≤ _
    exact (abs_add_le _ _).trans (by push_cast; linarith [allBound θ ht n x.1,square_score_bound θ ht x.2])

/-- For n i.i.d. observations under the actual model, the Fisher contribution is
at most 16n. The arbitrary offset allows direct insertion of the prior score. -/
theorem iid_score_information (θ : ℝ) (ht : |θ| ≤ 1/2) (c : ℝ) (n : ℕ) :
    (∫ x,(c+allScore θ n x)^2 ∂iidPastLaw θ n) ≤ c^2+16*(n:ℝ) := by
  let _ := square_law_probability ht
  have sc := mScore θ
  have si : Integrable (obsScore θ) (squareLaw θ) :=
    .of_bound sc.aestronglyMeasurable 4 (Filter.Eventually.of_forall (square_score_bound θ ht))
  have si2 : Integrable (fun z => obsScore θ z^2) (squareLaw θ) := by
    apply Integrable.of_bound (sc.pow_const 2).aestronglyMeasurable 16
    filter_upwards with z
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    nlinarith [sq_abs (obsScore θ z),square_score_bound θ ht z,sq_nonneg (4-|obsScore θ z|),
      mul_nonneg (sub_nonneg.mpr (square_score_bound θ ht z)) (by positivity : 0≤4+|obsScore θ z|)]
  have one (a : ℝ) : (∫ z, (a+obsScore θ z)^2 ∂squareLaw θ) ≤ a^2+16 := by
    have id (z : SquareObs) : (a+obsScore θ z)^2 = a^2+2*a*obsScore θ z+obsScore θ z^2 := by ring
    simp_rw [id]
    rw [integral_add (show Integrable (fun z => a^2+2*a*obsScore θ z) (squareLaw θ) from (integrable_const (a^2)).add (si.const_mul (2*a))) si2,
      integral_add (integrable_const (a^2)) (si.const_mul (2*a)),integral_const_mul,square_score_mean _ ht]
    simp only [integral_const,probReal_univ,one_smul,mul_zero,add_zero]
    apply add_le_add_right
    calc
      _ ≤ ∫ _ : SquareObs, (16:ℝ) ∂squareLaw θ := integral_mono si2 (integrable_const _) (fun z => by
        have h := square_score_bound θ ht z; nlinarith [sq_abs (obsScore θ z),mul_nonneg (sub_nonneg.mpr h) (by positivity : 0≤4+|obsScore θ z|)])
      _ = _ := by simp
  have reg (m : ℕ) : Integrable (fun x => (c+allScore θ m x)^2) (iidPastLaw θ m) := by
    let _ := iidProb θ ht m
    apply Integrable.of_bound ((measurable_const.add (mAll θ m)).pow_const 2).aestronglyMeasurable
      ((|c|+4*(m:ℝ))^2)
    filter_upwards with x
    change ‖(c+allScore θ m x)^2‖ ≤ _
    rw [Real.norm_of_nonneg (sq_nonneg _),← sq_abs (c+allScore θ m x)]
    exact pow_le_pow_left₀ (abs_nonneg _) ((abs_add_le _ _).trans (by linarith [allBound θ ht m x])) _
  induction n with
  | zero =>
    change (∫ _ : Unit,(c+0)^2 ∂Measure.dirac ()) ≤ _
    simp
  | succ n ih =>
    let _ := iidProb θ ht n
    have hprod := reg (n+1)
    change Integrable (fun x : Past n × SquareObs => (c+(allScore θ n x.1+obsScore θ x.2))^2) ((iidPastLaw θ n).prod (squareLaw θ)) at hprod
    change (∫ x : Past n × SquareObs, (c+(allScore θ n x.1+obsScore θ x.2))^2 ∂(iidPastLaw θ n).prod (squareLaw θ)) ≤ _
    rw [integral_prod _ hprod]
    have hcmp := integral_mono_of_nonneg (μ := iidPastLaw θ n)
      (Filter.Eventually.of_forall fun x : Past n => integral_nonneg fun z => sq_nonneg (c+(allScore θ n x+obsScore θ z)))
      ((reg n).add (integrable_const (16:ℝ))) (Filter.Eventually.of_forall fun x => by
        simpa only [←add_assoc,Pi.add_apply] using one (c+allScore θ n x))
    simp only [Pi.add_apply,integral_add (reg n) (integrable_const (16:ℝ)),integral_const,probReal_univ,one_smul] at hcmp
    push_cast; linarith

end
end SequentialRanks
