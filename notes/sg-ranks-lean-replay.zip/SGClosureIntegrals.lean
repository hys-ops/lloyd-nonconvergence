import StationaryReference
import PatchDynamics

open MeasureTheory Set Filter
open scoped ENNReal
namespace Vortex
noncomputable section

theorem measurable_circular (E : Set Space) (me : MeasurableSet E) : MeasurableSet (circular E) :=
  measurableSet_le (areaCoord_meas.comp measurable_fst)
    ((ENNReal.measurable_toReal.comp (measurable_measure_prodMk_right (μ := (volume : Measure H)) me)).comp measurable_snd)

private def hquad (x : H) : ℝ := x.1^2+x.2^2
private theorem hquad_nonneg (x : H) : 0 ≤ hquad x := by unfold hquad; positivity
private theorem hquad_meas : Measurable hquad := by unfold hquad; fun_prop

private theorem disk_budget (A : Set H) (mA : MeasurableSet A) (fA : volume A ≠ ⊤)
    (hi : IntegrableOn hquad A) :
    IntegrableOn hquad (disk (volume.real A)) ∧
      (∫ x in disk (volume.real A), hquad x) ≤ ∫ x in A, hquad x := by
  classical
  let a := volume.real A
  let D := disk a
  have md : MeasurableSet D := areaCoord_meas measurableSet_Iic
  have fd : volume D ≠ ⊤ := by rw [show D=disk a from rfl,disk,disk_area]; exact ENNReal.ofReal_ne_top
  have iD : IntegrableOn hquad D := by
    apply (integrableOn_const (C := a/Real.pi) fd).mono' hquad_meas.aestronglyMeasurable
    filter_upwards [ae_restrict_mem md] with x hx
    rw [Real.norm_eq_abs,abs_of_nonneg (hquad_nonneg _)]
    apply (le_div_iff₀ Real.pi_pos).mpr
    simpa [areaCoord,hquad,mul_comm,D,disk] using hx
  refine ⟨iD,?_⟩
  have same : volume.real A = volume.real D := by
    change a = (volume (disk a)).toReal
    rw [disk,disk_area,ENNReal.toReal_ofReal (show 0 ≤ a from ENNReal.toReal_nonneg)]
  have hh := disk_rearrange 1 a zero_lt_one A mA fA (hi.const_mul Real.pi) (iD.const_mul Real.pi) same
  have pt (x : H) : (x.1^2+x.2^2)*(patch A 1 x-patch D 1 x) = A.indicator hquad x-D.indicator hquad x := by
    by_cases hx : x ∈ A <;> by_cases hd : x ∈ D <;> simp [hx,hd,patch,hquad,indicator]
  change _ ≤ ∫ x : H, (x.1^2+x.2^2)*(patch A 1 x-patch D 1 x) at hh
  simp_rw [pt] at hh
  rw [integral_sub ((integrable_indicator_iff mA).mpr hi) ((integrable_indicator_iff md).mpr iD),
    integral_indicator mA, integral_indicator md] at hh
  exact sub_nonneg.mp ((by positivity : 0 ≤ 1/Real.pi*(volume.real (A \ D))^2).trans hh)

/-- The radial second moment of the comparison patch is finite under the original
initial second moment. The proof reuses the sharp, already verified disk comparison. -/
theorem circular_radial_integrable (E : Set Space) (me : MeasurableSet E)
    (fin : volume E ≠ ⊤) (iE : IntegrableOn radialSquare E) : IntegrableOn radialSquare (circular E) := by
  classical
  let q (A : Set Space) := A.indicator radialSquare
  let B := circular E
  have mb := measurable_circular E me
  have mrad : Measurable radialSquare := by unfold radialSquare; fun_prop
  have mi (A : Set Space) (ma : MeasurableSet A) : Measurable (q A) := mrad.indicator ma
  have qs (A : Set Space) (z : ℝ) (x : H) : q A (x,z) = (slice A z).indicator hquad x := by
    by_cases hx : (x,z) ∈ A
    · exact (indicator_of_mem hx _).trans (indicator_of_mem (show x ∈ slice A z from hx) hquad).symm
    · simp only [q,indicator_of_notMem hx,indicator_of_notMem (show x ∉ slice A z from hx)]
  have pos (A : Set Space) (y : Space) : 0 ≤ q A y := by
    apply indicator_nonneg; intro z _; exact hquad_nonneg z.1
  have norm (A : Set Space) (z : ℝ) (x : H) : ‖q A (x,z)‖ = (slice A z).indicator hquad x := by
    rw [Real.norm_eq_abs,abs_of_nonneg (pos _ _),qs]
  have ii : Integrable (q E) ((volume : Measure H).prod (volume : Measure ℝ)) :=
    (integrable_indicator_iff me).mpr iE
  have mvol : Measurable (fun z => volume (slice E z)) := measurable_measure_prodMk_right me
  have finite : ∀ᵐ z : ℝ, volume (slice E z) < ⊤ := ae_lt_top mvol (by
    change (∫⁻ z, volume ((fun x : H => (x,z)) ⁻¹' E)) ≠ ⊤
    rwa [← Measure.prod_apply_symm me])
  have isec := (integrable_prod_iff' ii.aestronglyMeasurable).mp ii
  have msec (A : Set Space) (ma : MeasurableSet A) (z : ℝ) : MeasurableSet (slice A z) :=
    ma.preimage (measurable_id.prodMk measurable_const)
  have data : ∀ᵐ z : ℝ, Integrable (fun x : H => q B (x,z)) ∧
      (∫ x : H, ‖q B (x,z)‖) ≤ ∫ x : H, ‖q E (x,z)‖ := by
    filter_upwards [finite,isec.1] with z hz iz
    simp only [qs] at iz ⊢
    have d := disk_budget _ (msec _ me z) hz.ne ((integrable_indicator_iff (msec _ me z)).mp iz)
    have r : slice B z = disk (volume.real (slice E z)) := rfl
    constructor
    · exact (integrable_indicator_iff (msec _ mb z)).mpr (r ▸ d.1)
    · simp_rw [← qs, norm]
      rw [integral_indicator (msec _ mb z),integral_indicator (msec _ me z),r]
      exact d.2
  apply (integrable_indicator_iff mb).mp
  apply (integrable_prod_iff' ((mi B mb).aestronglyMeasurable)).mpr
  refine ⟨data.mono (fun _ h => h.1),isec.2.mono' ((mi B mb).norm.stronglyMeasurable.integral_prod_left').aestronglyMeasurable ?_⟩
  filter_upwards [data] with z hz
  rw [Real.norm_eq_abs,abs_of_nonneg (integral_nonneg fun _ => norm_nonneg _)]
  exact hz.2

private theorem measurable_patch (A : Set Space) (mA : MeasurableSet A) (ρ : ℝ) :
    Measurable (patch A ρ) := (measurable_const.indicator mA : Measurable (A.indicator (fun _ => ρ)))

theorem patch_difference_integrals (E B : Set Space) (me : MeasurableSet E) (mb : MeasurableSet B)
    (fe : volume E ≠ ⊤) (fb : volume B ≠ ⊤) (ρ : ℝ)
    (ie : IntegrableOn radialSquare E) (ib : IntegrableOn radialSquare B) :
    Integrable (fun y => |patch E ρ y-patch B ρ y|) ∧
    Integrable (fun y => radialSquare y*(patch E ρ y-patch B ρ y)) := by
  have pi (A : Set Space) (m : MeasurableSet A) (h : volume A ≠ ⊤) : Integrable (patch A ρ) :=
    (integrable_indicator_iff m).mpr (integrableOn_const (C := ρ) h)
  have ri (A : Set Space) (m : MeasurableSet A) (h : IntegrableOn radialSquare A) :
      Integrable (fun y => radialSquare y * patch A ρ y) := by
    convert (integrable_indicator_iff m).mpr (h.mul_const ρ) using 1
    funext y; by_cases hy : y ∈ A <;> simp [patch,hy,indicator]
  constructor
  · exact ((pi E me fe).sub (pi B mb fb)).abs
  · simp_rw [mul_sub]
    exact (ri _ me ie).sub (ri _ mb ib)
end
end Vortex
