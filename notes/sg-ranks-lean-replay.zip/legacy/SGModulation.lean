import Std.Tactic

namespace SGModulation
variable {K : Type} [Lean.Grind.CommRing K]

def addV (p q : K × K) : K × K := (p.1+q.1,p.2+q.2)
def subV (p q : K × K) : K × K := (p.1-q.1,p.2-q.2)
def dotV (p q : K × K) : K := p.1*q.1+p.2*q.2
def rot (p : K × K) : K × K := (-p.2,p.1)
def affine (a b : K) (p : K × K) : K × K :=
  ((1+a)*p.1+b*p.2,b*p.1+(1-a)*p.2)
def strain (a b : K) (p : K × K) : K × K :=
  (-b*p.1+a*p.2,a*p.1+b*p.2)

/-- The derivative of the quadratic modulation after substituting y=A(x+w). -/
theorem cancellation (a b : K) (x w : K × K) :
    let v := addV x w
    let y := affine a b v
    dotV x (strain a b x) - dotV v (strain a b v) +
      2*dotV (subV v y) (rot (subV y x)) = dotV w (strain a b w) := by
  simp only [addV, affine, dotV, strain, subV, rot]
  grind

/-- Determinant of A' - s A; yields the two sharp generalized eigenvalues. -/
theorem characteristic (a b s : K) :
    (-b-s*(1+a))*(b-s*(1-a))-(a-s*b)^2 =
    (1-a^2-b^2)*s^2-(a^2+b^2) := by grind

/-- Sum-of-squares form of the sharp rate bound in an eigenbasis of A. -/
theorem rate_square (r x y : K) :
    r^2*((1+r)*x^2+(1-r)*y^2)^2 - (1-r^2)*(2*r*x*y)^2 =
    r^2*((1+r)*x^2-(1-r)*y^2)^2 := by grind

/-- Centering the cold-column second moment about a fixed mean level. -/
theorem height_moment (h m : K) :
    h^2-m^2=(h-m)^2+2*m*(h-m) := by grind

/-- Both optimal inner/outer shells contribute to the planar impulse deficit.
Here r is squared radius and d is transferred area divided by pi. -/
theorem annular_deficit (r d : K) :
    (r+d)^2-2*r^2+(r-d)^2=2*d^2 := by grind

end SGModulation
#print axioms SGModulation.cancellation
#print axioms SGModulation.characteristic
#print axioms SGModulation.rate_square
#print axioms SGModulation.height_moment
#print axioms SGModulation.annular_deficit
