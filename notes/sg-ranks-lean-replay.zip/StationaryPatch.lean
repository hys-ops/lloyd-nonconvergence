import StationaryOptimal
import StationaryFlux

open MeasureTheory Set Filter
open scoped Topology ContDiff
namespace Vortex
noncomputable section

private theorem compact_section (f : ℝ × Space → ℝ) (cf : HasCompactSupport f) (a : ℝ) :
    HasCompactSupport (fun y => f (a,y)) := by
  have k := cf.image continuous_snd
  apply k.of_isClosed_subset (isClosed_tsupport _)
  apply closure_minimal _ k.isClosed
  intro y hy
  exact ⟨(a,y),subset_tsupport f (show f (a,y) ≠ 0 from hy),rfl⟩

theorem stationary_weak_of_flux (B : Set Space) (S : Space → Space)
    (m : Measurable S) (fin : volume B ≠ ⊤)
    (speed : IntegrableOn (fun y => (vel y.1 (S y).1,(0:ℝ))) B)
    (spatial : ∀ g : Space → ℝ, ContDiff ℝ ∞ g → HasCompactSupport g →
      (∫ y in B, fderiv ℝ g y (vel y.1 (S y).1,0))=0)
    (t ρ : ℝ) (ht : 0 ≤ t) :
    WeakPatchEquation B (fun _ => B) t ρ (fun s => vel s.2.1 (S s.2).1) := by
  intro f hf cf
  let ν := (volume : Measure Space).restrict B
  let dt := (volume : Measure ℝ).restrict (Icc 0 t)
  have : IsFiniteMeasure ν := isFiniteMeasure_restrict.mpr fin
  have : IsFiniteMeasure dt := isFiniteMeasure_restrict.mpr (by simp [Real.volume_Icc])
  let v (y : Space) : Space := (vel y.1 (S y).1,0)
  have mv : Measurable v := by unfold v vel; fun_prop
  let ft (s : ℝ × Space) := fderiv ℝ f s (1,0)
  let fx (s : ℝ × Space) := fderiv ℝ f s (0,v s.2)
  have df := hf.continuous_fderiv (by simp)
  obtain ⟨K,bK⟩ := (cf.fderiv ℝ).exists_bound_of_continuous df
  have ct : Continuous ft := df.clm_apply continuous_const
  have it : Integrable ft (dt.prod ν) := by
    apply (integrable_const K).mono' ct.aestronglyMeasurable
    filter_upwards with s
    simpa [ft] using ((fderiv ℝ f s).le_opNorm ((1:ℝ),(0:Space))).trans
      (mul_le_mul_of_nonneg_right (bK _) (norm_nonneg _))
  have ix : Integrable fx (dt.prod ν) := by
    have speed' : Integrable v ν := speed
    apply ((speed'.norm.comp_snd dt).const_mul K).mono'
    · exact (continuous_fst.clm_apply continuous_snd).measurable.comp
        (df.measurable.prodMk (measurable_const.prodMk (mv.comp measurable_snd))) |>.aestronglyMeasurable
    · filter_upwards with s
      simpa [fx] using ((fderiv ℝ f s).le_opNorm ((0:ℝ),v s.2)).trans
        (mul_le_mul_of_nonneg_right (bK _) (norm_nonneg _))
  have hx (a : ℝ) : (∫ y, fx (a,y) ∂ν) = 0 := by
    let j := fun y : Space => (a,y)
    have dj (y : Space) := (hasFDerivAt_const a y).prodMk (hasFDerivAt_id y (𝕜 := ℝ))
    have sp := spatial (f ∘ j) (hf.comp (contDiff_const.prodMk contDiff_id)) (compact_section f cf a)
    have eq (y : Space) : fderiv ℝ (f ∘ j) y (v y) = fx (a,y) := by
      exact congrArg (fun L : Space →L[ℝ] ℝ => L (v y)) (((hf.differentiable (by simp) _).hasFDerivAt.comp y (dj y)).fderiv)
    change (∫ y, fderiv ℝ (f ∘ j) y (v y) ∂ν)=0 at sp
    simpa only [eq] using sp
  have fx0 : (∫ s, fx s ∂dt.prod ν)=0 := by
    rw [integral_prod _ ix]; simp [hx]
  have ftc (y : Space) : (∫ a, ft (a,y) ∂dt)= f (t,y)-f (0,y) := by
    have d (a : ℝ) : HasDerivAt (fun s => f (s,y)) (ft (a,y)) a := by
      have dj := (hasDerivAt_id a).prodMk (hasDerivAt_const a y)
      exact (hf.differentiable (by simp) _).hasFDerivAt.comp_hasDerivAt a dj
    change (∫ a in Icc 0 t, ft (a,y)) = _
    rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le ht]
    exact intervalIntegral.integral_eq_sub_of_hasDerivAt (fun a _ => d a)
      ((ct.comp (continuous_id.prodMk continuous_const)).intervalIntegrable ..)
  obtain ⟨C,bd⟩ := cf.exists_bound_of_continuous hf.continuous
  have intf (a : ℝ) : Integrable (fun y => f (a,y)) ν :=
    (integrable_const C).mono' (hf.continuous.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
      (ae_of_all _ fun _ => bd _)
  have oc : occupation (fun _ => B) t = dt.prod ν := by
    rw [show dt.prod ν = _ from Measure.prod_restrict (μ := volume) (ν := volume) (Icc 0 t) B]
    rfl
  have split (s : ℝ × Space) : fderiv ℝ f s (1,(vel s.2.1 (S s.2).1,0)) = ft s + fx s := by
    simpa [ft,fx,v] using (fderiv ℝ f s).map_add (1,0) (0,v s.2)
  rw [oc]; simp_rw [split]
  rw [integral_add it ix,fx0,add_zero,integral_prod_symm _ it]
  simp_rw [ftc]
  rw [integral_sub (intf _) (intf _),mul_sub]
  
/-- Actual reference-patch weak stationarity, against arbitrary time-dependent
smooth compact tests and for every nonnegative endpoint. The unique static
quadratic Monge map is the only geometric input. -/
theorem stationary_circular_patch (E0 D : Set Space) (me : MeasurableSet E0)
    (md : MeasurableSet D) (symm : ∀ θ y, rotateMap θ y ∈ D ↔ y ∈ D)
    (c : ENNReal) (S : Space → Space)
    (opt : UniqueMongeMap (volume.restrict (circular E0)) (c • volume.restrict D) S)
    (fin : volume (circular E0) ≠ ⊤)
    (speed : IntegrableOn (fun y => (vel y.1 (S y).1,(0:ℝ))) (circular E0))
    (t ρ : ℝ) (ht : 0 ≤ t) :
    WeakPatchEquation (circular E0) (fun _ => circular E0) t ρ (fun s => vel s.2.1 (S s.2).1) := by
  let ν := (volume : Measure Space).restrict (circular E0)
  have : IsFiniteMeasure ν := isFiniteMeasure_restrict.mpr fin
  have src := circular_invariant E0 me
  have body := symmetric_body_marginals D md symm
  have cov := orthogonal_covariance ν (c • volume.restrict D) S opt
    ⟨fun θ => (src.1 θ).map_eq,src.2.map_eq⟩
    ⟨fun θ => by rw [Measure.map_smul c (body.1 θ).measurable.aemeasurable,(body.1 θ).map_eq],by rw [Measure.map_smul c body.2.measurable.aemeasurable,body.2.map_eq]⟩
  exact stationary_weak_of_flux _ S opt.measurable fin speed
    (stationary_flux_of_symmetry ν S opt.measurable (fun θ => (src.1 θ).map_eq) src.2.map_eq
      cov.1 cov.2 speed) t ρ ht
end
end Vortex
