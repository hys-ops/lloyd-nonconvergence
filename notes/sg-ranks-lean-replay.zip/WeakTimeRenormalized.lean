import WeakTimeCommon

open MeasureTheory Set Filter
open scoped ENNReal Topology ContDiff
namespace Vortex
noncomputable section

/-- The divergence-free renormalized distributional equation for the public patch density.
The scalar renormalizations below are smooth, vanish at zero, and have compact support;
these are among the admissible renormalizations with compactly supported derivative.
No final-time evaluation appears. -/
def RenormalizedPatch (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (w : SpaceTime → H) : Prop :=
  ∀ β : ℝ → ℝ, ContDiff ℝ ∞ β → HasCompactSupport β → β 0 = 0 →
  ∀ f : SpaceTime → ℝ, ContDiff ℝ ∞ f → HasCompactSupport f →
    (∃ b < T, ∀ s : SpaceTime, b < s.1 → f s=0) →
    (∫ t in (0:ℝ)..T, ∫ y, β (patch (E t) ρ y)*fderiv ℝ f (t,y) (timeDirection w (t,y))) =
      -(∫ y, β (patch E0 ρ y)*f (0,y))

private theorem integrate_renormalization (ρ : ℝ) (β : ℝ → ℝ) (bz : β 0=0) (br : β ρ=ρ)
    (E : Set Space) (me : MeasurableSet E) (g : Space → ℝ) :
    (∫ y, β (patch E ρ y)*g y) = ρ*∫ y in E,g y := by
  classical
  have ident : (fun y => β (patch E ρ y)*g y) = E.indicator (fun y => ρ*g y) := by
    funext y
    by_cases hy : y ∈ E <;> simp [patch,hy,bz,br]
  rw [ident,integral_indicator me,integral_const_mul]

theorem distributional_of_renormalized_patch (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (w : SpaceTime → H) (me0 : MeasurableSet E0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1}) (sol : RenormalizedPatch E0 E T ρ w) :
    DistributionalPatch E0 E T ρ w := by
  let b : ContDiffBump (0 : ℝ) := ⟨|ρ|+1,|ρ|+2,by positivity,by linarith⟩
  let β := fun x : ℝ => b x*x
  have bz : β 0=0 := by simp [β]
  have br : β ρ=ρ := by
    have hb : ρ ∈ Metric.closedBall (0:ℝ) b.rIn := by
      rw [Metric.mem_closedBall,Real.dist_eq,sub_zero]
      change |ρ| ≤ |ρ|+1
      linarith
    simp [β,b.one_of_mem_closedBall hb]
  intro f hf hc admiss
  have eqn := sol β (b.contDiff.mul contDiff_id) b.hasCompactSupport.mul_right bz f hf hc admiss
  have slice (t : ℝ) : MeasurableSet (E t) := moving.preimage (measurable_const.prodMk measurable_id)
  simp_rw [integrate_renormalization ρ β bz br _ (slice _) _] at eqn
  rw [integrate_renormalization ρ β bz br E0 me0,intervalIntegral.integral_const_mul] at eqn
  exact eqn

/-- Common traces directly from the renormalized distributional identity, using a
smooth compactly supported renormalization agreeing with identity at 0 and ρ. -/
theorem weak_patch_of_renormalized (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (hT : 0 ≤ T) (hρ : 0 < ρ) (w : SpaceTime → H) (me0 : MeasurableSet E0)
    (finite0 : volume E0 ≠ ⊤) (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    [IsFiniteMeasure (occupation E T)] (hw : Integrable w (occupation E T))
    (sol : RenormalizedPatch E0 E T ρ w) :
    ∀ᵐ t ∂volume.restrict (Icc 0 T), WeakPatchEquation E0 E t ρ w :=
  weak_patch_of_distributional E0 E T ρ hT hρ w finite0 moving hw
    (distributional_of_renormalized_patch E0 E T ρ w me0 moving sol)

end
end Vortex
