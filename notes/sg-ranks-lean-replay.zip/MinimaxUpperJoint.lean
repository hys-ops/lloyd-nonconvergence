import MinimaxUpperParametric
import MinimaxUpperSelection
import MinimaxUpperKL

open MeasureTheory Set Filter
namespace SequentialRanks
noncomputable section

/-- A single measurable mixture-rank estimator, chosen before the true parameter,
simultaneously attains the public local parametric upper bound for every parameter
satisfying the mass and neighborhood KL assumptions. The one geometric input
is the midpoint inequality for versions certified by the transport plan. -/
theorem parametric_estimator_exists {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A)
    (hb : IsCompact B) [Nonempty B] (ν : Measure A) [SFinite ν] (base : ν.map Subtype.val ≪ volume)
    (target : ProbabilityMeasure B) (R : ℝ) (ball : ∀ k ∈ B, normSq k ≤ R^2)
    {Θ : Type*} [PseudoMetricSpace Θ] [MeasurableSpace Θ] [OpensMeasurableSpace Θ]
    (F : IIDFamily Θ A ν) (π : Measure Θ) [IsProbabilityMeasure π] (fallback : Θ)
    (T : ℕ) (hT : 0 < T) (C c k : ℝ) (cp : 0 < c) (cn : 0 ≤ C)
    (midpoint : ∀ θ t, t < T → ∀ h, 0 < historyDensity (F.forecast θ) t h →
      ∀ u v : A → RankPoint d, Measurable u → Measurable v →
      CertifiedRank ((F.forecast θ 0).law PUnit.unit) target u →
      CertifiedRank ((priorForecast F π fallback t).law h) target v →
      (weighted ν (fun y => Real.sqrt (F.density (θ,y))*Real.sqrt ((priorForecast F π fallback t).f (h,y)))).map
        (fun y => mid (u y) (v y)) ≤ (target : Measure B).map Subtype.val) :
    ∃ V : (t : ℕ) → History A t × A → RankPoint d, (∀ t, Measurable (V t)) ∧
      (∀ t h, CertifiedRank ((priorForecast F π fallback t).law h) target (fun y => V t (h,y))) ∧
      ∀ θ, c*(1/Real.sqrt (T:ℝ))^k ≤ π.real (Metric.ball θ (1/Real.sqrt (T:ℝ))) →
        (∀ η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ)),
          InformationTheory.klDiv ((F.forecast θ 0).law PUnit.unit : Measure A)
            ((F.forecast η 0).law PUnit.unit : Measure A) ≤ ENNReal.ofReal (C*(dist η θ)^2)) →
      ∃ U : A → RankPoint d, Measurable U ∧ CertifiedRank ((F.forecast θ 0).law PUnit.unit) target U ∧
        (∑ t ∈ Finset.range T, historyRisk (F.forecast θ) (fun n z => normSq (diff (U z.2) (V n z))) t) ≤
          16*R^2*(C+Real.log (1/c)+(k/2)*Real.log T) := by
  choose V mv vb vc using (fun t => forecast_rank_selector A B ha hb ν target R ball (priorForecast F π fallback t) base)
  refine ⟨V,mv,vc,?_⟩
  intro θ mass localKL
  have law (η) : IsProbabilityMeasure (weighted ν (fun y => F.density (η,y))) :=
    ((F.forecast η 0).law PUnit.unit).property
  have facts η (hη : η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ))) :=
    finite_kl_density_conditions ν (fun y => F.density (θ,y)) (fun y => F.density (η,y))
      (F.measurable.comp (measurable_const.prodMk measurable_id)) (F.measurable.comp (measurable_const.prodMk measurable_id))
      (fun y => F.nonneg _) (fun y => F.nonneg _) (mul_nonneg cn (sq_nonneg (dist η θ))) (localKL η hη)
  obtain ⟨W,mw,bw,cw⟩ := forecast_rank_selector A B ha hb ν target R ball (F.forecast θ 0) base
  let U := fun y : A => W (PUnit.unit,y)
  have mu : Measurable U := mw.comp (measurable_const.prodMk measurable_id)
  have cu : CertifiedRank ((F.forecast θ 0).law PUnit.unit) target U := cw _
  let ρ := (target : Measure B).map Subtype.val
  have prob : IsProbabilityMeasure ρ := by dsimp [ρ]; infer_instance
  have rb : ∀ᵐ y ∂ρ, normSq y ≤ R^2 := by
    apply ae_map_iff measurable_subtype_coe.aemeasurable (measurableSet_le (by unfold normSq; fun_prop) measurable_const) |>.2
    exact .of_forall (fun c => ball c.val c.property)
  have vmeas (t) (h : History A t) : Measurable (fun y => V t (h,y)) := (mv t).comp (measurable_const.prodMk measurable_id)
  refine ⟨U,mu,cu,?_⟩
  exact parametric_bayes_rank_upper F π θ fallback T hT C c k R cp cn mass
    (fun η hη => (facts η hη).1) (fun η hη => (facts η hη).2.1) (fun η hη => (facts η hη).2.2)
    ρ rb U V mu mv (fun y => bw (PUnit.unit,y)) vb (certified_rank_endpoint mu cu)
    (fun t h => certified_rank_endpoint (vmeas t h) (vc t h))
    (fun t ht h ph => midpoint θ t ht h ph U _ mu (vmeas t h) cu (vc t h))

end
end SequentialRanks
