import SquareModel
import MinimaxLowerSquare
import Mathlib.Probability.Moments.Variance
import Mathlib.NumberTheory.Harmonic.Bounds

open MeasureTheory Set ProbabilityTheory
open scoped BigOperators
namespace SequentialRanks
noncomputable section

def sampleStatistic (z : SquareObs) : ℝ := -2*(cosCoord z.1*cosCoord z.2)

private theorem stat_cont : Continuous sampleStatistic := by unfold sampleStatistic cosCoord; fun_prop
private theorem stat_bound (z : SquareObs) : |sampleStatistic z| ≤ 2 := by
  unfold sampleStatistic cosCoord
  rw [abs_mul,abs_mul]
  have h := mul_le_mul (Real.abs_cos_le_one (Real.pi*z.1)) (Real.abs_cos_le_one (Real.pi*z.2)) (abs_nonneg _) (by norm_num)
  norm_num at *; linarith

theorem square_statistic_mean (θ : ℝ) (hθ : |θ| ≤ 1/2) :
    (∫ z,sampleStatistic z ∂squareLaw θ) = θ := by
  let I := Icc (0:ℝ) 1
  let μ := (volume : Measure ℝ).restrict I
  have cc : Continuous cosCoord := by unfold cosCoord; fun_prop
  have a : Integrable cosCoord μ := cc.continuousOn.integrableOn_Icc
  have b : Integrable (fun x => cosCoord x^2) μ := (cc.pow 2).continuousOn.integrableOn_Icc
  have c : Integrable (fun x => cosCoord x^3) μ := (cc.pow 3).continuousOn.integrableOn_Icc
  have dens (z : SquareObs) : 0 ≤ density θ z := (by norm_num : (0:ℝ) ≤ 1/4).trans (actual_density_floor θ z.1 z.2 hθ)
  have md : Measurable (density θ) := by unfold density; fun_prop
  rw [squareLaw,integral_withDensity_eq_integral_toReal_smul (md.ennreal_ofReal) (Filter.Eventually.of_forall (fun _ => ENNReal.ofReal_lt_top))]
  simp only [ENNReal.toReal_ofReal (dens _),smul_eq_mul]
  have expr (z : SquareObs) : density θ z*sampleStatistic z =
    (-2+2*θ^2)*(cosCoord z.1*cosCoord z.2) +
    (4*θ)*(cosCoord z.1^2*cosCoord z.2^2) +
    (-2*θ^2)*((cosCoord z.1^3*cosCoord z.2)+(cosCoord z.1*cosCoord z.2^3)) := by
    rw [density_basis]; unfold sampleStatistic; ring
  unfold squareBase
  rw [Measure.volume_eq_prod ℝ ℝ,←Measure.prod_restrict]
  change (∫ z,density θ z * sampleStatistic z ∂μ.prod μ) = θ
  simp_rw [expr]
  have h1 := (a.mul_prod a).const_mul (-2+2*θ^2)
  have h2 := (b.mul_prod b).const_mul (4*θ)
  have h3 := ((c.mul_prod a).add (a.mul_prod c)).const_mul (-2*θ^2)
  have h4 := integral_add (h1.add h2) h3
  have h5 := integral_add h1 h2
  have h6 := integral_add (c.mul_prod a) (a.mul_prod c)
  simp only [Pi.add_apply] at h4 h5 h6
  rw [h4,h5,integral_const_mul,integral_const_mul,integral_const_mul,h6]
  rw [integral_prod_mul cosCoord cosCoord,integral_prod_mul (fun x => cosCoord x^2) (fun x => cosCoord x^2),
      integral_prod_mul (fun x => cosCoord x^3) cosCoord,integral_prod_mul cosCoord (fun x => cosCoord x^3)]
  change (-2+2*θ^2)*((∫ x in Icc (0:ℝ) 1,cosCoord x)*(∫ x in Icc (0:ℝ) 1,cosCoord x))+
    (4*θ)*((∫ x in Icc (0:ℝ) 1,cosCoord x^2)*(∫ x in Icc (0:ℝ) 1,cosCoord x^2))+
    (-2*θ^2)*((∫ x in Icc (0:ℝ) 1,cosCoord x^3)*(∫ x in Icc (0:ℝ) 1,cosCoord x)+
    (∫ x in Icc (0:ℝ) 1,cosCoord x)*(∫ x in Icc (0:ℝ) 1,cosCoord x^3))=θ
  rw [basis_mean,basis_square_mean]; ring

def clipParam (t : ℝ) := max (-(1/2)) (min (1/2) t)
def iidSampleLaw (n : ℕ) (θ : ℝ) := Measure.pi (fun _ : Fin n => squareLaw θ)
def sampleMean (n : ℕ) (x : Fin n → SquareObs) := (n:ℝ)⁻¹*(∑ i,sampleStatistic (x i))
def estimatedRank (n : ℕ) (x : Fin n → SquareObs) (y : SquareObs) := squareMap (clipParam (sampleMean n x)) y

private theorem clip_contract (x θ : ℝ) (hθ : |θ| ≤ 1/2) :
    (clipParam x-θ)^2 ≤ (x-θ)^2 := by
  obtain ⟨a,b⟩ := abs_le.mp hθ
  unfold clipParam
  rcases le_total x (1/2) with h|h
  · rw [min_eq_right h]
    rcases le_total x (-(1/2)) with j|j
    · rw [max_eq_left j]
      nlinarith [mul_nonneg (sub_nonneg.mpr j) (show 0 ≤ θ-x by linarith),mul_nonneg (sub_nonneg.mpr j) (show 0 ≤ θ+1/2 by linarith)]
    · rw [max_eq_right j]
  · rw [min_eq_left h,max_eq_right (by norm_num)]
    nlinarith [mul_nonneg (sub_nonneg.mpr h) (show 0 ≤ x-θ by linarith),mul_nonneg (sub_nonneg.mpr h) (show 0 ≤ 1/2-θ by linarith)]

private theorem mean_cont (n : ℕ) : Continuous (sampleMean n) := by
  unfold sampleMean
  have h (i : Fin n) : Continuous (fun x : Fin n → SquareObs => sampleStatistic (x i)) :=
    stat_cont.comp (continuous_apply i)
  fun_prop

private theorem clip_cont : Continuous clipParam := by unfold clipParam; fun_prop

private theorem clip_range (x : ℝ) : |clipParam x| ≤ 1/2 := by
  rw [abs_le]; exact ⟨le_max_left _ _,max_le (by norm_num) (min_le_left _ _)⟩

private theorem clippedBound (x θ : ℝ) (hθ : |θ| ≤ 1/2) : (clipParam x-θ)^2 ≤ 1 := by
  have := abs_sub _ _ |>.trans (add_le_add (clip_range x) hθ)
  rw [←sq_abs]; nlinarith only [this,abs_nonneg (clipParam x-θ),
    mul_nonneg (show 0 ≤ 1-|clipParam x-θ| by linarith only [this]) (show 0 ≤ 1+|clipParam x-θ| by positivity)]

private theorem mse_integrable {X : Type*} [MeasurableSpace X] (μ : Measure X) [IsFiniteMeasure μ]
    (g : X → ℝ) (mg : Measurable g) (θ : ℝ) (ht : |θ| ≤ 1/2) :
    Integrable (fun x => (clipParam (g x)-θ)^2) μ := by
  apply Integrable.mono' (integrable_const (1:ℝ)) (((clip_cont.measurable.comp mg).sub measurable_const).pow_const 2).aestronglyMeasurable
  exact ae_of_all _ fun x => by rw [Real.norm_of_nonneg (sq_nonneg _)]; exact clippedBound _ _ ht

theorem clipped_mean_risk (n : ℕ) (hn : 0 < n) (θ : ℝ) (ht : |θ| ≤ 1/2) :
    (∫ x,(clipParam (sampleMean n x)-θ)^2 ∂iidSampleLaw n θ) ≤ 4/n := by
  let ν := squareLaw θ
  let _ : IsProbabilityMeasure ν := square_law_probability ht
  let P := Measure.pi (fun _ : Fin n => ν)
  let g (i : Fin n) := fun x : Fin n → SquareObs => sampleStatistic (x i)
  have h2 : MemLp sampleStatistic 2 ν := MemLp.of_bound stat_cont.aestronglyMeasurable 2 (ae_of_all _ stat_bound)
  have hX (i : Fin n) : MemLp (g i) 2 P := h2.comp_measurePreserving (measurePreserving_eval _ i)
  have iv (i : Fin n) : (∫ x, g i x ∂P) = θ := by
    have he := measurePreserving_eval (fun _ : Fin n => ν) i
    change (∫ x,sampleStatistic (x i) ∂P) = _
    rw [←integral_map he.measurable.aemeasurable stat_cont.aestronglyMeasurable,he.map_eq]
    exact square_statistic_mean θ ht
  have hv : variance sampleStatistic ν ≤ 4 := by
    apply (variance_le_expectation_sq stat_cont.aestronglyMeasurable).trans
    calc
      _ ≤ ∫ _x, (4:ℝ) ∂ν := integral_mono h2.integrable_sq (integrable_const _) fun x => by
        have l := (abs_le.mp (stat_bound x)).1
        have u := (abs_le.mp (stat_bound x)).2
        change sampleStatistic x ^2 ≤ 4
        nlinarith [mul_nonneg (sub_nonneg.mpr u) (show 0 ≤ sampleStatistic x+2 by linarith)]
      _ = 4 := by simp
  have vs := variance_sum_pi (ι := Fin n) (μ := fun _ => ν) (X := fun _ => sampleStatistic) (fun _ => h2)
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at vs
  have hm : (∫ x, sampleMean n x ∂P) = θ := by
    unfold sampleMean
    rw [integral_const_mul,integral_finsetSum _ (fun i _ => (hX i).integrable (by norm_num))]
    change (n:ℝ)⁻¹*(∑ i,∫ x,g i x ∂P) = θ
    simp [iv,hn.ne']
  have hn' : (0:ℝ) < n := by exact_mod_cast hn
  have vm : variance (sampleMean n) P ≤ 4/(n:ℝ) := by
    have mean_eq : sampleMean n = fun x => (n:ℝ)⁻¹*((∑ i, g i) x) := by funext x; simp [sampleMean,g,Finset.sum_apply]
    rw [mean_eq]
    rw [variance_const_mul]
    change _ * variance (∑ i, fun x : Fin n → SquareObs => sampleStatistic (x i)) (Measure.pi (fun _ : Fin n => ν)) ≤ _
    rw [vs]
    calc
      _ ≤ (n:ℝ)⁻¹^2*((n:ℝ)*4) := by gcongr
      _ = _ := by field_simp
  rw [variance_eq_integral (mean_cont n).measurable.aemeasurable,hm] at vm
  have ms : MemLp (sampleMean n) 2 P := by
    have hh := memLp_finsetSum (μ := P) (p := 2) (s := Finset.univ) (fun i _ => hX i)
    unfold sampleMean; simpa only [g,Finset.sum_apply,Pi.mul_apply] using hh.const_mul (n:ℝ)⁻¹
  have tt := (ms.sub (memLp_const θ)).integrable_sq
  exact (integral_mono (mse_integrable P _ (mean_cont n).measurable θ ht) tt
    (fun x => clip_contract (sampleMean n x) θ ht)).trans vm

private theorem max_speed (z : SquareObs) : speed z ≤ 1/Real.pi^2 := by
  unfold speed S2 C2
  have aa (t : ℝ) : Real.sin t^2 ≤ 1 := by nlinarith [Real.sin_sq_add_cos_sq t,sq_nonneg (Real.cos t)]
  have bb (t : ℝ) : Real.cos t^2 ≤ 1 := by nlinarith [Real.sin_sq_add_cos_sq t,sq_nonneg (Real.sin t)]
  conv_rhs => rw [←mul_one (1/Real.pi^2)]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  nlinarith only [mul_le_mul_of_nonneg_left (bb (Real.pi*z.2)) (sq_nonneg (Real.sin (Real.pi*z.1))),
    mul_le_mul_of_nonneg_left (aa (Real.pi*z.2)) (sq_nonneg (Real.cos (Real.pi*z.1))),Real.sin_sq_add_cos_sq (Real.pi*z.1)]

def squareDateRisk (n : ℕ) (θ : ℝ) :=
  ∫ z : (Fin n → SquareObs) × SquareObs,
    squareCost2 (estimatedRank n z.1 z.2) (squareMap θ z.2) ∂(iidSampleLaw n θ).prod (squareLaw θ)

private theorem date_bound (n : ℕ) (θ : ℝ) (ht : |θ| ≤ 1/2) :
    squareDateRisk n θ ≤ (8/Real.pi^2)/(n+1) := by
  let _ : IsProbabilityMeasure (squareLaw θ) := square_law_probability ht
  let _ : IsProbabilityMeasure (iidSampleLaw n θ) := (inferInstance : IsProbabilityMeasure (Measure.pi _))
  let δ (x : Fin n → SquareObs) := (clipParam (sampleMean n x)-θ)^2
  let L (z : (Fin n → SquareObs) × SquareObs) :=
    squareCost2 (estimatedRank n z.1 z.2) (squareMap θ z.2)
  have identity (z) : L z = δ z.1 * speed z.2 := by
    rw [←speed_id]
    unfold L estimatedRank squareCost2 squareMap δ; ring
  have le (z) : L z ≤ δ z.1*(1/Real.pi^2) := identity z ▸
    mul_le_mul_of_nonneg_left (max_speed z.2) (sq_nonneg _)
  have ic : Integrable δ (iidSampleLaw n θ) := mse_integrable _ _ (mean_cont n).measurable θ ht
  have im : Integrable (fun z : (Fin n → SquareObs) × SquareObs => δ z.1*(1/Real.pi^2))
      ((iidSampleLaw n θ).prod (squareLaw θ)) := ((measurePreserving_fst (μ := iidSampleLaw n θ) (ν := squareLaw θ)).integrable_comp_of_integrable ic).mul_const _
  have iL : Integrable L ((iidSampleLaw n θ).prod (squareLaw θ)) := by
    apply im.mono' _ (ae_of_all _ fun z => ?_)
    · have cc : Continuous L := by
        unfold L squareCost2 estimatedRank squareMap perturb
        have hm := mean_cont n
        have hc := clip_cont
        fun_prop
      exact cc.aestronglyMeasurable
    · rw [Real.norm_of_nonneg (show 0 ≤ L z by unfold L squareCost2; positivity)]; exact le z
  have exp := integral_mono iL im le
  rw [integral_mul_const,integral_fun_fst,probReal_univ,one_smul] at exp
  apply exp.trans
  by_cases hn : n=0
  · subst n
    have small := integral_mono ic (integrable_const (1:ℝ)) (fun x => clippedBound (sampleMean 0 x) θ ht)
    rw [integral_const,probReal_univ,one_smul] at small
    simpa only [Nat.cast_zero,zero_add,div_one] using
      (show (∫ x,δ x ∂iidSampleLaw 0 θ)*(1/Real.pi^2) ≤ 8/Real.pi^2 from
        (mul_le_mul_of_nonneg_right small (by positivity : 0 ≤ 1/Real.pi^2)).trans (by
          rw [one_mul]; apply div_le_div_of_nonneg_right (by norm_num) (by positivity)))
  · have hpos : 0 < n := Nat.pos_of_ne_zero hn
    have hn1 : 1 ≤ (n:ℝ) := by exact_mod_cast hpos
    have hnr : 0 < (n:ℝ) := by linarith
    have bound := clipped_mean_risk n hpos θ ht
    apply (mul_le_mul_of_nonneg_right bound (by positivity : 0 ≤ 1/Real.pi^2)).trans
    apply (le_div_iff₀ (by positivity)).mpr
    field_simp
    nlinarith only [hn1]

/-- A single measurable estimator, independent of the unknown parameter, with a
uniform finite-T logarithmic bound for the fixed i.i.d. square model. The date-n
risk averages over the actual independent past and the same current observation. -/
theorem square_iid_uniform_upper (T : ℕ) :
    (∀ n, Measurable (fun z : (Fin n → SquareObs) × SquareObs => estimatedRank n z.1 z.2)) ∧
    ∀ θ, |θ| ≤ 1/2 → (∑ n ∈ Finset.range T, squareDateRisk n θ) ≤
      (8/Real.pi^2)*(1+Real.log T) := by
  constructor
  · intro n
    apply Continuous.measurable
    unfold estimatedRank squareMap perturb
    have hm := mean_cont n
    have hc := clip_cont
    fun_prop
  · intro θ ht
    calc
      _ ≤ ∑ n ∈ Finset.range T, (8/Real.pi^2)/((n:ℝ)+1) := Finset.sum_le_sum fun n _ => date_bound n θ ht
      _ = (8/Real.pi^2)*(harmonic T : ℝ) := by
        simp [harmonic,Rat.cast_sum,Finset.mul_sum,div_eq_mul_inv]
      _ ≤ _ := mul_le_mul_of_nonneg_left (harmonic_le_one_add_log T) (by positivity)

end
end SequentialRanks
