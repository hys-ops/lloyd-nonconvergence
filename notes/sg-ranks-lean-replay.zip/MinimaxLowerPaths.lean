import MinimaxLowerSquare
import Mathlib.Data.Nat.Log

open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def signParameter (b : Bool) : ℝ := if b then 1/2 else -(1/2)
def signLaw (b : Bool) := squareLaw (signParameter b)
instance (b : Bool) : IsProbabilityMeasure (signLaw b) := by
  apply square_law_probability; cases b <;> norm_num [signParameter]

def sqError (a b : SquareObs) : ℝ := (a.1-b.1)^2+(a.2-b.2)^2
def lossE (θ : ℝ) (a z : SquareObs) := ENNReal.ofReal (sqError a (squareMap θ z))
private theorem measurable_loss (θ : ℝ) : Measurable (fun q : SquareObs × SquareObs => lossE θ q.1 q.2) := by
  unfold lossE sqError squareMap perturb; fun_prop
private theorem mg (b : Bool) : Measurable (fun z => ENNReal.ofReal (density (signParameter b) z)) := by
  unfold density; fun_prop

def singleFloor := ENNReal.ofReal (1/(32*Real.pi^2))

/-- Sum of the two risks at one realized history, with no finiteness assumption
on the estimator's risk. -/
theorem hard_pair_sum (e : SquareObs → SquareObs) (he : Measurable e) :
    singleFloor + singleFloor ≤ (∫⁻ z, lossE (signParameter true) (e z) z ∂signLaw true) +
      ∫⁻ z, lossE (signParameter false) (e z) z ∂signLaw false := by
  let L := fun (b : Bool) (z : SquareObs) => lossE (signParameter b) (e z) z
  have ml (b : Bool) : Measurable (L b) := (measurable_loss _).comp (he.prodMk measurable_id)
  let d := fun (b : Bool) (z : SquareObs) => ENNReal.ofReal (density (signParameter b) z)
  have hL (b : Bool) : (∫⁻ z,L b z ∂signLaw b) = ∫⁻ z,d b z*L b z ∂squareBase :=
    lintegral_withDensity_eq_lintegral_mul _ (mg b) (ml b)
  change singleFloor+singleFloor ≤ (∫⁻ z,L true z ∂signLaw true)+(∫⁻ z,L false z ∂signLaw false)
  have md : Measurable (fun z => d true z*L true z) := (mg true).mul (ml true)
  rw [hL,hL,← lintegral_add_left md]
  have ispeed : Integrable speed squareBase := (show Continuous speed by
    unfold speed S2 C2; fun_prop).continuousOn.integrableOn_compact (isCompact_Icc.prod isCompact_Icc)
  have hfloor : singleFloor+singleFloor = ∫⁻ z, ENNReal.ofReal (speed z/8) ∂squareBase := by
    rw [← ofReal_integral_eq_lintegral_ofReal (ispeed.div_const 8) (by
      filter_upwards with z; rw [←speed_id]; positivity),integral_div]
    change singleFloor+singleFloor = ENNReal.ofReal ((∫ z in (Icc (0:ℝ) 1) ×ˢ Icc 0 1,speed z)/8)
    rw [square_energy]
    unfold singleFloor
    rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
    congr 1; ring
  rw [hfloor]
  apply lintegral_mono
  intro z
  have hd (b : Bool) : 0 ≤ density (signParameter b) z := by
    apply (by norm_num : (0:ℝ) ≤ 1/4).trans
    apply actual_density_floor; cases b <;> norm_num [signParameter]
  have er (b : Bool) : 0 ≤ sqError (e z) (squareMap (signParameter b) z) := by unfold sqError; positivity
  change ENNReal.ofReal (speed z/8) ≤
    ENNReal.ofReal _ * ENNReal.ofReal _ + ENNReal.ofReal _ * ENNReal.ofReal _
  rw [← ENNReal.ofReal_mul (hd true),← ENNReal.ofReal_mul (hd false),
    ← ENNReal.ofReal_add (mul_nonneg (hd true) (er true)) (mul_nonneg (hd false) (er false))]
  apply ENNReal.ofReal_le_ofReal
  have h := pair_pointwise e z
  change _ ≤ (density (1/2) z*sqError (e z) (squareMap (1/2) z) +
    density (-(1/2)) z*sqError (e z) (squareMap (-(1/2)) z))/2 at h
  simp only [signParameter,ite_true,Bool.false_eq_true,ite_false]
  linarith

/-- Coordinate n+1 appends the current observation to the ordered past. -/
def Past : ℕ → Type
  | 0 => Unit
  | n+1 => Past n × SquareObs
instance pastMeas : (n : ℕ) → MeasurableSpace (Past n)
  | 0 => (inferInstance : MeasurableSpace Unit)
  | n+1 => @Prod.instMeasurableSpace _ _ (pastMeas n) inferInstance

def Word : ℕ → Type
  | 0 => Unit
  | n+1 => Word n × Bool

def wordLaw : (n : ℕ) → Word n → Measure (Past n)
  | 0, _ => Measure.dirac ()
  | n+1, w => (wordLaw n w.1).prod (signLaw w.2)

instance wordProb : ∀ (n : ℕ) (w : Word n), IsProbabilityMeasure (wordLaw n w)
  | 0, _ => (inferInstance : IsProbabilityMeasure (Measure.dirac ()))
  | n+1, w => by
    let _ := wordProb n w.1
    change IsProbabilityMeasure ((wordLaw n w.1).prod (signLaw w.2))
    infer_instance

def pathLoss (A : ∀ n, Past n × SquareObs → SquareObs) : (n : ℕ) → Word n → Past n → ℝ≥0∞
  | 0, _, _ => 0
  | n+1, w, x => pathLoss A n w.1 x.1 + lossE (signParameter w.2) (A n x) x.2

private theorem measurable_pathLoss (A : ∀ n, Past n × SquareObs → SquareObs)
    (hA : ∀ n, Measurable (A n)) : ∀ n w, Measurable (pathLoss A n w)
  | 0, _ => measurable_const
  | n+1, w => ((measurable_pathLoss A hA n w.1).comp measurable_fst).add
      ((measurable_loss _).comp ((hA n).prodMk measurable_snd))

theorem hard_sign_after_history {X : Type} [MeasurableSpace X] (μ : Measure X) [IsProbabilityMeasure μ]
    (a : X × SquareObs → SquareObs) (ma : Measurable a) :
    ∃ b, singleFloor ≤ ∫⁻ x, lossE (signParameter b) (a x) x.2 ∂μ.prod (signLaw b) := by
  let f (b : Bool) (x : X × SquareObs) := lossE (signParameter b) (a x) x.2
  have mf (b : Bool) : Measurable (f b) := (measurable_loss _).comp (ma.prodMk measurable_snd)
  have hh (x : X) := hard_pair_sum (fun z => a (x,z)) (ma.comp (measurable_const.prodMk measurable_id))
  let v (b : Bool) := ∫⁻ x,f b x ∂μ.prod (signLaw b)
  have step : singleFloor+singleFloor ≤ v true + v false := by
    dsimp [v]
    rw [lintegral_prod _ (mf true).aemeasurable,lintegral_prod _ (mf false).aemeasurable,
      ← lintegral_add_left (mf true).lintegral_prod_right']
    calc
      _ = ∫⁻ _ : X, singleFloor+singleFloor ∂μ := by simp
      _ ≤ _ := lintegral_mono hh
  by_cases h : singleFloor ≤ v true
  · exact ⟨true,h⟩
  · refine ⟨false,?_⟩
    exact le_of_not_gt (fun hf => (not_lt_of_ge step) (ENNReal.add_lt_add (lt_of_not_ge h) hf))

/-- For every sequential estimator using all past observations and the current
one, some fixed sign word attains the lower bound under its independent product
law. Loss is extended nonnegative, so infinite-risk policies are included. -/
theorem hard_list_path_lower (A : ∀ n, Past n × SquareObs → SquareObs)
    (hA : ∀ n, Measurable (A n)) (n : ℕ) :
    ∃ w : Word n, (n:ℝ≥0∞)*singleFloor ≤ ∫⁻ x,pathLoss A n w x ∂wordLaw n w := by
  induction n with
  | zero => exact ⟨(),by simp⟩
  | succ n ih =>
    obtain ⟨w,hw⟩ := ih
    obtain ⟨b,hb⟩ := hard_sign_after_history (wordLaw n w) (A n) (hA n)
    refine ⟨(w,b),?_⟩
    change _ ≤ ∫⁻ x : Past n × SquareObs,
      pathLoss A n w x.1 + lossE (signParameter b) (A n x) x.2 ∂(wordLaw n w).prod (signLaw b)
    have mm : Measurable (fun x : Past n × SquareObs => pathLoss A n w x.1) :=
      (measurable_pathLoss A hA n w).comp measurable_fst
    rw [lintegral_add_left mm,lintegral_prod _ mm.aemeasurable]
    simpa [Nat.cast_succ,add_mul] using add_le_add hw hb

instance wordFintype : (n : ℕ) → Fintype (Word n)
  | 0 => (inferInstance : Fintype Unit)
  | n+1 => @instFintypeProd _ _ (wordFintype n) inferInstance

private theorem card_words (n : ℕ) : Fintype.card (Word n)=2^n := by
  induction n with
  | zero => change Fintype.card Unit=2^0; simp
  | succ n ih => change Fintype.card (Word n × Bool)=_; rw [Fintype.card_prod,ih,pow_succ]; simp

/-- After the early signs, append independent observations of density p₀. -/
def paddedLaw {n : ℕ} (w : Word n) : (k : ℕ) → Measure (Past (n+k))
  | 0 => wordLaw n w
  | k+1 => (paddedLaw w k).prod (squareLaw 0)

instance neutralProb : IsProbabilityMeasure (squareLaw 0) := square_law_probability (by norm_num)
instance paddedProb {n : ℕ} (w : Word n) : (k : ℕ) → IsProbabilityMeasure (paddedLaw w k)
  | 0 => wordProb n w
  | k+1 => by let _ := paddedProb w k; change IsProbabilityMeasure ((paddedLaw w k).prod (squareLaw 0)); infer_instance

def paddedLoss (A : ∀ n, Past n × SquareObs → SquareObs) {n : ℕ} (w : Word n) :
    (k : ℕ) → Past (n+k) → ℝ≥0∞
  | 0, x => pathLoss A n w x
  | k+1, x => paddedLoss A w k x.1 + lossE 0 (A (n+k) x) x.2

private theorem measurable_padded (A : ∀ n, Past n × SquareObs → SquareObs)
    (hA : ∀ n, Measurable (A n)) {n : ℕ} (w : Word n) :
    ∀ k, Measurable (paddedLoss A w k)
  | 0 => measurable_pathLoss A hA n w
  | k+1 => ((measurable_padded A hA w k).comp measurable_fst).add
      ((measurable_loss 0).comp ((hA (n+k)).prodMk measurable_snd))

private theorem risk_padded (A : ∀ n, Past n × SquareObs → SquareObs)
    (hA : ∀ n, Measurable (A n)) {n : ℕ} (w : Word n) (k : ℕ) :
    (∫⁻ x,pathLoss A n w x ∂wordLaw n w) ≤ ∫⁻ x,paddedLoss A w k x ∂paddedLaw w k := by
  induction k with
  | zero => exact le_rfl
  | succ k ih =>
    apply ih.trans
    change _ ≤ ∫⁻ x : Past (n+k) × SquareObs, paddedLoss A w k x.1 + lossE 0 (A (n+k) x) x.2
      ∂(paddedLaw w k).prod (squareLaw 0)
    have m : Measurable (fun x : Past (n+k) × SquareObs => paddedLoss A w k x.1) :=
      (measurable_padded A hA w k).comp measurable_fst
    rw [lintegral_add_left m,lintegral_prod _ m.aemeasurable]
    simp

/-- The public finite-list lower constant, horizon and list-size budget. The hard
candidate is chosen once, before the independent observations are drawn. -/
theorem minimax_hard_list_lower (T M : ℕ) (hM : M ≠ 0)
    (A : ∀ n, Past n × SquareObs → SquareObs) (hA : ∀ n, Measurable (A n)) :
    let l := min T (Nat.log 2 M)
    l+(T-l)=T ∧ Fintype.card (Word l) ≤ M ∧
      ∃ w : Word l, (l:ℝ≥0∞)*singleFloor ≤ ∫⁻ x,paddedLoss A w (T-l) x ∂paddedLaw w (T-l) := by
  dsimp only
  let l := min T (Nat.log 2 M)
  have len : l ≤ T := min_le_left _ _
  have hcard : Fintype.card (Word l) ≤ M := by
    rw [card_words]; exact (Nat.pow_le_pow_right (by decide : 0 < 2) (min_le_right _ _)).trans
      (Nat.pow_log_le_self 2 hM)
  obtain ⟨w,hw⟩ := hard_list_path_lower A hA l
  exact ⟨by omega,hcard,w,hw.trans (risk_padded A hA w _)⟩


/-- A single M-entry catalog, fixed before the estimator is chosen. Surplus
entries repeat an existing candidate. Every hard word occurs in the catalog. -/
theorem minimax_exact_catalog_lower (T M : ℕ) (hM : M ≠ 0) :
    let l := min T (Nat.log 2 M)
    ∃ catalog : Fin M → Word l, Function.Surjective catalog ∧
      ∀ (A : ∀ n, Past n × SquareObs → SquareObs), (∀ n, Measurable (A n)) →
      ∃ j : Fin M, (l:ℝ≥0∞)*singleFloor ≤
        ∫⁻ x,paddedLoss A (catalog j) (T-l) x ∂paddedLaw (catalog j) (T-l) := by
  classical
  dsimp only
  let l := min T (Nat.log 2 M)
  have hcard : Fintype.card (Word l) ≤ M := by
    rw [card_words]; exact (Nat.pow_le_pow_right (by decide : 0 < 2) (min_le_right _ _)).trans
      (Nat.pow_log_le_self _ hM)
  have hpos : 0 < Fintype.card (Word l) := by rw [card_words]; positivity
  let eqv := Fintype.equivFin (Word l)
  let catalog (j : Fin M) := eqv.symm (if hj : j.val < Fintype.card (Word l) then ⟨j.val,hj⟩ else ⟨0,hpos⟩)
  have onto : Function.Surjective catalog := by
    intro w
    refine ⟨(eqv w).castLE hcard,?_⟩
    simp [catalog,(eqv w).isLt]
  refine ⟨catalog,onto,?_⟩
  intro A mA
  obtain ⟨_,_,w,hw⟩ := minimax_hard_list_lower T M hM A mA
  obtain ⟨j,hj⟩ := onto w
  exact ⟨j,by simpa [hj] using hw⟩

end
end SequentialRanks
