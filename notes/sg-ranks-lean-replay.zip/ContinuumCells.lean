import ContinuumGrid
import ContinuumPlans

open MeasureTheory Filter Set
open scoped Topology ENNReal BoundedContinuousFunction BigOperators InnerProductSpace
namespace Vortex
noncomputable section

set_option linter.unusedSectionVars false

variable {Y K F : Type*}
    [MetricSpace Y] [SecondCountableTopology Y] [CompleteSpace Y] [MeasurableSpace Y] [BorelSpace Y]
    [MetricSpace K] [SecondCountableTopology K] [CompleteSpace K] [MeasurableSpace K] [BorelSpace K]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F] [SecondCountableTopology F] [MeasurableSpace F] [BorelSpace F]

def labelPlan (G : CommonGrid Y) (T : ProbabilityMeasure K) (tag : K → Fin G.size) :=
  T.map (fun k => (G.site (tag k),k))

/-- Static semidiscrete geometry. The label has the prescribed masses and its
joint transport has cyclically monotone support for the given cost. -/
structure CellFit (c : Y × K → ℝ) (G : CommonGrid Y) (P : ProbabilityMeasure Y)
    (T : ProbabilityMeasure K) (tag : K → Fin G.size) : Prop where
  measurable : Measurable tag
  masses : T.map tag = P.map G.label
  cyclic : SequentialRanks.cyclicSupport c (labelPlan G T tag)

theorem CellFit.certificate {c : Y × K → ℝ} {G : CommonGrid Y} {P : ProbabilityMeasure Y}
    {T : ProbabilityMeasure K} {tag : K → Fin G.size} (fit : CellFit c G P T tag) :
    SequentialRanks.certifiedPlan c (P.map G.round) T (labelPlan G T tag) := by
  have mz : Measurable (fun x => (G.site (tag x),x)) := ((measurable_of_finite G.site).comp fit.measurable).prodMk measurable_id
  refine ⟨ProbabilityMeasure.toMeasure_injective ?_,ProbabilityMeasure.toMeasure_injective ?_,fit.cyclic⟩
  · have same := congrArg (fun u : ProbabilityMeasure (Fin G.size) => (u : Measure (Fin G.size)).map G.site) fit.masses
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map (measurable_of_finite G.site)
      fit.measurable,Measure.map_map (measurable_of_finite G.site) G.measurableLabel] using
      (show (labelPlan G T tag : Measure (Y × K)).map Prod.fst = (P : Measure Y).map G.round from by
        rw [labelPlan,ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst mz]
        exact (by simpa [Measure.map_map (measurable_of_finite G.site) fit.measurable,
          Measure.map_map (measurable_of_finite G.site) G.measurableLabel] using same :
          (T : Measure K).map (G.site ∘ tag) = (P : Measure Y).map (G.site ∘ G.label)))
  · change ((T : Measure K).map _).map Prod.snd = _
    rw [Measure.map_map measurable_snd mz]
    exact Measure.map_id

theorem CellFit.mass_at {c : Y × K → ℝ} {G : CommonGrid Y} {P : ProbabilityMeasure Y}
    {T : ProbabilityMeasure K} {tag : K → Fin G.size} (fit : CellFit c G P T tag) (i : Fin G.size) :
    (T : Measure K).real (tag ⁻¹' {i}) = (P : Measure Y).real (G.label ⁻¹' {i}) := by
  have same := congrArg (fun u : ProbabilityMeasure (Fin G.size) => (u : Measure (Fin G.size)) {i}) fit.masses
  simpa [Measure.real,Measure.map_apply fit.measurable (measurableSet_singleton i),
    Measure.map_apply G.measurableLabel (measurableSet_singleton i)] using congrArg ENNReal.toReal same

def rawMoment {n : ℕ} (T : ProbabilityMeasure K) (tag : K → Fin n)
    (k : K →ᵇ F) (i : Fin n) : F := ∫ x in tag ⁻¹' {i}, k x ∂(T : Measure K)

private theorem sum_fiber_integrals {n : ℕ} {A E : Type*} [MeasurableSpace A]
    [NormedAddCommGroup E] [NormedSpace ℝ E] {μ : Measure A}
    (s : A → Fin n) (hs : Measurable s) (f : A → E) (hf : Integrable f μ) :
    (∑ i, ∫ x in s ⁻¹' {i}, f x ∂μ) = ∫ x, f x ∂μ := by
  rw [← integral_iUnion_fintype (fun i => hs (measurableSet_singleton i)) _ (fun _ => hf.integrableOn)]
  · have full : (⋃ i, s ⁻¹' {i}) = univ := by ext x; simp
    rw [full,setIntegral_univ]
  · intro a b hab
    exact Disjoint.preimage s (Set.disjoint_singleton.mpr hab)

private theorem paired_integrable {A : Type*} [MeasurableSpace A] {μ : Measure A}
    [IsFiniteMeasure μ] {f g : A → F} (mf : AEStronglyMeasurable f μ) (mg : AEStronglyMeasurable g μ)
    (C D : ℝ) (bc : ∀ x, ‖f x‖ ≤ C) (bd : ∀ x, ‖g x‖ ≤ D) :
    Integrable (fun x => ⟪f x,g x⟫_ℝ) μ := by
  exact (integrable_const (C*D)).mono' (mf.inner mg) (.of_forall fun x =>
    (norm_inner_le_norm _ _).trans (mul_le_mul (bc x) (bd x) (norm_nonneg _) ((norm_nonneg _).trans (bc x))))

theorem rawMoment_test (G : CommonGrid Y) (T : ProbabilityMeasure K)
    (tag : K → Fin G.size) (ht : Measurable tag) (k : K →ᵇ F) (g : Y →ᵇ F) :
    (∑ i, ⟪rawMoment T tag k i,g (G.site i)⟫_ℝ) =
      ∫ z : Y × K, ⟪k z.2,g z.1⟫_ℝ ∂(labelPlan G T tag : Measure (Y × K)) := by
  let ψ := fun x => g (G.site (tag x))
  have mψ : Measurable ψ := g.continuous.measurable.comp ((measurable_of_finite G.site).comp ht)
  have mz : Measurable (fun x => (G.site (tag x),x)) := ((measurable_of_finite G.site).comp ht).prodMk measurable_id
  have mc : Continuous (fun z : Y × K => ⟪k z.2,g z.1⟫_ℝ) := (k.continuous.comp continuous_snd).inner (g.continuous.comp continuous_fst)
  rw [labelPlan,ProbabilityMeasure.toMeasure_map,integral_map mz.aemeasurable mc.aestronglyMeasurable]
  change _ = ∫ x, ⟪k x,ψ x⟫_ℝ ∂(T : Measure K)
  rw [← sum_fiber_integrals tag ht _ (paired_integrable k.continuous.aestronglyMeasurable
    mψ.aestronglyMeasurable ‖k‖ ‖g‖ k.norm_coe_le_norm (fun x => g.norm_coe_le_norm _))]
  have ik : Integrable k (T : Measure K) := (integrable_const ‖k‖).mono'
    k.continuous.aestronglyMeasurable (.of_forall k.norm_coe_le_norm)
  apply Finset.sum_congr rfl
  intro i _
  rw [real_inner_comm,rawMoment,← integral_inner ik.integrableOn]
  apply setIntegral_congr_fun (ht (measurableSet_singleton _))
  intro x hx
  change tag x = i at hx
  simp [ψ,hx,real_inner_comm]

private theorem mass_square_test (G : CommonGrid Y) (P : ProbabilityMeasure Y) (g : Y →ᵇ F) :
    (∑ i, (P : Measure Y).real (G.label ⁻¹' {i}) * ‖g (G.site i)‖^2) =
      ∫ y, ‖g y‖^2 ∂(P.map G.round : Measure Y) := by
  have hi : Integrable (fun y => ‖g (G.round y)‖^2) (P : Measure Y) := by
    refine (integrable_const (‖g‖^2)).mono' ((g.continuous.measurable.comp G.measurable_round).norm.pow_const 2).aestronglyMeasurable ?_
    exact .of_forall (fun y => by change ‖‖g (G.round y)‖^2‖ ≤ ‖g‖^2; rw [Real.norm_eq_abs,abs_of_nonneg (sq_nonneg _)]; exact pow_le_pow_left₀ (norm_nonneg _) (g.norm_coe_le_norm _) _)
  have mg : Continuous (fun y => ‖g y‖^2) := g.continuous.norm.pow 2
  rw [ProbabilityMeasure.toMeasure_map,integral_map G.measurable_round.aemeasurable mg.aestronglyMeasurable]
  rw [← G.sum_fibers _ hi]
  apply Finset.sum_congr rfl
  intro i _
  rw [← smul_eq_mul,← setIntegral_const]
  apply setIntegral_congr_fun (G.measurableLabel (measurableSet_singleton _))
  intro y hy
  change G.label y = i at hy
  simp [CommonGrid.round,hy]


/-- Limit theorem in measure form. The finite input involves only the actual
labels of two finite transports from the common physical law. The pairing
identifies the derivative of the difference of the limiting first-moment
measures relative to the sum of their geostrophic marginals. -/
theorem endpoint_from_finite_cells (c : Y × K → ℝ) (hc : Continuous c)
    (k : K →ᵇ F) (P Q : ProbabilityMeasure Y) (T : ProbabilityMeasure K)
    (L M : ProbabilityMeasure (Y × K))
    (uniqueP : ∀ η, SequentialRanks.certifiedPlan c P T η → η = L)
    (uniqueQ : ∀ η, SequentialRanks.certifiedPlan c Q T η → η = M)
    (f : Y → F) (hf : MemLp f 2 ((P : Measure Y)+(Q : Measure Y)))
    (pairing : ∀ g : Y →ᵇ F,
      (∫ z, ⟪k z.2,g z.1⟫_ℝ ∂(L : Measure (Y × K))) -
      (∫ z, ⟪k z.2,g z.1⟫_ℝ ∂(M : Measure (Y × K))) =
      ∫ y, ⟪f y,g y⟫_ℝ ∂((P : Measure Y)+(Q : Measure Y)))
    (C : ℝ) (finiteGeom : ∀ G : CommonGrid Y,
      ∃ a b : K → Fin G.size, CellFit c G P T a ∧ CellFit c G Q T b ∧
      ∑ i, ‖rawMoment T a k i - rawMoment T b k i‖^2 /
        ((P : Measure Y).real (G.label ⁻¹' {i})+(Q : Measure Y).real (G.label ⁻¹' {i})) ≤ C) :
    (∫ y, ‖f y‖^2 ∂((P : Measure Y)+(Q : Measure Y))) ≤ C := by
  choose G hG using common_grids_for_all_laws (Y := Y)
  choose a b ha hb bd using fun n => finiteGeom (G n)
  have pa := stability_of_quantized_plans c hc _ (fun _ => T) P T
    (fun n => labelPlan (G n) T (a n)) L (hG P) tendsto_const_nhds (fun n => (ha n).certificate) uniqueP
  have pb := stability_of_quantized_plans c hc _ (fun _ => T) Q T
    (fun n => labelPlan (G n) T (b n)) M (hG Q) tendsto_const_nhds (fun n => (hb n).certificate) uniqueQ
  refine endpoint_of_atomic_weak_limit f hf (fun n => (G n).size) (fun n => (G n).site)
    (fun n i => (P : Measure Y).real ((G n).label ⁻¹' {i})+(Q : Measure Y).real ((G n).label ⁻¹' {i}))
    (fun n i => rawMoment T (a n) k i - rawMoment T (b n) k i) C
    (fun _ _ => add_nonneg ENNReal.toReal_nonneg ENNReal.toReal_nonneg) ?_ bd ?_ ?_
  · intro n i h
    have h0 := (add_eq_zero_iff_of_nonneg ENNReal.toReal_nonneg ENNReal.toReal_nonneg).mp h
    have za : (T : Measure K) ((a n) ⁻¹' {i}) = 0 := (ENNReal.toReal_eq_zero_iff _).mp
      (((ha n).mass_at i).trans h0.1) |>.resolve_right (measure_ne_top (T : Measure K) _)
    have zb : (T : Measure K) ((b n) ⁻¹' {i}) = 0 := (ENNReal.toReal_eq_zero_iff _).mp
      (((hb n).mass_at i).trans h0.2) |>.resolve_right (measure_ne_top (T : Measure K) _)
    simp [rawMoment,Measure.restrict_eq_zero.mpr za,Measure.restrict_eq_zero.mpr zb]
  · intro g
    rw [← pairing]
    refine ((plan_moment_test_convergence pa k g).sub (plan_moment_test_convergence pb k g)).congr (fun n => ?_)
    simp only [inner_sub_left,Finset.sum_sub_distrib]
    rw [rawMoment_test (G n) T (a n) (ha n).measurable k g,
      rawMoment_test (G n) T (b n) (hb n).measurable k g]
  · intro g
    let sqg : Y →ᵇ ℝ := BoundedContinuousFunction.ofNormedAddCommGroup
      (fun y => ‖g y‖^2) (g.continuous.norm.pow 2) (‖g‖^2) (fun y => by
        rw [Real.norm_eq_abs,abs_of_nonneg (sq_nonneg _)]; exact pow_le_pow_left₀ (norm_nonneg _) (g.norm_coe_le_norm _) _)
    have a1 := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp (hG P) sqg
    have b1 := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp (hG Q) sqg
    have integ (D : ProbabilityMeasure Y) : Integrable (fun y => ‖g y‖^2) (D : Measure Y) :=
      (memLp_two_iff_integrable_sq_norm (g.memLp_top (μ := (D : Measure Y))).aestronglyMeasurable).mp
        ((g.memLp_top (μ := (D : Measure Y))).mono_exponent le_top)
    rw [integral_add_measure (integ P) (integ Q)]
    apply (a1.add b1).congr
    intro n
    change (∫ y, ‖g y‖^2 ∂(P.map (G n).round : Measure Y))+
      (∫ y, ‖g y‖^2 ∂(Q.map (G n).round : Measure Y)) = _
    simp only [add_mul,Finset.sum_add_distrib,mass_square_test]

end
end Vortex
