import RankTransport
import Mathlib.MeasureTheory.Function.AEEqOfLIntegral
import Mathlib.InformationTheory.KullbackLeibler.Basic

open MeasureTheory InformationTheory Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

/-- Hellinger–KL comparison for the extended, measure-theoretic KL divergence.
Zero densities and infinite KL require no support convention on the quotient. -/
theorem hellinger_le_measure_kl {X : Type*} [MeasurableSpace X] (μ : Measure X) [SigmaFinite μ]
    (p q : X → ℝ) (mp : Measurable p) (mq : Measurable q) (pn : ∀ x, 0 ≤ p x)
    (qn : ∀ x, 0 ≤ q x) (ip : Integrable p μ) (iq : Integrable q μ) :
    ENNReal.ofReal (∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2 ∂μ) ≤ klDiv (weighted μ p) (weighted μ q) := by
  let P := weighted μ p
  let Q := weighted μ q
  have fP : IsFiniteMeasure P := isFiniteMeasure_withDensity_ofReal ip.2
  have fQ : IsFiniteMeasure Q := isFiniteMeasure_withDensity_ofReal iq.2
  change _ ≤ klDiv P Q
  by_cases ac : P ≪ Q
  swap; · rw [klDiv_of_not_ac ac]; exact le_top
  let r := P.rnDeriv Q
  let ep := fun x => ENNReal.ofReal (p x)
  let eq := fun x => ENNReal.ofReal (q x)
  have mp' : Measurable ep := ENNReal.measurable_ofReal.comp mp
  have mq' : Measurable eq := ENNReal.measurable_ofReal.comp mq
  have mr : Measurable r := P.measurable_rnDeriv Q
  have e : μ.withDensity ep = μ.withDensity (eq * r) := by
    rw [withDensity_mul μ mq' mr]
    exact (P.withDensity_rnDeriv_eq Q ac).symm
  have densities := (withDensity_eq_iff_of_sigmaFinite mp'.aemeasurable (mq'.mul mr).aemeasurable).mp e
  have ih : Integrable (fun x => (Real.sqrt (p x)-Real.sqrt (q x))^2) μ := by
    apply (ip.add iq).mono' (show Measurable (fun x => (Real.sqrt (p x)-Real.sqrt (q x))^2) by fun_prop).aestronglyMeasurable
    filter_upwards with x
    rw [Real.norm_of_nonneg (sq_nonneg _)]
    change _ ≤ p x+q x
    nlinarith only [Real.sq_sqrt (pn x),Real.sq_sqrt (qn x),mul_nonneg (Real.sqrt_nonneg (p x)) (Real.sqrt_nonneg (q x))]
  rw [ofReal_integral_eq_lintegral_ofReal ih (.of_forall fun _ => sq_nonneg _),klDiv_eq_lintegral_klFun,ite_eq_left ac]
  change _ ≤ ∫⁻ x, ENNReal.ofReal (klFun (r x).toReal) ∂μ.withDensity eq
  rw [lintegral_withDensity_eq_lintegral_mul μ mq' (show Measurable (fun x => ENNReal.ofReal (klFun (r x).toReal)) by fun_prop)]
  apply lintegral_mono_ae
  filter_upwards [densities] with x hx
  have rat := congrArg ENNReal.toReal hx
  change (ENNReal.ofReal (p x)).toReal = (ENNReal.ofReal (q x)*r x).toReal at rat
  rw [ENNReal.toReal_ofReal (pn x),ENNReal.toReal_mul,ENNReal.toReal_ofReal (qn x)] at rat
  have h := hellinger_kl_pointwise (r x).toReal 1 ENNReal.toReal_nonneg zero_le_one (by simp)
  simp only [Real.sqrt_one,div_one] at h
  have hr : (Real.sqrt (r x).toReal-1)^2 ≤ klFun (r x).toReal := by rw [klFun_apply]; linarith
  change ENNReal.ofReal _ ≤ ENNReal.ofReal (q x)*ENNReal.ofReal _
  rw [← ENNReal.ofReal_mul (qn x),rat,Real.sqrt_mul (qn x)]
  apply ENNReal.ofReal_le_ofReal
  calc _ = (Real.sqrt (q x))^2 * (Real.sqrt (r x).toReal-1)^2 := by ring
       _ ≤ _ := by rw [Real.sq_sqrt (qn x)]; exact mul_le_mul_of_nonneg_left hr (qn x)

end
end SequentialRanks
