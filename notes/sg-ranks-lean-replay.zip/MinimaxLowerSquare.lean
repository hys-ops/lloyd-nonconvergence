import RankPair
import Mathlib.MeasureTheory.Measure.WithDensity

open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

abbrev SquareObs := ℝ × ℝ
def squareBase : Measure SquareObs :=
  volume.restrict ((Icc (0:ℝ) 1) ×ˢ Icc 0 1)
def cosCoord (x : ℝ) := Real.cos (Real.pi*x)
def squareMap (θ : ℝ) (z : SquareObs) : SquareObs :=
  (z.1+θ*(perturb z).1,z.2+θ*(perturb z).2)

theorem basis_mean : (∫ x in Icc (0:ℝ) 1, cosCoord x) = 0 := by
  rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le (by norm_num)]
  unfold cosCoord
  rw [intervalIntegral.integral_comp_mul_left _ Real.pi_ne_zero]
  simp [integral_cos]
theorem basis_square_mean : (∫ x in Icc (0:ℝ) 1, cosCoord x^2) = 1/2 := by
  rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le (by norm_num)]
  unfold cosCoord
  rw [intervalIntegral.integral_comp_mul_left (fun t => Real.cos t ^ 2) Real.pi_ne_zero]
  simp [integral_cos_sq,smul_eq_mul]; field_simp

theorem density_basis (θ : ℝ) (z : SquareObs) :
    density θ z = 1-2*θ*(cosCoord z.1*cosCoord z.2) +
      θ^2*(cosCoord z.1^2*1 + 1*cosCoord z.2^2 - 1) := by
  unfold density cosCoord
  rw [mul_add Real.pi,mul_sub Real.pi,Real.cos_add,Real.cos_sub]
  have h (a b c d : ℝ) : (1-θ*(a*b-c*d))*(1-θ*(a*b+c*d)) =
    1-2*θ*(a*b)+θ^2*(a^2*b^2-c^2*d^2) := by ring
  rw [h,Real.sin_sq,Real.sin_sq]
  ring

private theorem continuous_density (θ : ℝ) : Continuous (density θ) := by
  unfold density; fun_prop

theorem square_density_normalized (θ : ℝ) : (∫ z,density θ z ∂squareBase) = 1 := by
  let I := Icc (0:ℝ) 1
  let μ := (volume : Measure ℝ).restrict I
  have one : (∫ _x, (1:ℝ) ∂μ)=1 := by simp [μ,I,Measure.real,Real.volume_Icc]
  have cc : Continuous cosCoord := by unfold cosCoord; fun_prop
  have a : Integrable cosCoord μ := cc.continuousOn.integrableOn_Icc
  have b : Integrable (fun x => cosCoord x^2) μ := (cc.pow 2).continuousOn.integrableOn_Icc
  have c : Integrable (fun _ : ℝ => (1:ℝ)) μ := continuous_const.continuousOn.integrableOn_Icc
  have p := a.mul_prod a
  have p1 := b.mul_prod c
  have p2 := c.mul_prod b
  have p0 := c.mul_prod c
  simp only [mul_one] at p0
  unfold squareBase
  rw [Measure.volume_eq_prod ℝ ℝ,← Measure.prod_restrict]
  change (∫ z,density θ z ∂μ.prod μ)=1
  simp_rw [density_basis]
  have main := integral_add (p0.sub (p.const_mul (2*θ))) (((p1.add p2).sub p0).const_mul (θ^2))
  have sub1 := integral_sub p0 (p.const_mul (2*θ))
  have sub2 := integral_sub (p1.add p2) p0
  have add12 := integral_add p1 p2
  simp only [Pi.sub_apply,Pi.add_apply] at main sub1 sub2 add12
  rw [main,sub1,integral_const_mul,integral_const_mul,sub2,add12,
      integral_prod_mul cosCoord cosCoord,integral_prod_mul (fun x => cosCoord x^2) (fun _ => (1:ℝ)),integral_prod_mul (fun _ => (1:ℝ)) (fun x => cosCoord x^2)]
  have p01 : (∫ _z : ℝ × ℝ, (1:ℝ) ∂μ.prod μ)=1 := by
    have id := integral_prod_mul (μ:=μ) (ν:=μ) (fun _ : ℝ => (1:ℝ)) (fun _ : ℝ => (1:ℝ))
    simpa [one] using id
  rw [p01,one]
  change 1-2*θ*((∫ x in Icc (0:ℝ) 1,cosCoord x)*(∫ x in Icc (0:ℝ) 1,cosCoord x))+
    θ^2*((∫ x in Icc (0:ℝ) 1,cosCoord x^2)*1+1*(∫ x in Icc (0:ℝ) 1,cosCoord x^2)-1)=1
  rw [basis_mean,basis_square_mean]; ring

def squareLaw (θ : ℝ) : Measure SquareObs :=
  squareBase.withDensity (fun z => ENNReal.ofReal (density θ z))

theorem square_law_probability {θ : ℝ} (hθ : |θ| ≤ 1/2) : IsProbabilityMeasure (squareLaw θ) := by
  constructor
  rw [squareLaw,withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ,
    ← ofReal_integral_eq_lintegral_ofReal, square_density_normalized,ENNReal.ofReal_one]
  · exact (continuous_density θ).continuousOn.integrableOn_compact (isCompact_Icc.prod isCompact_Icc)
  · filter_upwards with z
    exact (by norm_num : (0:ℝ) ≤ 1/4).trans (actual_density_floor θ z.1 z.2 hθ)
end
end SequentialRanks
