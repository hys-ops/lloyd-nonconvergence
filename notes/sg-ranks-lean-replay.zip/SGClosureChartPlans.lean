import SGClosureChart
import SGClosureData
import PredictiveRanks

open MeasureTheory Set Filter
open scoped Topology ENNReal NNReal
namespace Vortex
noncomputable section

/-- Reindex a certified coupling by homeomorphisms in each marginal. Supports
and every finite cycle are transported, including for noncompact source spaces. -/
theorem certified_under_chart {A B A' B' : Type*}
    [MetricSpace A] [MetricSpace B] [MetricSpace A'] [MetricSpace B']
    [SecondCountableTopology A] [SecondCountableTopology B] [SecondCountableTopology A'] [SecondCountableTopology B']
    [MeasurableSpace A] [MeasurableSpace B] [MeasurableSpace A'] [MeasurableSpace B']
    [BorelSpace A] [BorelSpace B] [BorelSpace A'] [BorelSpace B']
    (a : A ≃ₜ A') (b : B ≃ₜ B') (c : A × B → ℝ) (c' : A' × B' → ℝ)
    (cost : ∀ x y, c' (a x,b y) = c (x,y)) (P : ProbabilityMeasure A) (T : ProbabilityMeasure B)
    (π : ProbabilityMeasure (A × B)) (cert : SequentialRanks.certifiedPlan c P T π) :
    SequentialRanks.certifiedPlan c' (P.map a) (T.map b) (π.map (a.prodCongr b)) := by
  let j := a.prodCongr b
  have mj := j.measurable
  have fstJ (x : A × B) : ((a.prodCongr b) x).1 = a x.1 := rfl
  have sndJ (x : A × B) : ((a.prodCongr b) x).2 = b x.2 := rfl
  refine ⟨?_,?_,?_⟩
  · apply ProbabilityMeasure.toMeasure_injective
    have law := congrArg (fun p : ProbabilityMeasure A => (p : Measure A).map a) cert.1
    simp only [ProbabilityMeasure.toMeasure_map,Measure.map_map a.measurable measurable_fst] at law
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst (a.prodCongr b).measurable,Function.comp_def,fstJ] using law
  · apply ProbabilityMeasure.toMeasure_injective
    have law := congrArg (fun p : ProbabilityMeasure B => (p : Measure B).map b) cert.2.1
    simp only [ProbabilityMeasure.toMeasure_map,Measure.map_map b.measurable measurable_snd] at law
    simpa only [ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_snd (a.prodCongr b).measurable,Function.comp_def,sndJ] using law
  · let C := (π : Measure (A × B)).support
    have cl : IsClosed (j '' C) := j.isClosedMap _ Measure.isClosed_support
    have full : j '' C ∈ ae (π.map j : Measure (A' × B')) := by
      rw [ProbabilityMeasure.toMeasure_map,mem_ae_map_iff mj.aemeasurable cl.measurableSet]
      filter_upwards [Measure.support_mem_ae (μ := (π : Measure (A × B)))] with x hx
      exact mem_image_of_mem j hx
    have subset := Measure.support_subset_of_isClosed cl full
    intro n σ z hz
    choose x hx eq using fun i => subset (hz i)
    have jval (v : A × B) : j v = (a v.1,b v.2) := rfl
    simp only [← eq,jval,cost,Prod.mk.eta]
    exact cert.2.2 n σ x hx

def sgObservationChart := sgChart.trans (Homeomorph.Set.univ _).symm

theorem sgChartNorm (y : Space) : ‖sgChart y‖ ≤ ‖y‖ := by
  rw [pi_norm_le_iff_of_nonneg (norm_nonneg y)]
  intro i
  fin_cases i
  · exact (norm_fst_le y.1).trans (norm_fst_le y)
  · exact (norm_snd_le y.1).trans (norm_fst_le y)
  · exact norm_snd_le y

theorem charted_patch_inputs (D : Set Space) (P : ProbabilityMeasure Space) (T : ProbabilityMeasure D)
    (π : ProbabilityMeasure (Space × D)) (h : SequentialRanks.certifiedPlan (physicalCost D) P T π) :
    SequentialRanks.certifiedPlan SequentialRanks.squareCost (P.map sgObservationChart)
      (T.map (sgChart.image D)) (π.map (sgObservationChart.prodCongr (sgChart.image D))) := by
  apply certified_under_chart _ _ (physicalCost D) _ _ _ _ _ h
  intro x y; exact (sgChart_quadratic x y.val).symm
end
end Vortex
