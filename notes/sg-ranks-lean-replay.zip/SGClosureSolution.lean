import SGClosurePublic
import SGClosureBrenier
import SGClosureMoments
import SGClosureAdapter

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- The given map in the SG velocity is a quadratic optimal transport map.
This is the defining Monge condition only: it compares deterministic maps
with the same target. It assumes neither uniqueness nor optimality over plans. -/
structure IsQuadraticMap (D : Set Space) (P : ProbabilityMeasure Space) (T : ProbabilityMeasure D)
    (U : Space → D) : Prop where
  measurable : Measurable U
  law : P.map U = T
  least : ∀ V : Space → D, Measurable V → P.map V = T →
    (∫ y,quadraticCost y (U y).val ∂(P : Measure _)) ≤ ∫ y,quadraticCost y (V y).val ∂(P : Measure _)

private theorem pair_marg {D : Set Space} (P : ProbabilityMeasure Space) (U : Space → D) (mu : Measurable U) :
    (physicalGraph P U).map Prod.fst=P ∧ (physicalGraph P U).map Prod.snd=P.map U := by
  have mm : Measurable (fun y => (y,U y)) := measurable_id.prodMk mu
  constructor <;> apply ProbabilityMeasure.toMeasure_injective
  · simp only [physicalGraph,ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_fst mm]
    exact Measure.map_id
  · simp only [physicalGraph,ProbabilityMeasure.toMeasure_map,Measure.map_map measurable_snd mm]
    rfl

private theorem graph_cost {D : Set Space} (P : ProbabilityMeasure Space) (U : Space → D) (mu : Measurable U) :
    (∫ z,physicalCost D z ∂(physicalGraph P U : Measure (Space × D))) =
      ∫ y,quadraticCost y (U y).val ∂(P : Measure Space) := by
  have mm : Measurable (fun y => (y,U y)) := measurable_id.prodMk mu
  have mc : Continuous (physicalCost D) := by unfold physicalCost quadraticCost distSq; fun_prop
  rw [physicalGraph,ProbabilityMeasure.toMeasure_map,integral_map mm.aemeasurable mc.aestronglyMeasurable]
  rfl

theorem quadratic_map_unique_graph (D : Set Space) [CompactSpace D] (P : ProbabilityMeasure Space)
    (T : ProbabilityMeasure D) (U : Space → D) (actual : IsQuadraticMap D P T U)
    (ac : (P : Measure Space) ≪ volume) (m : Integrable (fun y : Space => ‖y‖^2) (P : Measure Space)) :
    PhysicalBrenierGraph D P T U := by
  obtain ⟨V,g⟩ := physical_static_brenier D P T ac m
  have pu := pair_marg P U actual.measurable
  have cv := g.optimal (physicalGraph P U) pu.1 (pu.2.trans actual.law)
  have pv := pair_marg P V g.measurable
  have via := actual.least V g.measurable (pv.2.symm.trans g.certified.2.1)
  rw [← graph_cost P U actual.measurable,← graph_cost P V g.measurable] at via
  have eqg := cv.2 (le_antisymm via cv.1)
  refine ⟨actual.measurable,eqg.symm ▸ g.certified,fun γ h => (g.cyclic_unique γ h).trans eqg.symm,?_⟩
  rw [eqg]; exact g.optimal

/-- The SG weak solution includes its defining quadratic optimal maps. For the
rearranged stationary comparison the theorem constructs the optimal map itself.
All static optimal-transport existence and uniqueness, semidiscrete cell realization
and passage to a horizontal continuum estimate are proved in the dependency chain.
The only separate geometric theorem at this entry point is the ordinary finite-cell
Brenier inequality. -/
theorem sg_public_from_monge_solution (E0 : Set Space) (E : ℝ → Set Space) (D : Set Space)
    [CompactSpace D] (target : ProbabilityMeasure D) (conv : Convex ℝ D)
    (bodySymm : ∀ θ y, rotateMap θ y ∈ D ↔ y∈D) (unif : UniformBodyLaw D target)
    (d : ℝ≥0) (hd : 0<d) (T a b R : ℝ) (ht : 0≤T) (hab : a≤b)
    (horizontal : ∀ x∈D, x.1.1^2+x.1.2^2 ≤ R^2) (U : ℝ → Space → D)
    (me0 : MeasurableSet E0) (mass0 : (d : ℝ≥0∞)*volume E0=1)
    (slab : ∀ᵐ z : ℝ, z ∉ Icc a b → volume (slice E0 z)=0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity (fun t y => (U t y).val)) (occupation E T))
    (mass : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*volume (E t)=1)
    (M : ℝ≥0) (moment0 : (d : ℝ≥0∞)*(∫⁻ y in E0, ‖y‖ₑ^2)≤M)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), (d : ℝ≥0∞)*(∫⁻ y in E t, ‖y‖ₑ^2)≤M)
    (sol : RenormalizedPatch E0 E T d (flowVelocity (fun t y => (U t y).val)))
    (actual : ∀ᵐ t ∂volume.restrict (Icc 0 T), ∀ h : (d : ℝ≥0∞)*volume (E t)=1,
      IsQuadraticMap D (patchProbability (E t) d h) target (U t))
    (finite : OrdinaryFiniteBrenier) :
    ∃ mB : (d : ℝ≥0∞)*volume (circular E0)=1, ∃ V : Space → D,
      PhysicalBrenierGraph D (patchProbability (circular E0) d mB) target V ∧
      (∀ s : ℝ, 0≤s → WeakPatchEquation (circular E0) (fun _ => circular E0) s d
        (fun z => vel z.2.1 (V z.2).val.1)) ∧
      ∀ᵐ t ∂volume.restrict (Icc 0 T),
        (d:ℝ)*(∫ y in E t ∩ circular E0, distSq (vel y.1 (U t y).val.1) (vel y.1 (V y).val.1)) ≤
          4*R^2*Real.sqrt (Real.pi*d*(b-a)*impulse E0 (circular E0) d) := by
  have compact : IsCompact D := isCompact_iff_compactSpace.mpr inferInstance
  obtain ⟨c,uniform⟩ := unif
  have fin := finite_of_patch_mass E0 d hd mass0
  have mB : (d : ℝ≥0∞)*volume (circular E0)=1 := by rwa [circular_volume_eq E0 me0 fin]
  have b2 := circular_second_moment E0 me0 fin (public_patch_second_moment E0 d M hd moment0)
  have ac (A : Set Space) (h : (d:ℝ≥0∞)*volume A=1) : (patchProbability A d h : Measure Space) ≪ volume :=
    (Measure.absolutelyContinuous_of_le Measure.restrict_le_self).smul_left _
  obtain ⟨V,g⟩ := physical_static_brenier D (patchProbability (circular E0) d mB) target
    (ac _ mB) b2.smul_measure_nnreal
  refine ⟨mB,V,g,sg_public_from_finite_tool E0 E D target conv bodySymm c uniform d hd
    T a b R ht hab horizontal U V me0 mass0 slab moving mw mass M moment0 moment sol ?_ ?_ finite⟩
  · filter_upwards [moment,actual] with t ht ha
    intro h
    exact current_of_physical_graph D (E t) compact.measurableSet target d hd h (U t)
      (quadratic_map_unique_graph D _ target (U t) (ha h) (ac _ h) (public_patch_second_moment (E t) d M hd ht).smul_measure_nnreal)
  · intro h; exact reference_of_physical_graph D _ compact.measurableSet target d hd h V g
end
end Vortex
