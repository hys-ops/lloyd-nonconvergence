import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

open MeasureTheory
open scoped BigOperators
namespace SequentialRanks
noncomputable section
def normSq {d : ℕ} (u : Fin d → ℝ) := ∑ i, (u i)^2
def mid {d : ℕ} (u v : Fin d → ℝ) (i : Fin d) := (u i+v i)/2
def diff {d : ℕ} (u v : Fin d → ℝ) (i : Fin d) := u i-v i
def gap {d : ℕ} (R : ℝ) (u : Fin d → ℝ) := R^2 - normSq u

private theorem coord (r s u v : ℝ) :
    r^2*(u-v)^2 ≤
    4*(r^2*u^2+s^2*v^2-2*r*s*((u+v)/2)^2) +
    (r-s)^2*(8*((u+v)/2)^2+4*v^2) := by
  nlinarith only [sq_nonneg (r*u-s*v+3*(r-s)*((u+v)/2)),
    sq_nonneg ((r-s)*(u-v)/2), sq_nonneg (r*u-s*v+3*(r-s)*v)]

theorem midpoint_ball {d} (R : ℝ) (u v : Fin d → ℝ)
    (hu : normSq u ≤ R^2) (hv : normSq v ≤ R^2) : normSq (mid u v) ≤ R^2 := by
  have hh := Finset.sum_le_sum (s := Finset.univ) (fun (i : Fin d) _ =>
    show ((u i+v i)/2)^2 ≤ ((u i)^2+(v i)^2)/2 by nlinarith [sq_nonneg (u i-v i)])
  simp only [← Finset.sum_div, Finset.sum_add_distrib] at hh
  unfold normSq at *; unfold mid
  linarith

/-- Each coordinate is paid for by the same midpoint test, including r=0 or s=0. -/
theorem rank_pointwise {d} (R r s : ℝ) (u v : Fin d → ℝ)
    (hu : normSq u ≤ R^2) (hv : normSq v ≤ R^2) :
    r^2*normSq (diff u v) ≤ (16*R^2)*(r-s)^2 +
      4*(2*r*s*gap R (mid u v)-r^2*gap R u-s^2*gap R v) := by
  have h := Finset.sum_le_sum (s := Finset.univ) (fun (i : Fin d) _ => coord r s (u i) (v i))
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum] at h
  have hm := midpoint_ball R u v hu hv
  change r^2*normSq (diff u v) ≤
    4*(r^2*normSq u+s^2*normSq v-2*r*s*normSq (mid u v))+
    (r-s)^2*(8*normSq (mid u v)+4*normSq v) at h
  unfold gap
  nlinarith only [h, mul_nonneg (sq_nonneg (r-s)) (sub_nonneg.mpr hm),
    mul_nonneg (sq_nonneg (r-s)) (sub_nonneg.mpr hv)]

/-- r and s represent square-root densities. htest states the transport test
inequality after pushing the two endpoints to their common reference. -/
theorem rank_from_midpoint_test {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {d : ℕ} (R : ℝ) (r s : Ω → ℝ) (u v : Ω → Fin d → ℝ)
    (hu : ∀ᵐ x ∂μ, normSq (u x) ≤ R^2) (hv : ∀ᵐ x ∂μ, normSq (v x) ≤ R^2)
    (hL : Integrable (fun x => (r x)^2*normSq (diff (u x) (v x))) μ)
    (hH : Integrable (fun x => (r x-s x)^2) μ)
    (hM : Integrable (fun x => 2*r x*s x*gap R (mid (u x) (v x))) μ)
    (hU : Integrable (fun x => (r x)^2*gap R (u x)) μ)
    (hV : Integrable (fun x => (s x)^2*gap R (v x)) μ)
    (htest : (∫ x, 2*r x*s x*gap R (mid (u x) (v x)) ∂μ) ≤
       (∫ x, (r x)^2*gap R (u x) ∂μ)+(∫ x, (s x)^2*gap R (v x) ∂μ)) :
    (∫ x, (r x)^2*normSq (diff (u x) (v x)) ∂μ) ≤
      16*R^2*∫ x, (r x-s x)^2 ∂μ := by
  let f := fun x => 2*r x*s x*gap R (mid (u x) (v x))
  let g := fun x => (r x)^2*gap R (u x)
  let k := fun x => (s x)^2*gap R (v x)
  have hs : Integrable (fun x => f x-g x) μ := hM.sub hU
  have ht : Integrable (fun x => f x-g x-k x) μ := hs.sub hV
  have hi : Integrable (fun x => (16*R^2)*(r x-s x)^2+4*(f x-g x-k x)) μ :=
    (hH.const_mul _).add (ht.const_mul _)
  have hh := integral_mono_ae hL hi (by
    filter_upwards [hu,hv] with x hux hvx
    exact rank_pointwise R (r x) (s x) (u x) (v x) hux hvx)
  rw [integral_add (hH.const_mul _) (ht.const_mul _), integral_const_mul, integral_const_mul,
      integral_sub hs hV, integral_sub hM hU] at hh
  linarith

/-- Nonnegative density version of the KL integrand, with absolute continuity
required on q=0. At p=0 the real-log convention gives the correct 0 log 0. -/
theorem hellinger_kl_pointwise (p q : ℝ) (hp : 0 ≤ p) (hq : 0 ≤ q)
    (hac : q = 0 → p = 0) :
    (Real.sqrt p-Real.sqrt q)^2 ≤ p*Real.log (p/q)-p+q := by
  rcases eq_or_lt_of_le hp with h | h
  · simp [← h, Real.sq_sqrt hq]
  have hq' : 0 < q := lt_of_le_of_ne hq (fun hz => h.ne (hac hz.symm).symm)
  let r := Real.sqrt p
  let s := Real.sqrt q
  have hr : 0 < r := Real.sqrt_pos.mpr h
  have hs : 0 < s := Real.sqrt_pos.mpr hq'
  have hlog := Real.log_le_sub_one_of_pos (div_pos hs hr)
  have hi := mul_le_mul_of_nonneg_right hlog hr.le
  rw [sub_mul, div_mul_cancel₀ _ hr.ne', one_mul, Real.log_div hs.ne' hr.ne'] at hi
  have hi2 := mul_le_mul_of_nonneg_right hi hr.le
  have hlp : Real.log p = 2*Real.log r := by rw [show r = Real.sqrt p from rfl, Real.log_sqrt hp]; ring
  have hlq : Real.log q = 2*Real.log s := by rw [show s = Real.sqrt q from rfl, Real.log_sqrt hq]; ring
  rw [Real.log_div h.ne' hq'.ne',hlp,hlq]
  change (r-s)^2 ≤ _
  have hp2 : r^2=p := Real.sq_sqrt hp
  have hq2 : s^2=q := Real.sq_sqrt hq
  rw [← hp2, ← hq2]
  nlinarith only [hi2]

theorem hellinger_kl_integral {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (p q : Ω → ℝ) (hp : ∀ᵐ x ∂μ, 0 ≤ p x) (hq : ∀ᵐ x ∂μ, 0 ≤ q x)
    (hac : ∀ᵐ x ∂μ, q x=0 → p x=0)
    (hH : Integrable (fun x => (Real.sqrt (p x)-Real.sqrt (q x))^2) μ)
    (hK : Integrable (fun x => p x*Real.log (p x/q x)) μ)
    (hip : Integrable p μ) (hiq : Integrable q μ)
    (hm : (∫ x, p x ∂μ) = ∫ x, q x ∂μ) :
    (∫ x, (Real.sqrt (p x)-Real.sqrt (q x))^2 ∂μ) ≤ ∫ x, p x*Real.log (p x/q x) ∂μ := by
  have hs : Integrable (fun x => p x*Real.log (p x/q x)-p x) μ := hK.sub hip
  have hi : Integrable (fun x => p x*Real.log (p x/q x)-p x+q x) μ := hs.add hiq
  have hh := integral_mono_ae hH hi (by
    filter_upwards [hp,hq,hac] with x a b c; exact hellinger_kl_pointwise _ _ a b c)
  rw [integral_add hs hiq,integral_sub hK hip,hm] at hh
  linarith

/-- risk and kl are the expected one-step losses and divergences, already
averaged over the true history. No conditional density chain rule is presumed proved here. -/
theorem sequential_bounds {T : ℕ} (R K C : ℝ) (risk kl : Fin T → ℝ)
    (step : ∀ i, risk i ≤ 16*R^2*kl i) (chain : ∑ i, kl i = K)
    (cap : ∀ i, risk i ≤ 4*R^2) (oracle : K ≤ C) :
    (∑ i, risk i) ≤ min (4*R^2*(T:ℝ)) (16*R^2*C) := by
  apply le_min
  · calc
      _ ≤ ∑ _i : Fin T, 4*R^2 := Finset.sum_le_sum (fun i _ => cap i)
      _ = _ := by simp [mul_comm]
  · calc
      _ ≤ ∑ i, (16*R^2)*kl i := Finset.sum_le_sum (fun i _ => step i)
      _ = 16*R^2*K := by rw [← Finset.mul_sum,chain]
      _ ≤ _ := mul_le_mul_of_nonneg_left oracle (by positivity)

end
end SequentialRanks
