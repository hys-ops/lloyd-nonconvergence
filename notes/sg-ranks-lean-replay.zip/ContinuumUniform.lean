import ContinuumPhysical

open MeasureTheory Filter Set
open scoped Topology NNReal ENNReal BoundedContinuousFunction BigOperators
namespace Vortex
noncomputable section

/-- The probability law on the body has constant Lebesgue density there.
Its total mass fixes the proportionality constant. -/
def UniformBodyLaw (K : Set Space) (T : ProbabilityMeasure K) : Prop :=
  ∃ d : ℝ≥0∞, (T : Measure K).map Subtype.val = d • (volume.restrict K)

/-- The original finite theorem in ambient dimension three. Its sole energy
comparison is on finite lists of distinct sites in one physical body.
The squared radius bound C has no dependence on the sites. -/
def OrdinaryFiniteBrenier : Prop :=
  ∀ (J : Set Space) [CompactSpace J], Convex ℝ J → ∀ (W : ProbabilityMeasure J),
    UniformBodyLaw J W → ∀ C : ℝ, (∀ x ∈ J, x.1.1^2+x.1.2^2+x.2^2 ≤ C) →
    ∀ (N : ℕ) (site : Fin N → Space), Function.Injective site →
    ∀ a b : J → Fin N, Measurable a → Measurable b →
    PowerLabels W site Subtype.val a → PowerLabels W site Subtype.val b →
    (∑ i, ‖rawMoment W a (stretchedCoordinates J 1) i-rawMoment W b (stretchedCoordinates J 1) i‖^2 /
      ((W : Measure J).real (a ⁻¹' {i})+(W : Measure J).real (b ⁻¹' {i}))) ≤
      C*∑ i, discr ((W : Measure J).real (a ⁻¹' {i})) ((W : Measure J).real (b ⁻¹' {i}))

private def verticalHomeo (e : ℝ) (he : e ≠ 0) : Space ≃ₜ Space where
  toFun := verticalStretch e
  invFun := verticalStretch e⁻¹
  left_inv x := by ext <;> simp [verticalStretch,he]
  right_inv x := by ext <;> simp [verticalStretch,he]
  continuous_toFun := by unfold verticalStretch; fun_prop
  continuous_invFun := by unfold verticalStretch; fun_prop

private def verticalLinear (e : ℝ) : Space →ₗ[ℝ] Space where
  toFun := verticalStretch e
  map_add' x y := by ext <;> simp [verticalStretch,mul_add]
  map_smul' c x := by ext <;> simp [verticalStretch,mul_left_comm]

theorem vertical_change_of_volume (e : ℝ) (he : e ≠ 0) :
    (volume : Measure Space).map (verticalStretch e) = ENNReal.ofReal |e⁻¹| • volume := by
  rw [Measure.volume_eq_prod H ℝ]
  change Measure.map (Prod.map (id : H → H) (e*·)) _ = _
  rw [← Measure.map_prod_map volume volume measurable_id (measurable_const_mul e), Measure.map_id,
    Real.map_volume_mul_left he,Measure.prod_smul_right]

private theorem stretched_uniform {K : Set Space} (T : ProbabilityMeasure K)
    (hT : UniformBodyLaw K T) (e : ℝ) (he : e ≠ 0) :
    UniformBodyLaw (verticalHomeo e he '' K) (T.map ((verticalHomeo e he).image K)) := by
  let v := verticalHomeo e he
  let w := v.image K
  obtain ⟨d,hd⟩ := hT
  refine ⟨d*ENNReal.ofReal |e⁻¹|,?_⟩
  change (((T : Measure K).map w).map Subtype.val) = _ • volume.restrict (v '' K)
  rw [Measure.map_map measurable_subtype_coe w.continuous.measurable]
  change (T : Measure K).map (v ∘ Subtype.val) = _
  rw [← Measure.map_map v.continuous.measurable measurable_subtype_coe,hd,
    Measure.map_smul d v.continuous.measurable.aemeasurable]
  have emb : MeasurableEmbedding v := v.toMeasurableEquiv.measurableEmbedding
  have rest := emb.restrict_map (volume : Measure Space) (v '' K)
  rw [v.injective.preimage_image] at rest
  rw [← rest]
  change d • ((volume : Measure Space).map (verticalStretch e)).restrict _ = _
  rw [vertical_change_of_volume e he,Measure.restrict_smul,smul_smul]

/-- An ordinary finite bound on uniform convex bodies supplies all the
stretched finite bounds used by the continuum proof. This transports the
uniform law (Jacobian factor), powers, masses and raw moments themselves. -/
theorem ordinary_tool_supplies_stretches (finite : OrdinaryFiniteBrenier)
    (K : Set Space) [CompactSpace K] (conv : Convex ℝ K) (T : ProbabilityMeasure K)
    (unif : UniformBodyLaw K T) (R Ht : ℝ)
    (horizontal : ∀ x ∈ K, x.1.1^2+x.1.2^2 ≤ R^2)
    (vertical : ∀ x ∈ K, x.2^2 ≤ Ht^2) : StretchedFiniteTool K T R Ht := by
  intro e he N site distinct a b ma mb pa pb
  let v := verticalHomeo e he.ne'
  let J := v '' K
  let w : K ≃ₜ J := v.image K
  let W := T.map w
  have comp : IsCompact J := (isCompact_iff_compactSpace.mpr inferInstance).image v.continuous
  let _ : CompactSpace J := isCompact_iff_compactSpace.mp comp
  have convex : Convex ℝ J := conv.linear_image (verticalLinear e)
  have radius (z : Space) (hz : z∈J) : z.1.1^2+z.1.2^2+z.2^2 ≤ R^2+e^2*Ht^2 := by
    obtain ⟨x,hx,rfl⟩ := hz
    change x.1.1^2+x.1.2^2+(e*x.2)^2 ≤ _
    rw [mul_pow]
    exact add_le_add (horizontal x hx) (mul_le_mul_of_nonneg_left (vertical x hx) (sq_nonneg _))
  have emb : MeasurableEmbedding w := w.toMeasurableEquiv.measurableEmbedding
  have tr (tag : K → Fin N) (pow : PowerLabels T site (fun x => verticalStretch e x.val) tag) :
      PowerLabels W site Subtype.val (tag ∘ w.symm) := by
    obtain ⟨d,hd⟩ := pow
    refine ⟨d,?_⟩
    apply (emb.ae_map_iff).mpr
    filter_upwards [hd] with x hx
    change ∀ j, linearScore (site j) (verticalStretch e x.val) + d j ≤
      linearScore (site (tag (w.symm (w x)))) (verticalStretch e x.val) + d (tag (w.symm (w x)))
    simpa only [w.symm_apply_apply] using hx
  have bd := finite J convex W (stretched_uniform T unif e he.ne') _ radius N site distinct
    (a ∘ w.symm) (b ∘ w.symm) (ma.comp w.symm.continuous.measurable)
    (mb.comp w.symm.continuous.measurable) (tr a pa) (tr b pb)
  have cell (tag : K → Fin N) (i : Fin N) : w ⁻¹' ((tag ∘ w.symm) ⁻¹' {i}) = tag ⁻¹' {i} := by ext; simp
  have mass (tag : K → Fin N) (i : Fin N) :
      (W : Measure J).real ((tag ∘ w.symm) ⁻¹' {i}) = (T : Measure K).real (tag ⁻¹' {i}) := by
    change (((T : Measure K).map w) _).toReal = _
    rw [emb.map_apply,cell]
    rfl
  have moment (tag : K → Fin N) (i : Fin N) :
      rawMoment W (tag ∘ w.symm) (stretchedCoordinates J 1) i =
      rawMoment T tag (stretchedCoordinates K e) i := by
    unfold rawMoment
    change (∫ x in _, stretchedCoordinates J 1 x ∂((T : Measure K).map w)) = _
    rw [emb.setIntegral_map,cell]
    apply integral_congr_ae
    filter_upwards with x
    apply WithLp.ofLp_injective 2
    change ![x.val.1.1,x.val.1.2,1*(e*x.val.2)] = ![x.val.1.1,x.val.1.2,e*x.val.2]
    rw [one_mul]
  simpa only [mass,moment] using bd

/-- Compactness supplies the auxiliary vertical radius, which disappears in
the published estimate. -/
theorem exists_stretched_tool_of_ordinary (finite : OrdinaryFiniteBrenier)
    (K : Set Space) [CompactSpace K] (conv : Convex ℝ K) (T : ProbabilityMeasure K)
    (unif : UniformBodyLaw K T) (R : ℝ) (horizontal : ∀ x ∈ K, x.1.1^2+x.1.2^2 ≤ R^2) :
    ∃ Ht : ℝ, StretchedFiniteTool K T R Ht := by
  have bounded := (isCompact_iff_compactSpace.mpr (inferInstance : CompactSpace K)).isBounded
  obtain ⟨H,hH⟩ := bounded.exists_norm_le
  refine ⟨H,ordinary_tool_supplies_stretches finite K conv T unif R H horizontal ?_⟩
  intro x hx
  have h := (norm_snd_le x).trans (hH x hx)
  simpa using pow_le_pow_left₀ (norm_nonneg _) h 2

end
end Vortex
