import WeakTimeMoments

open MeasureTheory Set Filter
open scoped ENNReal NNReal
namespace Vortex
noncomputable section

/-- Dynamic fields needed by the final velocity corollary, with time-slice torque
instead of any assumption on joint measurability of the vertical optimal coordinate. -/
structure PatchDynamicBounds (E0 : Set Space) (E : ℝ → Set Space) (t ρ : ℝ)
    (S : ℝ → Space → Space) : Prop where
  timeNonneg : 0 ≤ t
  finiteCurrent : volume (E t) ≠ ⊤
  finiteInitial : volume E0 ≠ ⊤
  velocityInt : Integrable (flowVelocity S) (occupation E t)
  weakEq : WeakPatchEquation E0 E t ρ (flowVelocity S)
  spaceMoment : Integrable (fun s : SpaceTime => ‖s.2‖^2) (occupation E t)
  momentInitial : IntegrableOn radialSquare E0
  momentNow : IntegrableOn radialSquare (E t)
  sliceMoment : ∀ᵐ z : ℝ, IntegrableOn areaCoord (slice (E t) z)
  sameRadial : (∫ y in E t,radialSquare y) = ∫ y in E0,radialSquare y

private theorem normSquare_integrable {X : Type*} [MeasurableSpace X] {μ : Measure X}
    {Y : Type*} [NormedAddCommGroup Y] {f : X → Y} (hm : AEStronglyMeasurable f μ)
    (h : (∫⁻ x, ‖f x‖ₑ^2 ∂μ) < ⊤) : Integrable (fun x => ‖f x‖^2) μ := by
  refine ⟨hm.norm.pow _,(hasFiniteIntegral_iff_norm _).mpr ?_⟩
  simpa [Real.norm_of_nonneg (sq_nonneg _),ENNReal.ofReal_pow (norm_nonneg _)] using h

private theorem radial_integrable (A : Set Space) (h : IntegrableOn (fun y : Space => ‖y‖^2) A) :
    IntegrableOn radialSquare A := by
  apply (h.const_mul 2).mono' (by unfold radialSquare; fun_prop)
  filter_upwards with y
  have a : |y.1.1| ≤ ‖y‖ := (norm_fst_le y.1).trans (norm_fst_le y)
  have b : |y.1.2| ≤ ‖y‖ := (norm_snd_le y.1).trans (norm_fst_le y)
  have a' := pow_le_pow_left₀ (abs_nonneg _) a 2
  have b' := pow_le_pow_left₀ (abs_nonneg _) b 2
  simp only [sq_abs] at a' b'
  change ‖y.1.1^2+y.1.2^2‖ ≤ 2*‖y‖^2
  rw [Real.norm_of_nonneg (by positivity)]
  linarith

theorem slice_integrability_of_radial (A : Set Space) (mA : MeasurableSet A)
    (h : IntegrableOn radialSquare A) : ∀ᵐ z : ℝ, IntegrableOn areaCoord (slice A z) := by
  classical
  have hi : Integrable (A.indicator (fun y => Real.pi*radialSquare y))
      ((volume : Measure H).prod (volume : Measure ℝ)) :=
    (integrable_indicator_iff mA).mpr (h.const_mul _)
  filter_upwards [hi.prod_left_ae] with z hz
  have ms : MeasurableSet (slice A z) := mA.preimage (measurable_id.prodMk measurable_const)
  apply (integrable_indicator_iff ms).mp
  convert hz using 1
  funext x
  by_cases hx : (x,z) ∈ A
  · rw [indicator_of_mem hx,indicator_of_mem (show x ∈ slice A z from hx)]
    rfl
  · rw [indicator_of_notMem hx,indicator_of_notMem (show x ∉ slice A z from hx)]

private theorem kinetic_square (E : ℝ → Set Space) (T ρ : ℝ) (hρ : 0 < ρ)
    (S : ℝ → Space → Space) (target : Measure Space) (K M : ℝ≥0)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity S) (occupation E T))
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * (∫⁻ y in E t, ‖y‖ₑ^2) ≤ M)
    (radius : ∀ᵐ x ∂target, ‖x‖ ≤ K)
    (optimal : ∀ᵐ t ∂volume.restrict (Icc 0 T), SymmetricMonge (volume.restrict (E t)) target (S t)) :
    Integrable (fun s => ‖flowVelocity S s‖^2) (occupation E T) := by
  let v := (ENNReal.ofReal ρ)⁻¹
  have fv : v ≠ ∞ := ENNReal.inv_ne_top.mpr (ENNReal.ofReal_ne_zero_iff.mpr hρ)
  let C := (2:ℝ≥0∞)*((K:ℝ≥0∞)^2)
  have fc : C ≠ ∞ := ENNReal.mul_ne_top (by norm_num) (by simp)
  apply normSquare_integrable mw
  apply occupation_uniform_bound E T moving _ (mw.enorm.pow_const 2) (C*v+2*(v*M))
    ((ENNReal.add_lt_top.mpr ⟨ENNReal.mul_lt_top fc.lt_top fv.lt_top,
      ENNReal.mul_lt_top (by norm_num) (ENNReal.mul_lt_top fv.lt_top ENNReal.coe_lt_top)⟩).ne)
  filter_upwards [normMass,moment,optimal] with t hmass hm opt
  have bb : ∀ᵐ y ∂volume.restrict (E t), ‖S t y‖ ≤ K := by
    apply (ae_map_iff opt.measurableMap.aemeasurable (measurableSet_le measurable_norm measurable_const)).mp
    rwa [opt.marginal]
  calc
    _ ≤ ∫⁻ y in E t,C+2*‖y‖ₑ^2 := by
      apply lintegral_mono_ae
      filter_upwards [bb] with y hy
      have wp := (transported_velocity_growth S t y).trans (add_le_add_right hy _)
      have ap := pow_le_pow_left₀ (norm_nonneg _) wp 2
      have hh := ENNReal.ofReal_le_ofReal (show ‖flowVelocity S (t,y)‖^2 ≤
          2*(K:ℝ)^2 + 2*‖y‖^2 by nlinarith only [ap,sq_nonneg (‖y‖-(K:ℝ))])
      simpa [C,ENNReal.ofReal_add (by positivity : (0:ℝ) ≤ 2*(K:ℝ)^2),
        ENNReal.ofReal_mul (by norm_num : (0:ℝ) ≤ 2), ENNReal.ofReal_pow (norm_nonneg _),
        ENNReal.ofReal_pow K.coe_nonneg] using hh
    _ = C*volume (E t)+2*∫⁻ y in E t,‖y‖ₑ^2 := by
      rw [lintegral_add_left measurable_const,setLIntegral_const,lintegral_const_mul _ (measurable_enorm.pow_const 2)]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left (show volume (E t) ≤ v by
      simpa [v] using unweight_patch_bound hρ hmass.le) zero_le)
      (mul_le_mul_of_nonneg_left (unweight_patch_bound hρ hm) zero_le)

private theorem radial_of_sliced_torque (E0 : Set Space) (E : ℝ → Set Space) (t ρ : ℝ)
    (ht : 0 ≤ t) (hρ : 0 < ρ) (S : ℝ → Space → Space) (target : Measure Space)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (hw : Integrable (flowVelocity S) (occupation E t))
    (mixed : Integrable (fun s : SpaceTime => ‖s.2‖*‖flowVelocity S s‖) (occupation E t))
    (momentInitial : IntegrableOn radialSquare E0) (momentNow : IntegrableOn radialSquare (E t))
    (eqn : WeakPatchEquation E0 E t ρ (flowVelocity S))
    (slices : ∀ᵐ u ∂volume.restrict (Icc 0 t), SymmetricMonge (volume.restrict (E u)) target (S u) ∧
      IntegrableOn (fun y : Space => ‖y‖^2) (E u) ∧ IntegrableOn (fun y => ‖S u y‖^2) (E u)) :
    (∫ y in E t,radialSquare y) = ∫ y in E0,radialSquare y := by
  let f := fun s : SpaceTime => 2*horizontalWork s.2 (flowVelocity S s)
  have fi : Integrable f (occupation E t) := by
    apply (mixed.const_mul 4).mono' ?_
    · filter_upwards with s
      change ‖2*horizontalWork s.2 (flowVelocity S s)‖ ≤ 4*(‖s.2‖*‖flowVelocity S s‖)
      rw [norm_mul,Real.norm_of_nonneg (by norm_num : 0 ≤ (2:ℝ))]
      linarith [work_bound s.2 (flowVelocity S s)]
    · have hm := hw.aestronglyMeasurable
      unfold f horizontalWork
      exact (((continuous_fst.comp (continuous_fst.comp continuous_snd)).aestronglyMeasurable.mul
        (continuous_fst.comp_aestronglyMeasurable hm)).add
        ((continuous_snd.comp (continuous_fst.comp continuous_snd)).aestronglyMeasurable.mul
        (continuous_snd.comp_aestronglyMeasurable hm))).const_mul 2
  apply sub_eq_zero.mp
  calc
    _ = ∫ s,f s ∂occupation E t := impulse_balance_from_trace E0 (E t) _ _ hw.aestronglyMeasurable
      mixed momentInitial momentNow (horizontal_trace_of_weak_patch E0 E t ρ ht hρ _ moving eqn)
    _ = _ := (occupation_fubini E moving t f fi).1
    _ = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [slices] with u h
      exact torque_of_optimal_map _ target (S u) h.1 h.2.1 h.2.2

/-- Collect the original PDE and moment consequences used in the sharp overlap corollary.
The vertical coordinate of the time-dependent optimal map need not be jointly measurable. -/
theorem patch_dynamic_bounds (E0 : Set Space) (E : ℝ → Set Space) (T ρ : ℝ)
    (hT : 0 ≤ T) (hρ : 0 < ρ) (S : ℝ → Space → Space) (target : Measure Space) (K M : ℝ≥0)
    (me0 : MeasurableSet E0) (p0 : ENNReal.ofReal ρ * volume E0 = 1)
    (moment0 : ENNReal.ofReal ρ * (∫⁻ y in E0, ‖y‖ₑ^2) ≤ M)
    (moving : MeasurableSet {s : SpaceTime | s.2 ∈ E s.1})
    (mw : AEStronglyMeasurable (flowVelocity S) (occupation E T))
    (normMass : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * volume (E t) = 1)
    (moment : ∀ᵐ t ∂volume.restrict (Icc 0 T), ENNReal.ofReal ρ * (∫⁻ y in E t, ‖y‖ₑ^2) ≤ M)
    (radius : ∀ᵐ x ∂target, ‖x‖ ≤ K)
    (optimal : ∀ᵐ t ∂volume.restrict (Icc 0 T), SymmetricMonge (volume.restrict (E t)) target (S t))
    (sol : RenormalizedPatch E0 E T ρ (flowVelocity S)) :
    ∀ᵐ t ∂volume.restrict (Icc 0 T), PatchDynamicBounds E0 E t ρ S := by
  let v := (ENNReal.ofReal ρ)⁻¹
  have fv : v ≠ ∞ := ENNReal.inv_ne_top.mpr (ENNReal.ofReal_ne_zero_iff.mpr hρ)
  have ub : v*(M:ℝ≥0∞) < ⊤ := ENNReal.mul_lt_top fv.lt_top ENNReal.coe_lt_top
  have fm {A : Set Space} (mass : ENNReal.ofReal ρ*volume A=1) :
      volume A ≠ ⊤ := ((unweight_patch_bound hρ mass.le).trans_lt (by simpa using hρ)).ne
  have im {A : Set Space} (mom : ENNReal.ofReal ρ*(∫⁻ y in A,‖y‖ₑ^2) ≤ M) :
      IntegrableOn (fun y : Space => ‖y‖^2) A :=
    normSquare_integrable aestronglyMeasurable_id ((unweight_patch_bound hρ mom).trans_lt ub)
  have transport : ∀ᵐ t ∂volume.restrict (Icc 0 T), Measurable (S t) ∧
      (volume.restrict (E t)).map (S t) = target :=
    optimal.mono fun _ h => ⟨h.measurableMap,h.marginal⟩
  have eqn := weak_patch_from_probability_dynamics E0 E T ρ hT hρ S target K M me0 p0
    moving mw normMass moment radius transport sol
  have hw := patch_velocity_integrable E T ρ hρ S target K M moving mw normMass moment radius transport
  have hk := kinetic_square E T ρ hρ S target K M moving mw normMass moment radius optimal
  have hs : Integrable (fun s : SpaceTime => ‖s.2‖^2) (occupation E T) := by
    apply normSquare_integrable continuous_snd.aestronglyMeasurable
    exact occupation_uniform_bound E T moving _ (measurable_snd.enorm.pow_const 2).aemeasurable
      _ ub.ne (moment.mono fun _ ht => unweight_patch_bound hρ ht)
  have hmix : Integrable (fun s : SpaceTime => ‖s.2‖*‖flowVelocity S s‖) (occupation E T) := by
    apply (hs.add hk).mono' (continuous_snd.norm.aestronglyMeasurable.mul mw.norm)
    filter_upwards with s
    change ‖‖s.2‖*‖flowVelocity S s‖‖ ≤ ‖s.2‖^2+‖flowVelocity S s‖^2
    rw [Real.norm_of_nonneg (by positivity)]
    nlinarith only [sq_nonneg (‖s.2‖-‖flowVelocity S s‖),sq_nonneg ‖s.2‖,sq_nonneg ‖flowVelocity S s‖]
  have slices : ∀ᵐ u ∂volume.restrict (Icc 0 T), SymmetricMonge (volume.restrict (E u)) target (S u) ∧
      IntegrableOn (fun y : Space => ‖y‖^2) (E u) ∧ IntegrableOn (fun y => ‖S u y‖^2) (E u) := by
    filter_upwards [normMass,moment,optimal] with t p hm ho
    refine ⟨ho,im hm,?_⟩
    have bb : ∀ᵐ y ∂volume.restrict (E t), ‖S t y‖ ≤ K := by
      apply (ae_map_iff ho.measurableMap.aemeasurable (measurableSet_le measurable_norm measurable_const)).mp
      rwa [ho.marginal]
    apply (integrableOn_const (C := (K:ℝ)^2) (fm p)).mono' (ho.measurableMap.norm.pow_const 2).aestronglyMeasurable
    filter_upwards [bb] with y hy
    simpa using pow_le_pow_left₀ (norm_nonneg _) hy 2
  filter_upwards [ae_restrict_mem measurableSet_Icc,normMass,moment,eqn] with t ht pn mn wn
  have a := radial_integrable E0 (im moment0)
  have b := radial_integrable (E t) (im mn)
  have dom := occupation_mono_time E ht.2
  have mt : MeasurableSet (E t) := moving.preimage (measurable_const.prodMk measurable_id)
  refine ⟨ht.1,fm pn,fm p0,hw.mono_measure dom,wn,hs.mono_measure dom,a,b,
    slice_integrability_of_radial _ mt b,?_⟩
  exact radial_of_sliced_torque E0 E t ρ ht.1 hρ S target moving (hw.mono_measure dom)
    (hmix.mono_measure dom) a b wn (slices.filter_mono (ae_mono (Measure.restrict_mono_set _
      (Icc_subset_Icc_right ht.2))))

end
end Vortex
