import MinimaxUpperIID
import MinimaxUpperRanks
open MeasureTheory Set Filter
open scoped ENNReal BigOperators
namespace SequentialRanks
noncomputable section

/-- For any prior neighborhood the path KL is at most the i.i.d. cumulative
local KL budget plus the negative log of its actual prior mass. This is the finite
KL branch; its two density conditions are absolute continuity and integrability
of the defining log-likelihood integrand, only for local components. -/
theorem iid_bayes_kl {Θ Y : Type*} [MeasurableSpace Θ] [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π] (θ fallback : Θ)
    (B : Set Θ) (mb : MeasurableSet B) (hb : π B ≠ 0) (K : ℝ)
    (ac : ∀ η ∈ B, ∀ᵐ y ∂ν, 0 < F.density (θ,y) → 0 < F.density (η,y))
    (ki : ∀ η ∈ B, Integrable (fun y => klTerm (F.density (θ,y)) (F.density (η,y))) ν)
    (bound : ∀ η ∈ B, (∫ y,klTerm (F.density (θ,y)) (F.density (η,y)) ∂ν) ≤ K) (n : ℕ) :
    let p := historyDensity (F.forecast θ) n
    let q := historyDensity (priorForecast F π fallback) n
    (∀ᵐ z ∂historyBase ν n, 0 < p z → 0 < q z) ∧
      Integrable (fun z => klTerm (p z) (q z)) (historyBase ν n) ∧
      historyKL (F.forecast θ) (priorForecast F π fallback) n ≤ n*K - Real.log (π.real B) := by
  let p := historyDensity (F.forecast θ) n
  have tr := history_is_density (F.forecast θ) n
  have tensor η (hη : η ∈ B) := iid_path_kl F θ η (ac η hη) (ki η hη) n
  have bounds η (hη : η ∈ B) : (∫ z,klTerm (p z) (F.paths n (η,z)) ∂historyBase ν n) ≤ n*K := by
    change historyKL (F.forecast θ) (F.forecast η) n ≤ _
    rw [(tensor η hη).2.2]
    exact mul_le_mul_of_nonneg_left (bound η hη) (by positivity)
  have mf := iid_paths_measurable F n
  have mix := local_mixture_kl π (historyBase ν n) B mb hb p (F.paths n) tr.1 mf tr.2.1
    (fun z => (history_is_density (F.forecast z.1) n).2.1 z.2) tr.2.2.1 tr.2.2.2
    (fun η => (history_is_density (F.forecast η) n).2.2.1)
    (fun η => (history_is_density (F.forecast η) n).2.2.2)
    _ (fun η hη => (tensor η hη).1) (fun η hη => (tensor η hη).2.1) bounds
  have eq := prior_forecast_paths F π fallback n
  have eqk : (fun z => klTerm (p z) (historyDensity (priorForecast F π fallback) n z)) =ᵐ[historyBase ν n]
      fun z => klTerm (p z) (priorMixture F π n z) := eq.mono (fun z hz => congrArg _ hz)
  exact ⟨(eq.and mix.1).mono (fun _ h hp => h.1 ▸ h.2 hp),mix.2.1.congr eqk.symm,(integral_congr_ae eqk).le.trans mix.2.2⟩

/-- Published local parametric upper bound with a genuine prior-mixture predictor
at each date. The metric/KL assumptions need only hold on the radius 1/√T ball.
The two maps are ranks of their respective conditional laws, with the common
reference pushforwards and midpoint domination specifying the geometric input. -/
theorem parametric_bayes_rank_upper {Θ Y : Type*} [PseudoMetricSpace Θ] [MeasurableSpace Θ]
    [OpensMeasurableSpace Θ] [MeasurableSpace Y] {ν : Measure Y} [SFinite ν]
    (F : IIDFamily Θ Y ν) (π : Measure Θ) [IsProbabilityMeasure π] (θ fallback : Θ)
    (T : ℕ) (hT : 0 < T) (C c k R : ℝ) (cpos : 0 < c) (Cnon : 0 ≤ C)
    (mass : c*(1/Real.sqrt (T:ℝ))^k ≤ π.real (Metric.ball θ (1/Real.sqrt (T:ℝ))))
    (ac : ∀ η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ)), ∀ᵐ y ∂ν, 0 < F.density (θ,y) → 0 < F.density (η,y))
    (ki : ∀ η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ)), Integrable (fun y => klTerm (F.density (θ,y)) (F.density (η,y))) ν)
    (localKL : ∀ η ∈ Metric.ball θ (1/Real.sqrt (T:ℝ)),
      (∫ y,klTerm (F.density (θ,y)) (F.density (η,y)) ∂ν) ≤ C*(dist η θ)^2)
    {d : ℕ} (ρ : Measure (Fin d → ℝ)) [IsProbabilityMeasure ρ] (refball : ∀ᵐ y ∂ρ, normSq y ≤ R^2)
    (U : Y → Fin d → ℝ) (V : (n : ℕ) → History Y n × Y → Fin d → ℝ)
    (mu : Measurable U) (mv : ∀ n, Measurable (V n))
    (ub : ∀ y, normSq (U y) ≤ R^2) (vb : ∀ n z, normSq (V n z) ≤ R^2)
    (pu : (weighted ν (fun y => F.density (θ,y))).map U = ρ)
    (qv : ∀ n h, (weighted ν (fun y => (priorForecast F π fallback n).f (h,y))).map (fun y => V n (h,y)) = ρ)
    (dom : ∀ n, n < T → ∀ h, 0 < historyDensity (F.forecast θ) n h →
      (weighted ν (fun y => Real.sqrt (F.density (θ,y))*Real.sqrt ((priorForecast F π fallback n).f (h,y)))).map
        (fun y => mid (U y) (V n (h,y))) ≤ ρ) :
    ∑ n ∈ Finset.range T, historyRisk (F.forecast θ) (fun t z => normSq (diff (U z.2) (V t z))) n ≤
      16*R^2*(C+Real.log (1/c)+(k/2)*Real.log T) := by
  let r := 1/Real.sqrt (T:ℝ)
  let B := Metric.ball θ r
  have posT : 0 < (T:ℝ) := by exact_mod_cast hT
  have rp : 0 < r := one_div_pos.mpr (Real.sqrt_pos.mpr posT)
  have small : 0 < c*r^k := mul_pos cpos (Real.rpow_pos_of_pos rp k)
  have hb : π B ≠ 0 := by by_contra hz; have h := small.trans_le mass; change 0 < (π B).toReal at h; simp [hz] at h
  have one η (h : η ∈ B) : (∫ y,klTerm (F.density (θ,y)) (F.density (η,y)) ∂ν) ≤ C*r^2 :=
    (localKL η h).trans (mul_le_mul_of_nonneg_left (sq_le_sq' (by linarith [dist_nonneg (x := η) (y := θ)] : -r ≤ dist η θ)
        (Metric.mem_ball.mp h).le) Cnon)
  have info (n) := iid_bayes_kl F π θ fallback B Metric.isOpen_ball.measurableSet hb _ ac ki one n
  let a := F.forecast θ
  let b := priorForecast F π fallback
  let loss := fun (t : ℕ) (z : History Y t × Y) => normSq (diff (U z.2) (V t z))
  have reg := history_rank_regret T R a b loss (fun t => by unfold loss normSq diff; fun_prop)
    (fun t z => bounded_rank_distance (ub _) (vb t z)) (fun t _ => (info t).1) (fun t _ => (info t).2.1) (by
      intro t ht h hp
      have source : Measurable (fun y : Y => (h,y)) := measurable_const.prodMk measurable_id
      exact one_step_from_geometry ν ρ R _ _ (F.measurable.comp (measurable_const.prodMk measurable_id))
        ((b t).measurable.comp source) (fun y => F.nonneg _) (fun y => (b t).nonneg _) (F.integrable θ)
        ((b t).integrable h) _ _ mu ((mv t).comp source) ub (fun y => vb t (h,y)) refball pu (qv t h) (dom t ht h hp))
  have sq : (T:ℝ)*(C*r^2)=C := by dsimp [r]; rw [div_pow,one_pow,Real.sq_sqrt posT.le]; field_simp
  have penalty := Real.log_le_log small mass
  change Real.log (c*r^k) ≤ Real.log (π.real B) at penalty
  rw [Real.log_mul cpos.ne' (Real.rpow_pos_of_pos rp k).ne',Real.log_rpow rp k] at penalty
  have lr : Real.log r = -Real.log T/2 := by
    dsimp [r]; rw [one_div,Real.log_inv,Real.log_sqrt posT.le]; ring
  rw [lr] at penalty
  have kT := (info T).2.2
  rw [sq] at kT
  apply (reg.trans (min_le_right _ _)).trans
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  rw [one_div,Real.log_inv]; linarith

end
end SequentialRanks
