import StaticRankConvex
import CyclicPlans
import Mathlib.Analysis.Calculus.Rademacher
import Mathlib.Analysis.Calculus.FDeriv.Measurable

open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal ENNReal
namespace SequentialRanks
noncomputable section

/-- The ordinary coordinate gradient; mathlib sets the Fréchet derivative to
zero where the potential is not differentiable. -/
def euclideanGradient {d : ℕ} (φ : RankPoint d → ℝ) (x : RankPoint d) : RankPoint d :=
  fun i => fderiv ℝ φ x (Pi.single i 1)

theorem measurable_euclideanGradient {d : ℕ} (φ : RankPoint d → ℝ) :
    Measurable (euclideanGradient φ) := by
  apply Measurable.of_eval
  intro i
  exact measurable_fderiv_apply_const ℝ φ (Pi.single i 1)

private theorem gradient_at_contact {d : ℕ} {φ : RankPoint d → ℝ} {y k : RankPoint d}
    (h : DifferentiableAt ℝ φ y) (contact : IsLocalMin (fun z => φ z - rankCovector k z) y) :
    euclideanGradient φ y = k := by
  have eq := sub_eq_zero.mp (contact.hasFDerivAt_eq_zero (h.hasFDerivAt.sub (rankCovector k).hasFDerivAt))
  funext i
  change fderiv ℝ φ y _ = _
  rw [eq]; simp [rankCovector,sum_apply,Pi.single_apply]

/-- A single Borel map into B for a fixed potential. -/
def supportGradient {d : ℕ} {A B : Set (RankPoint d)} [Nonempty B]
    (φ : RankPoint d → ℝ) (x : A) : B := by
  classical
  exact if h : euclideanGradient φ x.1 ∈ B then ⟨_,h⟩ else Classical.choice inferInstance

theorem measurable_supportGradient {d : ℕ} {A B : Set (RankPoint d)} [Nonempty B]
    (hB : MeasurableSet B) (φ : RankPoint d → ℝ) :
    Measurable (supportGradient (A := A) (B := B) φ) := by
  classical
  apply Measurable.subtype_mk (f := fun x : A => (supportGradient (B := B) φ x).val)
  let m := (measurable_euclideanGradient φ).comp (measurable_subtype_coe (p := (· ∈ A)))
  let t : A → RankPoint d := fun x => if euclideanGradient φ x.val ∈ B then euclideanGradient φ x.val
    else (Classical.choice (inferInstance : Nonempty B)).val
  have mt : Measurable t := m.ite (hB.preimage m) measurable_const
  convert mt using 1
  funext x; by_cases hx : euclideanGradient φ x.val ∈ B <;> simp [supportGradient,t,hx]

/-- Rademacher's theorem turns contact with a single Lipschitz supporting
potential into an actual graph law. Source absolute continuity is in ambient
Lebesgue measure; the compact source set need not have interior. -/
theorem graph_of_lipschitz_contact {d : ℕ} {A B : Set (RankPoint d)} [Nonempty B]
    (hB : MeasurableSet B) (π : ProbabilityMeasure (A × B)) (P : ProbabilityMeasure A)
    (marg : π.map Prod.fst = P) (ac : (P : Measure A).map Subtype.val ≪ volume)
    (φ : RankPoint d → ℝ) {L : ℝ≥0} (lip : LipschitzWith L φ)
    (contact : ∀ᵐ z ∂(π : Measure (A × B)),
      IsLocalMin (fun v => φ v - rankCovector z.2.val v) z.1.val) :
    ProbabilityMeasure.map P (fun x => (x,supportGradient (A := A) (B := B) φ x)) = π := by
  let F : A × B → RankPoint d := fun z => z.1.val
  have mF : Measurable F := measurable_subtype_coe.comp measurable_fst
  have mP : ((π : Measure (A × B)).map Prod.fst) = (P : Measure A) := congrArg Subtype.val marg
  have law : (π : Measure (A × B)).map F = (P : Measure A).map Subtype.val := by
    rw [← mP,Measure.map_map measurable_subtype_coe measurable_fst]; rfl
  have ae := ac.ae_le (lip.ae_differentiableAt (μ := (volume : Measure (RankPoint d))))
  rw [← law] at ae
  have hgrad := ae_of_ae_map mF.aemeasurable ae
  have same : (fun z : A × B => (z.1,supportGradient (B := B) φ z.1)) =ᵐ[(π : Measure (A × B))] id := by
    filter_upwards [hgrad,contact] with z hz hc
    have g := gradient_at_contact hz hc
    change euclideanGradient φ z.1.val = z.2.val at g
    have inside : euclideanGradient φ z.1.val ∈ B := g ▸ z.2.property
    refine Prod.ext (by rfl) ?_
    apply Subtype.ext
    simpa [supportGradient,inside] using g
  apply ProbabilityMeasure.toMeasure_injective
  have mg : Measurable (fun x : A => (x,supportGradient (B := B) φ x)) :=
    measurable_id.prodMk (measurable_supportGradient (A := A) hB φ)
  change (P : Measure A).map (fun x => (x,supportGradient (B := B) φ x)) = _
  rw [← mP,Measure.map_map mg measurable_fst,Measure.map_congr (
    show (fun x : A => (x,supportGradient (B := B) φ x)) ∘ Prod.fst =ᵐ[(π : Measure (A × B))] id from same),Measure.map_id]

end
end SequentialRanks
