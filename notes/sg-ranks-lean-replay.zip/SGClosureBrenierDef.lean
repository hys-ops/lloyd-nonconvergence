import ContinuumPhysical

open MeasureTheory
namespace Vortex
noncomputable section

def physicalGraph {D : Set Space} (P : ProbabilityMeasure Space) (U : Space → D) :=
  P.map (fun y => (y,U y))

/-- A static Monge graph and its complete coupling comparison at the original
quadratic cost. Uniqueness is supplied both in cyclic and minimizing forms. -/
structure PhysicalBrenierGraph (D : Set Space) (P : ProbabilityMeasure Space) (T : ProbabilityMeasure D)
    (U : Space → D) : Prop where
  measurable : Measurable U
  certified : SequentialRanks.certifiedPlan (physicalCost D) P T (physicalGraph P U)
  cyclic_unique : ∀ γ, SequentialRanks.certifiedPlan (physicalCost D) P T γ → γ=physicalGraph P U
  optimal : ∀ γ : ProbabilityMeasure (Space × D), γ.map Prod.fst=P → γ.map Prod.snd=T →
    (∫ z,physicalCost D z ∂(physicalGraph P U : Measure _)) ≤ (∫ z,physicalCost D z ∂(γ : Measure _)) ∧
    ((∫ z,physicalCost D z ∂(γ : Measure _))=(∫ z,physicalCost D z ∂(physicalGraph P U : Measure _)) → γ=physicalGraph P U)
end
end Vortex
