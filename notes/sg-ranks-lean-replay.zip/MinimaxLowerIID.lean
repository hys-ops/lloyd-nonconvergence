import MinimaxLowerJoint
open MeasureTheory Set
open scoped ENNReal
namespace SequentialRanks
noncomputable section

def iidDayRisk (n : ℕ) (a : Past n × SquareObs → SquareObs) (θ : ℝ) :=
  ∫⁻ q,lossE θ (a q) q.2 ∂(iidPastLaw θ n).prod (squareLaw θ)

private theorem measurable_error : Measurable (fun p : ℝ × SquareObs × SquareObs => lossE p.1 p.2.1 p.2.2) := by
  unfold lossE sqError squareMap perturb; fun_prop

private theorem weight_nonneg (θ : ℝ) : 0 ≤ priorWeight θ := by unfold priorWeight; positivity
private theorem ae_par : ∀ᵐ θ ∂parameterBase, |θ|≤1/2 := by
  filter_upwards [ae_restrict_mem (μ:=volume) (s:=parameterInterval) measurableSet_Icc] with θ ht
  exact abs_le.mpr ht
private theorem sqProb : IsProbabilityMeasure squareBase := by
  have h : squareLaw 0 = squareBase := by simp [squareLaw,density]
  rw [←h]; exact square_law_probability (by norm_num)
private theorem coord_sum (n : ℕ) (a : Past n × SquareObs → SquareObs) (ma : Measurable a)
    (z : SquareObs) :
    ENNReal.ofReal (speed z/(4*Real.pi^2+16*(n:ℝ))) ≤
      ∫⁻ p,lossE p.1 (a (p.2,z)) z ∂experiment n := by
  let K := 4*Real.pi^2+16*(n:ℝ)
  let v := perturb z
  let ax (x : Past n) := (a (x,z)).1-z.1
  let ay (x : Past n) := (a (x,z)).2-z.2
  have m := ma.comp (measurable_id.prodMk (measurable_const (a:=z)))
  have mx : Measurable ax := (measurable_fst.comp m).sub measurable_const
  have my : Measurable ay := (measurable_snd.comp m).sub measurable_const
  have hx := iid_scalar_unrestricted n v.1 ax mx
  have hy := iid_scalar_unrestricted n v.2 ay my
  let lx (p : ℝ × Past n) := ENNReal.ofReal ((ax p.2-v.1*p.1)^2)
  let ly (p : ℝ × Past n) := ENNReal.ofReal ((ay p.2-v.2*p.1)^2)
  have ml : Measurable lx :=
    (((mx.comp measurable_snd).sub (measurable_const.mul measurable_fst)).pow_const 2).ennreal_ofReal
  change ENNReal.ofReal (v.1^2/K) ≤ ∫⁻ p,lx p ∂experiment n at hx
  change ENNReal.ofReal (v.2^2/K) ≤ ∫⁻ p,ly p ∂experiment n at hy
  calc
    _ = ENNReal.ofReal (v.1^2/K)+ENNReal.ofReal (v.2^2/K) := by
      rw [←ENNReal.ofReal_add (by dsimp [K]; positivity) (by dsimp [K]; positivity),←speed_id]
      congr 1; dsimp [v,K]; ring
    _ ≤ _ := add_le_add hx hy
    _ = ∫⁻ p,lx p+ly p ∂experiment n := (lintegral_add_left ml _).symm
    _ = _ := by
      apply lintegral_congr; intro p
      rw [show lx p+ly p=ENNReal.ofReal ((ax p.2-v.1*p.1)^2+(ay p.2-v.2*p.1)^2) from
        (ENNReal.ofReal_add (sq_nonneg _) (sq_nonneg _)).symm]
      unfold lossE sqError squareMap ax ay v; congr 1; ring

set_option maxHeartbeats 750000 in
/-- Actual Bayes one-date lower bound after n past observations. The estimator
may also use the current observation, and its expected loss may be infinite. -/
theorem iid_day_lower (n : ℕ) (a : Past n × SquareObs → SquareObs) (ma : Measurable a) :
    ENNReal.ofReal ((1/(8*Real.pi^2))*(1/(4*Real.pi^2+16*(n:ℝ)))) ≤
      ∫⁻ θ,ENNReal.ofReal (priorWeight θ)*iidDayRisk n a θ ∂parameterBase := by
  let _ := sqProb
  let K := 4*Real.pi^2+16*(n:ℝ)
  let c := ENNReal.ofReal (1/4:ℝ)
  let f (pz : (ℝ × Past n) × SquareObs) := lossE pz.1.1 (a (pz.1.2,pz.2)) pz.2
  have mha : Measurable (fun v : (ℝ × Past n) × SquareObs => (v.1.2,v.2)) :=
    (measurable_snd.comp measurable_fst).prodMk measurable_snd
  have par : Measurable (fun v : (ℝ × Past n) × SquareObs => v.1.1) := measurable_fst.comp measurable_fst
  have obs : Measurable (fun v : (ℝ × Past n) × SquareObs => v.2) := measurable_snd
  have hvar := par.prodMk ((ma.comp mha).prodMk obs)
  have mf : Measurable f := by
    simpa only [f,Function.comp_def,Prod.mk.eta] using measurable_error.comp hvar
  have int_e : (∫⁻ z,ENNReal.ofReal (speed z/K) ∂squareBase)=ENNReal.ofReal ((1/(2*Real.pi^2))/K) := by
    have si : Integrable speed squareBase := (show Continuous speed by unfold speed S2 C2; fun_prop).continuousOn.integrableOn_compact (isCompact_Icc.prod isCompact_Icc)
    rw [← ofReal_integral_eq_lintegral_ofReal (si.div_const K) (by filter_upwards with z; rw [←speed_id]; dsimp [K]; positivity),
      integral_div]
    exact congrArg (fun r : ℝ => ENNReal.ofReal (r/K)) square_energy
  calc
    _ = c*(∫⁻ z,ENNReal.ofReal (speed z/K) ∂squareBase) := by
      rw [int_e]; unfold c; rw [←ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤1/4)]; congr 1; dsimp [K]; ring
    _ ≤ c*(∫⁻ z,∫⁻ p,f (p,z) ∂experiment n ∂squareBase) := by
      gcongr; exact coord_sum n a ma _
    _ = c*(∫⁻ p,∫⁻ z,f (p,z) ∂squareBase ∂experiment n) := by
      exact congrArg (c*·) (lintegral_lintegral_swap mf.aemeasurable).symm
    _ = ∫⁻ p,c*(∫⁻ z,f (p,z) ∂squareBase) ∂experiment n := (lintegral_const_mul c mf.lintegral_prod_right').symm
    _ = ∫⁻ θ,ENNReal.ofReal (priorWeight θ)*(∫⁻ x,c*(∫⁻ z,f ((θ,x),z) ∂squareBase) ∂iidPastLaw θ n) ∂parameterBase :=
      experiment_tonelli n (fun p => c*(∫⁻ z,f (p,z) ∂squareBase)) (measurable_const.mul mf.lintegral_prod_right')
    _ ≤ _ := by
      apply lintegral_mono_ae
      filter_upwards [ae_par] with θ ht
      have : IsProbabilityMeasure (squareLaw θ) := square_law_probability ht
      let l (q : Past n × SquareObs) := lossE θ (a q) q.2
      have m0 : Measurable (fun q : Past n × SquareObs => (θ, a q,q.2)) :=
        measurable_const.prodMk (ma.prodMk measurable_snd)
      have m : Measurable l := by simpa only [l,Function.comp_def] using measurable_error.comp m0
      change ENNReal.ofReal (priorWeight θ)*(∫⁻ x,c*(∫⁻ z,f ((θ,x),z) ∂squareBase) ∂iidPastLaw θ n)
        ≤ ENNReal.ofReal (priorWeight θ)*(∫⁻ q,l q ∂(iidPastLaw θ n).prod (squareLaw θ))
      rw [lintegral_prod _ m.aemeasurable]
      apply mul_le_mul_right
      apply lintegral_mono; intro x
      let g := fun z => f ((θ,x),z)
      have mg : Measurable g := mf.comp (measurable_const.prodMk measurable_id)
      have md : Measurable (fun z => ENNReal.ofReal (density θ z)) := by unfold density; fun_prop
      change c*(∫⁻ z,g z ∂squareBase) ≤ ∫⁻ z,g z ∂squareBase.withDensity _
      rw [lintegral_withDensity_eq_lintegral_mul _ md mg,←lintegral_const_mul c mg]
      apply lintegral_mono; intro z
      change c*g z ≤ ENNReal.ofReal (density θ z)*g z
      exact mul_le_mul_left (ENNReal.ofReal_le_ofReal (actual_density_floor _ _ _ ht)) _

/-- Worst-parameter lower bound in the published *single* i.i.d. family.
The same parameter is used throughout all T dates. No parameters depend on
the estimator's observations. -/
theorem minimax_iid_lower (T : ℕ) (A : ∀ n, Past n × SquareObs → SquareObs)
    (mA : ∀ n, Measurable (A n)) :
    ENNReal.ofReal ((1/(8*Real.pi^2))*∑ n ∈ Finset.range T,1/(4*Real.pi^2+16*(n:ℝ))) ≤
      ⨆ θ : parameterInterval, ∑ n ∈ Finset.range T,iidDayRisk n (A n) θ.1 := by
  let w := fun θ => ENNReal.ofReal (priorWeight θ)
  let r := fun n θ => iidDayRisk n (A n) θ
  have day := fun n => iid_day_lower n (A n) (mA n)
  have combined (k : ℕ) :
      (∑ n ∈ Finset.range k,∫⁻ θ,w θ*r n θ ∂parameterBase) ≤
        ∫⁻ θ,w θ*(∑ n ∈ Finset.range k,r n θ) ∂parameterBase := by
    induction k with
    | zero => simp
    | succ k ih =>
      simp only [Finset.sum_range_succ,mul_add]
      exact (add_le_add ih (le_refl _)).trans (le_lintegral_add _ _)
  have wi : Integrable priorWeight parameterBase :=
    (show Continuous priorWeight by unfold priorWeight; fun_prop).continuousOn.integrableOn_Icc
  have mw : Measurable w := (show Continuous priorWeight by unfold priorWeight; fun_prop).measurable.ennreal_ofReal
  have unit : (∫⁻ θ,w θ ∂parameterBase)=1 := by
    rw [←ofReal_integral_eq_lintegral_ofReal wi (Filter.Eventually.of_forall weight_nonneg),prior_mass_and_information.1,ENNReal.ofReal_one]
  let upper := ⨆ θ : parameterInterval, ∑ n ∈ Finset.range T,r n θ.1
  change _ ≤ upper
  calc
    _ = ∑ n ∈ Finset.range T,ENNReal.ofReal ((1/(8*Real.pi^2))*(1/(4*Real.pi^2+16*(n:ℝ)))) := by
      rw [Finset.mul_sum,ENNReal.ofReal_sum_of_nonneg (fun n _ => by positivity)]
    _ ≤ _ := Finset.sum_le_sum (fun n _ => day n)
    _ ≤ _ := combined T
    _ ≤ ∫⁻ θ,w θ*upper ∂parameterBase := by
      apply lintegral_mono_ae
      filter_upwards [ae_par] with θ hθ
      gcongr
      exact le_iSup (fun a : parameterInterval => ∑ n ∈ Finset.range T,r n a.1) ⟨θ,abs_le.mp hθ⟩
    _ = _ := by rw [lintegral_mul_const _ mw,unit,one_mul]

theorem minimax_iid_log_lower (T : ℕ) (A : ∀ n, Past n × SquareObs → SquareObs)
    (mA : ∀ n, Measurable (A n)) :
    ENNReal.ofReal (Real.log (1+4*(T:ℝ)/Real.pi^2)/(128*Real.pi^2)) ≤
      ⨆ θ : parameterInterval, ∑ n ∈ Finset.range T,iidDayRisk n (A n) θ.1 :=
  (ENNReal.ofReal_le_ofReal (lower_log_sum T)).trans (minimax_iid_lower T A mA)

end
end SequentialRanks
