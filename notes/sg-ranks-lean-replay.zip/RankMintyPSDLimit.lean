import RankMintyPSDLinear
import RankMintyDirections
import Mathlib.Logic.Equiv.Fin.Rotate

open MeasureTheory Filter Set
open scoped BigOperators Topology
namespace SequentialRanks
noncomputable section

private theorem finite_gradient_work {d m : ℕ} (C : RankPoint d → RankPoint d →L[ℝ] ℝ)
    (f : RankPoint d → ℝ) (G : Set (RankPoint d))
    (support : ∀ x ∈ G, ∀ y ∈ G, C x (y-x) ≤ f y-f x)
    (z : Fin m → RankPoint d) (good : ∀ i, z i ∈ G) (σ : Equiv.Perm (Fin m)) :
    (∑ i, C (z i) (z (σ i)-z i)) ≤ 0 := by
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => support (z i) (good i) (z (σ i)) (good _))
  simpa only [Finset.sum_sub_distrib,Equiv.sum_comp σ (fun i => f (z i)),sub_self] using h

private theorem scale_work {d m : ℕ} (x origin : RankPoint d) (r : ℝ) (hr : 0 < r)
    (u v : Fin m → RankPoint d) (σ : Equiv.Perm (Fin m))
    (work : (∑ i, rankCovector (u i) ((x+r • v (σ i))-(x+r • v i))) ≤ 0) :
    (∑ i, rankCovector (r⁻¹ • (u i-origin)) (v (σ i)-v i)) ≤ 0 := by
  have D (i : Fin m) : (x+r • v (σ i))-(x+r • v i) = r • (v (σ i)-v i) := by rw [smul_sub]; abel
  simp only [D,map_smul,smul_eq_mul,←Finset.mul_sum] at work
  have small := nonpos_of_mul_nonpos_right work hr
  have zero : (∑ i, rankCovector origin (v (σ i)-v i)) = 0 := by
    simp only [map_sub,Finset.sum_sub_distrib,Equiv.sum_comp σ (fun i => rankCovector origin (v i)),sub_self]
  have eqn (i : Fin m) : rankCovector (r⁻¹ • (u i-origin)) (v (σ i)-v i) =
      r⁻¹*(rankCovector (u i) (v (σ i)-v i)-rankCovector origin (v (σ i)-v i)) := by
    have coef : rankCovectorMap d (r⁻¹ • (u i-origin)) =
        r⁻¹ • (rankCovector (u i) - rankCovector origin) := by
      rw [map_smul,(rankCovectorMap d).map_sub,rankCovectorMap_apply,rankCovectorMap_apply]
    rw [← rankCovectorMap_apply (r⁻¹ • (u i-origin)),coef,smul_apply,sub_apply,smul_eq_mul]
  simp only [eqn,←Finset.mul_sum,Finset.sum_sub_distrib,zero,sub_zero]
  exact mul_nonpos_of_nonneg_of_nonpos (inv_nonneg.mpr hr.le) small

private theorem finite_to_chain {d : ℕ} (A : RankDifferential d)
    (cycle : ∀ (m : ℕ) (z : Fin m → RankPoint d) (σ : Equiv.Perm (Fin m)),
      (∑ i,rankCovector (A (z i)) (z (σ i)-z i)) ≤ 0) : LinearCycleWork A := by
  intro n z
  let s := finRotate (n+1)
  have zz := cycle (n+1) (fun i => z i) s
  rw [Fin.sum_univ_castSucc] at zz
  have rr (i : Fin n) : s i.castSucc=i.succ := finRotate_of_lt i.isLt
  simp only [rr] at zz
  change (∑ i : Fin n,rankCovector (A (z i)) (z ((i:ℕ)+1)-z i))+
    rankCovector (A (z n)) (z (s (Fin.last n))-z n) ≤ 0 at zz
  rw [show s (Fin.last n)=0 from finRotate_last,
    Fin.sum_univ_eq_sum_range (fun i => rankCovector (A (z i)) (z (i+1)-z i))] at zz
  exact zz

/-- Blow up every finite cycle on the same sequence of shrinking scales.
Subgradient inequalities for the original graph imply genuine cyclic work
for the linear derivative, hence symmetric positive semidefiniteness. -/
theorem minty_psd_of_directions {d : ℕ} (G : Set (RankPoint d)) (x : RankPoint d)
    (U : RankPoint d → RankPoint d) (A : RankDifferential d) (f : RankPoint d → ℝ)
    (support : ∀ y ∈ G, ∀ z ∈ G, rankCovector (U y) (z-y) ≤ f z-f y)
    (der : HasFDerivWithinAt U A G x)
    (directions : ∀ (m : ℕ) (v : Fin m → RankPoint d), ∃ (r : ℕ → ℝ) (u : ℕ → Fin m → RankPoint d),
      (∀ n, 0<r n) ∧ Tendsto r atTop (𝓝 0) ∧
      (∀ i, Tendsto (fun n => u n i) atTop (𝓝 (v i))) ∧ ∀ n i,x+r n • u n i ∈ G) :
    (LinearMap.toMatrix' A.toLinearMap).PosSemidef := by
  apply linear_cyclic_psd A (finite_to_chain A ?_)
  intro m v σ
  obtain ⟨r,u,pos,r0,uv,good⟩ := directions m v
  let y (n : ℕ) (i : Fin m) := x+r n • u n i
  let e (n : ℕ) (i : Fin m) := (r n)⁻¹ • (U (y n i)-U x)
  have work (n : ℕ) : (∑ i,rankCovector (e n i) (u n (σ i)-u n i)) ≤ 0 :=
    scale_work x (U x) _ (pos n) (fun i => U (y n i)) (u n) σ
      (finite_gradient_work (fun z => rankCovector (U z)) f G support (y n) (good n) σ)
  have ev (i : Fin m) : Tendsto (fun n => e n i) atTop (𝓝 (A (v i))) :=
    minty_derivative_along der pos r0 (uv i) (fun n => good n i)
  have tend (i : Fin m) : Tendsto (fun n => rankCovector (e n i) (u n (σ i)-u n i)) atTop
      (𝓝 (rankCovector (A (v i)) (v (σ i)-v i))) := by
    simp only [rankCovector,sum_apply,smul_apply,ContinuousLinearMap.proj_apply,smul_eq_mul,Pi.sub_apply]
    apply tendsto_finsetSum
    intro j _
    exact (tendsto_pi_nhds.mp (ev i) j).mul
      ((tendsto_pi_nhds.mp (uv (σ i)) j).sub (tendsto_pi_nhds.mp (uv i) j))
  have whole := tendsto_finsetSum (f := fun (i : Fin m) (n : ℕ) =>
    rankCovector (e n i) (u n (σ i)-u n i)) (x := atTop)
    (a := fun i => rankCovector (A (v i)) (v (σ i)-v i)) Finset.univ (fun i _ => tend i)
  exact le_of_tendsto whole (.of_forall work)

/-- At almost every point of an arbitrary measurable regularity piece, the
within-derivative of a subgradient graph has symmetric PSD coordinate matrix. -/
theorem convex_gradient_derivative_psd_ae {d : ℕ} (G : Set (RankPoint d)) (hG : MeasurableSet G)
    (U : RankPoint d → RankPoint d) (a : RankPoint d → RankDifferential d) (f : RankPoint d → ℝ)
    (support : ∀ y ∈ G, ∀ z ∈ G, rankCovector (U y) (z-y) ≤ f z-f y)
    (der : ∀ x ∈ G, HasFDerivWithinAt U (a x) G x) :
    ∀ᵐ x ∂volume.restrict G, (LinearMap.toMatrix' (a x).toLinearMap).PosSemidef := by
  filter_upwards [minty_density_directions G,ae_restrict_mem hG] with x hs hx
  exact minty_psd_of_directions G x U (a x) f support (der x hx) hs

end
end SequentialRanks
