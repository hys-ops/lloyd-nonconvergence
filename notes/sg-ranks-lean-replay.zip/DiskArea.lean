import SG
import Mathlib.MeasureTheory.Measure.Lebesgue.VolumeOfBalls
import Mathlib.MeasureTheory.Measure.Lebesgue.Complex
open MeasureTheory Set
open scoped ENNReal
namespace Vortex
noncomputable section
def areaCoord (x : H) := Real.pi*(x.1^2+x.2^2)
theorem areaCoord_meas : Measurable areaCoord := by unfold areaCoord; fun_prop

theorem disk_area (t : ℝ) : volume (areaCoord ⁻¹' Iic t) = ENNReal.ofReal t := by
  by_cases h : 0 ≤ t
  · let r := Real.sqrt (t/Real.pi)
    have hr : 0 ≤ r := Real.sqrt_nonneg _
    have hr2 : r^2 = t/Real.pi := Real.sq_sqrt (div_nonneg h Real.pi_pos.le)
    have ht : r^2*Real.pi=t := by rw [hr2,div_mul_cancel₀ _ Real.pi_ne_zero]
    have hd : Complex.measurableEquivRealProd ⁻¹' (areaCoord ⁻¹' Iic t) = Metric.closedBall (0 : ℂ) r := by
      ext z
      change Real.pi*(z.re^2+z.im^2) ≤ t ↔ _
      rw [Metric.mem_closedBall,dist_zero_right]
      have hnorm : ‖z‖^2=z.re^2+z.im^2 := by rw [← Complex.normSq_eq_norm_sq,Complex.normSq_apply]; ring
      rw [← hnorm, ← ht, mul_comm Real.pi, mul_le_mul_iff_left₀ Real.pi_pos]
      constructor <;> intro hh <;> nlinarith [norm_nonneg z]
    rw [← Complex.volume_preserving_equiv_real_prod.measure_preimage
      ((areaCoord_meas measurableSet_Iic).nullMeasurableSet),hd,Complex.volume_closedBall,
      ← ENNReal.ofReal_pow hr]
    have hp : (NNReal.pi : ℝ≥0∞) = ENNReal.ofReal Real.pi := by
      rw [← NNReal.coe_real_pi, ENNReal.ofReal_coe_nnreal]
    rw [hp, ← ENNReal.ofReal_mul (sq_nonneg _), ht]
  · have he : areaCoord ⁻¹' Iic t = ∅ := by
      apply Set.eq_empty_iff_forall_notMem.mpr
      intro x hx
      have hz : 0 ≤ areaCoord x := by unfold areaCoord; positivity
      exact h (hz.trans hx)
    simp [he, ENNReal.ofReal_of_nonpos (le_of_not_ge h)]

theorem area_distribution :
    (volume : Measure H).map areaCoord = (volume : Measure ℝ).restrict (Ici 0) := by
  let μ := (volume : Measure H).map areaCoord
  let ν := (volume : Measure ℝ).restrict (Ici 0)
  have hm (t : ℝ) : μ (Iic t) = ENNReal.ofReal t := by
    rw [show μ = _ from rfl,Measure.map_apply areaCoord_meas measurableSet_Iic,disk_area]
  have hn (t : ℝ) : ν (Iic t) = ENNReal.ofReal t := by
    rw [show ν = _ from rfl,Measure.restrict_apply measurableSet_Iic,
        Set.inter_comm, Ici_inter_Iic,Real.volume_Icc,sub_zero]
  change μ = ν
  apply Measure.ext_of_Ioc'
  · intro a b _
    apply measure_ne_top_of_subset (show Ioc a b ⊆ Iic b from fun _ h => h.2)
    rw [hm]; exact ENNReal.ofReal_ne_top
  · intro a b hab
    rw [← Iic_sdiff_Iic, measure_sdiff (Iic_subset_Iic.2 hab.le) nullMeasurableSet_Iic,
      measure_sdiff (Iic_subset_Iic.2 hab.le) nullMeasurableSet_Iic,hm,hm,hn,hn]
    · rw [hn]; exact ENNReal.ofReal_ne_top
    · rw [hm]; exact ENNReal.ofReal_ne_top
end
end Vortex
