import RankTransport
import Mathlib.Probability.Kernel.Disintegration.Unique
import Mathlib.Probability.Kernel.Composition.MeasureComp
import Mathlib.Probability.Kernel.MeasurableIntegral
import Mathlib.MeasureTheory.Measure.Portmanteau
import Mathlib.MeasureTheory.Measure.Prokhorov

open MeasureTheory ProbabilityTheory Set Filter MeasurableSpace
open scoped Topology ProbabilityTheory
namespace SequentialRanks
noncomputable section

/-- Closed-graph stability of a unique plan on a compact metric observation/target
product makes its law depend measurably on the parameter, in the kernel (Giry) sense. -/
theorem measurable_plan_of_closed_graph {L Z : Type*} [TopologicalSpace L]
    [MeasurableSpace L] [OpensMeasurableSpace L] [MetricSpace Z] [CompactSpace Z]
    [MeasurableSpace Z] [BorelSpace Z] (π : L → ProbabilityMeasure Z)
    (stable : IsClosed (Function.graph π)) : Measurable (fun ℓ => (π ℓ : Measure Z)) := by
  have continuousPlan : Continuous π := continuous_of_isClosed_graph stable
  apply Measurable.measure_of_isPiSystem_of_isProbabilityMeasure BorelSpace.measurable_eq isPiSystem_isOpen
  intro G hG
  have h : LowerSemicontinuous fun ℓ => (π ℓ : Measure Z) G :=
    lowerSemicontinuous_iff_le_liminf.mpr fun ℓ =>
      ProbabilityMeasure.le_liminf_measure_open_of_tendsto (continuousPlan.tendsto ℓ) hG
  exact h.measurable

/-- Coordinate barycenter of the disintegration, with an everywhere ball-valued
fallback on exceptional inputs. κ is the joint-law kernel before disintegration. -/
def rankVersion {H Y K : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    [MeasurableSpace K] [StandardBorelSpace K] [Nonempty K] [CountableOrCountablyGenerated H Y]
    (κ : Kernel H (Y × K)) [IsFiniteKernel κ] {d : ℕ} (coord : K → Fin d → ℝ)
    (R : ℝ) (z : H × Y) : Fin d → ℝ :=
  let u := fun i => ∫ k, coord k i ∂(κ.condKernel z)
  if normSq u ≤ R^2 then u else 0

theorem measurable_rankVersion {H Y K : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    [MeasurableSpace K] [StandardBorelSpace K] [Nonempty K] [CountableOrCountablyGenerated H Y]
    (κ : Kernel H (Y × K)) [IsFiniteKernel κ] {d : ℕ} (coord : K → Fin d → ℝ)
    (hc : Measurable coord) (R : ℝ) : Measurable (rankVersion κ coord R) := by
  have hcoord (i : Fin d) : Measurable fun k => coord k i := (measurable_pi_apply i).comp hc
  have hm : Measurable (fun z i => ∫ k, coord k i ∂(κ.condKernel z)) :=
    measurable_pi_iff.mpr (fun i => ((hcoord i).stronglyMeasurable.integral_kernel).measurable)
  have hn : Measurable (normSq : (Fin d → ℝ) → ℝ) := by unfold normSq; fun_prop
  exact hm.ite (measurableSet_le (hn.comp hm) measurable_const) measurable_const

theorem rankVersion_ball {H Y K : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    [MeasurableSpace K] [StandardBorelSpace K] [Nonempty K] [CountableOrCountablyGenerated H Y]
    (κ : Kernel H (Y × K)) [IsFiniteKernel κ] {d : ℕ} (coord : K → Fin d → ℝ)
    (R : ℝ) (z : H × Y) : normSq (rankVersion κ coord R z) ≤ R^2 := by
  unfold rankVersion; dsimp only
  split_ifs with h
  · exact h
  · simpa [normSq] using sq_nonneg R

/-- For EACH history separately and ANY map inducing its graph plan, the single
jointly measurable version agrees almost everywhere under the observation law. -/
theorem rankVersion_eq_graph_map {H Y K : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    [MeasurableSpace K] [StandardBorelSpace K] [Nonempty K] [CountableOrCountablyGenerated H Y]
    (κ : Kernel H (Y × K)) [IsFiniteKernel κ] {d : ℕ} (coord : K → Fin d → ℝ)
    (R : ℝ) (h : H) (ν : Measure Y) [IsFiniteMeasure ν] (f : Y → K)
    (hf : Measurable f) (graphLaw : κ h = ν.map (fun y => (y,f y)))
    (ball : ∀ᵐ y ∂ν, normSq (coord (f y)) ≤ R^2) :
    ∀ᵐ y ∂ν, rankVersion κ coord R (h,y) = coord (f y) := by
  have plan : κ h = ν ⊗ₘ Kernel.deterministic f hf :=
    graphLaw.trans (Measure.compProd_deterministic hf).symm
  have marg : κ.fst h = ν := by
    change (κ h).fst = ν
    rw [plan,Measure.fst_compProd]
  have unique := Kernel.condKernel_apply_eq_condKernel κ h
  rw [marg] at unique
  have other : (κ h).condKernel =ᵐ[ν] Kernel.deterministic f hf := by
    have first : (κ h).fst = ν := marg
    have result := eq_condKernel_of_measure_eq_compProd (ρ := κ h) (Kernel.deterministic f hf)
      (by rw [first]; exact plan)
    rw [first] at result
    filter_upwards [result] with y hy using hy.symm
  filter_upwards [unique,other,ball] with y hy hdir hin
  have dirac : κ.condKernel (h,y) = Measure.dirac (f y) := hy.trans hdir
  unfold rankVersion
  simp only [dirac,integral_dirac]
  exact ite_eq_left hin

/-- End-to-end selection from a stable family of deterministic plans. Neither the
plan kernel nor a jointly measurable family of individual maps is an input. -/
theorem conditional_ranks_of_stable_plans {H L Y K : Type*}
    [MeasurableSpace H] [TopologicalSpace L] [MeasurableSpace L] [OpensMeasurableSpace L]
    [MetricSpace Y] [MeasurableSpace Y] [BorelSpace Y] [CompactSpace Y] [SecondCountableTopology Y]
    [MetricSpace K] [MeasurableSpace K] [BorelSpace K] [CompactSpace K] [SecondCountableTopology K]
    [Nonempty K] [StandardBorelSpace K] [CountableOrCountablyGenerated H Y]
    (law : H → L) (hlaw : Measurable law) (π : L → ProbabilityMeasure (Y × K))
    (stable : IsClosed (Function.graph π)) {d : ℕ} (coord : K → Fin d → ℝ)
    (hc : Measurable coord) (R : ℝ) :
    ∃ S : H × Y → Fin d → ℝ, Measurable S ∧ (∀ z, normSq (S z) ≤ R^2) ∧
      ∀ (h : H) (ν : Measure Y) [IsFiniteMeasure ν] (f : Y → K), Measurable f →
        (π (law h) : Measure (Y × K)) = ν.map (fun y => (y,f y)) →
        (∀ᵐ y ∂ν, normSq (coord (f y)) ≤ R^2) →
        ∀ᵐ y ∂ν, S (h,y) = coord (f y) := by
  let κ : Kernel H (Y × K) := ⟨fun h => (π (law h) : Measure (Y × K)),
    (measurable_plan_of_closed_graph π stable).comp hlaw⟩
  let _ : IsMarkovKernel κ := ⟨fun h => (π (law h)).property⟩
  exact ⟨rankVersion κ coord R,measurable_rankVersion κ coord hc R,rankVersion_ball κ coord R,
    fun h ν _ f hf hplan hb => rankVersion_eq_graph_map κ coord R h ν f hf hplan hb⟩
/-- The squared loss of two versions is a measurable statistic of history and
the current observation. A true law absolutely continuous with respect to the
prediction law may evaluate both versions at that same observation. -/
theorem conditional_loss_versions {H Y : Type*} [MeasurableSpace H] [MeasurableSpace Y]
    {d : ℕ} (S T : H × Y → Fin d → ℝ) (hS : Measurable S) (hT : Measurable T) :
    Measurable (fun z => normSq (diff (S z) (T z))) ∧
    ∀ (h : H) (P Q : Measure Y) (p q : Y → Fin d → ℝ), P ≪ Q →
      (∀ᵐ y ∂P, S (h,y) = p y) → (∀ᵐ y ∂Q, T (h,y) = q y) →
      (∫ y, normSq (diff (S (h,y)) (T (h,y))) ∂P) = ∫ y, normSq (diff (p y) (q y)) ∂P := by
  constructor
  · unfold diff normSq; fun_prop
  · intro h P Q p q hac hs ht
    apply integral_congr_ae
    filter_upwards [hs,hac.ae_le ht] with y hy hz
    rw [hy,hz]
end
end SequentialRanks
