import MinimaxUpper
open MeasureTheory Set Filter
open scoped ENNReal
namespace SequentialRanks
noncomputable section

private theorem kl_floor {p q : ℝ} (pn : 0 ≤ p) (qn : 0 ≤ q) : -q ≤ klTerm p q := by
  rcases eq_or_lt_of_le pn with hp|hp
  · simp [← hp,klTerm,qn]
  rcases eq_or_lt_of_le qn with hq|hq
  · simp [← hq,klTerm]
  have hh := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos (div_pos hq hp)) pn
  rw [Real.log_div hq.ne' hp.ne',mul_sub p (q/p) 1,mul_comm p (q/p),div_mul_cancel₀ _ hp.ne',mul_one] at hh
  unfold klTerm; rw [Real.log_div hp.ne' hq.ne']; nlinarith

private theorem mean_pos {Θ : Type*} [MeasurableSpace Θ] {loc : Measure Θ} [IsProbabilityMeasure loc]
    {f : Θ → ℝ} (i : Integrable f loc) (pos : ∀ᵐ θ ∂loc, 0 < f θ) :
    0 < ∫ θ,f θ ∂loc := by
  have non := pos.mono fun _ h => h.le
  by_contra! zero
  have eq := (integral_eq_zero_iff_of_nonneg_ae non i).mp (le_antisymm zero (integral_nonneg_of_ae non))
  obtain ⟨θ,hz,hp⟩ := (eq.and pos).exists
  exact hp.ne' hz

private theorem kl_jensen {Θ : Type*} [MeasurableSpace Θ] {loc : Measure Θ} [IsProbabilityMeasure loc]
    {f : Θ → ℝ} {p : ℝ} (pp : 0 < p) (i : Integrable f loc) (pos : ∀ᵐ θ ∂loc, 0 < f θ)
    (ik : Integrable (fun θ => klTerm p (f θ)) loc) :
    klTerm p (∫ θ,f θ ∂loc) ≤ ∫ θ,klTerm p (f θ) ∂loc := by
  let m := ∫ θ,f θ ∂loc
  have mp : 0 < m := mean_pos i pos
  have ii : Integrable (fun θ => klTerm p m + p*(1-f θ/m)) loc :=
    (integrable_const _).add (((integrable_const 1).sub (i.div_const m)).const_mul _)
  have hh := integral_mono_ae ii ik (by
    filter_upwards [pos] with θ hp
    have h := Real.log_le_sub_one_of_pos (div_pos hp mp)
    rw [Real.log_div hp.ne' mp.ne'] at h
    unfold klTerm
    rw [Real.log_div pp.ne' mp.ne',Real.log_div pp.ne' hp.ne']
    nlinarith only [mul_le_mul_of_nonneg_left h pp.le])
  rw [integral_add (f := fun _ => klTerm p m) (g := fun θ => p*(1-f θ/m)) (integrable_const _) (((integrable_const 1).sub (i.div_const m)).const_mul _),
    integral_const_mul,integral_sub (integrable_const 1) (i.div_const m),integral_div] at hh
  simpa only [integral_const,probReal_univ,one_smul,show (∫ θ,f θ ∂loc) / m = 1 from div_self mp.ne',
    sub_self,mul_zero,add_zero] using hh

/-- Normalize the restriction of a prior to the selected parameter neighborhood. -/
def localPrior {Θ : Type*} [MeasurableSpace Θ] (π : Measure Θ) (B : Set Θ) : Measure Θ :=
  (π B)⁻¹ • π.restrict B

private theorem local_prob {Θ : Type*} [MeasurableSpace Θ] {π : Measure Θ} [IsProbabilityMeasure π]
    {B : Set Θ} (hb : π B ≠ 0) : IsProbabilityMeasure (localPrior π B) where
  measure_univ := by simp [localPrior,Measure.smul_apply,ENNReal.inv_mul_cancel hb (measure_ne_top π B)]

private theorem local_ae {Θ : Type*} [MeasurableSpace Θ] {π : Measure Θ}
    {B : Set Θ} (mb : MeasurableSet B) : ∀ᵐ θ ∂localPrior π B, θ ∈ B :=
  ((Measure.AbsolutelyContinuous.rfl : π.restrict B ≪ π.restrict B).smul_left _).ae_le (ae_restrict_mem mb)

/-- Actual prior mixture on an arbitrary path space, with its KL bound proved from
the local prior mass and the component KL bounds. Joint KL integrability, including
the true-versus-mixture integral, is a conclusion; no uniform bounds on densities. -/
theorem local_mixture_kl {Θ X : Type*} [MeasurableSpace Θ] [MeasurableSpace X]
    (π : Measure Θ) [IsProbabilityMeasure π] (μ : Measure X) [SFinite μ]
    (B : Set Θ) (mb : MeasurableSet B) (hb : π B ≠ 0) (p : X → ℝ) (f : Θ × X → ℝ)
    (mp : Measurable p) (mf : Measurable f) (pn : ∀ x, 0 ≤ p x) (fn : ∀ z, 0 ≤ f z)
    (ip : Integrable p μ) (pmass : (∫ x,p x ∂μ) = 1)
    (fi : ∀ θ, Integrable (fun x => f (θ,x)) μ) (mass : ∀ θ, (∫ x, f (θ,x) ∂μ) = 1)
    (K : ℝ) (ac : ∀ θ ∈ B, ∀ᵐ x ∂μ, 0 < p x → 0 < f (θ,x))
    (ki : ∀ θ ∈ B, Integrable (fun x => klTerm (p x) (f (θ,x))) μ)
    (bound : ∀ θ ∈ B, (∫ x,klTerm (p x) (f (θ,x)) ∂μ) ≤ K) :
    let q := fun x => ∫ θ, f (θ,x) ∂π
    (∀ᵐ x ∂μ, 0 < p x → 0 < q x) ∧ Integrable (fun x => klTerm (p x) (q x)) μ ∧
    (∫ x, klTerm (p x) (q x) ∂μ) ≤ K - Real.log (π.real B) := by
  let loc := localPrior π B
  have prob : IsProbabilityMeasure loc := local_prob hb
  let w := π.real B
  have wp : 0 < w := ENNReal.toReal_pos hb (measure_ne_top π B)
  let q := fun x => ∫ θ, f (θ,x) ∂π
  let g := fun x => ∫ θ, f (θ,x) ∂loc
  let k := fun z : Θ × X => klTerm (p z.2) (f z)
  have mk : Measurable k := (mp.comp measurable_snd).mul ((mp.comp measurable_snd).div mf).log
  have joint (γ : Measure Θ) [IsProbabilityMeasure γ] : Integrable f (γ.prod μ) := by
    apply (integrable_prod_iff mf.aestronglyMeasurable).2
    refine ⟨.of_forall fi,?_⟩
    simp only [Real.norm_of_nonneg (fn _),mass]
    exact integrable_const _
  have iq : Integrable q μ := (joint π).integral_prod_right
  have qn (x) : 0 ≤ q x := integral_nonneg (fun θ => fn (θ,x))
  have aeB : ∀ᵐ θ ∂loc, θ ∈ B := local_ae mb
  have jk : Integrable k (loc.prod μ) := by
    apply (integrable_prod_iff mk.aestronglyMeasurable).2
    refine ⟨aeB.mono (fun θ h => ki θ h),?_⟩
    apply (integrable_const (K+2) (μ := loc)).mono' mk.stronglyMeasurable.norm.integral_prod_right'.aestronglyMeasurable
    filter_upwards [aeB] with θ hθ
    rw [Real.norm_of_nonneg (integral_nonneg (fun _ => norm_nonneg _))]
    have sectionInt := ki θ hθ
    have hh := integral_mono sectionInt.norm (sectionInt.add ((fi θ).const_mul 2)) (fun x => by
      change |klTerm (p x) (f (θ,x))| ≤ klTerm (p x) (f (θ,x)) + 2*f (θ,x)
      rw [abs_le]; constructor <;> linarith [kl_floor (pn x) (fn (θ,x)),fn (θ,x)])
    change (∫ x,‖klTerm (p x) (f (θ,x))‖ ∂μ) ≤ ∫ x, klTerm (p x) (f (θ,x))+2*f (θ,x) ∂μ at hh
    rw [integral_add sectionInt ((fi θ).const_mul 2),integral_const_mul,mass,mul_one] at hh
    exact hh.trans (by linarith [bound θ hθ])
  have ij := jk.integral_prod_right
  have ac' : ∀ᵐ x ∂μ, ∀ᵐ θ ∂loc, 0 < p x → 0 < f (θ,x) := by
    apply (Measure.ae_ae_comm (p := fun θ x => 0 < p x → 0 < f (θ,x)) ?_).mp
    · exact aeB.mono fun θ h => ac θ h
    · classical
      simp only [imp_iff_not_or]
      exact (measurableSet_lt (measurable_const (a := (0:ℝ))) (mp.comp measurable_snd)).compl.union
        (measurableSet_lt measurable_const mf)
  have localInfo : ∀ᵐ x ∂μ, (0 < p x → 0 < q x) ∧
      klTerm (p x) (q x) ≤ (∫ θ,k (θ,x) ∂loc)-p x*Real.log w := by
    filter_upwards [(joint π).prod_left_ae,(joint loc).prod_left_ae,jk.prod_left_ae,ac'] with x iπ iloc ik ax
    have lower : w*g x ≤ q x := by
      dsimp [g,loc,localPrior,w,Measure.real]
      rw [integral_smul_measure,ENNReal.toReal_inv,smul_eq_mul,← mul_assoc,mul_inv_cancel₀ (show (π B).toReal ≠ 0 from wp.ne'),one_mul]
      exact integral_mono_measure Measure.restrict_le_self (.of_forall fun θ => fn (θ,x)) iπ
    rcases eq_or_lt_of_le (pn x) with hz|pp
    · simp [← hz,k,klTerm]
    have each := ax.mono (fun _ h => h pp)
    have gp : 0 < g x := mean_pos iloc each
    have qp := (mul_pos wp gp).trans_le lower
    refine ⟨fun _ => qp,?_⟩
    have small := kl_jensen pp iloc each ik
    have comp := Real.log_le_log (mul_pos wp gp) lower
    rw [Real.log_mul wp.ne' gp.ne'] at comp
    change klTerm (p x) (q x) ≤ _
    have wG : klTerm (p x) (q x) ≤ klTerm (p x) (g x) - p x * Real.log w := by
      unfold klTerm
      rw [Real.log_div pp.ne' qp.ne',Real.log_div pp.ne' gp.ne']
      nlinarith only [mul_le_mul_of_nonneg_left comp pp.le]
    exact wG.trans (sub_le_sub_right small _)
  let U := fun x => (∫ θ,k (θ,x) ∂loc) - p x*Real.log w
  have iu : Integrable U μ := ij.sub (ip.mul_const _)
  have mq : Measurable q := mf.stronglyMeasurable.integral_prod_left'.measurable
  have finalI : Integrable (fun x => klTerm (p x) (q x)) μ := by
    apply (iq.add iu.norm).mono' (mp.mul (mp.div mq).log).aestronglyMeasurable
    filter_upwards [localInfo] with x h
    change |klTerm (p x) (q x)| ≤ q x+|U x|
    rw [abs_le]; constructor
    · linarith [kl_floor (pn x) (qn x),abs_nonneg (U x)]
    · exact h.2.trans ((le_abs_self (U x)).trans (le_add_of_nonneg_left (qn x)))
  refine ⟨localInfo.mono (fun _ h => h.1),finalI,?_⟩
  have h := integral_mono_ae finalI iu (localInfo.mono (fun _ h => h.2))
  change _ ≤ (∫ x,(∫ θ,k (θ,x) ∂loc)-p x*Real.log w ∂μ) at h
  rw [integral_sub ij (ip.mul_const _),integral_mul_const,pmass,one_mul,
    ← integral_integral_swap (f := fun θ x => k (θ,x)) jk] at h
  have hh := integral_mono_ae jk.integral_prod_left (integrable_const K) (aeB.mono fun θ hθ => bound θ hθ)
  simpa using h.trans (sub_le_sub_right hh (Real.log w))

end
end SequentialRanks
