import StaticRankInverse

open MeasureTheory Filter Set
open scoped BigOperators Topology ENNReal NNReal
namespace SequentialRanks
noncomputable section

/-- An ambient rank map with values in B everywhere. This produces a certified
graph from the public compact-support and normalization assumptions and handles
the arbitrary representative outside the source support. -/
theorem compact_rank_graph_exists {d : ℕ} (A B : Set (RankPoint d)) (ha : IsCompact A) (hb : IsCompact B)
    [Nonempty B] (p w : RankPoint d → ℝ) [IsProbabilityMeasure (weighted volume p)]
    [IsProbabilityMeasure (weighted volume w)] (sa : ∀ᵐ x ∂weighted volume p, x ∈ A)
    (sb : ∀ᵐ x ∂weighted volume w, x ∈ B) :
    ∃ U : RankPoint d → RankPoint d, Measurable U ∧ (∀ x, U x ∈ B) ∧
      (weighted volume p).map U = weighted volume w ∧ compactRankGraph A B p U := by
  let μ := weighted volume p
  let ν := weighted volume w
  have ma := ha.isClosed.measurableSet
  have mb := hb.isClosed.measurableSet
  let Pa := μ.comap ((↑) : A → RankPoint d)
  let Qb := ν.comap ((↑) : B → RankPoint d)
  have massA : IsProbabilityMeasure Pa :=
    (MeasurableEmbedding.subtype_coe ma).isProbabilityMeasure_comap (by simpa using sa)
  have massB : IsProbabilityMeasure Qb :=
    (MeasurableEmbedding.subtype_coe mb).isProbabilityMeasure_comap (by simpa using sb)
  let P : ProbabilityMeasure A := ⟨Pa,massA⟩
  let Q : ProbabilityMeasure B := ⟨Qb,massB⟩
  have orig (D : Set (RankPoint d)) (mD : MeasurableSet D) (eta : Measure (RankPoint d))
      (onD : ∀ᵐ x ∂eta, x ∈ D) :
      (eta.comap ((↑) : D → RankPoint d)).map Subtype.val = eta := by
    rw [map_comap_subtype_coe mD,Measure.restrict_eq_self_of_ae_mem onD]
  have lawP : (P : Measure A).map Subtype.val = μ := orig A ma μ sa
  have lawQ : (Q : Measure B).map Subtype.val = ν := orig B mb ν sb
  have ac : (P : Measure A).map Subtype.val ≪ volume := lawP ▸ withDensity_absolutelyContinuous _ _
  obtain ⟨φ,_,π,_,_,cert,_,_,graph,_⟩ := compact_brenier A B ha hb P Q ac
  obtain ⟨F,mF,hF⟩ := (MeasurableEmbedding.subtype_coe ma).exists_measurable_extend
    (measurable_supportGradient (A := A) mb φ) (fun _ => inferInstance)
  let U : RankPoint d → RankPoint d := fun x => (F x).val
  have mu : Measurable U := measurable_subtype_coe.comp mF
  let e := fun z : A × B => (z.1.val,z.2.val)
  have me : Measurable e := (measurable_subtype_coe.comp measurable_fst).prodMk
    (measurable_subtype_coe.comp measurable_snd)
  let f := fun x : A => (x,supportGradient (B := B) φ x)
  have mf : Measurable f := measurable_id.prodMk (measurable_supportGradient mb φ)
  have egraph : (P : Measure A).map f = (π : Measure (A × B)) := congrArg Subtype.val graph
  have mg : Measurable (fun x : RankPoint d => (x,U x)) := measurable_id.prodMk mu
  have g : μ.map (fun x => (x,U x)) = (π : Measure (A × B)).map e := by
    rw [← lawP,← egraph,Measure.map_map mg measurable_subtype_coe,Measure.map_map me mf]
    congr 1
    funext x
    change (x.val,(F x.val).val) = (x.val,(supportGradient φ x).val)
    rw [show F x.val = supportGradient φ x from congrFun hF x]
  refine ⟨U,mu,fun x => (F x).property,?_,π,cert.2.2,g⟩
  have eq := congrArg (fun M : Measure (RankPoint d × RankPoint d) => M.map Prod.snd) g
  change (μ.map (fun x => (x,U x))).map Prod.snd = ((π : Measure _).map e).map Prod.snd at eq
  rw [Measure.map_map measurable_snd mg,Measure.map_map measurable_snd me] at eq
  calc
    μ.map U = (π : Measure (A × B)).map (fun z => z.2.val) := eq
    _ = ((π : Measure (A × B)).map Prod.snd).map Subtype.val := (Measure.map_map measurable_subtype_coe measurable_snd).symm
    _ = ν := (congrArg (fun m : ProbabilityMeasure B => (m : Measure B).map Subtype.val) cert.2.1).trans lawQ

end
end SequentialRanks
