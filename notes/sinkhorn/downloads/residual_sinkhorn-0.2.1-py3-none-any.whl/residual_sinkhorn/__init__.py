"""NumPy Sinkhorn with bounded automatic kernel reuse and explicit fixed-cost preparation."""
import ctypes
from dataclasses import dataclass
from threading import local
from typing import Optional
import warnings

import numpy as np
import ot

__all__ = ["sinkhorn", "prepare", "clear_cache"]

# One opportunistic entry per thread. Larger problems can explicitly request preparation.
_AUTO_BYTES = 32 * 1024 * 1024
_cache = local()

# A byte comparison uses no matrix-sized temporary and exits on the first difference.
# np.array_equal is the portable fallback when a C runtime symbol is unavailable.
try:
    _memcmp = ctypes.CDLL(None).memcmp
except (AttributeError, OSError, TypeError):
    _memcmp = None
else:
    _memcmp.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    _memcmp.restype = ctypes.c_int


def _eligible(a, b, M, reg, method, numItermax, stopThr, verbose, log, warn, warmstart, kwargs):
    if (ot.__version__ not in ("0.9.7", "0.9.7.post1") or type(method) is not str or method.lower() != "sinkhorn"
            or verbose is not False or log is not False or type(warn) is not bool
            or warmstart is not None or kwargs):
        return False
    if not all(type(x) is np.ndarray and x.dtype == np.float64 for x in (a,b,M)):
        return False
    if (a.ndim != 1 or b.ndim != 1 or M.shape != (a.size,b.size)
            or min(a.size,b.size) < 2 or not M.flags.c_contiguous):
        return False
    if (type(numItermax) not in (int,np.int32,np.int64) or numItermax < 11
            or type(stopThr) not in (float,np.float64) or not 1e-13 <= stopThr < 1
            or type(reg) not in (int,float,np.float64) or not np.isfinite(reg) or reg<=0):
        return False
    return True


def _plan_factor(low, high, n):
    # log cross-ratio diameter <= 2 log(high/low). Guard before dividing.
    cap = float(n-1)
    if high >= (2*cap-1)*low:
        return cap
    return .5*(1 + high/low)


@dataclass(frozen=True, eq=False)
class _Kernel:
    matrix: np.ndarray
    first_columns: np.ndarray
    column_factor: float
    row_factor: float


def _build_kernel(M, reg, *, shared):
    K = np.empty_like(M)
    with np.errstate(over="ignore", under="ignore", invalid="ignore", divide="ignore"):
        np.divide(M, -reg, out=K)
        np.exp(K, out=K)
        low, high = K.min(), K.max()
        if not (low > 1e-280 and high < 1e100):
            return None
        factor = _plan_factor(low, high, M.shape[1])
        ratio = low/high
        tau = (1-ratio)/(1+ratio)
        # Transferring the row residual produces a column residual at most tau times as large.
        propagated = min(1+_plan_factor(low, high, M.shape[0]), factor*tau)
        first = K.T @ np.full(M.shape[0], 1./M.shape[0])
    if shared:
        K.setflags(write=False)
        first.setflags(write=False)
    return _Kernel(K, first, factor, propagated)


@dataclass(frozen=True, eq=False)
class _Prepared:
    _cost: np.ndarray
    _reg: float
    _kernel: Optional[_Kernel]

    def solve(self, a, b, method="sinkhorn", numItermax=1000, stopThr=1e-9,
              verbose=False, log=False, warn=True, warmstart=None, **kwargs):
        """Solve with new marginals on the saved cost snapshot. Each returned plan is independent."""
        return _dispatch(a,b,self._cost,self._reg,method,numItermax,stopThr,verbose,log,warn,
                         warmstart,kwargs,True,prepared=self)


def prepare(M, reg):
    """Snapshot a finite CPU float64 cost matrix and cache the kernel from the first solve.
    Changing M later does not change this prepared problem. To use new costs, prepare them again.
    """
    if type(M) is not np.ndarray or M.ndim != 2 or M.dtype != np.float64 or min(M.shape) < 2:
        raise ValueError("expected a 2-D NumPy float64 matrix with at least two rows and columns")
    if type(reg) not in (int,float,np.float64) or not np.isfinite(reg) or reg <= 0:
        raise ValueError("expected a positive finite regularization")
    cost = M.copy(order="C")
    if not np.isfinite(cost).all():
        raise ValueError("expected finite costs")
    cost.setflags(write=False)
    return _Prepared(cost, reg, _build_kernel(cost, reg, shared=True))


def clear_cache():
    """Release the automatic cache in the calling thread. Explicit prepared handles stay valid."""
    _cache.entry = None


@dataclass
class _Entry:
    signature: tuple
    prepared: Optional[_Prepared] = None
    skip: int = 0


def _same_cost(M, saved):
    # Both are live C-contiguous CPU float64 ndarrays with matching shape, checked by the caller.
    if _memcmp is None:
        return np.array_equal(M,saved)
    return _memcmp(M.ctypes.data,saved.ctypes.data,M.nbytes) == 0


def _auto_kernel(M, reg):
    if 2*M.nbytes + M.shape[1]*8 > _AUTO_BYTES:
        return _build_kernel(M, reg, shared=False)
    rows,cols=M.shape
    signature=(M.shape,reg,M[0,0],M[rows//2,cols//2],M[-1,-1])
    entry = getattr(_cache, "entry", None)
    if entry is None or entry.signature != signature:
        # Samples screen candidates only. No kernel is ever reused on this basis.
        _cache.entry = _Entry(signature)
    elif entry.skip:
        entry.skip -= 1
    elif entry.prepared is None:
        cost = M.copy(order="C")
        cost.setflags(write=False)
        kernel = _build_kernel(cost, reg, shared=True)
        entry.prepared = _Prepared(cost,reg,kernel)
        return kernel
    elif _same_cost(M, entry.prepared._cost):
        return entry.prepared._kernel
    else:
        # If the samples match while other entries change, defer another snapshot.
        entry.prepared, entry.skip = None, 8
    return _build_kernel(M, reg, shared=False)


def _materialize(K, u, v):
    # An unshared kernel can be overwritten. Every shared-kernel solve creates its own result.
    out = K if K.flags.writeable else None
    plan = np.multiply(K, u[:, None], out=out)
    plan *= v
    return plan


def _dense(a,b,M,reg,numItermax,stopThr,*,early=True,details=False,warn=True,prepared=None):
    if (not np.min(a)>0 or not np.min(b)>0 or
            not abs(a.sum()-1.) <= 8e-15 or not abs(b.sum()-1.) <= 8e-15):
        return None
    kernel = _auto_kernel(M,reg) if prepared is None else prepared._kernel
    if kernel is None:
        return None
    K = kernel.matrix
    with np.errstate(over='ignore', invalid='ignore', divide='ignore', under='ignore'):
        factor = kernel.column_factor
        col_budget = (.25*stopThr)/factor
        wide = b.size >= 4*a.size
        row_budget = (.25*stopThr)/max(kernel.row_factor,1e-300)
        u = np.full(a.size, 1./a.size)
        col_product = kernel.first_columns
        for iteration in range(numItermax):
            v = b / col_product
            kv = K @ v
            checkpoint = iteration % 10 == 0
            # Probe three times within a standard ten-iteration block; this limits
            # residual reductions on cold kernels where most early checks would fail.
            try_early = early and iteration%10 in (4,7,9) and iteration + 10 - iteration%10 < numItermax
            accepted = False
            if wide and try_early:
                accepted = .5*np.abs(u*kv-a).sum() < row_budget
            u = a / kv
            if not accepted:
                col_product = K.T @ u
                if checkpoint:
                    accepted = np.linalg.norm(v*col_product-b) < stopThr
                elif try_early and not wide:
                    accepted = .5*np.abs(v*col_product-b).sum() < col_budget
            if accepted:
                K = _materialize(K, u, v)
                # Check the returned dense plan itself, after both multiplications.
                column_residual = K.sum(axis=0)-b
                if (not np.linalg.norm(column_residual)<stopThr
                        or not np.linalg.norm(K.sum(axis=1)-a)<stopThr
                        or (not wide and not checkpoint and not .5*np.abs(column_residual).sum()<col_budget)):
                    return None
                if details:
                    return K, iteration+1, not checkpoint, factor
                return K
            if checkpoint and not np.isfinite(u).all():
                return None
        # Stable exhaustion: preserve the last plan and POT's convergence warning.
        # Avoid repeating the entire iteration budget for a difficult but finite input.
        if not np.isfinite(u).all() or not np.isfinite(v).all():
            return None
        K = _materialize(K, u, v)
        if not np.linalg.norm(K.sum(axis=1)-a) < max(stopThr,1e-12):
            return None
    if warn:
        warnings.warn("Sinkhorn did not converge. You might want to "
                      "increase the number of iterations `numItermax` "
                      "or the regularization parameter `reg`.", UserWarning, stacklevel=3)
    if details:
        return K, numItermax, False, factor
    return K


def sinkhorn(a, b, M, reg, method="sinkhorn", numItermax=1000, stopThr=1e-9,
             verbose=False, log=False, warn=True, warmstart=None, **kwargs):
    """Return the POT entropic transport plan. Supported default CPU calls may terminate
    between public POT checkpoints if the plan-TV certificate is below stopThr/4.
    Other call forms and numerical failures use the installed POT solver.
    """
    return _dispatch(a,b,M,reg,method,numItermax,stopThr,verbose,log,warn,warmstart,kwargs,True)


def _dispatch(a,b,M,reg,method,numItermax,stopThr,verbose,log,warn,warmstart,kwargs,early,prepared=None):
    if _eligible(a,b,M,reg,method,numItermax,stopThr,verbose,log,warn,warmstart,kwargs):
        result = _dense(a,b,M,reg,numItermax,stopThr,early=early,warn=warn,prepared=prepared)
        if result is not None:
            return result
    return ot.sinkhorn(a,b,M,reg,method=method,numItermax=numItermax,stopThr=stopThr,
                       verbose=verbose,log=log,warn=warn,warmstart=warmstart,**kwargs)
