# Reproduce the Lloyd theorem

The detachable `Lloyd_Lean_Reproduction.zip` contains `lean/`, `checks/`, this README, the verification records, and a SHA-256 inventory. Commands below start in the extracted packet root. In the full publication kit, the exact same sources and release logs are under `research/`. The full development note and Brenier history are available in the full kit.

## Checklist for a reviewer

1. On Linux run `sha256sum -c SHA256SUMS` before building. The packet excludes compiled objects and external dependency caches.
2. Use Bash, Git, Python 3 and elan with network access on first install. The toolchain is `leanprover/lean4:v4.34.1`; mathlib is pinned to `d13f23b723b8a846827a245b89c10fc7d3f11612`. See `lean/lean-toolchain`, `lean/lakefile.toml` and `lean/lake-manifest.json`.
3. In a fresh extraction run the full check below. It fetches matching mathlib dependencies, scans local sources, builds the project, prints the named declarations and replays each listed local module with the kernel checker. Retain both exit status and output.

    ```bash
    cd lean
    set -o pipefail
    bash scripts/verify.sh 2>&1 | tee ../replay-local.log
    ```

4. To inspect just the main endpoint in `lean/`:

    ```bash
    lake exe cache get
    lake build NDVerified
    lake env leanchecker -v NDVerified
    lake env lean Audit.lean
    ```

5. In `lean/logs/axioms.log` read the expanded `JointExample` and `SolverAndLimits` types as well as the endpoint. Confirm that the displayed cluster space refers to configurations of the actual orbit, that both inclusions for cluster points are present, and that the same initial seed is used with three different sources. The quantification is existential in the source and seed for each dimension, derivative order and positive tolerance. Each source has its own limiting radius. The signed ordering used for the dynamics is forgotten for the final topology.
6. Compare `lean/logs/build.log`, `kernel-replay.log`, `source-scan.log`, `verification.txt` and `scripts/local-dependencies.json` with the local run. Expect 106 local modules in the full build and replay, 66 in the final import closure including the endpoint, 20 printed axiom reports. The endpoint uses `propext`, `Classical.choice`, `Quot.sound`. The low-dimensional theorems are separate. The full replay uses the pinned external dependencies.
7. From the packet root, optionally run `python3 checks/check_splitting.py` and (with mpmath installed) `python3 checks/check_steps.py`. The first tests the starting-error identity on rational sample data. The other eight finite checks test example steps in dimensions 3, 4, 5 and 8. The infinite orbit and the topology are proved in Lean.

## Declarations to inspect

| Assertion | Code |
|---|---|
| Joint theorem | `NDVerified.lean` · `LloydNDVerified.projective_lloyd` |
| Sources and prescribed exact gradient | `LloydNDModels.realize`, `LloydNDJet.profile_exact` |
| All cluster directions | `LloydNDLimits.exact_orbit`, `LloydNDMain.projective_equator_counterexample` |
| Optimal equal-mass assignments and unordered topology | `LloydNDMain.projective_equator_all_solvers`, `LloydNDProjective.cluster_homeomorphic` |
| Dimensions one and two | `LloydNDLine.one_step`, `LloydNDPlanar.convergence` and their balanced counterparts |

## What was rerun during publication preparation

All 106 local proof files, `Audit.lean` and the three version/build configuration files matched the populated release workspace byte for byte (110 files in total). The final-module kernel replay succeeded. Running `lake env lean Audit.lean` reproduced the archived declaration and axiom output byte for byte. Both optional finite checks ran and the eight-step output matched the stored JSON byte for byte. These current logs are under `prep-checks/` in the detachable packet and `review/` in the full kit. The complete 106-module clean build and the 106-module replay are the earlier archived runs; the preparation pass used their populated build cache. No new theorem was added.

The paper uses time −log z along its chosen curve and a classical cosine inverse. Lean uses a reciprocal-height clock and a Fourier right inverse for parameter families. The endpoint verifies the same mathematical existence statement, with a permutation of the equatorial normal. It does not formally verify the historical reading of authors, the written modified-radius comparison, or human responsibility for the manuscript.
