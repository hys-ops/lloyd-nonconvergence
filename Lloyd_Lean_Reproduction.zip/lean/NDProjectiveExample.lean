import NDMain
import NDProjective

/-! The canonical full-dimensional examples with projective topology attached to
all three actual population Lloyd orbits. -/
noncomputable section
open MeasureTheory
namespace LloydNDProjective
open LloydNDFrame LloydNDMain

theorem all_sources_projective (k m:ℕ) (ε:ℝ) (hε:0<ε) :
    ∃ (K:Set (E (k+3))) (ρ σ:E (k+3) → ℝ) (y:E (k+3)),
      JointExample m ε K ρ σ y ∧
      Nonempty (RealProjective (k+2) ≃ₜ clusterSet (LloydNDLimits.uniformOn K) y) ∧
      Nonempty (RealProjective (k+2) ≃ₜ clusterSet (LloydNDGaussian.law ρ) y) ∧
      Nonempty (RealProjective (k+2) ≃ₜ clusterSet (LloydNDGaussian.law σ) y) := by
  obtain ⟨K,ρ,σ,y,h⟩ := projective_equator_counterexample k m ε hε
  obtain ⟨_,_,_,_,_,_,_,_,hu,_⟩ := h.uniform
  exact ⟨K,ρ,σ,y,h,cluster_homeomorphic hu,cluster_homeomorphic h.gaussian_orbit,
    cluster_homeomorphic h.compact_orbit⟩

#print axioms all_sources_projective
end LloydNDProjective
