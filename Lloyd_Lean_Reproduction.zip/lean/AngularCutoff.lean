import AngularDensity
import Mathlib.Analysis.Calculus.ContDiff.Bounds

open Set Filter
open scoped ContDiff SchwartzMap Topology
namespace LloydAngular
noncomputable section
open LloydCosine

def cutoffMoment (a : E → ℝ) (k : ℕ) (f : 𝓢(E,ℝ)) (x : E) := a x * moment k f x

private lemma cutoff_zero {a : E → ℝ} (k : ℕ) (f : 𝓢(E,ℝ)) {x : E} (hx : x ∉ tsupport a) :
    cutoffMoment a k f =ᶠ[𝓝 x] (0 : E → ℝ) := by
  filter_upwards [notMem_tsupport_iff_eventuallyEq.mp hx] with y hy
  simp [cutoffMoment,hy]

/-- A fixed global smooth multiplier supported away from the origin transfers the
smooth angular moment to a global smooth defining perturbation. -/
theorem cutoffMoment_smooth {a : E → ℝ} (ha : ContDiff ℝ ∞ a) (hs : tsupport a ⊆ away)
    (k : ℕ) (f : 𝓢(E,ℝ)) : ContDiff ℝ ∞ (cutoffMoment a k f) := by
  apply contDiff_iff_contDiffAt.mpr
  intro x
  by_cases hx : x ∈ tsupport a
  · exact ha.contDiffAt.mul ((moment_smooth k f).contDiffAt (away_open.mem_nhds (hs hx)))
  · exact contDiffAt_const.congr_of_eventuallyEq (cutoff_zero k f hx)

private lemma norm_two (g : E → ℝ) (x : E) :
    ‖iteratedFDeriv ℝ 2 g x‖ = ‖fderiv ℝ (fderiv ℝ g) x‖ := by
  rw [← norm_iteratedFDeriv_fderiv (n := 1),norm_iteratedFDeriv_one]

/-- Global uniform C² convergence after applying the fixed cutoff. The multiplier
is independent of the family. The estimates include its support boundary. -/
theorem cutoff_eventually_small {ι : Type*} {l : Filter ι} {f : ι → 𝓢(E,ℝ)}
    (hf : Tendsto f l (𝓝 0)) {a : E → ℝ} (ha : ContDiff ℝ ∞ a)
    (hcompact : HasCompactSupport a) (hs : tsupport a ⊆ away) (k : ℕ)
    {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ i in l, ∀ x : E,
      ‖cutoffMoment a k (f i) x‖ < ε ∧
      ‖fderiv ℝ (cutoffMoment a k (f i)) x‖ < ε ∧
      ‖fderiv ℝ (fderiv ℝ (cutoffMoment a k (f i))) x‖ < ε := by
  obtain ⟨C,hC,hbound⟩ := hcompact.exists_bound_iteratedFDeriv ha 2
  let η := ε/(4*(C+1))
  have hη : 0 < η := by dsimp [η]; positivity
  have hsmall : 4*C*η < ε := by
    have hden : 0 < 4*(C+1) := by positivity
    calc
      4*C*η = (4*C*ε)/(4*(C+1)) := by dsimp [η]; ring
      _ < ε := (div_lt_iff₀ hden).mpr (by nlinarith)
  filter_upwards [eventually_C2_small hf k hη] with i hi x
  let g := moment k (f i)
  let B := cutoffMoment a k (f i)
  by_cases hx : x ∈ away
  · have gm : ∀ j ≤ 2, ‖iteratedFDeriv ℝ j g x‖ < η := by
      intro j hj
      obtain ⟨h0,h1,h2⟩ := hi x hx
      interval_cases j
      · simpa [g] using h0
      · simpa [g,norm_iteratedFDeriv_one] using h1
      · simpa [g,norm_two] using h2
    have bd (j : ℕ) (hj : j ≤ 2) : ‖iteratedFDeriv ℝ j B x‖ < ε := by
      have prod := norm_iteratedFDerivWithin_mul_le ha.contDiffOn (moment_smooth k (f i))
        away_open.uniqueDiffOn hx (n := j) (by exact_mod_cast (le_top : (j : ℕ∞) ≤ ⊤))
      simp only [iteratedFDerivWithin_of_isOpen _ away_open hx] at prod
      have ht (p : ℕ) (hp : p ≤ j) :
          (j.choose p : ℝ) * ‖iteratedFDeriv ℝ p a x‖ * ‖iteratedFDeriv ℝ (j-p) g x‖ ≤
            j.choose p * C * η := by
        gcongr
        · exact hbound _ (hp.trans hj) _
        · exact (gm _ ((Nat.sub_le _ _).trans hj)).le
      refine lt_of_le_of_lt prod ?_
      calc
        _ ≤ ∑ p ∈ Finset.range (j+1), (j.choose p : ℝ) * C * η :=
          Finset.sum_le_sum fun p hp => ht p (by simpa using Finset.mem_range.mp hp)
        _ ≤ 4*C*η := by
          interval_cases j <;> norm_num [Finset.sum_range_succ] <;> nlinarith [mul_nonneg hC hη.le]
        _ < ε := hsmall
    exact ⟨by simpa [B] using bd 0 (by decide),
      by simpa [B,norm_iteratedFDeriv_one] using bd 1 (by decide),
      by simpa [B,norm_two] using bd 2 le_rfl⟩
  · have hlocal : B =ᶠ[𝓝 x] (0 : E → ℝ) := cutoff_zero k (f i) (fun h => hx (hs h))
    have h0 := hlocal.eq_of_nhds
    have h1 := hlocal.fderiv_eq (𝕜 := ℝ)
    have h2 := (hlocal.iteratedFDeriv ℝ 2).eq_of_nhds
    change ‖B x‖ < ε ∧ ‖fderiv ℝ B x‖ < ε ∧ ‖fderiv ℝ (fderiv ℝ B) x‖ < ε
    rw [h0,h1,←norm_two,h2]
    simpa using hε

#print axioms cutoffMoment_smooth
#print axioms cutoff_eventually_small
end
end LloydAngular
