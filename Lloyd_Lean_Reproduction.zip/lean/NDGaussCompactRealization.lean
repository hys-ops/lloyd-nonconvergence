import NDGaussCompactShape
import NDGaussLawSupport
import NDGaussLogConcavity
import NDFourierRange

/-! Compact smooth, globally log-concave density with exact directional
absolute moments prescribed near the constant in each positive dimension. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set
open scoped Topology RealInnerProductSpace SchwartzMap ContDiff
namespace LloydNDCompactSource
open LloydNDAngular LloydNDNeutralShell LloydNDPolar LloydNDRadialSource
variable {dim : ℕ}
local notation "Vn" => E dim

def normalizer (k : ℕ) : ℝ := (∫ x:E k,LloydNDCompactDensity.base x)⁻¹
theorem normalizer_pos (k : ℕ) : 0 < normalizer k := inv_pos.mpr LloydNDCompactDensity.base_mass_pos
def pdf (x:Vn) := normalizer dim * LloydNDCompactDensity.base x

def reference (k : ℕ) : Base (dim:=k) where
  pdf := pdf
  smooth := contDiff_const.mul LloydNDCompactDensity.base_smooth
  compact := LloydNDCompactDensity.base_compact.mul_left
  nonneg := fun x => mul_nonneg (normalizer_pos k).le (LloydNDCompactDensity.base_nonneg x)
  positive := fun x => by simpa [pdf,mul_pos_iff_of_pos_left (normalizer_pos k)] using LloydNDCompactDensity.base_pos_iff x
  radial := fun x y h => by rw [pdf,pdf,LloydNDCompactDensity.base_radial h]
  normed := by unfold pdf normalizer; rw [integral_const_mul,inv_mul_cancel₀ LloydNDCompactDensity.base_mass_pos.ne']

theorem compact_realization (h : ℝ × Vn → ℝ) (hs : LloydNDFrequency.SmoothOnDirections h)
    (he : ∀ t (u:Vn), ‖u‖=1 → h (t,-u)=h (t,u))
    (hz : ∀ u:Vn, ‖u‖=1 → h (0,u)=1) :
    ∃ C : ℝ, 0<C ∧ ∀ᶠ t in 𝓝 (0:ℝ), ∃ ρ : Vn → ℝ, let μ := LloydNDGaussian.law ρ
      ContDiff ℝ ∞ ρ ∧ (∀ x,0≤ρ x) ∧ (∀ x, 0<ρ x ↔ ‖x‖<3) ∧
      tsupport ρ = Metric.closedBall (0:Vn) 3 ∧ μ.support = Metric.closedBall (0:Vn) 3 ∧
      (∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x=pdf x) ∧ (∀ x,ρ (-x)=ρ x) ∧
      IsProbabilityMeasure μ ∧ MeasurePreserving (fun x : Vn => -x) μ μ ∧ μ ≪ volume ∧
      (∫ x:Vn,x ∂μ)=0 ∧ MemLp id 2 μ ∧ covarianceBilin μ=covarianceBilin (LloydNDGaussian.law pdf) ∧
      (∀ x, ‖x‖<3 → ∀ v:Vn, ‖v‖^2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v) ∧
      (∀ (x y:Vn) (a b:ℝ), 0≤a → 0≤b → a+b=1 → (ρ x)^a*(ρ y)^b ≤ ρ (a • x+b • y)) ∧
      ∀ u:Vn, ‖u‖=1 → (∫ x, |⟪u,x⟫| ∂μ)=C*h (t,u) := by
  let R := reference dim
  obtain ⟨C,hC,hbase⟩ := R.constant_projection
  let H := fun p : ℝ × Vn => C * (h p - 1)
  have hsm : LloydNDFrequency.SmoothOnDirections H :=
    fun p hp => contDiffAt_const.mul ((hs p hp).sub contDiffAt_const)
  have h0 : ∀ u:Vn, ‖u‖=1 → H (0,u)=0 := by intro u hu; simp [H,hz u hu]
  have hev (t:ℝ) (u:Vn) (hu:‖u‖=1) : H (t,-u)=H (t,u) := by simp [H,he t u hu]
  let F := fun t => LloydNDFourierRange.rightInverse (fun u => H (t,u)) (LloydNDFrequency.slice_smooth hsm t)
  have hF : Tendsto F (𝓝 0) (𝓝 0) := LloydNDFourierRange.rightInverse_tendsto hsm h0
  refine ⟨C,hC,?_⟩
  filter_upwards [LloydNDCompactDensity.eventually_compact_shell hF (normalizer_pos dim)] with t ht
  obtain ⟨hc,hn,hp,hoff,hh⟩ := ht
  have spec := LloydNDFourierRange.rightInverse_spec (LloydNDFrequency.slice_smooth hsm t) (hev t)
  let A := radialize (F t)
  have hA : AngularSmooth A := by
    intro u hu
    apply (schwartz_radialize_smooth (F t)).contDiffAt
    exact away_open.mem_nhds (show u ∈ away by change 1/2 < ‖u‖; rw [hu]; norm_num)
  have heA (u:Vn) (_ : ‖u‖=1) : A (-u)=A u := radialize_even spec.1 u
  have hc' : ContDiff ℝ ∞ (R.perturbed A) := hc
  have hn' : ∀x, 0≤R.perturbed A x := hn
  have hsupport := R.exact_support (fun x => (hp x).mpr)
  refine ⟨R.perturbed A,hc',hn',hp,hsupport,(law_support hc'.continuous hn').trans hsupport,hoff,
    R.even heA,R.probability hA hn',law_neg (R.even heA),withDensity_absolutelyContinuous _ _,
    law_mean (R.even heA),R.measure_L2 hA hn',R.covariance_preserved hA hn' heA,hh,
    LloydNDLogConcave.zero_extended_logconcavity hc' hn' hp (fun x hx v=>(sq_nonneg _).trans (hh x hx v)),?_⟩
  intro u hu
  change (∫ x, |⟪u,x⟫| ∂R.measure A) = _
  rw [R.projection hA hn',hbase u hu]
  change C + cosineTransform (fun w => radialize (F t) w.val) u = _
  rw [schwartz_cosine]
  have hh := spec.2 u hu
  change (∫ x:Vn, |⟪x,u⟫| * F t x)=C*(h (t,u)-1) at hh
  conv_lhs => arg 2; arg 2; ext x; rw [real_inner_comm x u]
  rw [hh]
  ring

#print axioms compact_realization
end LloydNDCompactSource
