import GlobalCounterexample
import ParametricSpiral

/-! Smooth amplitude families vanishing at the origin of parameter space. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LloydFamily
open LloydSpiral.Chart LloydGlobal LloydFlatSpiral

def parameter (a t : ℝ) : ℝ := a*t^2/(1+t^2)
def angular (a t : ℝ) : E3 → ℝ := prescribedSupport (parameter a t)

theorem parameter_smooth (a : ℝ) : ContDiff ℝ ∞ (parameter a) := by
  unfold parameter
  fun_prop (disch := intro x; positivity)

@[simp] theorem parameter_zero (a : ℝ) : parameter a 0=0 := by simp [parameter]

theorem parameter_range {a : ℝ} (ha : 0<a) (t : ℝ) :
    0 ≤ parameter a t ∧ parameter a t < a := by
  have hp : 0<1+t^2 := by positivity
  unfold parameter
  exact ⟨by positivity, (div_lt_iff₀ hp).2 (by nlinarith)⟩

theorem parameter_pos {a t : ℝ} (ha : 0<a) (ht : t≠0) : 0<parameter a t := by
  unfold parameter
  positivity

private theorem cut_zero_of_band {f : ℝ → ℝ} (hf : ∀ z ∈ band, f z=0) (z : ℝ) : cut f z=0 := by
  by_cases hz : z ∈ band
  · simp [cut,hf z hz]
  · have ha : 9/40 ≤ |z| := by
      simp only [band,mem_Ioo,not_and_or,not_lt] at hz
      rcases hz with hz|hz
      · rw [abs_of_neg (by linarith : z<0)]; linarith
      · rw [abs_of_pos (by linarith : 0<z)]; linarith
    have hc : cutoff z=0 := cutoff.zero_of_le_dist (by
      change 9/40≤dist z 0; simpa [Real.dist_eq] using ha)
    simp [cut,hc]

theorem modelPotential_zero (x : E3) : modelPotential 0 x=0 := by
  have a := cut_zero_of_band (fun z hz => (zero_parameter_values (z:=z) hz).1)
  have b := cut_zero_of_band (fun z hz => (zero_parameter_values (z:=z) hz).2.1)
  have c := cut_zero_of_band (fun z hz => (zero_parameter_values (z:=z) hz).2.2)
  simp [modelPotential,evenLift,north,a,b,c]

@[simp] theorem angular_zero (a : ℝ) (x : E3) : angular a 0 x=1 := by
  simp [angular,prescribedSupport,modelPotential_zero]

theorem angular_even (a t : ℝ) (x : E3) : angular a t (-x) = angular a t x :=
  congrArg Real.exp (evenLift_neg _ _ _ _)

theorem angular_pos (a t : ℝ) (x : E3) : 0<angular a t x := Real.exp_pos _

/-- The analytic inputs only concern three explicit scalar functions on the fixed latitude strip. -/
def JointGerms (V : Set ℝ) : Prop :=
  ∀ δ ∈ V, ∀ z ∈ band,
    ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => primitive v.1 v.2) (δ,z) ∧
    ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => cosCoef v.1 v.2) (δ,z) ∧
    ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => sinCoef v.1 v.2) (δ,z)

private theorem cut_family {f : ℝ → ℝ → ℝ} {a : ℝ} {V : Set ℝ} (hV : ∀ t, parameter a t∈V)
    (hf : ∀ δ ∈ V, ∀ z ∈ band, ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => f v.1 v.2) (δ,z)) :
    ContDiff ℝ ∞ (fun v : ℝ × ℝ => cut (f (parameter a v.1)) v.2) := by
  apply contDiff_iff_contDiffAt.mpr
  intro v
  by_cases hz : v.2 ∈ band
  · unfold cut
    have h₁ : ContDiffAt ℝ ∞ (fun w : ℝ × ℝ => parameter a w.1) v :=
      (parameter_smooth a).contDiffAt.comp v contDiffAt_fst
    have hj : ContDiffAt ℝ ∞ (fun w : ℝ × ℝ => (parameter a w.1,w.2)) v :=
      h₁.prodMk contDiffAt_snd
    have ho := (hf (parameter a v.1) (hV v.1) v.2 hz).comp (f:=fun w : ℝ × ℝ => (parameter a w.1,w.2)) v hj
    exact (cutoff.contDiffAt.comp v contDiffAt_snd).mul ho
  · have ha : 9/40 < |v.2| := by
      simp only [band,mem_Ioo,not_and_or,not_lt] at hz
      rcases hz with hz|hz
      · rw [abs_of_neg (by linarith : v.2<0)]; linarith
      · rw [abs_of_pos (by linarith : 0<v.2)]; linarith
    apply (contDiffAt_const (c:=(0:ℝ))).congr_of_eventuallyEq
    have hd : Continuous (fun v : ℝ × ℝ => |v.2|) := continuous_abs.comp continuous_snd
    filter_upwards [hd.continuousAt.preimage_mem_nhds (Ioi_mem_nhds ha)] with w hw
    have hzero : cutoff w.2 = 0 := cutoff.zero_of_le_dist (by
      change 9/40≤dist w.2 0; simpa [Real.dist_eq] using (show 9/40 < |w.2| from hw).le)
    simp [cut,hzero]

theorem smooth_of_germs {a : ℝ} {V : Set ℝ} (hV : ∀ t, parameter a t∈V)
    (hg : JointGerms V) : ContDiff ℝ ∞ (fun v : ℝ × E3 => angular a v.1 v.2) := by
  have A := cut_family hV (f:=primitive) (fun d hd z hz => (hg d hd z hz).1)
  have B := cut_family hV (f:=cosCoef) (fun d hd z hz => (hg d hd z hz).2.1)
  have C := cut_family hV (f:=sinCoef) (fun d hd z hz => (hg d hd z hz).2.2)
  have pr : ContDiff ℝ ∞ (fun w : ℝ × E3 => (w.1, w.2 2)) := by fun_prop
  have n : ContDiff ℝ ∞ (fun w : ℝ × E3 =>
      north (primitive (parameter a w.1)) (cosCoef (parameter a w.1)) (sinCoef (parameter a w.1)) w.2) := by
    unfold north
    exact (A.comp pr).add (((by fun_prop : ContDiff ℝ ∞ (fun w : ℝ × E3 => w.2 1)).mul
        (B.comp pr)).sub ((by fun_prop : ContDiff ℝ ∞ (fun w : ℝ × E3 => w.2 0)).mul (C.comp pr)))
  exact Real.contDiff_exp.comp (n.add (n.comp (contDiff_fst.prodMk contDiff_snd.neg)))

theorem exists_scale_of_germs {V : Set ℝ} (hV : V ∈ 𝓝 (0:ℝ)) (hg : JointGerms V) :
    ∃ a : ℝ, 0<a ∧ a≤1 ∧ ContDiff ℝ ∞ (fun w : ℝ × E3 => angular a w.1 w.2) := by
  obtain ⟨ε,hε,hsub⟩ := Metric.mem_nhds_iff.mp hV
  let a := min (ε/2) 1
  have ha : 0<a := lt_min (half_pos hε) zero_lt_one
  refine ⟨a,ha,min_le_right _ _,smooth_of_germs (V:=V) ?_ hg⟩
  intro t
  apply hsub
  rw [Metric.mem_ball,Real.dist_eq,sub_zero,abs_of_nonneg (parameter_range ha t).1]
  exact ((parameter_range ha t).2.trans_le (min_le_left _ _)).trans (half_lt_self hε)

theorem exists_smooth_scale :
    ∃ a : ℝ, 0<a ∧ a≤1 ∧ ContDiff ℝ ∞ (fun w : ℝ × E3 => angular a w.1 w.2) := by
  obtain ⟨V,hV,h0,hg⟩ := LloydFlatSpiral.parametric_cartesian
  exact exists_scale_of_germs (V:=V) (hV.mem_nhds h0) hg

theorem angular_matches {a t : ℝ} (ha : 0<a) (h1 : a≤1) (ht : t≠0) :
    ∃ c : ℝ, 0<c ∧ ∀ z ∈ cap, ∀ φ, angular a t (point z φ) =
      c * Real.exp (LloydLocal.surface (parameter a t) z φ) :=
  (support_spec (parameter_pos ha ht) ((parameter_range ha t).2.le.trans h1)).2.2.2

#print axioms angular_zero
#print axioms angular_matches
#print axioms exists_smooth_scale
#print axioms exists_scale_of_germs
end LloydFamily
