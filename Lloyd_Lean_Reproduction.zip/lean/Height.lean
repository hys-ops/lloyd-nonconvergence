import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

open Filter Set
open scoped Topology

namespace LloydHeight
noncomputable section

/-- The initial latitude and the explicitly specified flat decrement. -/
def height (δ : ℝ) : ℕ → ℝ
  | 0 => 1 / 8
  | n + 1 => height δ n - δ * Real.exp (-(1 / (height δ n)^2))

@[simp] theorem height_zero (δ : ℝ) : height δ 0 = 1 / 8 := rfl

theorem height_succ (δ : ℝ) (n : ℕ) :
    height δ (n+1) = height δ n - δ * Real.exp (-(1 / (height δ n)^2)) := rfl

def phase (δ : ℝ) (n : ℕ) : ℝ := -Real.log (height δ n)

theorem exp_neg_inv_sq_le {x : ℝ} (hx : 0 < x) :
    Real.exp (-(1 / x^2)) ≤ x^2 := by
  have hsq : 0 < x^2 := sq_pos_of_pos hx
  have hlin : (1 / x^2) ≤ Real.exp (1 / x^2) := by
    linarith [Real.add_one_le_exp (1 / x^2)]
  rw [Real.exp_neg, inv_eq_one_div]
  apply (div_le_iff₀ (Real.exp_pos _)).2
  simpa [mul_comm, hsq.ne'] using (div_le_iff₀ hsq).1 hlin

theorem height_bounds {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) (n : ℕ) :
    0 < height δ n ∧ height δ n ≤ 1/8 := by
  induction n with
  | zero => norm_num
  | succ n ih =>
    obtain ⟨hp, hu⟩ := ih
    have hd := mul_le_mul_of_nonneg_right hδ' (Real.exp_pos (-(1/(height δ n)^2))).le
    have hsmall : δ * Real.exp (-(1 / (height δ n)^2)) ≤ (height δ n)^2 := by
      simpa only [one_mul] using hd.trans (by simpa using exp_neg_inv_sq_le hp)
    have hdec := mul_pos hδ (Real.exp_pos (-(1/(height δ n)^2)))
    rw [height_succ]
    constructor
    · nlinarith [mul_nonneg hp.le (sub_nonneg.mpr hu)]
    · linarith

theorem height_pos {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) (n : ℕ) :
    0 < height δ n := (height_bounds hδ hδ' n).1

theorem height_strictAnti {δ : ℝ} (hδ : 0 < δ) : StrictAnti (height δ) := by
  apply strictAnti_nat_of_succ_lt
  intro n
  rw [height_succ]
  exact sub_lt_self _ (mul_pos hδ (Real.exp_pos _))

theorem height_tendsto_zero {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) :
    Tendsto (height δ) atTop (𝓝 0) := by
  have hbd : BddBelow (range (height δ)) :=
    ⟨0, by rintro _ ⟨n,rfl⟩; exact (height_pos hδ hδ' n).le⟩
  let ℓ : ℝ := ⨅ n, height δ n
  have ht : Tendsto (height δ) atTop (𝓝 ℓ) := tendsto_atTop_ciInf (height_strictAnti hδ).antitone hbd
  suffices hzero : ℓ = 0 by simpa [hzero] using ht
  by_contra hn
  have htshift : Tendsto (fun n : ℕ => height δ (n+1)) atTop (𝓝 ℓ) :=
    ht.comp (tendsto_add_atTop_nat 1)
  have hi : Tendsto (fun n => 1 / (height δ n)^2) atTop (𝓝 (1 / ℓ^2)) :=
    tendsto_const_nhds.div (ht.pow 2) (pow_ne_zero _ hn)
  have hrec : Tendsto (fun n : ℕ => height δ (n+1)) atTop
      (𝓝 (ℓ - δ * Real.exp (-(1 / ℓ^2)))) := by
    simpa only [height_succ, Function.comp_apply] using ht.sub (tendsto_const_nhds.mul (Real.continuous_exp.continuousAt.tendsto.comp hi.neg))
  have heq := tendsto_nhds_unique htshift hrec
  linarith [mul_pos hδ (Real.exp_pos (-(1/ℓ^2)))]

theorem phase_strictMono {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) :
    StrictMono (phase δ) := by
  intro n m hnm
  exact neg_lt_neg (Real.log_lt_log (height_pos hδ hδ' m) (height_strictAnti hδ hnm))

theorem phase_tendsto_atTop {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) :
    Tendsto (phase δ) atTop atTop := by
  have ht : Tendsto (height δ) atTop (𝓝[>] 0) :=
    tendsto_nhdsWithin_iff.mpr ⟨height_tendsto_zero hδ hδ', Eventually.of_forall (height_pos hδ hδ')⟩
  exact tendsto_neg_atBot_atTop.comp (Real.tendsto_log_nhdsGT_zero.comp ht)

theorem phase_step_nonneg {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) (n : ℕ) :
    0 ≤ phase δ (n+1) - phase δ n :=
  sub_nonneg.mpr ((phase_strictMono hδ hδ').monotone (Nat.le_succ _))

theorem phase_nonneg {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) (n : ℕ) :
    0 ≤ phase δ n := by
  have ⟨hp,hu⟩ := height_bounds hδ hδ' n
  exact neg_nonneg.mpr (Real.log_nonpos hp.le (by linarith))

theorem phase_step_tendsto_zero {δ : ℝ} (hδ : 0 < δ) (hδ' : δ ≤ 1) :
    Tendsto (fun n => phase δ (n+1) - phase δ n) atTop (𝓝 0) := by
  let d := fun n => δ * Real.exp (-(1 / (height δ n)^2)) / height δ n
  have hd0 : ∀ n, 0 ≤ d n := fun n =>
    div_nonneg (mul_nonneg hδ.le (Real.exp_pos _).le) (height_pos hδ hδ' n).le
  have hd1 (n) : d n ≤ height δ n := by
    dsimp [d]
    apply (div_le_iff₀ (height_pos hδ hδ' n)).2
    have h := mul_le_mul_of_nonneg_right hδ' (Real.exp_pos (-(1/(height δ n)^2))).le
    calc
      δ * Real.exp (-(1/(height δ n)^2)) ≤ Real.exp (-(1/(height δ n)^2)) := by simpa only [one_mul] using h
      _ ≤ (height δ n)^2 := exp_neg_inv_sq_le (height_pos hδ hδ' n)
      _ = height δ n * height δ n := sq _
  have hdt : Tendsto d atTop (𝓝 0) :=
    squeeze_zero hd0 hd1 (height_tendsto_zero hδ hδ')
  have hratio : Tendsto (fun n => 1 - d n) atTop (𝓝 (1:ℝ)) := by
    simpa using (tendsto_const_nhds (x := (1:ℝ))).sub hdt
  have hlog := ((Real.continuousAt_log (by norm_num : (1:ℝ) ≠ 0)).tendsto.comp hratio).neg
  have heq (n) : phase δ (n+1) - phase δ n = -Real.log (1-d n) := by
    have hne := (height_pos hδ hδ' n).ne'
    have hr : 1 - d n = height δ (n+1) / height δ n := by
      rw [height_succ]
      dsimp [d]
      field_simp
    rw [hr,Real.log_div (height_pos hδ hδ' (n+1)).ne' hne]
    simp only [phase]
    ring
  simpa only [heq, Function.comp_apply, Real.log_one, neg_zero] using hlog

end
end LloydHeight

#print axioms LloydHeight.height_tendsto_zero
#print axioms LloydHeight.phase_tendsto_atTop
#print axioms LloydHeight.phase_step_tendsto_zero
