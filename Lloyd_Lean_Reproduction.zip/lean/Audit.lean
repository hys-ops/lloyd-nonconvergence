import NDVerified
import NDLine
import NDPlanarBalanced
import NDEmbedOrbit
import NDOrbit

#check @LloydNDVerified.projective_lloyd
#check LloydNDVerified.projective_lloyd 1 2 (1/1000) (by norm_num)
#print LloydNDVerified.SolverAndLimits
#print LloydNDMain.JointExample
#print LloydNDMain.UniformExample
#print LloydNDMain.ProjectiveOrbit
#print LloydNDMain.BalancedOrbit
#print LloydNDMain.FullSpan
#print LloydNDGeom.HasPositiveCurvedBoundary
#print LloydNDGeom.NearRound
#print LloydNDProjective.RealProjective
#check @LloydNDProjective.cluster_homeomorphic
#check @LloydNDPlanar.convergence
#check @LloydNDPlanar.balanced_convergence
#check @LloydNDLine.one_step
#print axioms LloydNDVerified.projective_lloyd
#print axioms LloydNDMain.projective_equator_counterexample
#print axioms LloydNDMain.projective_equator_all_solvers
#print axioms LloydNDProjective.all_sources_projective
#print axioms LloydNDProjective.cluster_homeomorphic
#print axioms LloydNDDense.exists_curve
#print axioms LloydNDDensePath.exists_path
#print axioms LloydNDFlat.contDiff_compactify
#print axioms LloydNDJet.profile_exact
#print axioms LloydNDModels.realize
#print axioms LloydNDModels.Profile.same_update
#print axioms LloydNDGeom.local_profile_realization
#print axioms LloydNDLimits.signedMoment_of_kick
#print axioms LloydNDLimits.exact_orbit
#print axioms LloydNDPlanar.convergence
#print axioms LloydNDPlanar.balanced_convergence
#print axioms LloydNDLine.one_step
#print axioms LloydNDLine.balanced_one_step
#print axioms LloydNDEmbed.uniform_embedded_circle
#print axioms LloydND.product_counterexample
