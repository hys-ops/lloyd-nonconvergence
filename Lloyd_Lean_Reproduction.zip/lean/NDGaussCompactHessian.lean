import NDGaussCompactBase
import NDGaussCurvature

/-! Exact interior Hessian of the flat compact radial model. -/
open Set Filter
open scoped RealInnerProductSpace Topology ContDiff
noncomputable section
namespace LloydNDCompactDensity
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def potential (x : Vn) := ‖x‖^2 + (9-‖x‖^2)⁻¹
private def g (t : ℝ) := t + (9-t)⁻¹
private def dg (t : ℝ) := 1 + ((9-t)⁻¹)^2
private def ddg (t : ℝ) := 2*((9-t)⁻¹)^3

private lemma pos_gap {x : Vn} (hx : ‖x‖<3) : 0<9-‖x‖^2 := by
  nlinarith [mul_pos (sub_pos.mpr hx) (by linarith [norm_nonneg x] : 0<3+‖x‖)]
private lemma inv_d (t : ℝ) (ht : (9-t) ≠ 0) :
    HasDerivAt (fun s : ℝ => (9-s)⁻¹) (((9-t)⁻¹)^2) t := by
  convert! (((hasDerivAt_id t).const_sub 9).inv ht) using 1
  simp [id_eq,inv_pow,one_div]
private lemma g_d (t : ℝ) (ht : (9-t) ≠ 0) : HasDerivAt g (dg t) t :=
  (hasDerivAt_id t).add (inv_d t ht)
private lemma dg_d (t : ℝ) (ht : (9-t) ≠ 0) : HasDerivAt dg (ddg t) t := by
  convert! (((inv_d t ht).pow 2).const_add 1) using 1
  simp only [ddg,Nat.cast_ofNat,Nat.reduceSub,pow_one]
  ring

theorem potential_hasFDerivAt {x : Vn} (hx : ‖x‖ < 3) :
    HasFDerivAt potential (dg (‖x‖^2) • (2 • innerSL ℝ x)) x :=
  by
    change HasFDerivAt (g ∘ fun z : Vn => ‖z‖^2) _ x
    exact (g_d _ (pos_gap hx).ne').comp_hasFDerivAt x (hasStrictFDerivAt_norm_sq x).hasFDerivAt

private lemma innerDouble_hasFDerivAt (x : Vn) :
    HasFDerivAt (fun z:Vn => (2 : ℕ) • innerSL ℝ z) ((2:ℕ) • (innerSL ℝ (E:=Vn))) x := by
  convert! ((2:ℕ) • (innerSL ℝ (E:=Vn))).hasFDerivAt (x:=x) using 1

theorem potential_hessian {x : Vn} (hx : ‖x‖ < 3) (v : Vn) :
    fderiv ℝ (fderiv ℝ potential) x v v =
      (2 + 2*((9-‖x‖^2)⁻¹)^2) * ‖v‖^2 + 8*((9-‖x‖^2)⁻¹)^3*⟪x,v⟫^2 := by
  have he : fderiv ℝ potential =ᶠ[𝓝 x] fun z:Vn => dg (‖z‖^2) • ((2:ℕ) • innerSL ℝ z) := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Iio_mem_nhds hx)] with z hz
    exact (potential_hasFDerivAt hz).fderiv
  have hd := (dg_d _ (pos_gap hx).ne').comp_hasFDerivAt x (hasStrictFDerivAt_norm_sq x).hasFDerivAt
  rw [he.fderiv_eq]
  change (fderiv ℝ ((dg ∘ fun z:Vn => ‖z‖^2) • (fun z:Vn => (2:ℕ) • innerSL ℝ z)) x) v v = _
  rw [(hd.smul (innerDouble_hasFDerivAt x)).fderiv]
  have hself : ((innerSL ℝ v) v) = ‖v‖^2 := by
    rw [innerSL_apply_apply,real_inner_self_eq_norm_sq]
  simp [dg,ddg,ContinuousLinearMap.smulRight_apply,hself]
  ring

/-- Exact quadratic lower bound on the full second derivative, before perturbation. -/
theorem base_hessian_ge (C : ℝ) (hC : 0 < C) {x : Vn} (hx : ‖x‖ < 3) (v : Vn) :
    2*‖v‖^2 ≤ fderiv ℝ (fderiv ℝ (fun z => -Real.log (C*base z))) x v v := by
  have he : (fun z:Vn => -Real.log (C*base z)) =ᶠ[𝓝 x] fun z => potential z - Real.log C := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Iio_mem_nhds hx)] with z hz
    rw [Real.log_mul hC.ne' ((base_pos_iff z).mpr hz).ne',base_positive_form hz,Real.log_exp,potential]
    ring
  have hf : fderiv ℝ (fun z => potential z - Real.log C) =ᶠ[𝓝 x] fderiv ℝ potential := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Iio_mem_nhds hx)] with z hz
    exact ((potential_hasFDerivAt hz).sub_const _).fderiv.trans (potential_hasFDerivAt hz).fderiv.symm
  rw [he.fderiv.fderiv_eq,hf.fderiv_eq,potential_hessian hx v]
  have hg := pos_gap hx
  nlinarith [mul_nonneg (sq_nonneg ((9-‖x‖^2)⁻¹)) (sq_nonneg ‖v‖),
    mul_nonneg (pow_nonneg (inv_pos.mpr hg).le 3) (sq_nonneg ⟪x,v⟫)]

#print axioms potential_hessian
#print axioms base_hessian_ge
end LloydNDCompactDensity
