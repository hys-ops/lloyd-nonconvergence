import Mathlib.Analysis.Calculus.DerivativeTest
import Mathlib.Analysis.Calculus.LocalExtr.Rolle
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Tactic

noncomputable section
open Filter Set Function
open scoped Topology ContDiff
namespace LloydNDPlanar

/-- Positivity of the second derivative at a smooth contact from above. -/
theorem second_nonneg {g : ℝ → ℝ} {x : ℝ} (hmin : IsLocalMin g x)
    (hc : ContinuousAt g x) : 0 ≤ deriv (deriv g) x := by
  by_contra! hn
  have hm := isLocalMax_of_deriv_deriv_neg hn hmin.deriv_eq_zero hc
  have he : g =ᶠ[𝓝 x] fun _ => g x :=
    (hm.and hmin).mono (fun _ h => le_antisymm h.1 h.2)
  have hd := (he.deriv).deriv_eq
  simp at hd
  linarith

def angleStep (h : ℝ → ℝ) (x : ℝ) := x + Real.arctan (deriv h x / h x)

theorem angle_deriv {h : ℝ → ℝ} (hs : ContDiff ℝ 2 h) (hp : ∀ x, 0 < h x) (x : ℝ) :
    HasDerivAt (angleStep h)
      (h x * (h x + deriv (deriv h) x) / (h x ^ 2 + deriv h x ^ 2)) x := by
  have hd : Differentiable ℝ h := hs.differentiable (by norm_num)
  have hs' : ContDiff ℝ 1 (deriv h) := (show ContDiff ℝ (1+1) h by convert hs using 1 <;> norm_num).deriv'
  have dd := hs'.differentiable (by norm_num) x
  have hr := dd.hasDerivAt.div (hd x).hasDerivAt (hp x).ne'
  have hc := (hasDerivAt_id x).add ((Real.hasDerivAt_arctan _).comp x hr)
  apply hc.congr_deriv
  have hp2 := hp x
  have hsum : 0 < h x ^ 2 + deriv h x ^ 2 := by positivity
  have hsum' : 0 < 1 + (deriv h x / h x)^2 := by positivity
  simp only [Pi.div_apply]
  field_simp
  ring

theorem angle_convergence {h : ℝ → ℝ} (hs : ContDiff ℝ 2 h) (hp : ∀ x, 0 < h x)
    (hcurv : ∀ x, 0 ≤ h x + deriv (deriv h) x)
    {period : ℝ} (hperiod : 0<period) (hper : Periodic h period) (x : ℝ) :
    ∃ y : ℝ, Tendsto (fun n : ℕ => (angleStep h)^[n] x) atTop (𝓝 y) := by
  let T := angleStep h
  have hT : Monotone T := by
    apply monotone_of_deriv_nonneg (fun t => (angle_deriv hs hp t).differentiableAt)
    intro t
    rw [(angle_deriv hs hp t).deriv]
    exact div_nonneg (mul_nonneg (hp t).le (hcurv t)) (by positivity)
  obtain ⟨b,hb,hb'⟩ := exists_deriv_eq_zero (show x < x+period by linarith)
    hs.continuous.continuousOn (hper x).symm
  obtain ⟨a,ha,ha'⟩ := exists_deriv_eq_zero (show x-period<x by linarith)
    hs.continuous.continuousOn (by simpa using (hper (x-period)).symm)
  have hTb : T b=b := by simp [T,angleStep,hb']
  have hTa : T a=a := by simp [T,angleStep,ha']
  have between (n : ℕ) : a ≤ T^[n] x ∧ T^[n] x ≤ b := by
    induction n with
    | zero => exact ⟨ha.2.le,hb.1.le⟩
    | succ n ih =>
      rw [iterate_succ_apply']
      exact ⟨hTa ▸ hT ih.1,hTb ▸ hT ih.2⟩
  rcases le_total x (T x) with hup|hdn
  · refine ⟨⨆ n:ℕ, T^[n] x,tendsto_atTop_ciSup ?_ ⟨b,?_⟩⟩
    · apply monotone_nat_of_le_succ
      intro n; exact (hT.iterate n) hup
    · rintro _ ⟨n,rfl⟩; exact (between n).2
  · refine ⟨⨅ n:ℕ, T^[n] x,tendsto_atTop_ciInf ?_ ⟨a,?_⟩⟩
    · apply antitone_nat_of_succ_le
      intro n; exact (hT.iterate n) hdn
    · rintro _ ⟨n,rfl⟩; exact (between n).1
end LloydNDPlanar
