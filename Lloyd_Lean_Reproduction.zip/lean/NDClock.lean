import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv
import Mathlib.Analysis.SpecialFunctions.SmoothTransition
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Tactic
noncomputable section
open Filter Topology Set
open scoped SchwartzMap ContDiff
namespace LloydNDClock

private def envelope (s : ℝ) := Real.smoothTransition (s+2) * Real.exp (-s)

private theorem envSmooth : ContDiff ℝ ∞ envelope :=
  (Real.smoothTransition.contDiff.comp (contDiff_id.add contDiff_const)).mul
    (Real.contDiff_exp.comp contDiff_id.neg)

private def envSchwartz : 𝓢(ℝ,ℝ) where
  toFun := envelope
  smooth' := envSmooth
  decay' := by
    intro k n
    let F := fun x : ℝ => ‖x‖^k * ‖iteratedDeriv n envelope x‖
    have hF : Continuous F := (continuous_norm.pow k).mul (envSmooth.continuous_iteratedDeriv n (by simp)).norm
    obtain ⟨C,hC⟩ := (isCompact_Icc (a:=(-3:ℝ)) (b:=1)).exists_bound_of_continuousOn hF.continuousOn
    refine ⟨max C (k.factorial:ℝ), fun x => ?_⟩
    rw [norm_iteratedFDeriv_eq_norm_iteratedDeriv]
    by_cases hneg : x < -3
    · have eq : envelope =ᶠ[𝓝 x] (fun _ => (0:ℝ)) := by
        filter_upwards [gt_mem_nhds (show x < -2 by linarith)] with y hy
        simp [envelope,Real.smoothTransition.zero_of_nonpos (show y+2≤0 by linarith)]
      rw [eq.iteratedDeriv_eq n]
      simp [le_max_iff]
    by_cases hpos : 1 < x
    · have eq : envelope =ᶠ[𝓝 x] (fun y => Real.exp ((-1)*y)) := by
        filter_upwards [lt_mem_nhds (show 0<x by linarith)] with y hy
        simp [envelope,Real.smoothTransition.one_of_one_le (show 1≤y+2 by linarith)]
      rw [eq.iteratedDeriv_eq n,iteratedDeriv_exp_const_mul, norm_mul]
      simp only [norm_pow,norm_neg,norm_one,one_pow,one_mul,neg_one_mul,Real.norm_eq_abs,
        abs_of_pos (show 0<x by linarith),Real.exp_neg]
      apply le_trans _ (le_max_right _ _)
      rw [abs_of_pos (inv_pos.mpr (Real.exp_pos _)),←div_eq_mul_inv]
      apply (div_le_iff₀ (Real.exp_pos _)).2
      simpa [mul_comm] using (div_le_iff₀ (by positivity : 0<(k.factorial:ℝ))).mp
        (Real.pow_div_factorial_le_exp x (by linarith : 0≤x) k)
    have hb := hC x ⟨by linarith,by linarith⟩
    exact (le_abs_self (F x)).trans (hb.trans (le_max_left _ _))

private def weight (p : ℝ × ℝ) := p.1^2+p.2^2
private theorem fst_temp : (Prod.fst : ℝ×ℝ → ℝ).HasTemperateGrowth := (ContinuousLinearMap.fst ℝ ℝ ℝ).hasTemperateGrowth
private theorem snd_temp : (Prod.snd : ℝ×ℝ → ℝ).HasTemperateGrowth := (ContinuousLinearMap.snd ℝ ℝ ℝ).hasTemperateGrowth
private theorem weight_temp : weight.HasTemperateGrowth := (fst_temp.pow 2).add (snd_temp.pow 2)
private theorem weight_proper : ∃ (k : ℕ) (C : ℝ), ∀ x : ℝ × ℝ, ‖x‖ ≤ C * (1+‖weight x‖)^k := by
  refine ⟨1,1,fun ⟨x,y⟩ => ?_⟩
  simp only [weight,Prod.norm_def,Real.norm_eq_abs,abs_of_nonneg (add_nonneg (sq_nonneg x) (sq_nonneg y)),pow_one,one_mul,max_le_iff,abs_le]
  constructor <;> constructor <;> nlinarith [sq_nonneg x,sq_nonneg y,sq_nonneg (x-1),sq_nonneg (x+1),sq_nonneg (y-1),sq_nonneg (y+1)]

def increment : 𝓢(ℝ×ℝ,ℝ) := SchwartzMap.smulLeftCLM ℝ Prod.fst
    (SchwartzMap.compCLM ℝ weight_temp weight_proper envSchwartz)

@[simp] theorem increment_apply (p : ℝ×ℝ) :
   increment p = p.1 * Real.exp (-(p.1^2+p.2^2)) := by
  unfold increment
  rw [SchwartzMap.smulLeftCLM_apply_apply fst_temp]
  change p.1 * envelope (weight p) = _
  unfold envelope
  rw [Real.smoothTransition.one_of_one_le (show 1≤weight p+2 by unfold weight; nlinarith [sq_nonneg p.1,sq_nonneg p.2]),one_mul]; rfl

def time (δ : ℝ) : ℕ → ℝ
  | 0 => 8
  | n+1 => time δ n + increment (δ,time δ n)
@[simp] theorem time_zero (δ : ℝ) : time δ 0 = 8 := rfl
theorem time_succ (δ : ℝ) (n : ℕ) : time δ (n+1) = time δ n + increment (δ,time δ n) := rfl
theorem time_mono {δ : ℝ} (h : 0<δ) : StrictMono (time δ) := by
  apply strictMono_nat_of_lt_succ
  intro n
  rw [time_succ,increment_apply]
  exact lt_add_of_pos_right _ (mul_pos h (Real.exp_pos _))
theorem time_ge {δ : ℝ} (hd : 0<δ) (n : ℕ) : 8 ≤ time δ n := (time_mono hd).monotone (Nat.zero_le n)
theorem time_atTop {δ : ℝ} (hd : 0<δ) : Tendsto (time δ) atTop atTop := by
  by_contra H
  have hb : BddAbove (range (time δ)) := by
    by_contra h
    apply H
    apply (time_mono hd).monotone.tendsto_atTop_atTop
    intro b
    obtain ⟨_,⟨n,rfl⟩,hn⟩ := not_bddAbove_iff.mp h b
    exact ⟨n,hn.le⟩
  have ht := tendsto_atTop_ciSup (time_mono hd).monotone hb
  let L := ⨆ n, time δ n
  have hs : Tendsto (fun n => time δ (n+1)) atTop (𝓝 L) := ht.comp (tendsto_add_atTop_nat 1)
  have he := tendsto_nhds_unique hs (show Tendsto (fun n => time δ (n+1)) atTop (𝓝 (L+increment (δ,L))) by
    simp only [time_succ]
    exact ht.add (increment.continuous.continuousAt.tendsto.comp (tendsto_const_nhds.prodMk_nhds ht)))
  simp only [increment_apply] at he
  linarith [mul_pos hd (Real.exp_pos (-(δ^2+L^2)))]
theorem time_mesh {δ : ℝ} (hd : 0<δ) : Tendsto (fun n => time δ (n+1)-time δ n) atTop (𝓝 0) := by
  have hT := time_atTop hd
  have hQ : Tendsto (fun n => δ^2+(time δ n)^2) atTop atTop :=
    tendsto_atTop_add_const_left _ _ ((tendsto_pow_atTop (by decide : (2:ℕ) ≠ 0)).comp hT)
  simpa [time_succ,increment_apply] using (Real.tendsto_exp_atBot.comp (tendsto_neg_atTop_atBot.comp hQ)).const_mul δ
end LloydNDClock
