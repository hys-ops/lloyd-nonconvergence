import NeutralShell
import NDPolar
import NDFrequencyAnnulus

/-! A dimension-corrected signed shell. The polar Jacobian cancels the radial
rescaling on the support, preserving exactly the three calibrated moments. -/
noncomputable section
open MeasureTheory Set Filter
open scoped Topology ContDiff RealInnerProductSpace ENNReal
namespace LloydNDNeutralShell
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim
local notation "punctured" => ({0}ᶜ : Set Vn)

def shell (dim : ℕ) (r : ℝ) : ℝ := LloydNeutralShell.shell r * r^2 / r^dim

theorem shell_zero_low (dim : ℕ) {r : ℝ} (hr : r≤1) : shell dim r=0 := by
  simp [shell,LloydNeutralShell.shell_zero_low hr]

theorem shell_zero_high (dim : ℕ) {r : ℝ} (hr : 2≤r) : shell dim r=0 := by
  simp [shell,LloydNeutralShell.shell_zero_high hr]

theorem shell_smooth (dim : ℕ) : ContDiff ℝ ∞ (shell dim) := by
  apply contDiff_iff_contDiffAt.2
  intro x
  by_cases hx : x = 0
  · subst x
    apply (contDiffAt_const (c := (0:ℝ))).congr_of_eventuallyEq
    filter_upwards [Iio_mem_nhds (show (0:ℝ)<1 by norm_num)] with r hr
    exact shell_zero_low dim (le_of_lt hr)
  · exact (LloydNeutralShell.shell_smooth.contDiffAt.mul (contDiffAt_id.pow 2)).div
      (contDiffAt_id.pow dim) (pow_ne_zero _ hx)

theorem unweight (dim : ℕ) {r : ℝ} (hr : 0<r) :
    r^dim * shell dim r = r^2 * LloydNeutralShell.shell r := by
  unfold shell
  field_simp [hr.ne'] <;> ring
def spatial (a : Vn → ℝ) : Vn → ℝ := LloydNDFrequency.profile a (shell dim)

abbrev AngularSmooth (a : Vn → ℝ) := ∀ w, ‖w‖=1 → ContDiffAt ℝ ∞ a w

theorem spatial_smooth {a : Vn → ℝ} (ha : AngularSmooth a) : ContDiff ℝ ∞ (spatial a) :=
  LloydNDFrequency.profile_smooth zero_lt_one ha (shell_smooth dim) (fun _ hr => shell_zero_low dim hr.le)

theorem spatial_compact (a : Vn → ℝ) : HasCompactSupport (spatial a) :=
  LloydNDFrequency.profile_compact (fun _ hr => shell_zero_high dim hr.le)

theorem spatial_even {a : Vn → ℝ} (he : ∀ w, ‖w‖=1 → a (-w)=a w) :
    ∀ x, spatial a (-x)=spatial a x := LloydNDFrequency.profile_even he

private theorem spatial_ray (a : Vn → ℝ) (w : Sn) (t : Ray) :
    spatial a (t.val • w.val) = shell dim t.val * a w.val := by
  have hw : ‖w.val‖=1 := by simp
  have ht : 0 < t.val := t.property
  simp [spatial,LloydNDFrequency.profile,norm_smul,Real.norm_eq_abs,hw,abs_of_pos ht,
    smul_smul,inv_mul_cancel₀ ht.ne']

theorem spatial_integrable {a : Vn → ℝ} (ha : AngularSmooth a) {p : Vn → ℝ} (hc : Continuous p) :
    Integrable (fun x => p x * spatial a x) :=
  (hc.mul (spatial_smooth ha).continuous).integrable_of_hasCompactSupport (spatial_compact a).mul_left

private theorem radial_integral (n : ℕ) :
    (∫ t : Ray, t.val^n*shell dim t.val ∂Measure.volumeIoiPow dim) = LloydNeutralShell.radMoment (n+2) LloydNeutralShell.shell := by
  unfold Measure.volumeIoiPow LloydNeutralShell.radMoment
  rw [integral_withDensity_eq_integral_toReal_smul (by fun_prop) (by simp)]
  rw [← integral_subtype_comap (μ := (volume : Measure ℝ)) measurableSet_Ioi]
  apply integral_congr_ae
  filter_upwards [] with t
  simp only [ENNReal.toReal_ofReal (pow_nonneg t.2.le dim),smul_eq_mul,pow_add]
  have h := unweight dim t.2
  linear_combination t.val^n * h

/-- Applies to any continuous positively homogeneous scalar probe. -/
theorem homogeneous_moment {a : Vn → ℝ} (ha : AngularSmooth a) (p : Vn → ℝ)
    (hc : Continuous p) (n : ℕ) (hhom : ∀ r : ℝ, 0 < r → ∀ x, p (r • x)=r^n*p x) :
    (∫ x:Vn, p x * spatial a x) =
      LloydNeutralShell.radMoment (n+2) LloydNeutralShell.shell * ∫ w:Sn, p w.val*a w.val ∂(volume:Measure Vn).toSphere := by
  let e := homeomorphUnitSphereProd Vn
  let h := fun x:Vn => p x * spatial a x
  let g := fun v:Sn × Ray => h (e.symm v).val
  have rank : Module.finrank ℝ Vn - 1 = dim := by simp [E]
  have hsub : Integrable (fun y : punctured => h y.val) (volume.comap Subtype.val) :=
    (integrableOn_iff_comap_subtypeVal (measurableSet_singleton _).compl).1
      (spatial_integrable ha hc).integrableOn
  have hg : Integrable g ((volume : Measure Vn).toSphere.prod (Measure.volumeIoiPow dim)) := by
    suffices hi : Integrable g ((volume : Measure Vn).toSphere.prod (Measure.volumeIoiPow (Module.finrank ℝ Vn - 1))) by simpa only [rank] using hi
    apply ((volume : Measure Vn).measurePreserving_homeomorphUnitSphereProd.integrable_comp_emb
      e.measurableEmbedding).mp
    change Integrable (fun y : punctured => h (e.symm (e y)).val) _
    simpa only [Homeomorph.symm_apply_apply] using hsub
  calc
    _ = ∫ y : punctured, h y.val ∂(volume.comap Subtype.val) := by
      rw [integral_subtype_comap (measurableSet_singleton _).compl, restrict_compl_singleton]
    _ = ∫ y : punctured, g (e y) ∂(volume.comap Subtype.val) := by simp [g]
    _ = ∫ v, g v ∂((volume:Measure Vn).toSphere.prod (Measure.volumeIoiPow dim)) := by
      simpa [rank] using (volume:Measure Vn).measurePreserving_homeomorphUnitSphereProd.integral_comp
        e.measurableEmbedding g
    _ = _ := by
      rw [integral_prod g hg,←integral_const_mul]
      apply integral_congr_ae
      filter_upwards [] with w
      rw [←radial_integral,←integral_mul_const]
      apply integral_congr_ae
      filter_upwards [] with t
      change p (t.val • w.val)*spatial a (t.val • w.val) = _
      rw [hhom t.val t.2,spatial_ray]
      ring

theorem mass_zero {a : Vn → ℝ} (ha : AngularSmooth a) :
    (∫ x, spatial a x)=0 := by
  simpa [LloydNeutralShell.shell_moments.1] using
    homogeneous_moment ha (fun _=>1) continuous_const 0 (fun r hr x=>by simp)

theorem second_moment_zero {a : Vn → ℝ} (ha : AngularSmooth a) (u v:Vn) :
    (∫ x, (⟪u,x⟫*⟪v,x⟫)*spatial a x)=0 := by
  have h := homogeneous_moment ha (fun x => ⟪u,x⟫*⟪v,x⟫) (by fun_prop) 2
    (fun r hr x=>by simp only [real_inner_smul_right];ring)
  simpa [LloydNeutralShell.shell_moments.2.2] using h

theorem projection_moment {a : Vn → ℝ} (ha : AngularSmooth a) (u:Vn) :
    (∫ x, |⟪u,x⟫| * spatial a x)=cosineTransform (fun w=>a w.val) u := by
  have h := homogeneous_moment ha (fun x=> |⟪u,x⟫|) (by fun_prop) 1
    (fun r hr x=>by simp [real_inner_smul_right,abs_mul,abs_of_pos hr])
  simpa [LloydNeutralShell.shell_moments.2.1,cosineTransform] using h

#print axioms homogeneous_moment
#print axioms mass_zero
#print axioms second_moment_zero
#print axioms projection_moment
end LloydNDNeutralShell
