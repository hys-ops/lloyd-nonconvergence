import Crossing
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Topology.MetricSpace.Lipschitz

open Filter Topology
open scoped RealInnerProductSpace NNReal
noncomputable section
namespace LloydNDSpiral
variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

def potential (A : ℝ → ℝ) (q a : ℝ → V) (z : ℝ) (ξ : V) :=
  A z + ⟪q z,ξ-a z⟫

/-- The primitive compensates the motion of the trajectory's angular base point. -/
theorem prescribed_height {A : ℝ → ℝ} {q a : ℝ → V} {z p : ℝ} {dq da : V}
    (hA : HasDerivAt A (p + ⟪q z,da⟫) z)
    (hq : HasDerivAt q dq z) (ha : HasDerivAt a da z) :
    HasDerivAt (fun s => potential A q a s (a z)) p z := by
  have h := HasDerivAt.add hA (hq.inner ℝ (ha.const_sub (a z)))
  change HasDerivAt (fun s => A s + ⟪q s,a z-a s⟫) p z
  simpa [inner_neg_right,Pi.add_def] using! h

theorem prescribed_angle {A : ℝ → ℝ} {q a : ℝ → V} (z : ℝ) :
    HasFDerivAt (potential A q a z) (innerSL ℝ (q z)) (a z) := by
  have h := (innerSL ℝ (q z)).hasFDerivAt.comp (a z) ((hasFDerivAt_id (a z)).sub_const (a z))
  change HasFDerivAt (fun x => A z + ⟪q z,x-a z⟫) _ _
  simpa using h.const_add (A z)

def kick (u v : V) := ⟪u,v⟫⁻¹ • v - u

theorem kick_exact {u v : V} (hu : ‖u‖=1) (hv : ‖v‖=1) (hd : 0<⟪u,v⟫) :
    ⟪u,kick u v⟫ = 0 ∧ ‖u + kick u v‖⁻¹ • (u + kick u v) = v := by
  constructor
  · simp [kick,inner_sub_right,real_inner_smul_right,hu,hd.ne']
  · rw [show u + kick u v = ⟪u,v⟫⁻¹ • v by unfold kick; abel]
    simp [norm_smul,hv,Real.norm_eq_abs,abs_of_pos hd,smul_smul,hd.ne']

/-- Vanishing time mesh preserves every tail limit of a Lipschitz trajectory. -/
theorem sampled_tail {X : Type*} [PseudoMetricSpace X] {γ : ℝ → X} {K : ℝ≥0}
    (hγ : LipschitzWith K γ) {a : ℕ → ℝ} (ha : Tendsto a atTop atTop)
    (hmesh : Tendsto (fun j => a (j+1)-a j) atTop (𝓝 0))
    {x : X} {b : ℕ → ℝ} (hb : Tendsto b atTop atTop) (hit : Tendsto (γ ∘ b) atTop (𝓝 x)) :
    MapClusterPt x atTop (γ ∘ a) := by
  obtain ⟨k,hk,_,he⟩ := LloydCrossing.first_crossing a b ha hmesh hb
  have habs : Tendsto (fun j => |a (k j)-b j|) atTop (𝓝 0) := by simpa using he.abs
  have hd : Tendsto (fun j => dist (γ (a (k j))) (γ (b j))) atTop (𝓝 0) := by
    apply squeeze_zero (fun _ => dist_nonneg) (fun j => ?_) (by simpa using habs.const_mul (K:ℝ))
    simpa [Real.dist_eq] using hγ.dist_le_mul (a (k j)) (b j)
  have hout : Tendsto (fun j => γ (a (k j))) atTop (𝓝 x) :=
    (tendsto_iff_dist_tendsto_zero.mpr (squeeze_zero (fun _ => dist_nonneg)
      (fun j => dist_triangle _ (γ (b j)) _) (by simpa using hd.add (tendsto_iff_dist_tendsto_zero.mp hit))))
  exact hout.mapClusterPt.of_comp hk

#print axioms kick_exact
#print axioms prescribed_height
#print axioms prescribed_angle
#print axioms sampled_tail
end LloydNDSpiral
