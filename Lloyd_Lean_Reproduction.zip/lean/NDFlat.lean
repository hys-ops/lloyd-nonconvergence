import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv
import Mathlib.Analysis.Calculus.ContDiff.FiniteDimension
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Tactic

/-! Smooth extension through a reciprocal end. The parameter and height can vary
simultaneously. Every successive directional derivative is again the same
extension of an explicitly differentiated Schwartz function. -/
noncomputable section
open Filter Set
open scoped Topology ContDiff SchwartzMap LineDeriv
namespace LloydNDFlat
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
abbrev Plane := ℝ × ℝ

def compactify (f : Plane → E) (p : Plane) : E :=
  if 0 < p.2 then f (p.1,p.2⁻¹) else 0

theorem estimate (f : 𝓢(Plane,E)) (k : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ p : Plane, ‖compactify f p‖ ≤ C * |p.2| ^ k := by
  obtain ⟨C,hC,h⟩ := f.decay k 0
  refine ⟨C,hC,fun p => ?_⟩
  by_cases hp : 0 < p.2
  · rw [compactify,if_pos hp]
    have h' := h (p.1,p.2⁻¹)
    rw [norm_iteratedFDeriv_zero] at h'
    have hsmall : ‖(p.2 : ℝ)⁻¹‖ ≤ ‖(p.1,p.2⁻¹)‖ := norm_snd_le (p.1,p.2⁻¹)
    have hb := (mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (norm_nonneg _) hsmall k)
      (norm_nonneg _)).trans h'
    rw [norm_inv,Real.norm_eq_abs,inv_pow,inv_mul_eq_div] at hb
    exact (div_le_iff₀ (pow_pos (abs_pos.mpr hp.ne') k)).mp hb
  · simp only [compactify,if_neg hp,norm_zero]
    positivity

theorem at_seam (f : 𝓢(Plane,E)) (δ : ℝ) :
    HasFDerivAt (𝕜:=ℝ) (compactify f) 0 (δ,0) := by
  obtain ⟨C,hC,h⟩ := estimate f 2
  rw [hasFDerivAt_iff_isLittleO_nhds_zero, Asymptotics.isLittleO_iff]
  intro ε hε
  filter_upwards [Metric.ball_mem_nhds (0:Plane) (div_pos hε hC)] with v hv
  have hd : ‖v‖ < ε/C := by simpa [Metric.mem_ball] using hv
  have hε' : C * ‖v‖ ≤ ε := by linarith [(lt_div_iff₀ hC).mp hd]
  have ha : |v.2| ≤ ‖v‖ := by simpa [Real.norm_eq_abs] using (norm_snd_le v)
  simp only [ContinuousLinearMap.zero_apply, sub_zero]
  rw [show compactify (f : Plane → E) (δ,0) = 0 by simp [compactify],sub_zero]
  calc
    ‖compactify (f : Plane → E) ((δ,0)+v)‖ ≤ C * |v.2|^2 := by
      have hv' := h ((δ,0)+v)
      change _ ≤ C * |(0:ℝ) + v.2| ^ 2 at hv'
      simpa only [zero_add] using hv'
    _ ≤ (C * ‖v‖) * ‖v‖ := by rw [mul_assoc, ←sq]; gcongr
    _ ≤ ε * ‖v‖ := mul_le_mul_of_nonneg_right hε' (norm_nonneg _)

private def inverseChart (p : Plane) : Plane := (p.1,p.2⁻¹)

private theorem derivative_pos (f : 𝓢(Plane,E)) {p : Plane} (hp : 0 < p.2) :
    HasFDerivAt (compactify f)
      ((fderiv ℝ f (inverseChart p)).comp
        ((ContinuousLinearMap.fst ℝ ℝ ℝ).prod
          ((-(p.2⁻¹ ^ 2)) • ContinuousLinearMap.snd ℝ ℝ ℝ))) p := by
  have hinv := ((hasDerivAt_inv hp.ne').hasFDerivAt.comp p (hasFDerivAt_snd (𝕜:=ℝ) (p:=p)))
  have hc : HasFDerivAt inverseChart
      ((ContinuousLinearMap.fst ℝ ℝ ℝ).prod ((-(p.2⁻¹ ^ 2)) • ContinuousLinearMap.snd ℝ ℝ ℝ)) p := by
    apply (hasFDerivAt_fst.prodMk ?_)
    have hEq : ((-(p.2⁻¹ ^ 2)) • ContinuousLinearMap.snd ℝ ℝ ℝ) =
        (ContinuousLinearMap.toSpanSingleton ℝ (-(p.2 ^ 2)⁻¹)).comp (ContinuousLinearMap.snd ℝ ℝ ℝ) := by
      apply ContinuousLinearMap.ext
      intro v
      simp [mul_comm]
    rw [hEq]
    exact hinv
  apply ((f.differentiableAt.hasFDerivAt).comp p hc).congr_of_eventuallyEq
  filter_upwards [continuous_snd.continuousAt.eventually (lt_mem_nhds hp)] with q hq
  simp [compactify,hq,inverseChart,Function.comp_def]

private theorem derivative_neg (f : 𝓢(Plane,E)) {p : Plane} (hp : p.2 < 0) :
    HasFDerivAt (𝕜:=ℝ) (compactify f) 0 p := by
  apply hasFDerivAt_zero_of_eventually_const 0
  filter_upwards [continuous_snd.continuousAt.eventually (gt_mem_nhds hp)] with q hq
  simp [compactify,not_lt.mpr hq.le]

theorem differentiable_compactify (f : 𝓢(Plane,E)) : Differentiable ℝ (compactify f) := by
  rintro ⟨δ,z⟩
  rcases lt_trichotomy z 0 with hz|rfl|hz
  · exact (derivative_neg f hz).differentiableAt
  · exact (at_seam f δ).differentiableAt
  · exact (derivative_pos f hz).differentiableAt

private theorem weight_grows (v : Plane) :
    (fun p : Plane => -(p.2 ^ 2) * v.2).HasTemperateGrowth := by
  have hs := (ContinuousLinearMap.snd ℝ ℝ ℝ).hasTemperateGrowth
  change (fun p : Plane => p.2).HasTemperateGrowth at hs
  fun_prop

def jet (v : Plane) (f : 𝓢(Plane,E)) : 𝓢(Plane,E) :=
  ∂_{((v.1,0):Plane)} f + SchwartzMap.smulLeftCLM E (fun p : Plane => -(p.2^2) * v.2) (∂_{((0,1):Plane)} f)

theorem deriv_eq (v : Plane) (f : 𝓢(Plane,E)) (p : Plane) :
    fderiv ℝ (compactify f) p v = compactify (jet v f) p := by
  rcases p with ⟨δ,z⟩
  rcases lt_trichotomy z 0 with hz|rfl|hz
  · rw [(derivative_neg f hz).fderiv]
    simp [compactify, not_lt.mpr hz.le]
  · rw [(at_seam f δ).fderiv]; simp [compactify]
  · rw [(derivative_pos f hz).fderiv]
    simp only [compactify,if_pos hz,jet,SchwartzMap.add_apply,
      SchwartzMap.smulLeftCLM_apply_apply (weight_grows v), SchwartzMap.lineDerivOp_apply_eq_fderiv]
    change fderiv ℝ f (δ,z⁻¹) (v.1, -(z⁻¹^2)*v.2) = _
    rw [← (fderiv ℝ f (δ,z⁻¹)).map_smul, ← map_add]
    congr 1
    ext <;> simp

theorem contDiff_compactify (f : 𝓢(Plane,E)) : ContDiff ℝ ∞ (compactify f) := by
  apply contDiff_infty.2
  intro n
  induction n generalizing f with
  | zero => exact contDiff_zero.mpr (differentiable_compactify f).continuous
  | succ n ih =>
    rw [Nat.cast_succ,contDiff_succ_iff_fderiv_apply]
    refine ⟨differentiable_compactify f, by simp, fun v => ?_⟩
    simp_rw [deriv_eq]
    exact ih (jet v f)

end LloydNDFlat
