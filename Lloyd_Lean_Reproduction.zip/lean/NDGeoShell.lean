import NDGeoBoundary
import NDGeoJets
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
open Set Filter MeasureTheory
open scoped Topology SchwartzMap ContDiff RealInnerProductSpace
noncomputable section
namespace LloydNDGeom
open LloydNDPolar LloydNDAngular
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim

def shellCut : ContDiffBump (1:ℝ) := ⟨9/16,11/16,by norm_num,by norm_num⟩
def shellNorm (x : Vn) : ℝ := shellCut (‖x‖^2) * ‖x‖^(dim+2)

private theorem cut_vanish {x : Vn} (hx : ‖x‖^2 ≤ 5/16 ∨ 27/16 ≤ ‖x‖^2) :
    shellCut (‖x‖^2) = 0 := by
  apply shellCut.zero_of_le_dist
  change (11:ℝ)/16 ≤ dist (‖x‖^2) 1
  rw [Real.dist_eq]
  rcases hx with hx | hx
  · rw [abs_of_nonpos (by linarith)]; linarith
  · rw [abs_of_nonneg (by linarith)]; linarith

private theorem shell_support : tsupport (shellNorm (dim:=dim)) ⊆
    {x : Vn | ‖x‖^2 ∈ Icc (5/16:ℝ) (27/16)} := by
  apply closure_minimal _ (isClosed_Icc.preimage (continuous_norm.pow 2))
  intro x hx
  change shellNorm x ≠ 0 at hx
  by_contra! hn
  have hor : ‖x‖^2 ≤ 5/16 ∨ 27/16 ≤ ‖x‖^2 := by
    by_cases h : ‖x‖^2 < 5/16
    · exact Or.inl h.le
    · exact Or.inr (le_of_lt (not_le.mp (fun hh => hn ⟨not_lt.mp h,hh⟩)))
  exact hx (by simp [shellNorm,cut_vanish hor])

theorem shellNorm_compact : HasCompactSupport (shellNorm (dim:=dim)) := by
  apply (isCompact_closedBall (0:Vn) 2).of_isClosed_subset (isClosed_tsupport _) ?_
  intro x hx
  have h := (shell_support hx).2
  change ‖x‖^2 ≤ 27/16 at h
  rw [Metric.mem_closedBall,dist_zero_right]
  nlinarith [norm_nonneg x]

theorem shellNorm_away : tsupport (shellNorm (dim:=dim)) ⊆ away := by
  intro x hx
  have h := (shell_support hx).1
  change 5/16 ≤ ‖x‖^2 at h
  change 1/2 < ‖x‖
  nlinarith [norm_nonneg x]

theorem shellNorm_smooth : ContDiff ℝ ∞ (shellNorm (dim:=dim)) := by
  apply contDiff_iff_contDiffAt.mpr
  intro x
  by_cases hx : x ∈ tsupport (shellNorm (dim:=dim))
  · have h := shellNorm_away hx
    change 1/2 < ‖x‖ at h
    have h' : x ≠ 0 := norm_ne_zero_iff.mp (by linarith)
    unfold shellNorm
    have h1 : ContDiffAt ℝ ∞ (fun y : Vn => shellCut (‖y‖^2)) x := (shellCut.contDiff.comp (contDiff_norm_sq (𝕜:=ℝ) (E:=Vn))).contDiffAt (x:=x)
    exact h1.mul ((contDiffAt_id.norm ℝ h').pow _)
  · exact contDiffAt_const.congr_of_eventuallyEq (notMem_tsupport_iff_eventuallyEq.mp hx)

theorem shellNorm_value (w : Sn) {r : ℝ} (hlo : 3/4 ≤ r) (hhi : r ≤ 5/4) :
    shellNorm (r • w.val) = r^(dim+2) := by
  have hr : 0 ≤ r := by linarith
  have hnorm : ‖r • w.val‖ = r := by simp [norm_smul, Real.norm_eq_abs,abs_of_nonneg hr]
  have hcut : shellCut (r^2) = 1 := by
    apply shellCut.one_of_mem_closedBall
    change dist (r^2) 1 ≤ 9/16
    rw [Real.dist_eq,abs_le]
    constructor <;> nlinarith [mul_nonneg (sub_nonneg.mpr hlo) (by linarith : 0 ≤ r+3/4),
      mul_nonneg (sub_nonneg.mpr hhi) (by linarith : 0 ≤ 5/4+r)]
  rw [shellNorm,hnorm,hcut,one_mul]

/-- Convert a radial graph to a regular strong-convexity sublevel using the
squared-radius correction on a fixed shell. Outside it a quarter-unit bound suffices. -/
theorem sublevel_of_shell {r : Sn → Ray} {b : Vn → ℝ}
    (hb : ∀ x, |b x| ≤ 1/4)
    (hs : ∀ w : Sn, ∀ s : ℝ, 3/4 ≤ s → s ≤ 5/4 →
      b (s • w.val) = (r w).val^2-1) :
    solidStar r = {x : Vn | ‖x‖^2-b x ≤ 1} := by
  ext x
  by_cases hz : x=0
  · subst x
    have h := (abs_le.mp (hb 0)).1
    simp only [solidStar,mem_union,mem_singleton_iff,or_true,mem_ofPred_eq,norm_zero,ne_eq,
      OfNat.ofNat_ne_zero,not_false_eq_true,zero_pow,zero_sub,true_iff]
    linarith
  let p := homeomorphUnitSphereProd Vn ⟨x,hz⟩
  have he : ((homeomorphUnitSphereProd Vn).symm p).val = x := by simp [p]
  have hre : p.2.val • (p.1.val : Vn) = x := by simpa only [homeomorphUnitSphereProd_symm_apply_coe] using he
  have hn : p.2.val = ‖x‖ := homeomorphUnitSphereProd_apply_snd_coe _ _
  have hi : x ∈ solidStar r ↔ ‖x‖^2 ≤ (r p.1).val^2 := by
    calc
      _ ↔ p.2 ≤ r p.1 := by rw [←he]; exact solidStar_polar r p
      _ ↔ _ := by
        rw [←hn]
        change p.2.val ≤ (r p.1).val ↔ _
        exact (pow_le_pow_iff_left₀ p.2.2.le (r p.1).2.le (by decide : (2:ℕ)≠0)).symm
  rw [hi]
  change _ ↔ ‖x‖^2 - b x ≤ 1
  have hr0 := hs p.1 1 (by norm_num) (by norm_num)
  rw [one_smul] at hr0
  have hbr := abs_le.mp (hb p.1.val)
  have hbx := abs_le.mp (hb x)
  by_cases hl : ‖x‖ < 3/4
  · have h2 := pow_le_pow_left₀ (norm_nonneg x) hl.le 2
    exact iff_of_true (by linarith) (by linarith)
  by_cases hh : 5/4 < ‖x‖
  · have h2 := pow_le_pow_left₀ (by norm_num : (0:ℝ)≤5/4) hh.le 2
    exact iff_of_false (by linarith) (by linarith)
  have hi' := hs p.1 p.2.val (hn ▸ not_lt.mp hl) (hn ▸ not_lt.mp hh)
  rw [hre] at hi'
  constructor <;> intro hh' <;> linarith

theorem strict_of_sublevel {b : Vn → ℝ} (hb : ContDiff ℝ 2 b)
    (hh : ∀ x, ‖fderiv ℝ (fderiv ℝ b) x‖ ≤ 1) :
    StrictConvex ℝ {x : Vn | ‖x‖^2 - b x ≤ 1} := by
  let F := fun x : Vn => ‖x‖^2 - b x
  have sc : StrictConvexOn ℝ univ F := (strong_quadratic_perturbation hb hh).strictConvexOn zero_lt_one
  have hc : Continuous F := (continuous_norm.pow 2).sub hb.continuous
  intro x hx y hy hxy s t hs ht hst
  change F x ≤ 1 at hx
  change F y ≤ 1 at hy
  have h1 := sc.2 (mem_univ x) (mem_univ y) hxy hs ht hst
  have h2 : s * F x + t * F y ≤ 1 := by nlinarith [mul_nonneg hs.le (sub_nonneg.mpr hx),mul_nonneg ht.le (sub_nonneg.mpr hy)]
  have h3 : F (s • x + t • y) < 1 := h1.trans_le h2
  apply (interior_mono (show {v | F v < 1} ⊆ {v | F v ≤ 1} from fun v h => (show F v < 1 from h).le))
  rw [(isOpen_lt hc continuous_const).interior_eq]
  exact h3

theorem solidStar_neg_mem {q : Sn → ℝ} (hq : ∀ w, 0 < q w)
    (even : ∀ w, q (antipode w) = q w) (x : Vn) :
    -x ∈ solidStar (positiveRoot q hq) ↔ x ∈ solidStar (positiveRoot q hq) := by
  let ρ := positiveRoot q hq
  have hrho (w : Sn) : ρ (antipode w) = ρ w := by
    apply Subtype.ext
    simp [ρ,positiveRoot,even]
  by_cases hz : x = 0
  · subst x; simp
  let p := homeomorphUnitSphereProd Vn ⟨x,hz⟩
  have he : ((homeomorphUnitSphereProd Vn).symm p).val = x := by simp [p]
  have hn : ((homeomorphUnitSphereProd Vn).symm (antipode p.1,p.2)).val = -x := by
    rw [homeomorphUnitSphereProd_symm_apply_coe]
    change p.2.val • (-p.1.val) = -x
    rw [smul_neg]
    exact congrArg Neg.neg (by simpa only [homeomorphUnitSphereProd_symm_apply_coe] using he)
  change -x ∈ solidStar ρ ↔ x ∈ solidStar ρ
  rw [←hn,solidStar_polar,←he,solidStar_polar,hrho]

end LloydNDGeom
