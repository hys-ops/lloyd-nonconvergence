import NDGaussCompactConservation

/-! A continuous nonnegative Lebesgue density and its measure have the same
closed support, including zeros on the boundary. -/
open MeasureTheory Set Filter
open scoped Topology
namespace LloydNDRadialSource
open LloydNDPolar LloydNDGaussian
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim

noncomputable section

theorem law_support {f:Vn→ℝ} (hc:Continuous f) (hn:∀x,0≤f x) : (law f).support=tsupport f := by
  have hsf : Function.support (fun x=>ENNReal.ofReal (f x))=Function.support f := by
    ext x
    simp only [Function.mem_support,ne_eq,ENNReal.ofReal_eq_zero]
    exact not_congr ⟨fun h=>le_antisymm h (hn x), fun h=>h.le⟩
  refine le_antisymm (Measure.support_subset_of_isClosed isClosed_closure ?_) ?_
  · change ∀ᵐx ∂volume.withDensity (fun x=>ENNReal.ofReal (f x)),x∈tsupport f
    rw [ae_withDensity_iff hc.measurable.ennreal_ofReal]
    filter_upwards [] with x hx
    apply subset_closure
    rw [←hsf];exact hx
  · apply closure_minimal _ Measure.isClosed_support
    intro x hx
    apply (Measure.mem_support_iff_forall _).2
    intro U hU
    unfold law
    rw [withDensity_apply',setLIntegral_pos_iff hc.measurable.ennreal_ofReal,hsf]
    apply Measure.measure_pos_of_mem_nhds (μ:=volume)
    exact inter_mem (hc.isOpen_support.mem_nhds hx) hU

#print axioms law_support
end
end LloydNDRadialSource
