import NDGaussConservation
import NDGaussCurvature
import NDFourierRange

/-! A full-space realization of the given angular data by an isotropic, smooth,
strongly log-concave probability law in each positive ambient dimension. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set
open scoped Topology RealInnerProductSpace SchwartzMap ContDiff
namespace LloydNDGaussian
open LloydNDAngular LloydNDNeutralShell LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim

theorem gaussian_realization (h : ℝ × Vn → ℝ) (hs : LloydNDFrequency.SmoothOnDirections h)
    (he : ∀ t (u:Vn), ‖u‖=1 → h (t,-u)=h (t,u))
    (hz : ∀ u:Vn, ‖u‖=1 → h (0,u)=1) :
    ∃ C : ℝ, 0<C ∧ ∀ᶠ t in 𝓝 (0:ℝ), ∃ ρ : Vn → ℝ, let μ := law ρ
      (∀ x,0<ρ x) ∧ ContDiff ℝ ∞ ρ ∧
      (∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x=pdf x) ∧
      (∀ x,ρ (-x)=ρ x) ∧ IsProbabilityMeasure μ ∧ Measure.IsOpenPosMeasure μ ∧
      MeasurePreserving (fun x : Vn => -x) μ μ ∧ μ ≪ volume ∧ volume ≪ μ ∧
      (∫ x:Vn,x ∂μ)=0 ∧ MemLp id 2 μ ∧ covarianceBilin μ=innerSL ℝ ∧
      (∀ x v:Vn, ‖v‖^2/2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v) ∧
      ∀ u:Vn, ‖u‖=1 → (∫ x, |⟪u,x⟫| ∂μ)=C*h (t,u) := by
  obtain ⟨C,hC,hbase⟩ := standard_projection (dim:=dim)
  let H := fun p : ℝ × Vn => C * (h p - 1)
  have hsm : LloydNDFrequency.SmoothOnDirections H :=
    fun p hp => contDiffAt_const.mul ((hs p hp).sub contDiffAt_const)
  have h0 : ∀ u:Vn, ‖u‖=1 → H (0,u)=0 := by intro u hu; simp [H,hz u hu]
  have hev (t:ℝ) (u:Vn) (hu:‖u‖=1) : H (t,-u)=H (t,u) := by simp [H,he t u hu]
  let F := fun t => LloydNDFourierRange.rightInverse (fun u => H (t,u)) (LloydNDFrequency.slice_smooth hsm t)
  have hF : Tendsto F (𝓝 0) (𝓝 0) := LloydNDFourierRange.rightInverse_tendsto hsm h0
  refine ⟨C,hC,?_⟩
  filter_upwards [LloydNDGaussianShape.eventually_standard_shell hF] with t ht
  have spec := LloydNDFourierRange.rightInverse_spec (LloydNDFrequency.slice_smooth hsm t) (hev t)
  let A := radialize (F t)
  have hA : AngularSmooth A := by
    intro u hu
    apply (schwartz_radialize_smooth (F t)).contDiffAt
    exact away_open.mem_nhds (show u ∈ away by change 1/2 < ‖u‖; rw [hu]; norm_num)
  have heA (u:Vn) (_ : ‖u‖=1) : A (-u)=A u := radialize_even spec.1 u
  have hp : ∀ x,0<density A x := ht.1
  have hn : ∀ x,0≤density A x := fun x => (hp x).le
  obtain ⟨hac,hca⟩ := source_mutual_ac hA hp
  refine ⟨density A,hp,ht.2.1,ht.2.2.1,density_even heA,source_probability hA hn,
    ht.2.2.2.1,source_neg heA,hac,hca,source_mean heA,source_L2 hA hn,
    source_covariance hA hn heA,ht.2.2.2.2,?_⟩
  intro u hu
  change (∫ x, |⟪u,x⟫| ∂source A) = _
  rw [source_projection hA hn,hbase u hu]
  change C + cosineTransform (fun w => radialize (F t) w.val) u = _
  rw [schwartz_cosine]
  have hh := spec.2 u hu
  change (∫ x:Vn, |⟪x,u⟫| * F t x)=C*(h (t,u)-1) at hh
  conv_lhs => arg 2; arg 2; ext x; rw [real_inner_comm x u]
  rw [hh]
  ring

#print axioms gaussian_realization
end LloydNDGaussian
