import NDProduct
import GaussianCounterexample

/-! An unconditional all-dimensions nonconvergence endpoint, using the genuine
three-dimensional law and an independent standard Gaussian along the other axes. -/
noncomputable section
open scoped ContDiff
open Filter Topology TopologicalSpace MeasureTheory ProbabilityTheory
open LloydProduct LloydVerification
namespace LloydND
abbrev V3 := EuclideanSpace ℝ (Fin 3)
abbrev Extra (k : ℕ) := EuclideanSpace ℝ (Fin k)

theorem product_counterexample (k : ℕ) :
    ∃ (ρ : V3 → ℝ) (Y : V3 × V3),
      let μ := LloydGaussian.law ρ
      let ν := stdGaussian (Extra k)
      IsProbabilityMeasure μ ∧ (∀ x, 0 < ρ x) ∧ ContDiff ℝ ∞ ρ ∧
      (∀ n : ℕ, (productStep (μ.prod ν))^[n] (liftPair Y) =
        liftPair ((ordinaryStep μ)^[n] Y)) ∧
      ¬∃ P, Tendsto (fun n => unordered ((productStep (μ.prod ν))^[n] (liftPair Y))) atTop (𝓝 P) := by
  obtain ⟨ρ,δ,_,_,hp,hs,_,_,hpr,_,_,hl,_,_,ho⟩ := LloydGaussianExample.gaussian_counterexample
  let μ := LloydGaussian.law ρ
  let ν := stdGaussian (Extra k)
  letI : IsProbabilityMeasure μ := hpr
  have hi : Integrable (id : V3 → V3) μ := hl.integrable (by norm_num)
  have hj : Integrable (id : Extra k → Extra k) ν := IsGaussian.integrable_id
  have hz : (∫ z:Extra k, z ∂ν) = 0 := integral_id_stdGaussian
  let y := (1:ℝ) • dir δ 0
  let Y : V3 × V3 := (y,-y)
  obtain ⟨c,hc,hlm,hfix,hdiv⟩ := ho 1 zero_lt_one
  refine ⟨ρ,Y,hpr,hp,hs,fun n => product_iterate μ ν hi hj hz Y n,?_⟩
  apply product_diverges μ ν hi hj hz Y
  exact hdiv

#print axioms product_counterexample
end LloydND
