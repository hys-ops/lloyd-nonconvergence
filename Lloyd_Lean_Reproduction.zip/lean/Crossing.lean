import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Order.Filter.AtTopBot.Archimedean
import Mathlib.Data.Nat.Find
import Mathlib.Tactic

open Filter Topology Finset
noncomputable section
namespace LloydCrossing

/-- At the first crossing of any diverging levels the overshoot tends to zero.
The input sequence need not be monotone. -/
theorem first_crossing (a b : ℕ → ℝ) (ha : Tendsto a atTop atTop)
    (hstep : Tendsto (fun j => a (j+1)-a j) atTop (𝓝 0))
    (hb : Tendsto b atTop atTop) :
    ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      (∀ n, b n ≤ a (k n) ∧ ∀ j < k n, a j < b n) ∧
      Tendsto (fun n => a (k n)-b n) atTop (𝓝 0) := by
  classical
  have exists_cross (n : ℕ) : ∃ j, b n ≤ a j := (ha.eventually_ge_atTop (b n)).exists
  let k (n : ℕ) := Nat.find (exists_cross n)
  have first (n : ℕ) : b n ≤ a (k n) ∧ ∀ j < k n, a j < b n := by
    refine ⟨Nat.find_spec (exists_cross n),?_⟩
    intro j hj
    exact lt_of_not_ge (Nat.find_min (exists_cross n) hj)
  have hk : Tendsto k atTop atTop := by
    apply tendsto_atTop.mpr
    intro M
    let B := ∑ j ∈ range M, |a j|
    filter_upwards [hb.eventually_gt_atTop B] with n hn
    by_contra! hsmall
    have h : |a (k n)| ≤ B := single_le_sum (fun j _ => abs_nonneg (a j)) (mem_range.mpr hsmall)
    linarith [(first n).1, le_abs_self (a (k n))]
  have hp : Tendsto (fun n => k n-1) atTop atTop := by
    apply tendsto_atTop.mpr
    intro M
    filter_upwards [hk.eventually_ge_atTop (M+1)] with n hn
    omega
  refine ⟨k,hk,first,?_⟩
  apply squeeze_zero' (Eventually.of_forall (fun n => sub_nonneg.mpr (first n).1)) _ (hstep.comp hp)
  filter_upwards [hk.eventually_ge_atTop 1] with n hn
  have h := (first n).2 (k n-1) (by omega)
  change a (k n)-b n ≤ a (k n-1+1)-a (k n-1)
  rw [Nat.sub_add_cancel hn]
  linarith

/-- Every prescribed phase is approached at successively higher turn numbers. -/
theorem phase_crossing (a : ℕ → ℝ) (ha : Tendsto a atTop atTop)
    (hstep : Tendsto (fun j => a (j+1)-a j) atTop (𝓝 0)) (α : ℝ) :
    ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      Tendsto (fun n => a (k n)-(2*Real.pi*(n:ℝ)+α)) atTop (𝓝 0) := by
  have hb : Tendsto (fun n : ℕ => 2*Real.pi*(n:ℝ)+α) atTop atTop :=
    tendsto_atTop_add_const_right _ _ (tendsto_natCast_atTop_atTop.const_mul_atTop (by positivity))
  obtain ⟨k,hk,_,ho⟩ := first_crossing a _ ha hstep hb
  exact ⟨k,hk,ho⟩

theorem trig_crossing (a : ℕ → ℝ) (ha : Tendsto a atTop atTop)
    (hstep : Tendsto (fun j => a (j+1)-a j) atTop (𝓝 0)) (α : ℝ) :
    ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      Tendsto (fun n => Real.cos (a (k n))) atTop (𝓝 (Real.cos α)) ∧
      Tendsto (fun n => Real.sin (a (k n))) atTop (𝓝 (Real.sin α)) := by
  obtain ⟨k,hk,ho⟩ := phase_crossing a ha hstep α
  have ht : Tendsto (fun n => a (k n)-(n:ℝ)*(2*Real.pi)) atTop (𝓝 α) := by
    have h := ho.add_const α
    rw [zero_add] at h
    apply h.congr
    intro n; ring
  refine ⟨k,hk,?_,?_⟩
  · apply (Real.continuous_cos.continuousAt.tendsto.comp ht).congr
    intro n
    simpa only [sub_add_cancel,Function.comp_apply] using
      (Real.cos_add_nat_mul_two_pi (a (k n)-(n:ℝ)*(2*Real.pi)) n).symm
  · apply (Real.continuous_sin.continuousAt.tendsto.comp ht).congr
    intro n
    simpa only [sub_add_cancel,Function.comp_apply] using
      (Real.sin_add_nat_mul_two_pi (a (k n)-(n:ℝ)*(2*Real.pi)) n).symm

#print axioms first_crossing
#print axioms phase_crossing
#print axioms trig_crossing
end LloydCrossing
