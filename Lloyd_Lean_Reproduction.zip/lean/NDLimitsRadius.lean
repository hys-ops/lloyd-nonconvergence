import NDLimitsSupport

/-! Support and radius of the actual normalized-volume antipodal centroid update. -/

noncomputable section
open MeasureTheory Filter Set
open scoped RealInnerProductSpace Topology
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)

lemma signedPoint_integrable (μ : Measure E) (u : E) (hi : Integrable (id : E → E) μ) :
    Integrable (signedPoint u) μ := by
  classical
  have heq : signedPoint u = (positive u).piecewise id (-id) := by
    funext x
    by_cases h : 0 < ⟪x,u⟫ <;> simp [positive,Set.piecewise,signedPoint,h]
  rw [heq]
  exact Integrable.piecewise (positive_meas u) hi.integrableOn hi.neg.integrableOn

@[simp] lemma norm_signedPoint (u x : E) : ‖signedPoint u x‖ = ‖x‖ := by
  by_cases h : 0 < ⟪x,u⟫ <;> simp [signedPoint,h]

/-- A signed centroid gives a simultaneous supporting linear functional in every direction. -/
theorem inner_signedMoment_le (μ : Measure E) (u v : E) (hi : Integrable (id : E → E) μ) :
    ⟪v,signedMoment μ u⟫ ≤ populationSupport μ v := by
  change innerSL ℝ v (∫ x, signedPoint u x ∂μ) ≤ _
  rw [← (innerSL ℝ v).integral_comp_comm (signedPoint_integrable μ u hi)]
  apply integral_mono ((innerSL ℝ v).integrable_comp (signedPoint_integrable μ u hi))
  · simpa only [Real.norm_eq_abs,id_eq,innerSL_apply_apply,real_inner_comm v _] using
      ((innerSL ℝ v).integrable_comp hi).norm
  · intro x
    by_cases h : 0 < ⟪x,u⟫
    · simpa [signedPoint,h,real_inner_comm v x] using le_abs_self ⟪x,v⟫
    · simpa [signedPoint,h,real_inner_comm v x] using neg_le_abs ⟪x,v⟫

/-- This bound holds even in the presence of ties. -/
theorem norm_signedMoment_le (μ : Measure E) (u : E) :
    ‖signedMoment μ u‖ ≤ ∫ x : E, ‖x‖ ∂μ := by
  simpa only [signedMoment,norm_signedPoint] using
    (norm_integral_le_integral_norm (signedPoint u) (μ := μ))

lemma uniform_id_integrable (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) :
    Integrable (id : E → E) (uniformOn K) := by
  have h : Integrable (id : E → E) (volume.restrict K) := continuous_id.continuousOn.integrableOn_compact compact
  exact h.smul_measure (ENNReal.inv_ne_top.mpr volpos)

lemma uniform_probability (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) :
    IsProbabilityMeasure (uniformOn K) :=
  ProbabilityTheory.cond_isProbabilityMeasure_of_finite volpos compact.measure_lt_top.ne

lemma uniform_no_ties (K : Set E) (u : E) (hu : u ≠ 0) :
    uniformOn K {x | ⟪x,u⟫ = 0} = 0 :=
  no_ties_of_ac _ ProbabilityTheory.cond_absolutelyContinuous u hu

/-- An integrable source gives a continuous signed centroid at every null-tie direction. -/
theorem continuousAt_signedMoment (μ : Measure E) (u : E) (hi : Integrable (id : E → E) μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) : ContinuousAt (signedMoment μ) u := by
  apply tendsto_integral_filter_of_dominated_convergence (fun x : E => ‖x‖)
    (.of_forall fun v => (signedPoint_integrable μ v hi).aestronglyMeasurable)
    (.of_forall fun v => .of_forall fun x => (norm_signedPoint v x).le) hi.norm
  have ht' : ∀ᵐ x ∂μ, ⟪x,u⟫ ≠ 0 := by
    apply ae_iff.mpr
    simpa only [not_not] using ht
  filter_upwards [ht'] with x hx
  have hcont : ContinuousAt (fun v : E => ⟪x,v⟫) u := (continuous_const.inner continuous_id).continuousAt
  rcases lt_or_gt_of_ne hx with hneg | hpos
  · have ev := hcont.tendsto.eventually (Iio_mem_nhds hneg)
    rw [show signedPoint u x = -x by simp [signedPoint,not_lt.mpr hneg.le]]
    apply tendsto_const_nhds.congr'
    filter_upwards [ev] with v hv
    have hv' : ⟪x,v⟫ < 0 := hv
    simp [signedPoint,not_lt.mpr hv'.le]
  · have ev := hcont.tendsto.eventually (Ioi_mem_nhds hpos)
    rw [show signedPoint u x = x by simp [signedPoint,hpos]]
    apply tendsto_const_nhds.congr'
    filter_upwards [ev] with v hv
    have hv' : 0 < ⟪x,v⟫ := hv
    simp [signedPoint,hv']


end LloydNDLimits
