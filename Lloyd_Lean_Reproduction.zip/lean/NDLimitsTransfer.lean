import NDLimitsOrbit
import NDPrescribe
import Mathlib.Analysis.SpecialFunctions.Sqrt

noncomputable section
open Filter Topology MeasureTheory
open scoped RealInnerProductSpace
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)

/-- Equal differentiable functions on the sphere agree to first order in every
tangent direction. The explicit normalizing factor has derivative zero. -/
theorem tangent_congr {F G : E → ℝ} {u : E} (hu : ‖u‖=1)
    (h : ∀ x, ‖x‖=1 → F x = G x) (hf : DifferentiableAt ℝ F u)
    (hg : DifferentiableAt ℝ G u) {w : E} (hw : ⟪u,w⟫=0) :
    fderiv ℝ F u w = fderiv ℝ G u w := by
  let b := fun t : ℝ => 1 + t^2 * ‖w‖^2
  let γ := fun t : ℝ => (Real.sqrt (b t))⁻¹ • (u + t • w)
  have bpos (t:ℝ) : 0 < b t := by dsimp [b]; positivity
  have sq (t:ℝ) : ‖u + t • w‖ ^ 2 = b t := by
    rw [norm_add_sq_real,hu,real_inner_smul_right,hw,norm_smul,Real.norm_eq_abs]
    dsimp [b]
    rw [mul_pow,sq_abs]
    ring
  have normγ (t:ℝ) : ‖γ t‖=1 := by
    have hnorm : Real.sqrt (b t) = ‖u+t • w‖ := by rw [←sq,Real.sqrt_sq (norm_nonneg _)]
    change ‖(Real.sqrt (b t))⁻¹ • (u + t • w)‖ = 1
    rw [norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr (Real.sqrt_pos.mpr (bpos t))),
        ←hnorm,inv_mul_cancel₀ (Real.sqrt_ne_zero'.mpr (bpos t))]
  have db : HasDerivAt b 0 0 := by
    simpa [b] using ((((hasDerivAt_id (0:ℝ)).pow 2).mul_const (‖w‖^2)).const_add 1)
  have dsc : HasDerivAt (fun t => (Real.sqrt (b t))⁻¹) 0 0 := by
    simpa [b,Pi.inv_def] using! ((db.sqrt (bpos 0).ne').inv (Real.sqrt_ne_zero'.mpr (bpos 0)))
  have dvec : HasDerivAt (fun t : ℝ => u + t • w) w 0 := by
    simpa using (((hasDerivAt_id (0:ℝ)).smul_const w).const_add u)
  have dγ : HasDerivAt γ w 0 := by
    apply (dsc.smul dvec).congr_deriv
    simp [b]
  have c0 : γ 0 = u := by simp [γ,b]
  have hf' := (c0.symm ▸ hf.hasFDerivAt : HasFDerivAt F (fderiv ℝ F u) (γ 0)).comp_hasDerivAt 0 dγ
  have hg' := (c0.symm ▸ hg.hasFDerivAt : HasFDerivAt G (fderiv ℝ G u) (γ 0)).comp_hasDerivAt 0 dγ
  exact hf'.unique (hg'.congr_of_eventuallyEq (.of_forall fun t => h (γ t) (normγ t)))

/-- Transfer a computed scalar log-profile jet to the original Euclidean
population Lloyd map. The profile need only agree on the unit sphere. -/
theorem signedMoment_of_kick {μ : Measure E} [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {f:E→ℝ} {C : ℝ} (hC : 0<C)
    (hs : ∀ x, ‖x‖=1 → populationSupport μ x = C * Real.exp (f x))
    {u v : E} (hu : ‖u‖=1) (hv : ‖v‖=1) (hd : 0<⟪u,v⟫)
    (hf : DifferentiableAt ℝ f u)
    (hjet : ∀ w : E, ⟪u,w⟫=0 → fderiv ℝ f u w = ⟪LloydNDSpiral.kick u v,w⟫) :
    signedMoment μ u = ‖signedMoment μ u‖ • v := by
  have unz : u≠0 := by intro h; simpa [h] using hu
  have ht := no_ties_of_ac μ hac u unz
  have hp := populationSupport_pos μ u ht hi
  have hlog := ((signedMoment_hasGradientAt μ u ht hi).hasFDerivAt.log hp.ne').differentiableAt
  have hprof : ∀ x : E, ‖x‖=1 →
      Real.log (populationSupport μ x) = Real.log C + f x := by
    intro x hx
    rw [hs x hx,Real.log_mul hC.ne' (Real.exp_pos _).ne',Real.log_exp]
  let g := tangentLogSupport μ u
  let q := LloydNDSpiral.kick u v
  have tg := tangentLogSupport_spec μ u hu ht hi
  have tq := (LloydNDSpiral.kick_exact hu hv hd).1
  have diff (w:E) (hw : ⟪u,w⟫=0) : ⟪g,w⟫ = ⟪q,w⟫ := by
    rw [←tg.2 w hw,tangent_congr hu hprof hlog (hf.const_add _) hw,
      fderiv_const_add, hjet w hw]
  have hw : ⟪u,g-q⟫=0 := by simpa [g,q,inner_sub_right,tg.1,tq]
  have hself : ⟪g-q,g-q⟫=0 := by rw [inner_sub_left,diff (g-q) hw,sub_self]
  have he : g=q := sub_eq_zero.mp (inner_self_eq_zero.mp hself)
  have he' : signedMoment μ u = (populationSupport μ u * ⟪u,v⟫⁻¹) • v := by
    have h := congrArg (fun a : E => populationSupport μ u • (u + a)) he
    simpa [g,q,tangentLogSupport,LloydNDSpiral.kick,smul_smul,hp.ne'] using h
  have hnorm := congrArg norm he'
  rw [norm_smul,hv,mul_one,Real.norm_eq_abs,abs_of_pos (mul_pos hp (inv_pos.mpr hd))] at hnorm
  simpa only [hnorm] using he'

#print axioms signedMoment_of_kick
end LloydNDLimits
