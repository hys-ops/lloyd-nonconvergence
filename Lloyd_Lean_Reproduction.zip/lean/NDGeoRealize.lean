import NDGeoSolid
import NDRealization

/-! Parametric local realization of even directional profiles by uniform volumes.
The family of sets and scaling constants is chosen before the requested order and
tolerance. The statement contains no orbit, Fourier, cosine-transform, radial
density or curvature assumptions on an inverse. -/

open Set Filter MeasureTheory
open scoped Topology SchwartzMap ContDiff RealInnerProductSpace
open LloydNDPolar LloydNDAngular

namespace LloydNDGeom
noncomputable section
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim
local notation "law" => ProbabilityTheory.cond (volume : Measure Vn)

/-- For any jointly smooth real one-parameter profile which is even in the direction
and equals one at parameter zero, its restriction to the unit sphere is, up to a
positive scalar, the absolute first projection moment of a compact, centrally
symmetric uniform solid with smooth positively curved boundary. The same family
works simultaneously for all finite radial orders and tolerances. -/
theorem local_profile_realization {h : ℝ × Vn → ℝ} (hs : LloydNDFrequency.SmoothOnDirections h)
    (he : ∀ t (u:Vn), ‖u‖=1 → h (t,-u) = h (t,u))
    (hz : ∀ u:Vn, ‖u‖=1 → h (0,u) = 1) :
    ∃ (K : ℝ → Set Vn) (c : ℝ → ℝ), ∀ (m : ℕ) (ε : ℝ), 0 < ε →
      ∀ᶠ t in 𝓝 (0:ℝ), 0 < c t ∧ IsCompact (K t) ∧ 0 < volume (K t) ∧
        (∀ x:Vn, -x ∈ K t ↔ x ∈ K t) ∧ StrictConvex ℝ (K t) ∧
        HasPositiveCurvedBoundary (K t) ∧ Metric.closedBall (0:Vn) (1/2:ℝ) ⊆ K t ∧
        IsProbabilityMeasure (law (K t)) ∧ NearRound (K t) m ε ∧
        ∀ u:Vn, ‖u‖=1 → (∫ x, |⟪u,x⟫| ∂law (K t)) = c t * h (t,u) := by
  classical
  obtain ⟨A,hA,hbase⟩ := constant_cosine_sphere (dim:=dim)
  let H := fun p : ℝ × Vn => A * (h p - 1)
  have hsm : LloydNDFrequency.SmoothOnDirections H :=
    fun p hp => contDiffAt_const.mul ((hs p hp).sub contDiffAt_const)
  have h0 : ∀ u:Vn, ‖u‖=1 → H (0,u)=0 := by
    intro u hu
    simp [H,hz u hu]
  have hev (t : ℝ) (u : Vn) (hu : ‖u‖ = 1) : H (t,-u) = H (t,u) := by
    simp [H,he t u hu]
  let F : ℝ → 𝓢(Vn,ℝ) := fun t => LloydNDFourierRange.rightInverse
    (fun u => H (t,u)) (LloydNDFrequency.slice_smooth hsm t)
  have hF : Tendsto F (𝓝 0) (𝓝 0) := LloydNDFourierRange.rightInverse_tendsto hsm h0
  have spec (t : ℝ) :=
    LloydNDFourierRange.rightInverse_spec (LloydNDFrequency.slice_smooth hsm t) (hev t)
  let K : ℝ → Set Vn := fun t => if hp : ∀ w, 0 < weight (F t) w then body (F t) hp else ∅
  let c := fun t => (volume.real (K t))⁻¹ * (A / ((dim:ℝ)+2))
  refine ⟨K,c,?_⟩
  intro m ε hε
  have hj := eventually_nearRound hF m hε
  filter_upwards [eventually_smooth_solid hF,hj] with t hgeom hjets
  obtain ⟨hp,hstrict,hcurv,hball⟩ := hgeom
  have hp' : ∀ w, 0 < weight (F t) w := hp
  have hK : K t = body (F t) hp' := by simp [K,hp']
  have hqc : Continuous (weight (F t)) := continuous_const.add (sphere_radialize_continuous _)
  have hqe (w : Sn) : weight (F t) (antipode w) = weight (F t) w := by
    unfold weight
    rw [show (antipode w).val = -w.val from rfl, radialize_even (spec t).1]
  obtain ⟨hcompact,hprob,_,hsupport⟩ := solid_uniform_data hqc hp' hqe
  have hprobK : IsProbabilityMeasure (law (K t)) := hK.symm ▸ hprob
  have hvol : 0 < volume (K t) := by
    let : IsProbabilityMeasure (law (K t)) := hprobK
    apply pos_iff_ne_zero.mpr
    intro hv
    exact IsProbabilityMeasure.ne_zero (law (K t)) (ProbabilityTheory.cond_eq_zero_of_meas_eq_zero hv)
  have hcK : IsCompact (K t) := hK.symm ▸ hcompact
  have hscale : 0 < c t := by
    have hv : 0 < volume.real (K t) := ENNReal.toReal_pos hvol.ne' hcK.measure_lt_top.ne
    exact mul_pos (inv_pos.mpr hv) (by positivity)
  refine ⟨hscale,hcK,hvol,?_,hK.symm ▸ hstrict,hK.symm ▸ hcurv,?_,hprobK,?_,?_⟩
  · rw [hK]
    exact solidStar_neg_mem hp' hqe
  · rw [hK]
    exact hball
  · rw [hK]
    exact hjets hp'
  · intro u hu
    have hcos : cosineTransform (weight (F t)) u = A*h (t,u) := by
      change cosineTransform (fun w => 1 + radialize (F t) w.val) u = _
      rw [cosine_add_const (sphere_radialize_continuous _) 1,hbase u hu,schwartz_cosine]
      have hfi := (spec t).2 u hu
      change (∫ x:Vn, |inner ℝ x u| * F t x) = H (t,u) at hfi
      conv_lhs => rhs; arg 2; ext x; rw [real_inner_comm x u]
      rw [hfi]
      dsimp [H]
      ring
    dsimp [c]
    rw [hK]
    unfold body
    rw [hsupport u, hcos]
    ring

#print axioms local_profile_realization
end
end LloydNDGeom
