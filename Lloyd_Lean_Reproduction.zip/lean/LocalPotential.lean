import Gate
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

noncomputable section
open Set MeasureTheory
open scoped ContDiff
namespace LloydLocal
open LloydSpiral.Chart

def belt : Set ℝ := Ioo 0 (1/4)
def denom (δ z : ℝ) : ℝ :=
  radial z * radial (nextHeight δ z) * Real.cos (azimuth (nextHeight δ z) - azimuth z)
    + z*nextHeight δ z

theorem denom_eq (δ z : ℝ) :
    denom δ z = inner ℝ (point z (azimuth z)) (point (nextHeight δ z) (azimuth (nextHeight δ z))) :=
  (dot_points _ _ _ _).symm

def p (δ z : ℝ) : ℝ :=
  (nextHeight δ z - z*radial (nextHeight δ z)*
    Real.cos (azimuth (nextHeight δ z) - azimuth z)/radial z) / denom δ z
def q (δ z : ℝ) : ℝ :=
  (radial z * radial (nextHeight δ z) *
    Real.sin (azimuth (nextHeight δ z) - azimuth z)) / denom δ z
def integrand (δ z : ℝ) : ℝ := p δ z + q δ z * -(z⁻¹)
def primitive (δ z : ℝ) : ℝ := ∫ t in (1/8 : ℝ)..z, integrand δ t
def surface (δ : ℝ) := potential (primitive δ) (q δ) azimuth

/-- Open-chart side conditions used in local smoothness and the FTC. -/
def RegularAt (δ z : ℝ) : Prop :=
  0 < z ∧ 0 < 1-z^2 ∧ 0 < nextHeight δ z ∧ 0 < 1-(nextHeight δ z)^2 ∧ 0 < denom δ z

theorem smooth_coefficients {δ z : ℝ} (h : RegularAt δ z) :
    ContDiffAt ℝ ∞ (p δ) z ∧ ContDiffAt ℝ ∞ (q δ) z ∧ ContDiffAt ℝ ∞ (integrand δ) z := by
  obtain ⟨hz, hrad, hs, hsrad, hden⟩ := h
  have hn : ContDiffAt ℝ ∞ (nextHeight δ) z := by
    unfold nextHeight
    fun_prop (disch := positivity)
  have hphase : ContDiffAt ℝ ∞ azimuth z := by
    unfold azimuth
    fun_prop (disch := positivity)
  have hphase' : ContDiffAt ℝ ∞ (fun t => azimuth (nextHeight δ t)) z := by
    unfold azimuth
    fun_prop (disch := positivity)
  have hr : ContDiffAt ℝ ∞ radial z := by
    unfold radial
    fun_prop (disch := positivity)
  have hr' : ContDiffAt ℝ ∞ (fun t => radial (nextHeight δ t)) z := by
    unfold radial
    fun_prop (disch := positivity)
  have hd : ContDiffAt ℝ ∞ (denom δ) z := by
    unfold denom
    fun_prop
  have hP : ContDiffAt ℝ ∞ (p δ) z := by
    unfold p
    fun_prop (disch := first | exact (Real.sqrt_pos.mpr hrad).ne' | positivity)
  have hQ : ContDiffAt ℝ ∞ (q δ) z := by
    unfold q
    fun_prop (disch := positivity)
  exact ⟨hP, hQ, by unfold integrand; fun_prop (disch := positivity)⟩

private theorem measurable_integrand (δ : ℝ) : Measurable (integrand δ) := by
  unfold integrand p q denom azimuth nextHeight radial
  fun_prop

theorem primitive_hasDerivAt {δ z : ℝ} (hz : z ∈ belt)
    (hgate : ∀ x ∈ belt, RegularAt δ x) :
    HasDerivAt (primitive δ) (integrand δ z) z := by
  apply intervalIntegral.integral_hasDerivAt_right
  · apply ContinuousOn.intervalIntegrable
    intro x hx
    have hxb : x ∈ belt := ordConnected_Ioo.uIcc_subset (show (1/8:ℝ) ∈ belt by norm_num [belt]) hz hx
    exact (smooth_coefficients (hgate x hxb)).2.2.continuousAt.continuousWithinAt
  · exact (measurable_integrand δ).aestronglyMeasurable.stronglyMeasurableAtFilter
  · exact (smooth_coefficients (hgate z hz)).2.2.continuousAt

theorem primitive_smooth {δ : ℝ} (hgate : ∀ x ∈ belt, RegularAt δ x) :
    ContDiffOn ℝ ∞ (primitive δ) belt := by
  apply (contDiffOn_infty_iff_deriv_of_isOpen (show IsOpen belt from isOpen_Ioo)).mpr
  constructor
  · exact fun x hx => (primitive_hasDerivAt hx hgate).differentiableAt.differentiableWithinAt
  · apply ContDiffOn.congr (f := integrand δ)
    · exact fun x hx => (smooth_coefficients (hgate x hx)).2.2.contDiffWithinAt
    · exact fun x hx => (primitive_hasDerivAt hx hgate).deriv

theorem realized_chart_step {δ z : ℝ} (hz : z ∈ belt)
    (hgate : ∀ x ∈ belt, RegularAt δ x) :
    ∃! g, IsChartGradient (surface δ) z (azimuth z) g ∧
      normalize (point z (azimuth z) + g) = point (nextHeight δ z) (azimuth (nextHeight δ z)) := by
  obtain ⟨hzp, hrad, hs, hsrad, hden⟩ := hgate z hz
  have haz : HasDerivAt azimuth (-(z⁻¹)) z := (Real.hasDerivAt_log hzp.ne').neg
  apply chart_reconstruction (F := primitive δ) (q := q δ) (Φ := azimuth) hrad hsrad
    (by rwa [← denom_eq])
  · simpa only [integrand, p, zComponent, ← denom_eq] using primitive_hasDerivAt hz hgate
  · exact ((smooth_coefficients (hgate z hz)).2.1.differentiableAt (by simp)).hasDerivAt
  · exact haz
  · simp only [q, phiComponent, ← denom_eq]

theorem gate_all {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) : ∀ z ∈ belt, RegularAt δ z := by
  intro z hz
  obtain ⟨hpos,hlim⟩ := hz
  change 0 < z at hpos
  change z < 1/4 at hlim
  obtain ⟨hl,hu⟩ := LloydGate.step_bounds hd hd' hpos hlim
  change z/2 < nextHeight δ z at hl
  change nextHeight δ z < z at hu
  have hs : 0 < nextHeight δ z := by linarith
  have hs' : nextHeight δ z < 1 := by linarith
  exact ⟨hpos, by nlinarith [mul_pos (sub_pos.mpr (show z<1 by linarith)) (show 0<1+z by linarith)],
    hs, by nlinarith [mul_pos (sub_pos.mpr hs') (show 0<1+nextHeight δ z by linarith)],
    (denom_eq _ _).symm ▸ LloydGate.positive_chord hd hd' hpos hlim⟩

theorem exact_step {δ z : ℝ} (hd : 0<δ) (hd' : δ≤1) (hz : z ∈ belt) :
    ∃! g, IsChartGradient (surface δ) z (azimuth z) g ∧
      normalize (point z (azimuth z) + g) = point (nextHeight δ z) (azimuth (nextHeight δ z)) :=
  realized_chart_step hz (gate_all hd hd')


/-- Joint smoothness in both chart coordinates on the entire northern belt. -/
theorem surface_smooth {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) :
    ContDiffOn ℝ ∞ (fun x : ℝ × ℝ => surface δ x.1 x.2) (belt ×ˢ Set.univ) := by
  intro x hx
  have hxz : x.1 ∈ belt := hx.1
  have hw : IsOpen belt := isOpen_Ioo
  have hF := (primitive_smooth (gate_all hd hd')).contDiffAt (hw.mem_nhds hxz)
  have hQ := (smooth_coefficients (gate_all hd hd' x.1 hxz)).2.1
  have hZ : x.1 ≠ 0 := hxz.1.ne'
  have hphase : ContDiffAt ℝ ∞ azimuth x.1 := by
    unfold azimuth
    fun_prop (disch := assumption)
  apply ContDiffAt.contDiffWithinAt
  unfold surface potential
  fun_prop

theorem exact_step_on_orbit {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) (n : ℕ) :
    let z := LloydHeight.height δ n
    ∃! g, IsChartGradient (surface δ) z (azimuth z) g ∧
      normalize (point z (azimuth z) + g) =
        point (LloydHeight.height δ (n+1)) (LloydHeight.phase δ (n+1)) := by
  obtain ⟨hp,hu⟩ := LloydHeight.height_bounds hd hd' n
  exact exact_step hd hd' (show LloydHeight.height δ n ∈ belt from ⟨hp, by linarith⟩)

#print axioms exact_step
#print axioms surface_smooth
#print axioms exact_step_on_orbit
end LloydLocal
