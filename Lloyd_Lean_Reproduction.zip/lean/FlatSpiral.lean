import Flat
import LocalPotential
import Mathlib.Analysis.Analytic.Order
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic

noncomputable section
open scoped ContDiff Topology
open Set MeasureTheory Polynomial Filter
namespace LloydFlatSpiral
open LloydSpiral.Chart

def u (δ x : ℝ) : ℝ := δ * (x⁻¹ * LloydFlat.bump x)
def s (δ x : ℝ) : ℝ := x - δ * LloydFlat.bump x
def deltaAngle (δ x : ℝ) : ℝ := -Real.log (1-u δ x)
def chord (δ x : ℝ) : ℝ :=
  radial x * radial (s δ x) * Real.cos (deltaAngle δ x) + x * s δ x
def ratio (δ x : ℝ) : ℝ := radial x * radial (s δ x) / chord δ x
def p (δ x : ℝ) : ℝ :=
  (s δ x - x * radial (s δ x) * Real.cos (deltaAngle δ x) / radial x) / chord δ x
def q (δ x : ℝ) : ℝ := ratio δ x * Real.sin (deltaAngle δ x)
def integrand (δ x : ℝ) : ℝ := p δ x - q δ x * x⁻¹
def primitive (δ z : ℝ) : ℝ := ∫ x in (0:ℝ)..z, integrand δ x
def surface (δ : ℝ) (x : ℝ × ℝ) : ℝ := primitive δ x.1 + q δ x.1 * Real.sin (x.2 + Real.log x.1)

@[simp] theorem u_zero (δ : ℝ) : u δ 0 = 0 := by simp [u]
@[simp] theorem s_zero (δ : ℝ) : s δ 0 = 0 := by simp [s,LloydFlat.bump]
@[simp] theorem angle_zero (δ : ℝ) : deltaAngle δ 0 = 0 := by simp [deltaAngle]
@[simp] theorem radial_zero : radial 0 = 1 := by norm_num [radial]
@[simp] theorem chord_zero (δ : ℝ) : chord δ 0 = 1 := by simp [chord]

theorem smooth_bump : ContDiff ℝ ∞ LloydFlat.bump := by
  simpa using LloydFlat.contDiff_amplitude (1 : ℝ[X])

theorem smooth_u (δ : ℝ) : ContDiff ℝ ∞ (u δ) := by
  have h : ContDiff ℝ ∞ (fun x : ℝ => x⁻¹ * LloydFlat.bump x) := by
    simpa using LloydFlat.contDiff_amplitude (X : ℝ[X])
  exact contDiff_const.mul h

theorem smooth_s (δ : ℝ) : ContDiff ℝ ∞ (s δ) :=
  contDiff_id.sub (contDiff_const.mul smooth_bump)

theorem smooth_p_ratio {δ x : ℝ} (hx : 0 < 1-x^2) (hs : 0 < 1-(s δ x)^2)
    (hu : 0 < 1-u δ x) (hc : 0 < chord δ x) :
    ContDiffAt ℝ ∞ (p δ) x ∧ ContDiffAt ℝ ∞ (ratio δ) x := by
  have hU := (smooth_u δ).contDiffAt (x := x)
  have hS := (smooth_s δ).contDiffAt (x := x)
  have ha : ContDiffAt ℝ ∞ (deltaAngle δ) x := by
    unfold deltaAngle
    fun_prop (disch := positivity)
  have hr : ContDiffAt ℝ ∞ radial x := by unfold radial; fun_prop (disch := positivity)
  have hrs : ContDiffAt ℝ ∞ (fun t => radial (s δ t)) x := by unfold radial; fun_prop (disch := positivity)
  have hc' : ContDiffAt ℝ ∞ (chord δ) x := by unfold chord; fun_prop
  constructor
  · unfold p
    fun_prop (disch := first | exact (Real.sqrt_pos.mpr hx).ne' | positivity)
  · unfold ratio
    fun_prop (disch := positivity)

private def waveAngle (t : ℝ) : ℝ := Real.sin (-Real.log (1-t))

private theorem factor_exists : ∃ H : ℝ → ℝ,
    AnalyticAt ℝ H 0 ∧ ∀ t, waveAngle t = t * H t := by
  have ha : AnalyticAt ℝ waveAngle 0 := by unfold waveAngle; fun_prop (disch := norm_num)
  obtain ⟨H,hH,he⟩ := ha.exists_eq_sum_add_pow_mul 1
  refine ⟨H,hH, fun t => ?_⟩
  simpa [waveAngle,smul_eq_mul] using he t

private noncomputable def H : ℝ → ℝ := Classical.choose factor_exists
private theorem analytic_H : AnalyticAt ℝ H 0 := (Classical.choose_spec factor_exists).1
private theorem wave_factor (t : ℝ) : waveAngle t = t*H t :=
  (Classical.choose_spec factor_exists).2 t

def coefficient (δ x : ℝ) : ℝ := δ * ratio δ x * H (u δ x)

theorem q_factor (δ x : ℝ) :
    q δ x = coefficient δ x * (x⁻¹ * LloydFlat.bump x) := by
  change ratio δ x * waveAngle (u δ x) = _
  rw [wave_factor]; unfold coefficient u; ring

theorem q_over_height_factor (δ x : ℝ) :
    q δ x * x⁻¹ = coefficient δ x * (x⁻¹ ^ 2 * LloydFlat.bump x) := by
  rw [q_factor]; ring

theorem q_angular_factor (δ x φ : ℝ) :
    q δ x * Real.sin (φ + Real.log x) =
      coefficient δ x * LloydFlat.angular 1 φ X x := by
  rw [q_factor]; simp [LloydFlat.angular]; ring

private theorem smooth_coefficient {δ x : ℝ} (hr : ContDiffAt ℝ ∞ (ratio δ) x)
    (hH : AnalyticAt ℝ H (u δ x)) : ContDiffAt ℝ ∞ (coefficient δ) x := by
  have h := hH.contDiffAt (n := ∞)
  have hU := (smooth_u δ).contDiffAt (x := x)
  unfold coefficient
  fun_prop

theorem smooth_q_angular (δ φ : ℝ) :
    ContDiffAt ℝ ∞ (fun w : ℝ × ℝ => q δ w.1 * Real.sin (w.2 + Real.log w.1)) (0,φ) := by
  have hr := (smooth_p_ratio (δ := δ) (x := 0) (by norm_num) (by simp) (by simp) (by simp)).2
  have hC := smooth_coefficient hr (by simpa using analytic_H)
  have hW := (LloydFlat.contDiff_angular_joint 1 X).contDiffAt (x := (0,φ))
  simp_rw [q_angular_factor]
  exact (hC.comp (0,φ) contDiffAt_fst).mul hW

private theorem smooth_integrand_at {δ x : ℝ} (hp : ContDiffAt ℝ ∞ (p δ) x)
    (hC : ContDiffAt ℝ ∞ (coefficient δ) x) : ContDiffAt ℝ ∞ (integrand δ) x := by
  have hB : ContDiff ℝ ∞ (fun t : ℝ => t⁻¹ ^ 2 * LloydFlat.bump t) := by
    convert! LloydFlat.contDiff_amplitude ((X : ℝ[X]) ^ (2 : ℕ)) using 1
    funext t
    rw [Polynomial.eval_pow,Polynomial.eval_X]
  unfold integrand
  simp_rw [q_over_height_factor]
  exact hp.sub (hC.mul hB.contDiffAt)

private theorem eventually_smooth_integrand (δ : ℝ) :
    ∀ᶠ x in 𝓝 0, ContDiffAt ℝ ∞ (integrand δ) x := by
  have hU := (smooth_u δ).continuous.continuousAt (x := 0)
  have hS := (smooth_s δ).continuous.continuousAt (x := 0)
  have hA : ContinuousAt (deltaAngle δ) 0 := by
    unfold deltaAngle
    fun_prop (disch := simp)
  have hr : Continuous radial := by unfold radial; fun_prop
  have hch : ContinuousAt (chord δ) 0 := by unfold chord; fun_prop
  have eH : ∀ᶠ x in 𝓝 0, AnalyticAt ℝ H (u δ x) := by
    exact hU.tendsto.eventually (by simpa using analytic_H.eventually_analyticAt)
  have e1 : ∀ᶠ x : ℝ in 𝓝 0, 0 < 1-x^2 :=
    (show ContinuousAt (fun x : ℝ => 1-x^2) 0 by fun_prop).tendsto.eventually_const_lt (by norm_num)
  have e2 : ∀ᶠ x : ℝ in 𝓝 0, 0 < 1-(s δ x)^2 :=
    (show ContinuousAt (fun x : ℝ => 1-(s δ x)^2) 0 by fun_prop).tendsto.eventually_const_lt (by simp)
  have e3 : ∀ᶠ x : ℝ in 𝓝 0, 0 < 1-u δ x :=
    (show ContinuousAt (fun x : ℝ => 1-u δ x) 0 by fun_prop).tendsto.eventually_const_lt (by simp)
  have e4 : ∀ᶠ x in 𝓝 0, 0 < chord δ x := hch.tendsto.eventually_const_lt (by simp)
  filter_upwards [e1,e2,e3,e4,eH] with x hx hs hu hd hH
  obtain ⟨hp,hrat⟩ := smooth_p_ratio hx hs hu hd
  exact smooth_integrand_at hp (smooth_coefficient hrat hH)

theorem smooth_integrand_zero (δ : ℝ) : ContDiffAt ℝ ∞ (integrand δ) 0 :=
  (eventually_smooth_integrand δ).self_of_nhds

private theorem measurable_integrand (δ : ℝ) : Measurable (integrand δ) := by
  have hb := smooth_bump.continuous.measurable
  unfold integrand p q ratio chord deltaAngle u s radial
  fun_prop

/-- The genuine zero-anchored primitive is smooth on an open interval around the equator. -/
theorem primitive_smooth (δ : ℝ) : ContDiffAt ℝ ∞ (primitive δ) 0 := by
  obtain ⟨a,b,h0,hI⟩ := mem_nhds_iff_exists_Ioo_subset.1 (eventually_smooth_integrand δ)
  change ∀ ⦃x : ℝ⦄, x ∈ Ioo a b → ContDiffAt ℝ ∞ (integrand δ) x at hI
  have hD : ∀ x ∈ Ioo a b, HasDerivAt (primitive δ) (integrand δ x) x := by
    intro x hx
    apply intervalIntegral.integral_hasDerivAt_right
    · apply ContinuousOn.intervalIntegrable
      intro t ht
      exact (hI (ordConnected_Ioo.uIcc_subset h0 hx ht)).continuousAt.continuousWithinAt
    · exact (measurable_integrand δ).aestronglyMeasurable.stronglyMeasurableAtFilter
    · exact (hI hx).continuousAt
  apply ContDiffOn.contDiffAt (s := Ioo a b) _ (isOpen_Ioo.mem_nhds h0)
  apply (contDiffOn_infty_iff_deriv_of_isOpen isOpen_Ioo).mpr
  constructor
  · exact fun x hx => (hD x hx).differentiableAt.differentiableWithinAt
  · exact (show ContDiffOn ℝ ∞ (integrand δ) (Ioo a b) from
      fun _ hx => (hI hx).contDiffWithinAt).congr (fun x hx => (hD x hx).deriv)

/-- The actual surface, combining the primitive and the oscillatory coefficient, is jointly
smooth at each equatorial point. -/
theorem surface_smooth (δ φ : ℝ) : ContDiffAt ℝ ∞ (surface δ) (0,φ) :=
by
  unfold surface
  have h : ContDiffAt ℝ ∞ (fun w : ℝ × ℝ => primitive δ w.1) (0,φ) := (primitive_smooth δ).comp (0,φ) contDiffAt_fst
  exact h.add (smooth_q_angular δ φ)

theorem s_eq_next {δ x : ℝ} (hx : 0 < x) : s δ x = nextHeight δ x := by
  simp [s,nextHeight,LloydFlat.bump_of_pos hx]

theorem angle_eq {δ x : ℝ} (hx : 0 < x) (hs : 0 < nextHeight δ x) :
    deltaAngle δ x = azimuth (nextHeight δ x) - azimuth x := by
  have e : 1-u δ x = s δ x /x := by unfold s u; field_simp [hx.ne']
  rw [deltaAngle,e,s_eq_next hx,Real.log_div hs.ne' hx.ne']
  unfold azimuth
  ring

/-- Exact identity with the previously checked northern chart quantities. -/
theorem agree_north {δ x : ℝ} (hx : 0 < x) (hs : 0 < nextHeight δ x) :
    p δ x = LloydLocal.p δ x ∧ q δ x = LloydLocal.q δ x ∧
      integrand δ x = LloydLocal.integrand δ x := by
  have hd : chord δ x = LloydLocal.denom δ x := by
    simp [chord,LloydLocal.denom,s_eq_next hx,angle_eq hx hs]
  have hp : p δ x = LloydLocal.p δ x := by simp [p,LloydLocal.p,s_eq_next hx,angle_eq hx hs,hd]
  have hq : q δ x = LloydLocal.q δ x := by
    simp [q,ratio,LloydLocal.q,s_eq_next hx,angle_eq hx hs,hd,div_eq_mul_inv]
    ring
  exact ⟨hp,hq, by simp [integrand,LloydLocal.integrand,hp,hq,sub_eq_add_neg]⟩

/-- Full joint regularity on a neighborhood of each zero-parameter point in the chart. -/
theorem joint_germs_eventually {δ z : ℝ} (hZ : 0 < 1-z^2) (hS : 0 < 1-(s δ z)^2)
    (hu0 : u δ z = 0) (hD : 0 < chord δ z) :
    ∀ᶠ w : ℝ × ℝ in 𝓝 (δ,z),
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => integrand v.1 v.2) w ∧
      ∀ φ : ℝ, ContDiffAt ℝ ∞
        (fun v : (ℝ × ℝ) × ℝ => q v.1.1 v.1.2 * Real.sin (v.2 + Real.log v.1.2)) (w,φ) := by
  have hL : ContDiff ℝ ∞ (fun x : ℝ => x⁻¹ * LloydFlat.bump x) := by
    simpa using LloydFlat.contDiff_amplitude (X : ℝ[X])
  have hL2 : ContDiff ℝ ∞ (fun t : ℝ => t⁻¹ ^ 2 * LloydFlat.bump t) := by
    convert! LloydFlat.contDiff_amplitude ((X : ℝ[X]) ^ (2 : ℕ)) using 1
    funext t
    rw [Polynomial.eval_pow,Polynomial.eval_X]
  have hU : ContDiff ℝ ∞ (fun w : ℝ × ℝ => u w.1 w.2) :=
    contDiff_fst.mul (hL.comp contDiff_snd)
  have hT : ContDiff ℝ ∞ (fun w : ℝ × ℝ => s w.1 w.2) :=
    contDiff_snd.sub (contDiff_fst.mul (smooth_bump.comp contDiff_snd))
  have hA : ContinuousAt (fun w : ℝ × ℝ => deltaAngle w.1 w.2) (δ,z) := by
    have h1 := hU.continuous.continuousAt (x := (δ,z))
    unfold deltaAngle; fun_prop (disch := simp [hu0])
  have hr : Continuous radial := by unfold radial; fun_prop
  have hch : ContinuousAt (fun w : ℝ × ℝ => chord w.1 w.2) (δ,z) := by
    have h1 := hT.continuous.continuousAt (x := (δ,z))
    unfold chord; fun_prop
  have hU0 := hU.continuous.continuousAt (x := (δ,z))
  have hT0 := hT.continuous.continuousAt (x := (δ,z))
  have eH : ∀ᶠ w : ℝ × ℝ in 𝓝 (δ,z), AnalyticAt ℝ H (u w.1 w.2) := by
    apply (hU.continuous.continuousAt (x := (δ,z))).tendsto.eventually
    simpa [hu0] using analytic_H.eventually_analyticAt
  have e1 : ∀ᶠ w : ℝ × ℝ in 𝓝 (δ,z), 0 < 1-w.2^2 :=
    (show ContinuousAt (fun w : ℝ × ℝ => 1-w.2^2) (δ,z) by fun_prop).tendsto.eventually_const_lt hZ
  have e2 : ∀ᶠ w : ℝ × ℝ in 𝓝 (δ,z), 0 < 1-(s w.1 w.2)^2 :=
    (show ContinuousAt (fun w : ℝ × ℝ => 1-(s w.1 w.2)^2) (δ,z) by fun_prop).tendsto.eventually_const_lt hS
  have e3 : ∀ᶠ w : ℝ × ℝ in 𝓝 (δ,z), 0 < 1-u w.1 w.2 :=
    (show ContinuousAt (fun w : ℝ × ℝ => 1-u w.1 w.2) (δ,z) by fun_prop).tendsto.eventually_const_lt (by simp [hu0])
  filter_upwards [e1,e2,e3,hch.tendsto.eventually_const_lt hD,eH] with w hw hs hu hc hH
  have hR : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => radial v.2) w := by
    unfold radial; fun_prop (disch := positivity)
  have hR' : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => radial (s v.1 v.2)) w := by
    unfold radial; fun_prop (disch := positivity)
  have ha : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => deltaAngle v.1 v.2) w := by
    unfold deltaAngle; fun_prop (disch := positivity)
  have hch' : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => chord v.1 v.2) w := by unfold chord; fun_prop
  have hp : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => p v.1 v.2) w := by
    unfold p; fun_prop (disch := first | exact (Real.sqrt_pos.mpr hw).ne' | positivity)
  have hrat : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => ratio v.1 v.2) w := by
    unfold ratio; fun_prop (disch := positivity)
  have hcoef : ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => coefficient v.1 v.2) w := by
    have hab := hH.contDiffAt (n := ∞)
    unfold coefficient; fun_prop
  constructor
  · simp_rw [integrand,q_over_height_factor]
    exact hp.sub (hcoef.mul (hL2.comp contDiff_snd).contDiffAt)
  · intro φ
    have hwave := (LloydFlat.contDiff_angular_joint 1 X).comp
      (show ContDiff ℝ ∞ (fun v : (ℝ × ℝ) × ℝ => (v.1.2,v.2)) by fun_prop)
    simp_rw [q_angular_factor]
    exact (hcoef.comp (w,φ) contDiffAt_fst).mul hwave.contDiffAt

theorem chord_zero_parameter {z : ℝ} (hz : 0 ≤ 1-z^2) : chord 0 z = 1 := by
  simp [chord,s,deltaAngle,u,radial,← pow_two,Real.sq_sqrt hz]

theorem zero_parameter_germs {z : ℝ} (hz : 0 < 1-z^2) :
    ∀ᶠ w : ℝ × ℝ in 𝓝 (0,z),
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => integrand v.1 v.2) w ∧
      ∀ φ : ℝ, ContDiffAt ℝ ∞
        (fun v : (ℝ × ℝ) × ℝ => q v.1.1 v.1.2 * Real.sin (v.2 + Real.log v.1.2)) (w,φ) :=
  joint_germs_eventually (δ := 0) hz (by simpa [s] using hz) (by simp [u])
    (by simp [chord_zero_parameter hz.le])

#print axioms zero_parameter_germs
#print axioms smooth_q_angular
#print axioms primitive_smooth
#print axioms surface_smooth
#print axioms agree_north
end LloydFlatSpiral
