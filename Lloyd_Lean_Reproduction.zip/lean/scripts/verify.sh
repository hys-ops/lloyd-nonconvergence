#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
unset LEAN_PATH
export LEAN_NUM_THREADS="${LEAN_NUM_THREADS:-2}"
lean --version
lake exe cache get
python3 scripts/audit_sources.py
lake build LloydDimension
lake env lean Audit.lean
python3 scripts/replay.py
