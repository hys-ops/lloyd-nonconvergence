#!/usr/bin/env python3
"""Replay each local module's declarations against its pinned imports."""
import concurrent.futures
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
os.chdir(root)
modules = sys.argv[1:] or Path("scripts/modules.txt").read_text().split()
def replay(name):
    result = subprocess.run(["lake", "env", "leanchecker", "-v", name],
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            env={**os.environ, "LEAN_NUM_THREADS": "1"})
    return name, result.returncode, result.stdout
errors = []
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("REPLAY_JOBS", "2"))) as pool:
    for name, code, output in pool.map(replay, modules):
        print(output.rstrip(), flush=True)
        print(name, "exit", code, flush=True)
        if code: errors.append(name)
if errors: sys.exit("Replay failed: " + ", ".join(errors))
