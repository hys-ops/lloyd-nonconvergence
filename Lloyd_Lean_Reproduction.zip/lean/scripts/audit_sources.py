"""Verify that the distributed first-party proof sources use no proof placeholders or new axioms."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
mods = (root/'scripts/modules.txt').read_text().split()
pattern = re.compile(r'\b(?:sorry|admit|axiom|unsafe|extern|native_decide|implemented_by)\b')
for mod in mods:
    file = root/(mod+'.lean')
    for i, line in enumerate(file.read_text().splitlines(), 1):
        if pattern.search(line):
            raise SystemExit(f'{file.name}:{i}: {line.strip()}')
print(f'Checked {len(mods)} local proof modules. No matches for ' + pattern.pattern + '.')
