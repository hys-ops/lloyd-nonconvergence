import SupportDerivative

/-! Support and radius of the actual normalized-volume antipodal centroid update. -/

noncomputable section
open MeasureTheory Filter Set
open scoped RealInnerProductSpace Topology
namespace LloydCentroid

lemma signedPoint_integrable (μ : Measure E) (u : E) (hi : Integrable (id : E → E) μ) :
    Integrable (signedPoint u) μ := by
  classical
  have heq : signedPoint u = (positive u).piecewise id (-id) := by
    funext x
    by_cases h : 0 < ⟪x,u⟫ <;> simp [positive,Set.piecewise,signedPoint,h]
  rw [heq]
  exact Integrable.piecewise (positive_meas u) hi.integrableOn hi.neg.integrableOn

@[simp] lemma norm_signedPoint (u x : E) : ‖signedPoint u x‖ = ‖x‖ := by
  by_cases h : 0 < ⟪x,u⟫ <;> simp [signedPoint,h]

/-- A signed centroid gives a simultaneous supporting linear functional in every direction. -/
theorem inner_signedMoment_le (μ : Measure E) (u v : E) (hi : Integrable (id : E → E) μ) :
    ⟪v,signedMoment μ u⟫ ≤ populationSupport μ v := by
  change innerSL ℝ v (∫ x, signedPoint u x ∂μ) ≤ _
  rw [← (innerSL ℝ v).integral_comp_comm (signedPoint_integrable μ u hi)]
  apply integral_mono ((innerSL ℝ v).integrable_comp (signedPoint_integrable μ u hi))
  · simpa only [Real.norm_eq_abs,id_eq,innerSL_apply_apply,real_inner_comm v _] using
      ((innerSL ℝ v).integrable_comp hi).norm
  · intro x
    by_cases h : 0 < ⟪x,u⟫
    · simpa [signedPoint,h,real_inner_comm v x] using le_abs_self ⟪x,v⟫
    · simpa [signedPoint,h,real_inner_comm v x] using neg_le_abs ⟪x,v⟫

/-- This bound holds even in the presence of ties. -/
theorem norm_signedMoment_le (μ : Measure E) (u : E) :
    ‖signedMoment μ u‖ ≤ ∫ x : E, ‖x‖ ∂μ := by
  simpa only [signedMoment,norm_signedPoint] using
    (norm_integral_le_integral_norm (signedPoint u) (μ := μ))

lemma uniform_id_integrable (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) :
    Integrable (id : E → E) (uniformOn K) := by
  have h : Integrable (id : E → E) (volume.restrict K) := continuous_id.continuousOn.integrableOn_compact compact
  exact h.smul_measure (ENNReal.inv_ne_top.mpr volpos)

lemma uniform_probability (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) :
    IsProbabilityMeasure (uniformOn K) :=
  ProbabilityTheory.cond_isProbabilityMeasure_of_finite volpos compact.measure_lt_top.ne

lemma uniform_no_ties (K : Set E) (u : E) (hu : u ≠ 0) :
    uniformOn K {x | ⟪x,u⟫ = 0} = 0 :=
  no_ties_of_ac _ ProbabilityTheory.cond_absolutelyContinuous u hu

/-- On the unit sphere a compact positive-volume source has a uniform positive support. -/
theorem uniform_support_lower (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) :
    ∃ m : ℝ, 0 < m ∧ ∀ u : E, ‖u‖ = 1 → m ≤ populationSupport (uniformOn K) u := by
  let _ := uniform_probability K compact volpos
  have hi := uniform_id_integrable K compact volpos
  let S := Metric.sphere (0 : E) 1
  have unit {v : E} (hv : v ∈ S) : ‖v‖ = 1 := by simpa [S,Metric.mem_sphere] using hv
  have nz {v : E} (hv : v ∈ S) : v ≠ 0 := by intro h; simpa [h] using unit hv
  rcases S.eq_empty_or_nonempty with hs | hs
  · refine ⟨1, zero_lt_one, fun v hv => ?_⟩
    have hm : v ∈ S := by simpa [S,Metric.mem_sphere] using hv
    simp [hs] at hm
  have hc : ContinuousOn (populationSupport (uniformOn K)) S := fun v hv =>
    (signedMoment_hasGradientAt _ v (uniform_no_ties K v (nz hv)) hi).hasFDerivAt.continuousAt.continuousWithinAt
  obtain ⟨v,hv,hmin⟩ := (isCompact_sphere (0 : E) 1).exists_isMinOn hs hc
  refine ⟨_,populationSupport_pos _ v (uniform_no_ties K v (nz hv)) hi,fun u hu => ?_⟩
  apply hmin
  simpa [S,Metric.mem_sphere] using hu

/-- An integrable source gives a continuous signed centroid at every null-tie direction. -/
theorem continuousAt_signedMoment (μ : Measure E) (u : E) (hi : Integrable (id : E → E) μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) : ContinuousAt (signedMoment μ) u := by
  apply tendsto_integral_filter_of_dominated_convergence (fun x : E => ‖x‖)
    (.of_forall fun v => (signedPoint_integrable μ v hi).aestronglyMeasurable)
    (.of_forall fun v => .of_forall fun x => (norm_signedPoint v x).le) hi.norm
  have ht' : ∀ᵐ x ∂μ, ⟪x,u⟫ ≠ 0 := by
    apply ae_iff.mpr
    simpa only [not_not] using ht
  filter_upwards [ht'] with x hx
  have hcont : ContinuousAt (fun v : E => ⟪x,v⟫) u := (continuous_const.inner continuous_id).continuousAt
  rcases lt_or_gt_of_ne hx with hneg | hpos
  · have ev := hcont.tendsto.eventually (Iio_mem_nhds hneg)
    rw [show signedPoint u x = -x by simp [signedPoint,not_lt.mpr hneg.le]]
    apply tendsto_const_nhds.congr'
    filter_upwards [ev] with v hv
    have hv' : ⟪x,v⟫ < 0 := hv
    simp [signedPoint,not_lt.mpr hv'.le]
  · have ev := hcont.tendsto.eventually (Ioi_mem_nhds hpos)
    rw [show signedPoint u x = x by simp [signedPoint,hpos]]
    apply tendsto_const_nhds.congr'
    filter_upwards [ev] with v hv
    have hv' : 0 < ⟪x,v⟫ := hv
    simp [signedPoint,hv']

/-- A compactness formulation independent of angular coordinates. A trajectory can rotate
forever while its distance in height from the equator vanishes. -/
theorem radius_tendsto_on_level (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (height : E → ℝ) (hheight : Continuous height) (u : ℕ → E) (unit : ∀ n, ‖u n‖ = 1)
    (level : Tendsto (fun n => height (u n)) atTop (𝓝 0)) (c : ℝ)
    (flat : ∀ v : E, ‖v‖ = 1 → height v = 0 →
      populationSupport (uniformOn K) v = c ∧ tangentLogSupport (uniformOn K) v = 0) :
    Tendsto (fun n => ‖signedMoment (uniformOn K) (u n)‖) atTop (𝓝 c) := by
  have hi := uniform_id_integrable K compact volpos
  let _ := uniform_probability K compact volpos
  apply Filter.tendsto_of_subseq_tendsto
  intro φ hφ
  have hmem (n : ℕ) : u (φ n) ∈ Metric.sphere (0 : E) 1 := by
    simpa [Metric.mem_sphere] using unit (φ n)
  obtain ⟨v,hv,ψ,hψ,hl⟩ := (isCompact_sphere (0 : E) 1).tendsto_subseq hmem
  have hv1 : ‖v‖ = 1 := by simpa [Metric.mem_sphere] using hv
  have hv0 : v ≠ 0 := by intro h; simp [h] at hv1
  have hlev : height v = 0 := tendsto_nhds_unique (hheight.continuousAt.tendsto.comp hl)
    (level.comp (hφ.comp hψ.tendsto_atTop))
  have hf := flat v hv1 hlev
  have hp := populationSupport_pos _ v (uniform_no_ties K v hv0) hi
  have hc : 0 < c := hf.1 ▸ hp
  have hver : signedMoment (uniformOn K) v = c • v := by
    calc signedMoment (uniformOn K) v = populationSupport (uniformOn K) v •
          (v + tangentLogSupport (uniformOn K) v) := by simp [tangentLogSupport,smul_smul,hp.ne']
         _ = c • v := by rw [hf.1,hf.2,add_zero]
  have hnorm : ‖signedMoment (uniformOn K) v‖ = c := by
    simp [hver,norm_smul,hv1,Real.norm_eq_abs,abs_of_pos hc]
  refine ⟨ψ,?_⟩
  rw [← hnorm]
  exact (continuousAt_signedMoment _ v hi (uniform_no_ties K v hv0)).norm.tendsto.comp hl

#print axioms continuousAt_signedMoment
#print axioms radius_tendsto_on_level
#print axioms inner_signedMoment_le
#print axioms norm_signedMoment_le
#print axioms uniform_support_lower
end LloydCentroid
