import NDLimitsTransfer
import NDLimitsDirections
import NDLimitsInterior
import NDGeoRealize

/-! User-facing predicates for exact unordered two-site dynamics in arbitrary dimension. -/
noncomputable section
open MeasureTheory Set Filter Topology TopologicalSpace
open scoped RealInnerProductSpace
namespace LloydNDMain
open LloydNDFrame LloydNDLimits

abbrev trajectory {m : ℕ} (μ : Measure (E m)) (y : E m) (n : ℕ) :=
  (LloydProduct.step μ)^[n] (y,-y)

/-- All and only the equatorial unordered axes at one positive radius occur,
every one is stationary, and the full sequence has no limit. -/
def ProjectiveOrbit {m:ℕ} (μ : Measure (E (m+1))) (y : E (m+1)) : Prop :=
  ∃ c : ℝ, 0<c ∧
    (∀ P : NonemptyCompacts (E (m+1)),
      MapClusterPt P atTop (fun n => LloydProduct.unordered (trajectory μ y n)) ↔
      ∃ w:E m, ‖w‖=1 ∧ P=axis (c • equator w)) ∧
    (∀ w:E m, ‖w‖=1 → let x:=c • equator w; LloydProduct.step μ (x,-x)=(x,-x)) ∧
    ¬∃ P, Tendsto (fun n=>LloydProduct.unordered (trajectory μ y n)) atTop (𝓝 P)

/-- Along the displayed trajectory, every optimal equal-mass coupling exists
and takes exactly the same next step; both actual sites are interior. -/
def InteriorBalanced {m:ℕ} (K:Set (E m)) (y:E m) : Prop :=
  ∀ n : ℕ, let Y := trajectory (uniformOn K) y n
    Y.1 ∈ interior K ∧ Y.2 ∈ interior K ∧ ∀ p, IsBalancedStep (uniformOn K) Y.1 p ↔
      p = trajectory (uniformOn K) y (n+1)

/-- Compact body, explicit geometric regularity and closeness, with a genuine
interior initialization for both unconstrained and equal-mass Lloyd. -/
def UniformExample {m:ℕ} (k:ℕ) (ε:ℝ) (K : Set (E (m+1))) (y : E (m+1)) : Prop :=
  IsCompact K ∧ 0 < volume K ∧ (∀ x, -x ∈ K ↔ x ∈ K) ∧
  StrictConvex ℝ K ∧ LloydNDGeom.HasPositiveCurvedBoundary K ∧
  Metric.closedBall (0:E (m+1)) (1/2:ℝ) ⊆ K ∧
  IsProbabilityMeasure (uniformOn K) ∧ LloydNDGeom.NearRound K k ε ∧
  ProjectiveOrbit (uniformOn K) y ∧ InteriorBalanced K y

set_option maxHeartbeats 1000000 in
theorem projective_no_limit {k:ℕ} {c:ℝ} (hc : 0<c)
    {s : ℕ → NonemptyCompacts (E (k+3))}
    (h : ∀ w:E (k+2), ‖w‖=1 → MapClusterPt (axis (c • equator w)) atTop s) :
    ¬∃ P, Tendsto s atTop (𝓝 P) := by
  let i : Fin (k+2) := 0
  let j : Fin (k+2) := ⟨1,by omega⟩
  let a : E (k+2) := EuclideanSpace.single i (1:ℝ)
  let b : E (k+2) := EuclideanSpace.single j (1:ℝ)
  have ha : ‖a‖=1 := (PiLp.norm_single 2 (fun _:Fin (k+2) => ℝ) i (1:ℝ)).trans norm_one
  have hb : ‖b‖=1 := (PiLp.norm_single 2 (fun _:Fin (k+2) => ℝ) j (1:ℝ)).trans norm_one
  rintro ⟨P,hP⟩
  have eqP (w:E (k+2)) (hw:‖w‖=1) : axis (c • equator w)=P := by
    obtain ⟨j,hj,hlim⟩ := (h w hw).tendsto_subseq
    exact tendsto_nhds_unique hlim (hP.comp hj.tendsto_atTop)
  have eqA := eqP a ha
  have eqB := eqP b hb
  have mem : c • equator a ∈ (axis (c • equator a):Set _) := by simp [axis,LloydProduct.unordered]
  rw [eqA,←eqB] at mem
  simp only [axis,LloydProduct.unordered,NonemptyCompacts.coe_sup,NonemptyCompacts.coe_singleton,
    mem_union,mem_singleton_iff] at mem
  have hji : j ≠ i := by intro hh; have hh' := congrArg Fin.val hh; simp [i,j] at hh'
  rcases mem with he | he <;>
    have hv := congrArg (fun v : E (k+3) => v i.succ) he <;>
    simpa [a,b,equator,pack,EuclideanSpace.single_apply,hji,hji.symm,hc.ne'] using hv

theorem projective_from_steps {k : ℕ} {μ : Measure (E (k+3))} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x:E (k+3)=>-x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E (k+3)→E (k+3)) μ)
    {u : ℕ → E (k+3)} (hu : ∀ n, ‖u n‖=1)
    (hstep : ∀ n,signedMoment μ (u n)=‖signedMoment μ (u n)‖ • u (n+1))
    (hB : ∀ v, MapClusterPt v atTop u ↔ ∃ w:E (k+2), ‖w‖=1 ∧ v=equator w)
    {r₀ : ℝ} (hr : 0<r₀) :
    ProjectiveOrbit μ (r₀ • u 0) := by
  let B : Set (E (k+3)) := {v | ∃ w:E (k+2), ‖w‖=1 ∧ v=equator w}
  obtain ⟨c,hc,hAll,hFix⟩ := exact_orbit hsym hac hi hu hstep (B:=B) hB hr
  refine ⟨c,hc,?_,?_,?_⟩
  · intro P
    change MapClusterPt P atTop (fun n => LloydProduct.unordered (orbitSites μ u r₀ n)) ↔ _
    rw [hAll]
    constructor
    · rintro ⟨v,⟨w,hw,rfl⟩,hp⟩
      exact ⟨w,hw,hp⟩
    · rintro ⟨w,hw,rfl⟩
      exact ⟨equator w, ⟨w,hw,rfl⟩,rfl⟩
  · exact fun w hw => hFix _ ⟨w,hw,rfl⟩
  · exact projective_no_limit hc fun w hw => (hAll _).mpr ⟨equator w,⟨w,hw,rfl⟩,rfl⟩

theorem uniform_symmetric {m:ℕ} {K:Set (E m)} (hK : IsCompact K)
    (symm : ∀ x, -x∈K ↔ x∈K) :
    MeasurePreserving (fun x : E m => -x) (uniformOn K) (uniformOn K) := by
  have h0 : (fun x:E m => -x) ⁻¹' K = K := Set.ext symm
  have hneg : MeasurePreserving (fun x:E m=>-x) volume volume :=
    (LinearIsometryEquiv.neg ℝ : E m ≃ₗᵢ[ℝ] E m).measurePreserving
  have hm := hneg.restrict_preimage hK.measurableSet
  rw [h0] at hm
  refine ⟨measurable_neg,?_⟩
  unfold uniformOn ProbabilityTheory.cond
  rw [Measure.map_smul _ measurable_neg.aemeasurable, hm.map_eq]

theorem interior_balanced {m:ℕ} {K:Set (E (m+1))} (hK : IsCompact K)
    (hp : 0<volume K) (hs : StrictConvex ℝ K) (hn : ∀ x, -x∈K ↔ x∈K)
    (hball : Metric.closedBall (0:E (m+1)) (1/2:ℝ) ⊆ K)
    {u : E (m+1)} (hu:‖u‖=1) : InteriorBalanced K ((1/4:ℝ) • u) := by
  have h := closedBall_interior_start hball (by norm_num : 0<(1/4:ℝ)) (by norm_num) hu
  have nz : u≠0 := by intro h; simpa [h] using hu
  intro n
  have hh := uniform_orbit_interior_balanced hK hp.ne' hs hn (smul_ne_zero (by norm_num : (1/4:ℝ)≠0) nz) h.1 n
  simpa only [trajectory, Function.iterate_succ_apply'] using hh

#print axioms projective_from_steps
#print axioms interior_balanced
end LloydNDMain
