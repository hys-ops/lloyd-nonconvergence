import NDPolar
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Convex.Strong
import Mathlib.Analysis.Convex.Strict

open Set
open scoped RealInnerProductSpace
namespace LloydNDGeom
noncomputable section
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim

/-- The unit Hessian margin converts an actual C² ambient perturbation of the squared
norm into a strongly convex defining function. The underlying norm in the Hessian
hypothesis is the iterated operator norm. -/
theorem strong_quadratic_perturbation {b : Vn → ℝ} (hb : ContDiff ℝ 2 b)
    (hh : ∀ x, ‖fderiv ℝ (fderiv ℝ b) x‖ ≤ 1) :
    StrongConvexOn univ 1 (fun x : Vn => ‖x‖^2 - b x) := by
  rw [strongConvexOn_iff_convex]
  let F := fun x : Vn => ‖x‖^2 / 2 - b x
  suffices hc : ConvexOn ℝ univ F by
    convert hc using 2
    dsimp [F]
    ring
  refine ⟨convex_univ,?_⟩
  intro x _ y _ a c ha hc hac
  let v := y-x
  let p := fun t : ℝ => x+t • v
  let G := fun t : ℝ => ‖x‖^2/2 + t*⟪x,v⟫ + t^2/2*‖v‖^2 - b (p t)
  let G' := fun t : ℝ => ⟪x,v⟫ + t*‖v‖^2 - fderiv ℝ b (p t) v
  let G'' := fun t : ℝ => ‖v‖^2 - (fderiv ℝ (fderiv ℝ b) (p t) v) v
  have hp (t : ℝ) : HasDerivAt p v t := by
    simpa [p] using ((hasDerivAt_id t).smul_const v).const_add x
  have hb' := (hb.fderiv_right (m := 1) (by norm_num)).differentiable (by norm_num)
  have hG (t : ℝ) : HasDerivAt G (G' t) t := by
    have h0 := (hb.differentiable (by norm_num) (p t)).hasFDerivAt.comp_hasDerivAt t (hp t)
    have h1 : HasDerivAt (fun t : ℝ => ‖x‖^2/2 + t*⟪x,v⟫ + t^2/2*‖v‖^2)
        (⟪x,v⟫ + t*‖v‖^2) t := by
      have h2 := (((hasDerivAt_id t).pow 2).div_const 2).mul_const (‖v‖^2)
      have h3 := (((hasDerivAt_id t).mul_const ⟪x,v⟫).const_add (‖x‖^2/2)).add h2
      convert! h3 using 1
      simp
    exact h1.sub h0
  have hG' (t : ℝ) : HasDerivAt G' (G'' t) t := by
    have hz := (hb' (p t)).hasFDerivAt.comp_hasDerivAt t (hp t)
    have hv := hz.clm_apply (hasDerivAt_const t v)
    have hlin : HasDerivAt (fun t : ℝ => ⟪x,v⟫ + t*‖v‖^2) (‖v‖^2) t := by
      simpa using ((hasDerivAt_id t).mul_const (‖v‖^2)).const_add ⟪x,v⟫
    convert! hlin.sub hv using 1
    simp [G'']
  have hnon (t : ℝ) : 0 ≤ G'' t := by
    let H := fderiv ℝ (fderiv ℝ b) (p t)
    have h : H v v ≤ ‖v‖ ^ 2 := calc
      _ ≤ ‖H v v‖ := Real.le_norm_self _
      _ ≤ ‖H v‖ * ‖v‖ := (H v).le_opNorm v
      _ ≤ (‖H‖ * ‖v‖) * ‖v‖ := by gcongr; exact H.le_opNorm v
      _ ≤ (1 * ‖v‖) * ‖v‖ := by gcongr; exact hh (p t)
      _ = _ := by ring
    exact sub_nonneg.mpr h
  have hd : deriv G = G' := funext fun t => (hG t).deriv
  have hcv := convexOn_univ_of_deriv2_nonneg (fun t => (hG t).differentiableAt)
    (hd ▸ (fun t => (hG' t).differentiableAt)) (fun t => by
      change 0 ≤ deriv (deriv G) t
      rw [hd,(hG' t).deriv]
      exact hnon t)
  have hform (t : ℝ) : G t = F (p t) := by
    simp [G,F,p,norm_add_sq_real,real_inner_smul_right,norm_smul,mul_pow]
    ring_nf
  have hline : p c = a • x + c • y := by
    dsimp [p,v]
    rw [show a = 1-c by linarith]
    module
  have h := hcv.2 (show (0:ℝ) ∈ univ by trivial) (show (1:ℝ) ∈ univ by trivial) ha hc hac
  simp only [smul_eq_mul,mul_zero,mul_one,zero_add,hform] at h
  rw [hline] at h
  simpa [p,v] using h

#print axioms strong_quadratic_perturbation
end
end LloydNDGeom
