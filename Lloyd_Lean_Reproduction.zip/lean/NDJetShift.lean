import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Tactic
noncomputable section
open scoped SchwartzMap ContDiff Topology
open Filter Set Function
namespace LloydNDJet
abbrev X := ℝ × ℝ
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

def BoundedJets (f : ℝ → E) : Prop := ContDiff ℝ ∞ f ∧ ∀ j : ℕ, ∃ C : ℝ, ∀ t, ‖iteratedFDeriv ℝ j f t‖ ≤ C

theorem BoundedJets.temperate {f : ℝ → E} (hf : BoundedJets f) : HasTemperateGrowth f :=
  ⟨hf.1, fun j => by obtain ⟨C,h⟩ := hf.2 j; exact ⟨0,C,by simpa using h⟩⟩

theorem BoundedJets.derivative {f : ℝ → E} (hf : BoundedJets f) : BoundedJets (deriv f) := by
  refine ⟨(contDiff_infty_iff_deriv.mp hf.1).2, fun n => ?_⟩
  obtain ⟨C,h⟩ := hf.2 (n+1)
  exact ⟨C, fun t => by simpa only [norm_iteratedFDeriv_eq_norm_iteratedDeriv,iteratedDeriv_succ'] using h t⟩

def clock : X →L[ℝ] ℝ := ContinuousLinearMap.snd ℝ ℝ ℝ
def shift (f : ℝ → E) (b : 𝓢(X,ℝ)) (x : X) := f (clock x + b x) - f (clock x)

theorem shift_smooth {f : ℝ → E} (hf : ContDiff ℝ ∞ f) (b : 𝓢(X,ℝ)) : ContDiff ℝ ∞ (shift f b) :=
  (hf.comp (clock.contDiff.add (b.smooth ⊤))).sub (hf.comp clock.contDiff)

private def derivativeResidue (f : ℝ → E) (hf : BoundedJets f) (b : 𝓢(X,ℝ)) : 𝓢(X, X →L[ℝ] E) :=
  SchwartzMap.bilinLeftCLM (ContinuousLinearMap.smulRightL ℝ X E)
    (hf.derivative.temperate.comp (clock.hasTemperateGrowth.add b.hasTemperateGrowth))
    (SchwartzMap.fderivCLM ℝ X ℝ b)

private theorem fderiv_shift {f : ℝ → E} (hf : BoundedJets f) (b : 𝓢(X,ℝ)) :
    fderiv ℝ (shift f b) = (ContinuousLinearMap.smulRightL ℝ X E clock) ∘ (shift (deriv f) b)
      + (derivativeResidue f hf b : X → X →L[ℝ] E) := by
  funext x
  have d1 := ((hf.1.differentiable (by simp) _).hasDerivAt.hasFDerivAt).comp x
    (clock.hasFDerivAt.add (b.differentiableAt (x:=x)).hasFDerivAt)
  have d0 := ((hf.1.differentiable (by simp) _).hasDerivAt.hasFDerivAt).comp x clock.hasFDerivAt
  change fderiv ℝ (f ∘ ((clock : X → ℝ) + (b : X → ℝ)) - f ∘ (clock : X → ℝ)) x = _
  rw [(d1.sub d0).fderiv]
  apply ContinuousLinearMap.ext
  intro y
  change (clock y + fderiv ℝ b x y) • deriv f (clock x + b x) - clock y • deriv f (clock x) = clock y • (deriv f (clock x+b x)-deriv f (clock x)) + (fderiv ℝ b x y) • deriv f (clock x+b x)
  rw [add_smul,smul_sub]; abel

private theorem shift_decay (n k : ℕ) (b : 𝓢(X,ℝ)) (f : ℝ → E) (hf : BoundedJets f) :
    ∃ C:ℝ, ∀ x : X, ‖x‖^k * ‖iteratedFDeriv ℝ n (shift f b) x‖ ≤ C := by
  induction n generalizing f with
  | zero =>
    obtain ⟨C,hC⟩ := hf.derivative.2 0
    have hC' (t:ℝ) : ‖deriv f t‖ ≤ C := by simpa using hC t
    obtain ⟨M,_,hM⟩ := b.decay k 0
    refine ⟨C*M, fun x => ?_⟩
    simp only [norm_iteratedFDeriv_zero] at hM ⊢
    have lip := (convex_univ : Convex ℝ (univ:Set ℝ)).norm_image_sub_le_of_norm_deriv_le
      (fun t _ => hf.1.differentiable (by simp) t) (fun t _ => hC' t)
      (mem_univ (clock x)) (mem_univ (clock x + b x))
    simp only [add_sub_cancel_left] at lip
    have cp := (norm_nonneg _).trans (hC' 0)
    unfold shift
    calc _ ≤ ‖x‖^k * (C*‖b x‖) := mul_le_mul_of_nonneg_left (by simpa using lip) (by positivity)
         _ = C*(‖x‖^k * ‖b x‖) := by ring
         _ ≤ _ := mul_le_mul_of_nonneg_left (hM x) cp
  | succ n ih =>
    let L := ContinuousLinearMap.smulRightL ℝ X E clock
    let g := shift (deriv f) b
    let r := derivativeResidue f hf b
    have hg : ContDiff ℝ ∞ g := shift_smooth hf.derivative.1 _
    obtain ⟨B,hB⟩ := ih (deriv f) hf.derivative
    obtain ⟨C,_,hC⟩ := r.decay k n
    refine ⟨‖L‖*B+C, fun x => ?_⟩
    rw [←norm_iteratedFDeriv_fderiv, fderiv_shift hf b]
    change ‖x‖^k * ‖iteratedFDeriv ℝ n ((L ∘ g) + (r : X → _)) x‖ ≤ _
    rw [iteratedFDeriv_add_apply ((L.contDiff.comp hg).of_le (by simp)).contDiffAt (r.contDiffAt n)]
    rw [L.iteratedFDeriv_comp_left hg.contDiffAt (by simp)]
    calc _ ≤ ‖x‖^k * (‖L‖ * ‖iteratedFDeriv ℝ n g x‖ + ‖iteratedFDeriv ℝ n r x‖) := by
              apply mul_le_mul_of_nonneg_left _ (by positivity)
              exact (norm_add_le _ _).trans (add_le_add_left (L.norm_compContinuousMultilinearMap_le _) _)
         _ = ‖L‖ * (‖x‖^k * ‖iteratedFDeriv ℝ n g x‖) + ‖x‖^k * ‖iteratedFDeriv ℝ n r x‖ := by ring
         _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left (hB x) (norm_nonneg L)) (hC x)

def shiftedDifference (f : ℝ → E) (hf : BoundedJets f) (b : 𝓢(X,ℝ)) : 𝓢(X,E) where
  toFun := shift f b
  smooth' := shift_smooth hf.1 b
  decay' k n := shift_decay n k b f hf
end LloydNDJet
