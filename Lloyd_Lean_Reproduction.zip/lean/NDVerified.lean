import NDMainBalanced
import NDProjectiveExample

/-! Common witnesses for every assertion: physical sources, optimal equal-mass
updates on their actual orbits, and the topology of the sets of cluster configurations. -/
noncomputable section
open MeasureTheory Set
namespace LloydNDVerified
open LloydNDFrame LloydNDMain LloydNDLimits LloydNDProjective

def SolverAndLimits {k : ℕ} (μ : Measure (E (k+3))) (y : E (k+3)) : Prop :=
  BalancedOrbit μ y ∧ Nonempty (RealProjective (k+2) ≃ₜ clusterSet μ y)

/-- With only a dimension index, derivative order, and positive tolerance as inputs,
one common pair of sites and three actual sources have the full projective cluster set. -/
theorem projective_lloyd (k m : ℕ) (ε : ℝ) (hε : 0<ε) :
    ∃ (K : Set (E (k+3))) (ρ σ : E (k+3) → ℝ) (y : E (k+3)),
      JointExample m ε K ρ σ y ∧
      SolverAndLimits (uniformOn K) y ∧
      SolverAndLimits (LloydNDGaussian.law ρ) y ∧
      SolverAndLimits (LloydNDGaussian.law σ) y := by
  obtain ⟨K,ρ,σ,y,H,hb,hg,hs⟩ := projective_equator_all_solvers k m ε hε
  obtain ⟨_,_,_,_,_,_,_,_,hu,_⟩ := H.uniform
  exact ⟨K,ρ,σ,y,H,⟨hb,cluster_homeomorphic hu⟩,
    ⟨hg,cluster_homeomorphic H.gaussian_orbit⟩,⟨hs,cluster_homeomorphic H.compact_orbit⟩⟩

#print axioms projective_lloyd
end LloydNDVerified
