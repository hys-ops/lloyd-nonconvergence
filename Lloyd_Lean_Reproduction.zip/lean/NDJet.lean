import NDJetKick
import NDJetPotential
import NDClock

/-! Ambient smooth even log-moment realizing each discrete chord of any bounded-jet
unit trajectory whose height is reciprocal time on its positive tail. -/
noncomputable section
open Function Set Filter
open scoped ContDiff Topology RealInnerProductSpace
namespace LloydNDJet
open LloydNDFrame LloydNDClock
variable {m : ℕ}
local notation "V" => LloydNDFrame.E (m+1)

def logProfile (P : ℝ → V) (hP : BoundedJets P) (p : ℝ × V) : ℝ :=
  LloydNDPotential.potential (kicks P hP increment) P hP.temperate p.1 p.2

theorem profile_smooth (P : ℝ → V) (hP : BoundedJets P) : ContDiff ℝ ∞ (logProfile P hP) :=
  LloydNDPotential.smooth _ _ _

theorem profile_zero (P : ℝ → V) (hP : BoundedJets P) (x : V) : logProfile P hP (0,x)=0 :=
  LloydNDPotential.zero_parameter _ _ _ (fun t => kicks_zero _ _ _ _ (by simp)) x

theorem profile_even (P : ℝ → V) (hP : BoundedJets P) (δ : ℝ) (x : V) :
    logProfile P hP (δ,-x) = logProfile P hP (δ,x) := LloydNDPotential.even _ _ _ _ _

theorem profile_seam (P : ℝ → V) (hP : BoundedJets P) (δ : ℝ) {x:V} (hx : head x=0) :
    logProfile P hP (δ,x)=0 ∧ HasFDerivAt (fun v => logProfile P hP (δ,v)) (0 : V →L[ℝ] ℝ) x :=
  ⟨LloydNDPotential.seam_value _ _ _ _ hx,LloydNDPotential.seam_derivative _ _ _ _ hx⟩

theorem profile_exact (P : ℝ → V) (hP : BoundedJets P)
    (hunit : ∀ T:ℝ, 8 ≤ T → ‖P T‖=1) (hhead : ∀ T:ℝ, 8 ≤ T → head (P T) = T⁻¹) :
    ∃ ε:ℝ, 0<ε ∧ ∀ δ:ℝ, 0<δ → δ≤ε → ∀ T:ℝ, 8≤T →
      let U := P T
      let V' := P (T + increment (δ,T))
      0 < ⟪U,V'⟫ ∧
      HasFDerivAt (fun v => logProfile P hP (δ,v)) (innerSL ℝ (LloydNDSpiral.kick U V')) U := by
  obtain ⟨ε,he,hclose⟩ := uniformly_close P hP
  refine ⟨ε,he,fun δ hd hδε T hT => ?_⟩
  have Ti : 0<T := by linarith
  have inc : |increment (δ,T)| ≤ ε := by
    rw [increment_apply, abs_of_pos (mul_pos hd (Real.exp_pos _))]
    exact (mul_le_of_le_one_right hd.le (Real.exp_le_one_iff.mpr (by nlinarith [sq_nonneg T,sq_nonneg δ]))).trans hδε
  obtain ⟨hpos, heq⟩ := kicks_exact P hP increment (δ,T) (hunit T hT) (hclose T _ inc)
  refine ⟨hpos,?_⟩
  have headPos : 0 < head (P T) := (hhead T hT) ▸ inv_pos.mpr Ti
  have hh : (head (P T))⁻¹ = T := by rw [hhead T hT,inv_inv]
  have h := LloydNDPotential.track_derivative (kicks P hP increment) P hP.temperate δ headPos (by rw [hh])
  rw [hh,heq] at h
  exact h

#print axioms profile_exact
#print axioms profile_smooth
#print axioms profile_zero
#print axioms profile_seam
end LloydNDJet
