import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Topology.Sets.VietorisTopology
import Mathlib.Tactic

open Filter Topology TopologicalSpace
namespace LloydOrbit
noncomputable section

abbrev E := EuclideanSpace ℝ (Fin 3)

def xyz (x y z : ℝ) : E := WithLp.toLp 2 ![x,y,z]

def direction (z a : ℝ) : E :=
  xyz (Real.sqrt (1-z^2) * Real.cos a) (Real.sqrt (1-z^2) * Real.sin a) z

def equator (a : ℝ) : E := xyz (Real.cos a) (Real.sin a) 0

/-- Forget the labels, with the usual compact-set topology. -/
def antipodes (x : E) : NonemptyCompacts E :=
  ({x} : NonemptyCompacts E) ⊔ ({-x} : NonemptyCompacts E)

theorem continuous_antipodes : Continuous antipodes :=
  NonemptyCompacts.continuous_singleton.sup
    (NonemptyCompacts.continuous_singleton.comp continuous_neg)

theorem tendsto_xyz {x y z : ℕ → ℝ} {x₀ y₀ z₀ : ℝ}
    (hx : Tendsto x atTop (𝓝 x₀)) (hy : Tendsto y atTop (𝓝 y₀))
    (hz : Tendsto z atTop (𝓝 z₀)) :
    Tendsto (fun n => xyz (x n) (y n) (z n)) atTop (𝓝 (xyz x₀ y₀ z₀)) := by
  apply (PiLp.continuous_toLp 2 (fun _ : Fin 3 => ℝ)).continuousAt.tendsto.comp
  apply tendsto_pi_nhds.mpr
  intro i
  fin_cases i
  · exact hx
  · exact hy
  · exact hz

theorem cos_sin_surj {u v : ℝ} (h : u^2+v^2=1) :
    ∃ θ : ℝ, Real.cos θ = u ∧ Real.sin θ = v := by
  have hl : -1 ≤ u := by nlinarith [sq_nonneg v, sq_nonneg (u+1)]
  have hu : u ≤ 1 := by nlinarith [sq_nonneg v, sq_nonneg (u-1)]
  have he : 1-u^2=v^2 := by linarith
  by_cases hv : 0 ≤ v
  · refine ⟨Real.arccos u, Real.cos_arccos hl hu, ?_⟩
    rw [Real.sin_arccos, he, Real.sqrt_sq_eq_abs, abs_of_nonneg hv]
  · refine ⟨-Real.arccos u, by simp [Real.cos_arccos hl hu], ?_⟩
    rw [Real.sin_neg, Real.sin_arccos, he, Real.sqrt_sq_eq_abs, abs_of_neg (lt_of_not_ge hv), neg_neg]

theorem tendsto_direction {z a : ℕ → ℝ} {u v : ℝ}
    (hz : Tendsto z atTop (𝓝 0))
    (hu : Tendsto (fun n => Real.cos (a n)) atTop (𝓝 u))
    (hv : Tendsto (fun n => Real.sin (a n)) atTop (𝓝 v)) :
    Tendsto (fun n => direction (z n) (a n)) atTop (𝓝 (xyz u v 0)) := by
  have hb : Tendsto (fun n => Real.sqrt (1 - z n ^ 2)) atTop (𝓝 1) := by
    simpa using ((tendsto_const_nhds (x := (1:ℝ))).sub (hz.pow 2)).sqrt
  exact tendsto_xyz (by simpa using hb.mul hu) (by simpa using hb.mul hv) hz

/-- Two perpendicular axes remain distinct after forgetting the signs. -/
theorem equatorial_axes_ne {c : ℝ} (hc : c ≠ 0) :
    antipodes (c • equator 0) ≠ antipodes (c • equator (Real.pi/2)) := by
  intro he
  have mem0 : c • equator 0 ∈ (antipodes (c • equator 0) : Set E) := by
    simp [antipodes]
  rw [he] at mem0
  simp only [antipodes, NonemptyCompacts.coe_sup, NonemptyCompacts.coe_singleton,
    Set.mem_union, Set.mem_singleton_iff] at mem0
  rcases mem0 with hm | hm <;>
    have hp := congrArg (fun v : E => v 0) hm <;>
    simp [equator, xyz] at hp <;> exact hc hp

/-- Every angular limit gives an actual limit of unordered configurations. -/
theorem all_axes {z a r : ℕ → ℝ} {c : ℝ}
    (hz : Tendsto z atTop (𝓝 0)) (hr : Tendsto r atTop (𝓝 c))
    (hphase : ∀ θ : ℝ, ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      Tendsto (fun n => Real.cos (a (k n))) atTop (𝓝 (Real.cos θ)) ∧
      Tendsto (fun n => Real.sin (a (k n))) atTop (𝓝 (Real.sin θ))) (θ : ℝ) :
    ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧ Tendsto
      (fun n => antipodes (r (k n) • direction (z (k n)) (a (k n)))) atTop
      (𝓝 (antipodes (c • equator θ))) := by
  obtain ⟨k,hk,hcos,hsin⟩ := hphase θ
  refine ⟨k,hk,continuous_antipodes.continuousAt.tendsto.comp ?_⟩
  exact (hr.comp hk).smul (tendsto_direction (hz.comp hk) hcos hsin)

/-- Existence of two different unordered limits rules out any single limit. -/
theorem nonconvergence_of_all_axes {s : ℕ → NonemptyCompacts E} {c : ℝ}
    (hc : c ≠ 0) (h : ∀ θ : ℝ, ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      Tendsto (s ∘ k) atTop (𝓝 (antipodes (c • equator θ)))) :
    ¬ ∃ K, Tendsto s atTop (𝓝 K) := by
  rintro ⟨K,hK⟩
  obtain ⟨k,hk,ha⟩ := h 0
  obtain ⟨m,hm,hb⟩ := h (Real.pi/2)
  exact equatorial_axes_ne hc ((tendsto_nhds_unique ha (hK.comp hk)).trans
    (tendsto_nhds_unique (hK.comp hm) hb))

/-- Any cluster configuration must lie on an equatorial axis, with the limiting radius. -/
theorem only_axes {z a r : ℕ → ℝ} {c : ℝ}
    (hz : Tendsto z atTop (𝓝 0)) (hr : Tendsto r atTop (𝓝 c))
    {K : NonemptyCompacts E}
    (hK : MapClusterPt K atTop (fun n => antipodes (r n • direction (z n) (a n)))) :
    ∃ θ : ℝ, K = antipodes (c • equator θ) := by
  obtain ⟨k,hk,h₁⟩ := hK.tendsto_subseq
  let xy := fun n => (Real.cos (a (k n)), Real.sin (a (k n)))
  have hx : ∀ n, xy n ∈ (Set.Icc (-1:ℝ) 1 ×ˢ Set.Icc (-1:ℝ) 1) :=
    fun n => ⟨⟨Real.neg_one_le_cos _,Real.cos_le_one _⟩,⟨Real.neg_one_le_sin _,Real.sin_le_one _⟩⟩
  obtain ⟨b,_,j,hj,h₂⟩ := (isCompact_Icc.prod isCompact_Icc).tendsto_subseq hx
  have hu : Tendsto (fun n => Real.cos (a (k (j n)))) atTop (𝓝 b.1) := continuous_fst.continuousAt.tendsto.comp h₂
  have hv : Tendsto (fun n => Real.sin (a (k (j n)))) atTop (𝓝 b.2) := continuous_snd.continuousAt.tendsto.comp h₂
  have ht := (hu.pow 2).add (hv.pow 2)
  simp only [Real.cos_sq_add_sin_sq] at ht
  have hb : b.1^2+b.2^2=1 := tendsto_nhds_unique ht tendsto_const_nhds
  obtain ⟨θ,hcos,hsin⟩ := cos_sin_surj hb
  refine ⟨θ,tendsto_nhds_unique (h₁.comp hj.tendsto_atTop) ?_⟩
  apply continuous_antipodes.continuousAt.tendsto.comp
  apply (hr.comp (hk.tendsto_atTop.comp hj.tendsto_atTop)).smul
  exact tendsto_direction ((hz.comp hk.tendsto_atTop).comp hj.tendsto_atTop)
    (hcos ▸ hu) (hsin ▸ hv)

end
end LloydOrbit
