import GlobalSpiral
import FlatSpiralGerms
import LloydOrbit

/-! Globally smooth even ambient potential with nonconvergent normalized spherical gradient iterates. -/
noncomputable section
open Set Filter TopologicalSpace
open scoped ContDiff Topology
namespace LloydGlobal
open LloydSpiral.Chart

def modelPotential (δ : ℝ) : E3 → ℝ :=
  evenLift (LloydFlatSpiral.primitive δ) (LloydFlatSpiral.cosCoef δ) (LloydFlatSpiral.sinCoef δ)

private def modelData {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) : SideData δ where
  A := LloydFlatSpiral.primitive δ
  B := LloydFlatSpiral.cosCoef δ
  C := LloydFlatSpiral.sinCoef δ
  offset := LloydFlatSpiral.primitive δ (1/8)
  smoothA := fun z hz => (LloydFlatSpiral.germ_smooth hd hd' hz.1 hz.2).1
  smoothB := fun z hz => (LloydFlatSpiral.germ_smooth hd hd' hz.1 hz.2).2.1
  smoothC := fun z hz => (LloydFlatSpiral.germ_smooth hd hd' hz.1 hz.2).2.2
  zero := fun z hz hn => LloydFlatSpiral.germ_zero δ hz.1 hn
  agree := by
    intro z hz
    have hb : z ∈ LloydLocal.belt := ⟨hz.1, by linarith [hz.2]⟩
    have hs := (LloydLocal.gate_all hd hd' z hb).2.2.1
    have hq := (LloydFlatSpiral.agree_north hz.1 hs).2.1
    exact ⟨LloydFlatSpiral.primitive_eq_on_belt hd hd' hb,
      by simp only [LloydFlatSpiral.cosCoef,hq],
      by simp only [LloydFlatSpiral.sinCoef,hq]⟩

def start : E3 := point (1/8) (azimuth (1/8))

theorem global_exact_iterates {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) (n : ℕ) :
    (mapping (modelPotential δ))^[n] start = LloydVerification.dir δ n :=
  (modelData hd hd').iterates hd hd' n

theorem globally_smooth_counterexample {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) :
    ContDiff ℝ ∞ (modelPotential δ) ∧
    (∀ u, modelPotential δ (-u) = modelPotential δ u) ∧
    (∀ u : E3, u 2 = 0 → ‖u‖=1 → mapping (modelPotential δ) u = u) ∧
    (∀ K : NonemptyCompacts E3,
      MapClusterPt K atTop (fun n : ℕ => LloydOrbit.antipodes ((mapping (modelPotential δ))^[n] start)) ↔
        ∃ θ : ℝ, K = LloydOrbit.antipodes (LloydOrbit.equator θ)) ∧
    ¬ ∃ K, Tendsto (fun n : ℕ => LloydOrbit.antipodes ((mapping (modelPotential δ))^[n] start)) atTop (𝓝 K) := by
  let d := modelData hd hd'
  refine ⟨d.smooth, d.even, fun u hz hu => d.fixed_equator hz hu, ?_⟩
  simp only [global_exact_iterates hd hd']
  exact (LloydVerification.model_counterexample hd hd').2

/-- The globally positive even angular target which is to be realized as a centroid support. -/
def prescribedSupport (δ : ℝ) (u : E3) := Real.exp (modelPotential δ u)

theorem support_spec {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) :
    ContDiff ℝ ∞ (prescribedSupport δ) ∧
    (∀ u, 0 < prescribedSupport δ u) ∧
    (∀ u, prescribedSupport δ (-u) = prescribedSupport δ u) ∧
    ∃ c : ℝ, 0 < c ∧ ∀ z ∈ cap, ∀ φ, prescribedSupport δ (point z φ) =
      c * Real.exp (LloydLocal.surface δ z φ) := by
  let d := modelData hd hd'
  have h : ContDiff ℝ ∞ (modelPotential δ) := d.smooth
  refine ⟨Real.contDiff_exp.comp h, fun _ => Real.exp_pos _, ?_, Real.exp d.offset, Real.exp_pos _, ?_⟩
  · exact fun u => congrArg Real.exp (d.even u)
  · intro z hz φ
    have hm := d.match (u := point z φ) (show (point z φ) 2 ∈ cap from hz)
    change d.full (point z φ) = d.offset + LloydAmbient.lift δ (point z φ) at hm
    have hrad : 0<1-z^2 := (LloydLocal.gate_all hd hd' z ⟨hz.1,by linarith [hz.2]⟩).2.1
    change Real.exp (d.full (point z φ)) = _
    rw [hm,LloydAmbient.lift_point hrad,Real.exp_add]

#print axioms global_exact_iterates
#print axioms globally_smooth_counterexample
#print axioms support_spec
end LloydGlobal
