import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Normed.Lp.MeasurableSpace
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.Analysis.Calculus.Deriv.Abs
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.Probability.ConditionalProbability
import Mathlib.Tactic

open MeasureTheory Set Filter
open scoped RealInnerProductSpace Topology

namespace LloydCentroid
noncomputable section
abbrev E := EuclideanSpace ℝ (Fin 3)

/-- Ties are assigned to the negative site. -/
def nearestPlus (y : E) : Set E := {x | dist x y < dist x (-y)}
def nearestMinus (y : E) : Set E := (nearestPlus y)ᶜ
def positive (u : E) : Set E := {x | 0 < ⟪x,u⟫}

def cellCentroid (μ : Measure E) (A : Set E) : E :=
  (μ.real A)⁻¹ • ∫ x in A, x ∂μ

def signedPoint (u x : E) : E := if 0 < ⟪x,u⟫ then x else -x

def signedMoment (μ : Measure E) (u : E) : E := ∫ x, signedPoint u x ∂μ

/-- Exact Lloyd update, with both output points computed from their actual Voronoi cells. -/
def update (μ : Measure E) (y : E) : E × E :=
  (cellCentroid μ (nearestPlus y),cellCentroid μ (nearestMinus y))

theorem nearestPlus_eq (u : E) {r : ℝ} (hr : 0<r) : nearestPlus (r • u) = positive u := by
  ext x
  change dist x (r • u) < dist x (-(r • u)) ↔ 0<⟪x,u⟫
  rw [dist_eq_norm, dist_eq_norm, sub_neg_eq_add]
  have h1 := norm_sub_sq_real x (r • u)
  have h2 := norm_add_sq_real x (r • u)
  rw [real_inner_smul_right] at h1 h2
  constructor
  · intro hs
    have hh : 0<r*⟪x,u⟫ := by nlinarith [sq_lt_sq' (by linarith [norm_nonneg (x-r • u)]) hs]
    exact pos_of_mul_pos_right hh hr.le
  · intro hp
    have hrp := mul_pos hr hp
    nlinarith [norm_nonneg (x-r • u), norm_nonneg (x+r • u)]

theorem positive_meas (u : E) : MeasurableSet (positive u) :=
  measurableSet_lt measurable_const (continuous_id.inner continuous_const).measurable

private theorem nonzero_ae (μ : Measure E) (u : E) (ht : μ {x | ⟪x,u⟫=0} = 0) :
    ∀ᵐ x ∂μ, ⟪x,u⟫ ≠ 0 := by
  apply ae_iff.mpr
  simpa only [not_not] using ht

theorem cap_mass (μ : Measure E) [IsProbabilityMeasure μ] (u : E)
    (hμ : MeasurePreserving (fun x : E => -x) μ μ) (ht : μ {x | ⟪x,u⟫=0} = 0) :
    μ.real (positive u) = 1/2 ∧ μ.real (positive u)ᶜ = 1/2 := by
  have hs : (fun x : E => -x) ⁻¹' positive u =ᵐ[μ] (positive u)ᶜ := by
    filter_upwards [nonzero_ae μ u ht] with x hx
    change (-x ∈ positive u) = (x ∉ positive u)
    simp only [positive, mem_ofPred_eq, inner_neg_left]
    apply propext
    constructor <;> intro _ <;> grind
  have he := hμ.measureReal_preimage (positive_meas u).nullMeasurableSet
  rw [measureReal_congr hs] at he
  have ht := measureReal_add_measureReal_compl (μ:=μ) (positive_meas u)
  have h1 : μ.real univ = 1 := by simp [Measure.real]
  rw [h1] at ht
  constructor <;> linarith

private theorem integral_neg_cap (μ : Measure E) (u : E)
    (hμ : MeasurePreserving (fun x : E => -x) μ μ) (ht : μ {x | ⟪x,u⟫=0} = 0) :
    (∫ x in (positive u)ᶜ, x ∂μ) = -(∫ x in (positive u), x ∂μ) := by
  have h := hμ.integral_comp (Homeomorph.neg E).measurableEmbedding ((positive u).indicator (id : E → E))
  have ae : (fun x => (positive u).indicator (id : E → E) (-x)) =ᵐ[μ]
        (fun x => -((positive u)ᶜ.indicator (id : E → E) x)) := by
    filter_upwards [nonzero_ae μ u ht] with x hx
    rcases lt_or_gt_of_ne hx with hn|hp
    · simp [positive, Set.indicator, inner_neg_left, hn, hn.not_gt]
    · simp [positive, Set.indicator, inner_neg_left, hp, hp.not_gt]
  rw [integral_congr_ae ae, integral_neg, integral_indicator (positive_meas u).compl,
    integral_indicator (positive_meas u)] at h
  exact neg_eq_iff_eq_neg.mp h

theorem reflection_update (μ : Measure E) [IsProbabilityMeasure μ] (u : E) {r : ℝ} (hr : 0<r)
    (hμ : MeasurePreserving (fun x : E => -x) μ μ) (ht : μ {x | ⟪x,u⟫=0} = 0)
    (hi : Integrable (id : E → E) μ) :
    μ.real (nearestPlus (r • u)) = 1/2 ∧ μ.real (nearestMinus (r • u)) = 1/2 ∧
    update μ (r • u) = (signedMoment μ u,-signedMoment μ u) := by
  obtain ⟨hm,hmc⟩ := cap_mass μ u hμ ht
  have hneg := integral_neg_cap μ u hμ ht
  have decomp (x : E) : signedPoint u x =
      (positive u).indicator (id : E → E) x - (positive u)ᶜ.indicator (id : E → E) x := by
    by_cases hx : 0<⟪x,u⟫ <;> simp [signedPoint,positive,Set.indicator,hx]
  have sign_eq : signedMoment μ u = 2 • (∫ x in positive u, x ∂μ) := by
    simp only [signedMoment, decomp]
    rw [integral_sub (hi.indicator (positive_meas u)) (hi.indicator (positive_meas u).compl),
      integral_indicator (positive_meas u), integral_indicator (positive_meas u).compl]
    simp only [id_eq, hneg]
    simp [two_nsmul]
  rw [nearestMinus, nearestPlus_eq u hr]
  refine ⟨hm, hmc, ?_⟩
  simp only [update,nearestMinus,nearestPlus_eq u hr,cellCentroid,hm,hmc,hneg, sign_eq]
  norm_num
  simp [two_smul]

/-- The squared cost of the actual pointwise nearest assignment. -/
def nearestCost (y x : E) : ℝ := by
  classical
  exact if x ∈ nearestPlus y then dist x y ^ 2 else dist x (-y) ^ 2

/-- Competitor sends a conditional fraction w(x) to the positive site. The bound holds
even before requiring that its integral match the prescribed half of the mass. -/
def planCost (w : E → ℝ) (y x : E) : ℝ :=
  w x * dist x y ^ 2 + (1-w x) * dist x (-y) ^ 2

theorem pointwise_le (y x : E) (w : E → ℝ) (hw : 0≤w x ∧ w x≤1) :
    nearestCost y x ≤ planCost w y x := by
  unfold nearestCost planCost
  by_cases h : x ∈ nearestPlus y
  · rw [ite_eq_left h]
    have hh : dist x y ≤ dist x (-y) := le_of_lt h
    have hs := pow_le_pow_left₀ (dist_nonneg) hh 2
    nlinarith [mul_nonneg (sub_nonneg.mpr hw.2) (sub_nonneg.mpr hs)]
  · rw [ite_eq_right h]
    have hh : dist x (-y) ≤ dist x y := le_of_not_gt h
    have hs := pow_le_pow_left₀ (dist_nonneg) hh 2
    nlinarith [mul_nonneg hw.1 (sub_nonneg.mpr hs)]

theorem nearest_minimizes (μ : Measure E) (y : E) (w : E → ℝ)
    (hw : ∀ᵐ x ∂μ, 0≤w x ∧ w x≤1) (hi : Integrable (planCost w y) μ) :
    (∫ x, nearestCost y x ∂μ) ≤ ∫ x, planCost w y x ∂μ := by
  refine integral_mono_of_nonneg ?_ hi ?_
  · apply Filter.Eventually.of_forall
    intro x
    unfold nearestCost
    split_ifs <;> exact sq_nonneg _
  · exact hw.mono fun x hx => pointwise_le y x w hx

/-- An absolutely continuous Euclidean law has no tie on a nonzero bisector. -/
theorem no_ties_of_ac (μ : Measure E) (hac : μ ≪ volume) (u : E) (hu : u ≠ 0) :
    μ {x | ⟪x,u⟫=0} = 0 := by
  let L := (innerSL ℝ u).toLinearMap
  have proper : LinearMap.ker L ≠ ⊤ := by
    intro he
    have hu' : u ∈ LinearMap.ker L := by rw [he]; trivial
    have huu : ⟪u,u⟫=0 := hu'
    exact hu (inner_self_eq_zero.mp huu)
  apply hac
  have hs : {x : E | ⟪x,u⟫=0} = (LinearMap.ker L : Set E) := by
    ext x
    change ⟪x,u⟫=0 ↔ ⟪u,x⟫=0
    rw [real_inner_comm]
  rw [hs]
  exact Measure.addHaar_submodule volume _ proper

/-- Normalized ambient Lebesgue volume on K. -/
def uniformOn (K : Set E) : Measure E := ProbabilityTheory.cond volume K

/-- For a compact centrally symmetric body of positive volume, the scalar mass,
evenness and null-boundary hypotheses follow directly from ambient volume. -/
theorem uniform_update (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (symm : ∀ x : E, -x ∈ K ↔ x ∈ K) (u : E) (hu : u≠0) {r : ℝ} (hr : 0<r) :
    (uniformOn K).real (nearestPlus (r • u)) = 1/2 ∧
    (uniformOn K).real (nearestMinus (r • u)) = 1/2 ∧
    update (uniformOn K) (r • u) = (signedMoment (uniformOn K) u,-signedMoment (uniformOn K) u) := by
  have : IsProbabilityMeasure (uniformOn K) :=
    ProbabilityTheory.cond_isProbabilityMeasure_of_finite volpos compact.measure_lt_top.ne
  have h0 : (fun x : E => -x) ⁻¹' K = K := Set.ext symm
  have hneg : MeasurePreserving (fun x : E => -x) volume volume :=
    (LinearIsometryEquiv.neg ℝ : E ≃ₗᵢ[ℝ] E).measurePreserving
  have hm := hneg.restrict_preimage compact.measurableSet
  rw [h0] at hm
  have even : MeasurePreserving (fun x : E => -x) (uniformOn K) (uniformOn K) := by
    refine ⟨measurable_neg,?_⟩
    unfold uniformOn ProbabilityTheory.cond
    rw [Measure.map_smul _ measurable_neg.aemeasurable, hm.map_eq]
  have hi : Integrable (id : E → E) (uniformOn K) := by
    have h1 : Integrable (id : E → E) (volume.restrict K) := continuous_id.continuousOn.integrableOn_compact compact
    exact h1.smul_measure (ENNReal.inv_ne_top.mpr volpos)
  exact reflection_update _ u hr even (no_ties_of_ac _ ProbabilityTheory.cond_absolutelyContinuous u hu) hi

#print axioms uniform_update
#print axioms nearest_minimizes
#print axioms reflection_update

end
end LloydCentroid
