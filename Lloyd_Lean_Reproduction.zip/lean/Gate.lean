import Chart
import Height
import Mathlib.Analysis.Real.Pi.Bounds

open LloydSpiral.Chart
namespace LloydGate
noncomputable section

theorem step_bounds {δ z : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hz : 0 < z) (hz' : z < 1/4) :
    z/2 < z - δ * Real.exp (-(1/z^2)) ∧ z - δ * Real.exp (-(1/z^2)) < z := by
  have he := LloydHeight.exp_neg_inv_sq_le hz
  have hm := mul_le_mul_of_nonneg_right hd' (Real.exp_pos (-(1/z^2))).le
  rw [one_mul] at hm
  constructor
  · nlinarith [mul_pos hz (sub_pos.mpr hz')]
  · exact sub_lt_self _ (mul_pos hd (Real.exp_pos _))

theorem positive_chord {δ z : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hz : 0 < z) (hz' : z < 1/4) :
    0 < inner ℝ (point z (-Real.log z))
        (point (z - δ * Real.exp (-(1/z^2))) (-Real.log (z - δ * Real.exp (-(1/z^2))))) := by
  let s := z - δ * Real.exp (-(1/z^2))
  obtain ⟨hs1,hs2⟩ := step_bounds hd hd' hz hz'
  change z/2 < s at hs1
  change s < z at hs2
  have hs : 0 < s := by linarith
  have hr : z/s < 2 := (div_lt_iff₀ hs).mpr (by linarith)
  have hl : 0 < Real.log z - Real.log s := sub_pos.mpr (Real.log_lt_log hs hs2)
  have hu : Real.log z - Real.log s ≤ 1 := by
    rw [← Real.log_div hz.ne' hs.ne']
    exact le_trans (Real.log_le_sub_one_of_pos (div_pos hz hs)) (by linarith)
  rw [dot_points]
  change 0 < radial z * radial s * Real.cos (-Real.log s - -Real.log z) + z*s
  have hcos : 0 < Real.cos (-Real.log s - -Real.log z) :=
    Real.cos_pos_of_mem_Ioo ⟨by linarith [Real.pi_pos], by linarith [Real.pi_gt_three]⟩
  have h₁ : 0 ≤ radial z := Real.sqrt_nonneg _
  have h₂ : 0 ≤ radial s := Real.sqrt_nonneg _
  exact add_pos_of_nonneg_of_pos (mul_nonneg (mul_nonneg h₁ h₂) hcos.le) (mul_pos hz hs)
end
end LloydGate
