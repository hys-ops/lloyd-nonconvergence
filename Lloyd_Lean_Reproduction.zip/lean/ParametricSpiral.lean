import FlatSpiralGerms
import Mathlib.Analysis.Calculus.ContDiff.Convolution
import Mathlib.Analysis.Calculus.BumpFunction.FiniteDimension
open scoped ContDiff Topology Convolution
open Set Function MeasureTheory Filter Metric
noncomputable section
namespace LloydFlatSpiral

private def regular : Set (ℝ × ℝ) :=
  {w | ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => integrand v.1 v.2) w ∧
      ∀ φ : ℝ, ContDiffAt ℝ ∞
        (fun v : (ℝ × ℝ) × ℝ => q v.1.1 v.1.2 * Real.sin (v.2 + Real.log v.1.2)) (w,φ)}

private theorem tube : ∃ V : Set ℝ, IsOpen V ∧ 0 ∈ V ∧
    V ×ˢ Icc (-(1/2:ℝ)) (1/2) ⊆ regular := by
  have h : ({0}:Set ℝ) ×ˢ Icc (-(1/2:ℝ)) (1/2) ⊆ interior regular := by
    rintro ⟨δ,z⟩ ⟨hd,hz⟩
    have hδ : δ=0 := hd
    subst δ
    apply mem_interior_iff_mem_nhds.mpr
    apply zero_parameter_germs
    obtain ⟨h1,h2⟩ := hz
    nlinarith [mul_pos (show 0<1+z by linarith) (show 0<1-z by linarith)]
  obtain ⟨V,W,hV,_,h0,hK,hinc⟩ := generalized_tube_lemma isCompact_singleton isCompact_Icc isOpen_interior h
  exact ⟨V,hV,h0 (mem_singleton 0),fun w hw => interior_subset (hinc ⟨hw.1,hK hw.2⟩)⟩

private def cutoff : ContDiffBump (0:ℝ) := ⟨1/4,1/3,by norm_num,by norm_num⟩
private def kernel : ℝ → ℝ := (Ioc (0:ℝ) 1).indicator (fun _ => 1)
private def g (δ t : ℝ) := cutoff t * integrand δ t
private def conv (δ z : ℝ) := (kernel ⋆[ContinuousLinearMap.mul ℝ ℝ,volume] g δ) z

private theorem g_zero_outside (δ : ℝ) {t : ℝ} (ht : t ∉ closedBall 0 (1/3:ℝ)) :
    g δ t=0 := by
  unfold g
  rw [cutoff.zero_of_le_dist (le_of_lt (not_le.mp ht)), zero_mul]

private theorem g_zero_nonpos (δ : ℝ) {t : ℝ} (ht : t≤0) : g δ t=0 := by
  by_cases hm : t ∈ closedBall 0 (1/3:ℝ)
  · have h : -(1/3:ℝ) ≤ t := by simpa [Real.closedBall_eq_Icc] using (show 0-(1/3:ℝ) ≤ t from (Real.closedBall_eq_Icc ▸ hm).1)
    simp [g,integrand_nonpos δ (by linarith : -1<t) ht]
  · exact g_zero_outside δ hm

private theorem conv_integral (δ z : ℝ) : conv δ z = ∫ t in z-1..z, g δ t := by
  unfold conv
  rw [convolution_def]
  change (∫ t : ℝ, (Ioc (0:ℝ) 1).indicator (fun _ => (1:ℝ)) t * g δ (z-t)) = _
  have eq : (fun t : ℝ => (Ioc (0:ℝ) 1).indicator (fun _ => (1:ℝ)) t * g δ (z-t)) =
      (Ioc (0:ℝ) 1).indicator (fun t => g δ (z-t)) := by
    funext t
    by_cases ht : t ∈ Ioc (0:ℝ) 1 <;> simp [ht]
  rw [eq]
  rw [integral_indicator measurableSet_Ioc, ← intervalIntegral.integral_of_le (zero_le_one : (0:ℝ) ≤ 1)]
  simp [intervalIntegral.integral_comp_sub_left]

private theorem conv_eq_primitive {V : Set ℝ}
    (htube : V ×ˢ Icc (-(1/2:ℝ)) (1/2) ⊆ regular)
    {δ z : ℝ} (hδ : δ ∈ V) (hz : z ∈ Ioo (-(1/4:ℝ)) (1/4)) : conv δ z=primitive δ z := by
  rw [conv_integral]
  have hz' : z-1 ≤ 0 := by linarith [hz.2]
  have c0 : EqOn (g δ) (fun _ => (0:ℝ)) (uIcc (z-1) 0) := by
    rw [uIcc_of_le hz']
    intro t ht
    exact g_zero_nonpos δ ht.2
  have i0 : IntervalIntegrable (g δ) volume (z-1) 0 := by
    apply ContinuousOn.intervalIntegrable
    exact continuousOn_const.congr c0
  have c1 : EqOn (g δ) (integrand δ) (uIcc 0 z) := by
    intro t ht
    have hsub := ordConnected_Ioo.uIcc_subset (show (0:ℝ) ∈ Ioo (-(1/4:ℝ)) (1/4) by norm_num) hz ht
    have hone := cutoff.one_of_mem_closedBall (x := t) (by
      rw [Real.closedBall_eq_Icc]
      change 0-(1/4:ℝ) ≤ t ∧ t ≤ 0+1/4
      exact ⟨by linarith [hsub.1],by linarith [hsub.2]⟩)
    simp [g,hone]
  have i1 : IntervalIntegrable (g δ) volume 0 z := by
    apply ContinuousOn.intervalIntegrable
    apply ContinuousOn.congr _ c1
    intro t ht
    have hsub := ordConnected_Ioo.uIcc_subset (show (0:ℝ) ∈ Ioo (-(1/4:ℝ)) (1/4) by norm_num) hz ht
    have hc : ContDiffAt ℝ ∞ (fun v : ℝ×ℝ => integrand v.1 v.2) (δ,t) :=
      (htube ⟨hδ,by constructor <;> linarith [hsub.1,hsub.2]⟩).1
    exact (hc.continuousAt.comp (continuousAt_const.prodMk continuousAt_id)).continuousWithinAt
  rw [← intervalIntegral.integral_add_adjacent_intervals i0 i1,intervalIntegral.integral_congr c0,
    intervalIntegral.integral_congr c1]
  simp [primitive]

private theorem smooth_conv {V : Set ℝ} (hV : IsOpen V)
    (htube : V ×ˢ Icc (-(1/2:ℝ)) (1/2) ⊆ regular) :
    ContDiffOn ℝ ∞ (fun v : ℝ × ℝ => conv v.1 v.2) (V ×ˢ univ) := by
  apply contDiffOn_convolution_right_with_param (n := ⊤) (k := closedBall 0 (1/3:ℝ))
      (ContinuousLinearMap.mul ℝ ℝ) hV (isCompact_closedBall _ _)
  · exact fun δ t _ ht => g_zero_outside δ ht
  · exact (continuous_const.locallyIntegrable).indicator measurableSet_Ioc
  · intro w hw
    apply ContDiffAt.contDiffWithinAt
    by_cases hm : w.2 ∈ closedBall 0 (1/3:ℝ)
    · have hr : w ∈ regular := htube ⟨hw.1,by
        rw [Real.closedBall_eq_Icc] at hm
        constructor <;> linarith [hm.1,hm.2]⟩
      exact ((cutoff.contDiff.comp contDiff_snd).contDiffAt).mul hr.1
    · have hc := (show IsClosed (closedBall (0:ℝ) (1/3)) from isClosed_closedBall).isOpen_compl.preimage (continuous_snd : Continuous (Prod.snd : ℝ × ℝ → ℝ))
      apply (show ContDiffAt ℝ ∞ (fun _ : ℝ×ℝ => (0:ℝ)) w from contDiffAt_const).congr_of_eventuallyEq
      filter_upwards [hc.eventually_mem hm] with v hv using g_zero_outside v.1 hv

/-- A single open interval-neighborhood in the perturbation parameter suffices along the
whole signed chart belt. Both the primitive and its genuine angular terms are jointly smooth. -/
theorem parametric_chart : ∃ V : Set ℝ, IsOpen V ∧ 0 ∈ V ∧
    ∀ δ ∈ V, ∀ z ∈ Ioo (-(1/4:ℝ)) (1/4),
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => primitive v.1 v.2) (δ,z) ∧
      ∀ φ : ℝ, ContDiffAt ℝ ∞
        (fun v : (ℝ × ℝ) × ℝ => q v.1.1 v.1.2 * Real.sin (v.2 + Real.log v.1.2)) ((δ,z),φ) := by
  obtain ⟨V,hV,h0,hK⟩ := tube
  refine ⟨V,hV,h0,fun δ hδ z hz => ⟨?_,?_⟩⟩
  · have hc := (smooth_conv hV hK).contDiffAt
      ((hV.prod isOpen_univ).mem_nhds (show (δ,z) ∈ V ×ˢ univ from ⟨hδ,mem_univ _⟩))
    apply hc.congr_of_eventuallyEq
    filter_upwards [(hV.prod isOpen_Ioo).eventually_mem (show (δ,z) ∈ V ×ˢ Ioo (-(1/4:ℝ)) (1/4) from ⟨hδ,hz⟩)] with v hv
    exact (conv_eq_primitive hK hv.1 hv.2).symm
  · exact (hK ⟨hδ,by constructor <;> linarith [hz.1,hz.2]⟩).2

/-- Joint smoothness in parameter and height for the three Cartesian coefficients. -/
theorem parametric_cartesian : ∃ V : Set ℝ, IsOpen V ∧ 0 ∈ V ∧
    ∀ δ ∈ V, ∀ z ∈ Ioo (-(1/4:ℝ)) (1/4),
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => primitive v.1 v.2) (δ,z) ∧
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => cosCoef v.1 v.2) (δ,z) ∧
      ContDiffAt ℝ ∞ (fun v : ℝ × ℝ => sinCoef v.1 v.2) (δ,z) := by
  obtain ⟨V,hV,h0,hC⟩ := parametric_chart
  refine ⟨V,hV,h0,fun δ hδ z hz => ?_⟩
  obtain ⟨hF,hW⟩ := hC δ hδ z hz
  have hz' : 0 < 1-z^2 := by
    nlinarith [mul_pos (show 0<1+z by linarith [hz.1]) (show 0<1-z by linarith [hz.2])]
  have hr : ContDiffAt ℝ ∞ (fun w : ℝ×ℝ => LloydSpiral.Chart.radial w.2) (δ,z) := by
    unfold LloydSpiral.Chart.radial; fun_prop (disch := positivity)
  have hn : LloydSpiral.Chart.radial z ≠0 := (Real.sqrt_pos.mpr hz').ne'
  have ha (a:ℝ) : ContDiffAt ℝ ∞
      (fun w : ℝ×ℝ => q w.1 w.2 * Real.sin (a+Real.log w.2)) (δ,z) :=
    (hW a).comp (δ,z) (contDiffAt_id.prodMk contDiffAt_const)
  have hc : ContDiffAt ℝ ∞ (fun w : ℝ×ℝ => q w.1 w.2 * Real.cos (LloydSpiral.Chart.azimuth w.2)) (δ,z) := by
    simpa only [LloydSpiral.Chart.azimuth,Real.cos_neg,add_comm (Real.pi/2),Real.sin_add_pi_div_two] using ha (Real.pi/2)
  have hs : ContDiffAt ℝ ∞ (fun w : ℝ×ℝ => q w.1 w.2 * Real.sin (LloydSpiral.Chart.azimuth w.2)) (δ,z) := by
    simpa only [LloydSpiral.Chart.azimuth,Real.sin_neg,mul_neg,zero_add] using (ha 0).neg
  exact ⟨hF,hc.div hr hn,hs.div hr hn⟩

theorem zero_parameter_values {z : ℝ} (hz : z ∈ Ioo (-(1/4:ℝ)) (1/4)) :
    primitive 0 z=0 ∧ cosCoef 0 z=0 ∧ sinCoef 0 z=0 := by
  have hq (t : ℝ) : q 0 t = 0 := by simp [q_factor,coefficient]
  have hi : EqOn (integrand 0) (fun _ => (0:ℝ)) (uIcc 0 z) := by
    intro t ht
    have ht' := ordConnected_Ioo.uIcc_subset (show (0:ℝ) ∈ Ioo (-(1/4:ℝ)) (1/4) by norm_num) hz ht
    have hr : LloydSpiral.Chart.radial t ≠0 := by
      apply (Real.sqrt_pos.mpr _).ne'
      nlinarith [mul_pos (show 0<1+t by linarith [ht'.1]) (show 0<1-t by linarith [ht'.2])]
    simp [integrand,p,s,deltaAngle,u,hr,hq]
  exact ⟨by simpa [primitive] using intervalIntegral.integral_congr (μ := volume) hi,
    by simp [cosCoef,hq],by simp [sinCoef,hq]⟩

#print axioms parametric_cartesian
#print axioms zero_parameter_values
#print axioms parametric_chart
end LloydFlatSpiral
