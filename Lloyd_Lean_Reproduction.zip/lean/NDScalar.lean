import NDPolar
import Mathlib.Analysis.InnerProductSpace.Projection.Reflection

/-! Normalize the constant mode of the actual Haar-sphere cosine transform and
certify positivity of small named perturbations before radial realization. -/
noncomputable section
open MeasureTheory Set
open scoped RealInnerProductSpace ENNReal
namespace LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim

private def unitRadius : Sn → Ray := fun _ => ⟨1,show (0:ℝ)<1 from zero_lt_one⟩

private theorem unitStar_set : star (unitRadius (dim:=dim)) = Metric.ball (0:Vn) 1 \ {(0:Vn)} := by
  ext x
  constructor
  · rintro ⟨hx,hr⟩
    refine ⟨?_,hx⟩
    change ((homeomorphUnitSphereProd Vn) ⟨x,hx⟩).2.val < 1 at hr
    simpa using hr
  · rintro ⟨hb,hx⟩
    refine ⟨hx,?_⟩
    change ((homeomorphUnitSphereProd Vn) ⟨x,hx⟩).2.val < 1
    simpa using hb

/-- In ambient dimension d, the sphere cosine transform of the constant one
equals d + 1 times the unnormalized unit ball first moment. -/
theorem cosine_one_ball (u : Vn) : cosineTransform (fun _ => 1) u =
    ((dim:ℝ)+2) * ∫ x in Metric.ball (0:Vn) 1, |⟪u,x⟫| := by
  have h := real_star_abs_moment (ρ := unitRadius) measurable_const u
  rw [unitStar_set,Measure.restrict_congr_set (sdiff_null_ae_eq_self (measure_singleton (0:Vn)))] at h
  change (∫ x in Metric.ball (0:Vn) 1, |⟪u,x⟫|) = ∫ w:Sn, |⟪u,(w:Vn)⟫| * ((1:ℝ)^(dim+2)/((dim:ℝ)+2)) ∂(volume : Measure Vn).toSphere at h
  simp only [one_pow,mul_one_div,integral_div] at h
  simp only [cosineTransform,mul_one]
  field_simp at h ⊢
  linarith

/-- The ball first moment is constant on each norm sphere. -/
theorem ball_moment_eq_of_norm_eq (u v : Vn) (hn : ‖u‖ = ‖v‖) :
    (∫ x in Metric.ball (0:Vn) 1, |⟪u,x⟫|) = ∫ x in Metric.ball (0:Vn) 1, |⟪v,x⟫| := by
  let R : Vn ≃ₗᵢ[ℝ] Vn := (ℝ ∙ (u-v))ᗮ.reflection
  have hv : R u = v := Submodule.reflection_sub hn
  have hpre : R ⁻¹' Metric.ball (0:Vn) 1 = Metric.ball (0:Vn) 1 := by
    ext x
    simp [Metric.mem_ball,dist_zero_right]
  have hm := R.measurePreserving.restrict_preimage (show MeasurableSet (Metric.ball (0:Vn) 1) from Metric.isOpen_ball.measurableSet)
  rw [hpre] at hm
  calc
    _ = ∫ x in Metric.ball (0:Vn) 1, |⟪v,R x⟫| := by
      apply integral_congr_ae
      filter_upwards [] with x
      rw [←hv,R.inner_map_map]
    _ = _ := hm.integral_comp R.toHomeomorph.measurableEmbedding (fun x => |⟪v,x⟫|)

/-- Unit ball has positive finite ambient mass, so the normalized ball really
is a probability source. -/
theorem ball_normalization : (0 < volume.real (Metric.ball (0:Vn) 1)) ∧
    IsProbabilityMeasure (ProbabilityTheory.cond volume (Metric.ball (0:Vn) 1)) := by
  have hp := Metric.measure_ball_pos (volume : Measure Vn) (0:Vn) (by norm_num : (0:ℝ)<1)
  exact ⟨ENNReal.toReal_pos hp.ne' measure_ball_lt_top.ne,
    ProbabilityTheory.cond_isProbabilityMeasure_of_finite hp.ne' measure_ball_lt_top.ne⟩

/-- Positive constant mode for precisely the sphere measure used in `cosineTransform`. -/
theorem constant_cosine_sphere : ∃ A : ℝ, 0 < A ∧
    ∀ u : Vn, ‖u‖ = 1 → cosineTransform (fun _ => 1) u = A := by
  let w : Sn := Classical.choice (NormedSpace.sphere_nonempty_rclike (𝕜:=ℝ) (zero_le_one : (0:ℝ)≤1))
  have hw : ‖(w:Vn)‖ = 1 := by simp
  refine ⟨cosineTransform (fun _ => 1) w.val,?_,fun u hu => ?_⟩
  · simp only [cosineTransform,mul_one]
    have hc : Continuous (fun s:Sn => |⟪(w:Vn),(s:Vn)⟫|) := (continuous_const.inner continuous_subtype_val).abs
    apply integral_pos_of_integrable_nonneg_nonzero (x:=w) hc
      (hc.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)) (fun _ => abs_nonneg _)
    simp [hw]
  · rw [cosine_one_ball, cosine_one_ball,ball_moment_eq_of_norm_eq u (w:Vn) (hu.trans hw.symm)]

/-- A bounded smaller signed perturbation preserves pointwise strict positivity. -/
theorem positive_perturbed_weight (B : ℝ) (q : Sn → ℝ) (h : ∀ w, |q w| < B) :
    ∀ w, 0 < B + q w := fun w => by linarith [(abs_lt.mp (h w)).1]

/-- Affine linearity, specialized to the actual finite sphere measure. -/
theorem cosine_add_const {q : Sn → ℝ} (hc : Continuous q) (B : ℝ) (u : Vn) :
    cosineTransform (fun w => B + q w) u = B * cosineTransform (fun _ => 1) u + cosineTransform q u := by
  let f := fun w : Sn => |⟪u,(w:Vn)⟫|
  have hcont : Continuous f := (continuous_const.inner continuous_subtype_val).abs
  have hi := hcont.integrable_of_hasCompactSupport (μ := (volume : Measure Vn).toSphere) (HasCompactSupport.of_compactSpace _)
  have hi' := (hcont.mul hc).integrable_of_hasCompactSupport (μ := (volume : Measure Vn).toSphere) (HasCompactSupport.of_compactSpace _)
  simp only [cosineTransform,mul_one,mul_add]
  change Integrable (fun w : Sn => |⟪u,(w:Vn)⟫| * q w) _ at hi'
  change Integrable (fun w : Sn => |⟪u,(w:Vn)⟫|) _ at hi
  rw [integral_add (hi.mul_const B) hi',integral_mul_const,mul_comm B]

#print axioms cosine_one_ball
#print axioms constant_cosine_sphere
#print axioms cosine_add_const
#print axioms ball_normalization
end LloydNDPolar
