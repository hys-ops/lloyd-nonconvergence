import NDGaussModels
import NDLimitsBalancedUpdate
import NDProduct

/-! Removing compact support from the equivalence of ordinary and optimal
equal-mass population Lloyd for antipodal sites. A finite second moment suffices. -/
noncomputable section
open Set MeasureTheory Filter
open scoped RealInnerProductSpace Topology ENNReal
namespace LloydNDModels
open LloydNDLimits
variable {k : ℕ}
local notation "Vn" => LloydNDPolar.E k

theorem nearest_cost_finite {μ : Measure Vn} [IsProbabilityMeasure μ] (h₂ : MemLp id 2 μ) (y:Vn) :
    squaredTransportCost (nearestCoupling μ y) ≠ ∞ := by
  have hlp : MemLp (fun x:Vn => x-y) 2 μ := h₂.sub (memLp_const y)
  have hs : Integrable (fun x => dist x y ^ 2) μ := by
    simpa only [dist_eq_norm] using (memLp_two_iff_integrable_sq_norm hlp.aestronglyMeasurable).mp hlp
  have hf := (lintegral_ofReal_ne_top_iff_integrable hs.aestronglyMeasurable (.of_forall (fun x => sq_nonneg (dist x y)))).mpr hs
  unfold squaredTransportCost nearestCoupling
  have hm : Measurable (fun p:Vn × Vn => ENNReal.ofReal (dist p.1 p.2 ^ 2)) :=
    ((measurable_fst.dist measurable_snd).pow_const _).ennreal_ofReal
  have hg : Measurable (fun x:Vn => (x,nearestSite y x)) := measurable_id.prodMk (nearestSite_measurable y)
  rw [lintegral_map hm hg]
  apply ne_top_of_le_ne_top hf
  apply lintegral_mono
  intro x
  change ENNReal.ofReal (dist x (nearestSite y x)^2) ≤ ENNReal.ofReal (dist x y ^2)
  apply ENNReal.ofReal_le_ofReal
  apply pow_le_pow_left₀ dist_nonneg
  by_cases h:x ∈ nearestPlus y
  · simp [nearestSite,h]
  · simpa [nearestSite,h] using le_of_not_gt h

theorem Profile.balanced {μ : Measure Vn} {h : Vn→ℝ} {c:ℝ} (p:Profile μ h c) (h₂:MemLp id 2 μ)
    {y:Vn} (hy:y≠0) (P:Vn×Vn) : IsBalancedStep μ y P ↔ P = update μ y := by
  have : IsProbabilityMeasure μ := p.probability
  have tie := no_ties_of_ac μ p.ac y hy
  have h := reflection_update μ y (r:=1) zero_lt_one p.even tie p.first
  simp only [one_smul] at h
  have hm := nearestCoupling_marginals μ y h.1 h.2.1
  have nt : ∀ᵐ x ∂μ, dist x y ≠ dist x (-y) := by
    have hn : ∀ᵐ x ∂μ, ⟪x,y⟫≠0 := ae_iff.mpr (by simpa only [not_not] using tie)
    filter_upwards [hn] with x hx hxy
    apply hx
    simp only [dist_eq_norm,sub_neg_eq_add] at hxy
    have eqn := norm_sub_sq_real x y
    rw [hxy,norm_add_sq_real] at eqn
    linarith
  constructor
  · rintro ⟨π,hf,hs,ho,rfl⟩
    rw [nearestCoupling_unique μ y π hf hs nt (nearest_cost_finite h₂ y) (ho _ hm.1 hm.2)]
    exact graph_barycenters_eq_update μ y hy
  · rintro rfl
    exact ⟨_,hm.1,hm.2,nearestCoupling_minimal μ y,(graph_barycenters_eq_update μ y hy).symm⟩

theorem Profile.antipodal {μ : Measure Vn} {h : Vn→ℝ} {c:ℝ} (p:Profile μ h c)
    {y:Vn} (hy:y≠0) (n : ℕ) : ∃ v:Vn, v≠0 ∧ (LloydProduct.step μ)^[n] (y,-y) = (v,-v) := by
  have : IsProbabilityMeasure μ := p.probability
  induction n with
  | zero => exact ⟨y,hy,rfl⟩
  | succ n ih =>
    obtain ⟨v,hv,hi⟩ := ih
    have tie := no_ties_of_ac μ p.ac v hv
    have mpos : signedMoment μ v ≠ 0 := by
      intro hm
      have hh := inner_signedMoment μ v p.first
      rw [hm,inner_zero_right] at hh
      exact (populationSupport_pos μ v tie p.first).ne' hh.symm
    refine ⟨_,mpos,?_⟩
    rw [Function.iterate_succ_apply',hi]
    simpa only [one_smul] using! (reflection_update μ v (r:=1) zero_lt_one p.even tie p.first).2.2

/-- From every nonzero antipodal start, at every time, the complete optimal
equal-mass update relation is the singleton ordinary update. -/
theorem Profile.balanced_trajectory {μ : Measure Vn} {h : Vn→ℝ} {c:ℝ} (p:Profile μ h c)
    (h₂:MemLp id 2 μ) {y:Vn} (hy:y≠0) (n:ℕ) (z:Vn×Vn) :
    IsBalancedStep μ ((LloydProduct.step μ)^[n] (y,-y)).1 z ↔
      z = (LloydProduct.step μ)^[n+1] (y,-y) := by
  obtain ⟨v,hv,hi⟩ := p.antipodal hy n
  rw [Function.iterate_succ_apply',hi]
  exact p.balanced h₂ hv z

/-- Standalone version for every even, normalized volume density with finite second moment. -/
theorem balanced_of_even_law {ρ : Vn → ℝ} (he : ∀x,ρ (-x) = ρ x)
    (hp : IsProbabilityMeasure (LloydNDGaussian.law ρ))
    (h₂ : MemLp id 2 (LloydNDGaussian.law ρ)) {y:Vn} (hy : y≠0) (n : ℕ) (z : Vn × Vn) :
    let μ := LloydNDGaussian.law ρ
    IsBalancedStep μ ((LloydProduct.step μ)^[n] (y,-y)).1 z ↔
      z = (LloydProduct.step μ)^[n+1] (y,-y) := by
  let μ := LloydNDGaussian.law ρ
  have : IsProbabilityMeasure μ := hp
  have p : Profile μ (populationSupport μ) 1 := ⟨zero_lt_one,hp,LloydNDRadialSource.law_neg he,
    withDensity_absolutelyContinuous _ _,h₂.integrable (by norm_num),fun _ _ => (one_mul _).symm⟩
  exact p.balanced_trajectory h₂ hy n z

#print axioms balanced_of_even_law
#print axioms Profile.balanced_trajectory
#print axioms Profile.balanced
end LloydNDModels
