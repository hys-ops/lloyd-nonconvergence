import NDGeoShell
import NDGeoChain
import NDGaussCutoff
open Set Filter MeasureTheory
open scoped Topology SchwartzMap ContDiff
noncomputable section
namespace LloydNDGeom
open LloydNDPolar LloydNDAngular
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim

def weight (f : 𝓢(Vn,ℝ)) (w : Sn) : ℝ := 1+radialize f w.val
def body (f : 𝓢(Vn,ℝ)) (hp : ∀ w, 0<weight f w) := solidStar (positiveRoot (weight f) hp)
def NearRound (K : Set Vn) (m : ℕ) (ε : ℝ) : Prop :=
  ∃ (r : Sn → Ray) (R : Vn → ℝ), K = solidStar r ∧
    (∀ w : Sn, R w.val = (r w).val) ∧ ContDiffOn ℝ ∞ R away ∧
    ∀ n ≤ m, ∀ w ∈ away, ‖iteratedFDeriv ℝ n (fun x => R x - 1) w‖ < ε

theorem eventually_nearRound {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) (m : ℕ) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ t in l, ∀ hp : ∀ w, 0 < weight (F t) w, NearRound (body (F t) hp) m ε := by
  have hj := (eventually_all_finset (Finset.range (m+1))).2
    (fun j _ => radExt_jets hF j hε)
  filter_upwards [hj,eventually_radExt_smooth hF] with t ht hs hp
  exact ⟨positiveRoot (weight (F t)) hp,radExt (F t),rfl,fun _ => rfl,hs,
    fun n hn => ht n (Finset.mem_range.mpr (by omega))⟩

private theorem norm_two (g : Vn → ℝ) (x : Vn) :
    ‖iteratedFDeriv ℝ 2 g x‖ = ‖fderiv ℝ (fderiv ℝ g) x‖ := by
  rw [← norm_iteratedFDeriv_fderiv (n := 1),norm_iteratedFDeriv_one]

theorem eventually_smooth_solid {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) :
    ∀ᶠ i in l, ∃ hp : ∀ w, 0 < weight (F i) w,
      StrictConvex ℝ (body (F i) hp) ∧ HasPositiveCurvedBoundary (body (F i) hp) ∧
      Metric.closedBall (0:Vn) (1/2:ℝ) ⊆ body (F i) hp := by
  let G := fun i => cutoffMoment shellNorm (dim+1) (F i)
  have hG (i : ι) : ContDiff ℝ ∞ (G i) := cutoffMoment_smooth shellNorm_smooth shellNorm_away _ _
  have hGs (j : ℕ) (hj : j ≤ 2) (η : ℝ) (hη : 0<η) :
      ∀ᶠ i in l, ∀ x, ‖iteratedFDeriv ℝ j (G i) x‖ < η := by
    filter_upwards [cutoff_eventually_small hF shellNorm_smooth shellNorm_compact shellNorm_away (dim+1) hη] with i hi x
    obtain ⟨h0,h1,h2⟩ := hi x
    interval_cases j
    · simpa only [norm_iteratedFDeriv_zero] using h0
    · simpa only [norm_iteratedFDeriv_one] using h1
    · simpa only [norm_two] using h2
  let g := fun a : ℝ => ((1+a)^(((dim:ℝ)+2)⁻¹))^2-1
  let T := {a : ℝ | 0 < 1+a}
  have hT : IsOpen T := isOpen_lt continuous_const (continuous_const.add continuous_id)
  have hg : ContDiffOn ℝ ∞ g T := by
    intro x hx
    have hx' : 0<1+x := hx
    apply ContDiffAt.contDiffWithinAt
    dsimp [g]
    fun_prop (disch := positivity)
  have hg0 : g 0=0 := by simp [g]
  have hb := global_C2_change hG hGs hT (show (0:ℝ)∈T by simp [T]) hg hg0 (by norm_num : (0:ℝ)<1/4)
  filter_upwards [hb,eventually_C2_small hF (dim+1) (by norm_num : (0:ℝ)<1/4)] with i hi hpos
  have hp (w : Sn) : 0<weight (F i) w := by
    have h := (hpos w.val (show w.val ∈ away by change 1/2 < ‖w.val‖; norm_num)).1
    change |radialize (F i) w.val| < 1/4 at h
    dsimp [weight]
    linarith [(abs_lt.mp h).1]
  let b := g ∘ G i
  have h0 (x : Vn) : |b x| ≤ 1/4 := by simpa only [norm_iteratedFDeriv_zero,Real.norm_eq_abs] using (hi.2 0 (by decide) x).le
  have h1 (x : Vn) : ‖fderiv ℝ b x‖ ≤ 1 := by
    exact le_trans (by simpa only [norm_iteratedFDeriv_one] using (hi.2 1 (by decide) x).le) (by norm_num : (1/4:ℝ)≤1)
  have h2 (x : Vn) : ‖fderiv ℝ (fderiv ℝ b) x‖ ≤ 1 := by
    exact le_trans (by simpa only [norm_two] using (hi.2 2 (by decide) x).le) (by norm_num : (1/4:ℝ)≤1)
  have hshell (w : Sn) (s : ℝ) (hlo : 3/4 ≤ s) (hhi : s ≤ 5/4) :
      b (s • w.val) = (positiveRoot (weight (F i)) hp w).val^2-1 := by
    have hGval : G i (s • w.val) = radialize (F i) w.val := by
      change shellNorm (s • w.val) * radialize (F i) (s • w.val) = _
      rw [shellNorm_value w hlo hhi,radialize_homogeneous (F i) w.val (by linarith : 0<s)]
    change g (G i (s • w.val)) = _
    rw [hGval]
    rfl
  have he : body (F i) hp = {x : Vn | ‖x‖^2-b x ≤ 1} := sublevel_of_shell h0 hshell
  refine ⟨hp,he.symm ▸ strict_of_sublevel (b:=b) (hi.1.of_le (by norm_num)) h2,
    he.symm ▸ regular_curved_sublevel hi.1 h0 h1 h2,?_⟩
  intro x hx
  rw [he]
  have hn : ‖x‖ ≤ 1/2 := by simpa [Metric.mem_closedBall] using hx
  have hsq := pow_le_pow_left₀ (norm_nonneg x) hn 2
  change ‖x‖^2-b x ≤ 1
  linarith [(abs_le.mp (h0 x)).1]
end LloydNDGeom
