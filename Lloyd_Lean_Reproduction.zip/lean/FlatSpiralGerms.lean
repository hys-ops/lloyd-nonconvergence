import FlatSpiral

noncomputable section
open Set Filter MeasureTheory
open scoped ContDiff Topology
namespace LloydFlatSpiral
open LloydSpiral.Chart

def cosCoef (δ z : ℝ) : ℝ := q δ z * Real.cos (azimuth z) / radial z
def sinCoef (δ z : ℝ) : ℝ := q δ z * Real.sin (azimuth z) / radial z

theorem q_nonpos (δ : ℝ) {z : ℝ} (hz : z ≤ 0) : q δ z = 0 := by
  simp [q_factor,LloydFlat.bump,not_lt_of_ge hz]

theorem integrand_nonpos (δ : ℝ) {z : ℝ} (hl : -1<z) (hu : z≤0) :
    integrand δ z = 0 := by
  have hr : 0 < radial z := by
    unfold radial; apply Real.sqrt_pos.2
    nlinarith [mul_pos (show 0<1+z by linarith) (show 0<1-z by linarith)]
  have hs : s δ z=z := by simp [s,LloydFlat.bump,not_lt_of_ge hu]
  have ha : deltaAngle δ z=0 := by simp [deltaAngle,u,LloydFlat.bump,not_lt_of_ge hu]
  simp [integrand,p,q_nonpos δ hu,hs,ha,hr.ne']

theorem germ_zero (δ : ℝ) {z : ℝ} (hl : -(1/4:ℝ)<z) (hu : z≤0) :
    primitive δ z=0 ∧ cosCoef δ z=0 ∧ sinCoef δ z=0 := by
  have he : EqOn (integrand δ) (fun _ => (0:ℝ)) (uIcc 0 z) := by
    rw [uIcc_of_ge hu]
    intro t ht
    exact integrand_nonpos δ (lt_of_lt_of_le (by linarith : -1 < z) ht.1) ht.2
  exact ⟨by simpa [primitive] using intervalIntegral.integral_congr (μ := volume) he,
    by simp [cosCoef,q_nonpos δ hu], by simp [sinCoef,q_nonpos δ hu]⟩

private theorem agree_pos {δ z : ℝ} (hd : 0 < δ) (hδ : δ ≤ 1) (hz : z ∈ LloydLocal.belt) :
    p δ z = LloydLocal.p δ z ∧ q δ z = LloydLocal.q δ z ∧
      integrand δ z = LloydLocal.integrand δ z := by
  have hg := LloydLocal.gate_all hd hδ z hz
  exact agree_north hg.1 hg.2.2.1

private theorem smooth_i_belt {δ z : ℝ} (hd : 0<δ) (hδ : δ≤1) (hz : z ∈ LloydLocal.belt) :
    ContDiffAt ℝ ∞ (integrand δ) z := by
  apply (LloydLocal.smooth_coefficients (LloydLocal.gate_all hd hδ z hz)).2.2.congr_of_eventuallyEq
  filter_upwards [(show IsOpen LloydLocal.belt from isOpen_Ioo).eventually_mem hz] with t ht
  exact (agree_pos hd hδ ht).2.2

theorem primitive_eq_on_belt {δ z : ℝ} (hd : 0<δ) (hδ : δ≤1) (hz : z ∈ LloydLocal.belt) :
    primitive δ z = primitive δ (1/8) + LloydLocal.primitive δ z := by
  let f := integrand δ
  have h18 : (1/8:ℝ) ∈ LloydLocal.belt := by norm_num [LloydLocal.belt]
  have ib : IntervalIntegrable f volume 0 (1/8) := by
    apply ContinuousOn.intervalIntegrable
    intro t ht
    rw [uIcc_of_le (by norm_num : (0:ℝ) ≤ 1/8)] at ht
    rcases eq_or_lt_of_le ht.1 with rfl | ht'
    · exact (smooth_integrand_zero δ).continuousAt.continuousWithinAt
    · exact (smooth_i_belt hd hδ ⟨ht',lt_of_le_of_lt ht.2 (by norm_num)⟩).continuousAt.continuousWithinAt
  have ic : IntervalIntegrable f volume (1/8) z := by
    apply ContinuousOn.intervalIntegrable
    intro t ht
    exact (smooth_i_belt hd hδ (ordConnected_Ioo.uIcc_subset h18 hz ht)).continuousAt.continuousWithinAt
  have eqI : (∫ x in (1/8:ℝ)..z, f x) = LloydLocal.primitive δ z := by
    apply intervalIntegral.integral_congr
    intro t ht
    exact (agree_pos hd hδ (ordConnected_Ioo.uIcc_subset h18 hz ht)).2.2
  rw [← eqI]
  exact (intervalIntegral.integral_add_adjacent_intervals ib ic).symm

theorem germ_smooth {δ z : ℝ} (hd : 0<δ) (hδ : δ≤1) (hl : -(1/4:ℝ) < z) (hu : z<1/4) :
    ContDiffAt ℝ ∞ (primitive δ) z ∧ ContDiffAt ℝ ∞ (cosCoef δ) z ∧
      ContDiffAt ℝ ∞ (sinCoef δ) z := by
  have hra : 0 < 1-z^2 := by
    nlinarith [mul_pos (show 0<1+z by linarith) (show 0<1-z by linarith)]
  have hr : ContDiffAt ℝ ∞ radial z := by unfold radial; fun_prop (disch := positivity)
  have hn : radial z ≠0 := (Real.sqrt_pos.mpr hra).ne'
  rcases lt_trichotomy z 0 with hz | rfl | hz
  · have ev := isOpen_Ioo.eventually_mem (show z ∈ Ioo (-(1/4:ℝ)) 0 from ⟨hl,hz⟩)
    have h0 : ContDiffAt ℝ ∞ (fun _ : ℝ => (0:ℝ)) z := contDiffAt_const
    refine ⟨h0.congr_of_eventuallyEq ?_,h0.congr_of_eventuallyEq ?_,
      h0.congr_of_eventuallyEq ?_⟩
    · filter_upwards [ev] with t ht using (germ_zero δ ht.1 ht.2.le).1
    · filter_upwards [ev] with t ht using (germ_zero δ ht.1 ht.2.le).2.1
    · filter_upwards [ev] with t ht using (germ_zero δ ht.1 ht.2.le).2.2
  · have hQ (a : ℝ) : ContDiffAt ℝ ∞ (fun x : ℝ => q δ x * Real.sin (a + Real.log x)) 0 :=
      (smooth_q_angular δ a).comp 0 (contDiffAt_id.prodMk contDiffAt_const)
    have hc : ContDiffAt ℝ ∞ (fun x : ℝ => q δ x * Real.cos (azimuth x)) 0 := by
      simpa only [azimuth,Real.cos_neg,add_comm (Real.pi/2),Real.sin_add_pi_div_two] using hQ (Real.pi/2)
    have hs : ContDiffAt ℝ ∞ (fun x : ℝ => q δ x * Real.sin (azimuth x)) 0 := by
      simpa only [azimuth,Real.sin_neg,mul_neg,zero_add] using (hQ 0).neg
    exact ⟨primitive_smooth δ,hc.div hr hn,hs.div hr hn⟩
  · have hb : z ∈ LloydLocal.belt := ⟨hz,hu⟩
    have ev := (show IsOpen LloydLocal.belt from isOpen_Ioo).eventually_mem hb
    have hq : ContDiffAt ℝ ∞ (q δ) z := by
      apply (LloydLocal.smooth_coefficients (LloydLocal.gate_all hd hδ z hb)).2.1.congr_of_eventuallyEq
      filter_upwards [ev] with t ht using (agree_pos hd hδ ht).2.1
    have ha : ContDiffAt ℝ ∞ azimuth z := by unfold azimuth; fun_prop (disch := positivity)
    refine ⟨?_,by unfold cosCoef; fun_prop (disch := assumption),by unfold sinCoef; fun_prop (disch := assumption)⟩
    have hF := (LloydLocal.primitive_smooth (LloydLocal.gate_all hd hδ)).contDiffAt
      ((show IsOpen LloydLocal.belt from isOpen_Ioo).mem_nhds hb)
    apply (contDiffAt_const.add hF).congr_of_eventuallyEq
    filter_upwards [ev] with t ht using primitive_eq_on_belt hd hδ ht

#print axioms primitive_eq_on_belt
#print axioms germ_zero
#print axioms germ_smooth
end LloydFlatSpiral
