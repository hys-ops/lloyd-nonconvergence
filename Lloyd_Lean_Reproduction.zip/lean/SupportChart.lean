import SupportDerivative
import Chart
import LocalPotential

/-! # From scalar support on a chart to an exact population Lloyd step

The hypothesis about a candidate potential is an equality of scalar functions near
the point. No hypotheses about the gradient of the population objective or the
iterated centroid vectors are used. -/

open MeasureTheory Filter
open scoped Topology RealInnerProductSpace
open LloydCentroid LloydSpiral.Chart

namespace LloydSupportChart

noncomputable section

def logChart (μ : Measure E3) (z φ : ℝ) : ℝ :=
  Real.log (populationSupport μ (point z φ))

/-- The ambient derivative of the actual integral supplies both derivatives on the sphere. -/
theorem population_chart_gradient (μ : Measure E3) [IsProbabilityMeasure μ] {z φ : ℝ}
    (hz : 0 < 1-z^2) (ht : μ {x | ⟪x,point z φ⟫ = 0} = 0)
    (hi : Integrable (id : E3 → E3) μ) :
    IsChartGradient (logChart μ) z φ (tangentLogSupport μ (point z φ)) := by
  let u := point z φ
  have htang := tangentLogSupport_spec μ u (point_norm hz) ht hi
  have hd := ((signedMoment_hasGradientAt μ u ht hi).hasFDerivAt.log
    (populationSupport_pos μ u ht hi).ne').differentiableAt.hasFDerivAt
  have hp := point_partials (φ:=φ) hz
  refine ⟨(real_inner_comm _ _).trans htang.1, ?_, ?_⟩
  · rw [← htang.2 (heightVec z φ) (tangent_height hz)]
    exact hd.comp_hasDerivAt z hp.1
  · rw [← htang.2 (angleVec z φ) (tangent_angle z φ)]
    exact hd.comp_hasDerivAt φ hp.2

/-- A locally additive constant between chart potentials preserves their whole chart jet. -/
theorem chartGradient_congr_add {f g : ℝ → ℝ → ℝ} {z φ c : ℝ} {v : E3}
    (heq : (fun a : ℝ × ℝ => f a.1 a.2) =ᶠ[𝓝 (z,φ)] (fun a => c + g a.1 a.2))
    (hg : IsChartGradient g z φ v) : IsChartGradient f z φ v := by
  have hz' : Tendsto (fun t : ℝ => (t,φ)) (𝓝 z) (𝓝 (z,φ)) :=
    (continuous_id.prodMk continuous_const).continuousAt
  have hφ' : Tendsto (fun t : ℝ => (z,t)) (𝓝 φ) (𝓝 (z,φ)) :=
    (continuous_const.prodMk continuous_id).continuousAt
  refine ⟨hg.1, ?_, ?_⟩
  · apply ((hasDerivAt_const z c).add hg.2.1).congr_of_eventuallyEq (heq.comp_tendsto hz') |>.congr_deriv
    simp
  · apply ((hasDerivAt_const φ c).add hg.2.2).congr_of_eventuallyEq (heq.comp_tendsto hφ') |>.congr_deriv
    simp

theorem normalize_pos_smul {v : E3} {a : ℝ} (ha : 0 < a) :
    normalize (a • v) = normalize v := by
  simp [LloydSpiral.Chart.normalize, norm_smul, Real.norm_eq_abs, abs_of_pos ha, smul_smul, ha.ne']

/-- A scalar chart identity transfers a computed model step to the actual Voronoi centroids. -/
theorem normalized_update_of_local_chart (μ : Measure E3) [IsProbabilityMeasure μ]
    {z φ c r : ℝ} {f : ℝ → ℝ → ℝ} {g : E3} (hz : 0 < 1-z^2) (hr : 0 < r)
    (hμ : MeasurePreserving (fun x : E3 => -x) μ μ)
    (ht : μ {x | ⟪x,point z φ⟫ = 0} = 0) (hi : Integrable (id : E3 → E3) μ)
    (heq : (fun a : ℝ × ℝ => logChart μ a.1 a.2) =ᶠ[𝓝 (z,φ)] (fun a => c + f a.1 a.2))
    (hgrad : IsChartGradient f z φ g) :
    normalize (update μ (r • point z φ)).1 = normalize (point z φ + g) := by
  have hg := grad_unique hz (population_chart_gradient μ hz ht hi)
    (chartGradient_congr_add heq hgrad)
  rw [update_pos_sphere μ _ hr hμ ht hi, normalize_pos_smul (populationSupport_pos μ _ ht hi), hg]

/-- A law whose scalar support realizes the potential on the belt follows the explicit
spiral under its actual centroid update. The support identity is the only realization
input. Its constant multiplier can be arbitrary and positive. -/
theorem actual_spiral_step (μ : Measure E3) [IsProbabilityMeasure μ]
    {δ z c r : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hz : z ∈ LloydLocal.belt)
    (hc : 0 < c) (hr : 0 < r) (hμ : MeasurePreserving (fun x : E3 => -x) μ μ)
    (ht : μ {x | ⟪x, point z (azimuth z)⟫ = 0} = 0)
    (hi : Integrable (id : E3 → E3) μ)
    (hreal : ∀ t ∈ LloydLocal.belt, ∀ φ, populationSupport μ (point t φ) =
      c * Real.exp (LloydLocal.surface δ t φ)) :
    normalize (update μ (r • point z (azimuth z))).1 =
      point (nextHeight δ z) (azimuth (nextHeight δ z)) := by
  obtain ⟨g, hg, _⟩ := LloydLocal.exact_step hd hd' hz
  have hrad := (LloydLocal.gate_all hd hd' z hz).2.1
  have hlocal :
      (fun a : ℝ × ℝ => logChart μ a.1 a.2) =ᶠ[𝓝 (z, azimuth z)]
        (fun a => Real.log c + LloydLocal.surface δ a.1 a.2) := by
    have hh : ∀ᶠ a : ℝ × ℝ in 𝓝 (z, azimuth z), a.1 ∈ LloydLocal.belt :=
      continuous_fst.continuousAt (isOpen_Ioo.mem_nhds hz)
    filter_upwards [hh] with a ha
    simp only [logChart, hreal a.1 ha a.2, Real.log_mul hc.ne' (Real.exp_pos _).ne', Real.log_exp]
  exact (normalized_update_of_local_chart μ hrad hr hμ ht hi hlocal hg.1).trans hg.2

/-- The produced positive radius is genuine, so the one-step direction theorem can be
iterated with the actual labeled sites. -/
theorem actual_spiral_step_pair (μ : Measure E3) [IsProbabilityMeasure μ]
    {δ z c r : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hz : z ∈ LloydLocal.belt)
    (hc : 0 < c) (hr : 0 < r) (hμ : MeasurePreserving (fun x : E3 => -x) μ μ)
    (ht : μ {x | ⟪x, point z (azimuth z)⟫ = 0} = 0)
    (hi : Integrable (id : E3 → E3) μ)
    (hreal : ∀ t ∈ LloydLocal.belt, ∀ φ, populationSupport μ (point t φ) =
      c * Real.exp (LloydLocal.surface δ t φ)) :
    ∃ r' : ℝ, 0 < r' ∧ let v := point (nextHeight δ z) (azimuth (nextHeight δ z))
      update μ (r • point z (azimuth z)) = (r' • v, -(r' • v)) := by
  let u := point z (azimuth z)
  let m := signedMoment μ u
  have hm : m ≠ 0 := by
    intro hm
    have heul := inner_signedMoment μ u hi
    change ⟪u,m⟫ = _ at heul
    rw [hm, inner_zero_right] at heul
    exact (populationSupport_pos μ u ht hi).ne' heul.symm
  have hlen := norm_pos_iff.mpr hm
  have hup := (reflection_update μ u hr hμ ht hi).2.2
  have hdir := actual_spiral_step μ hd hd' hz hc hr hμ ht hi hreal
  change normalize (update μ (r • u)).1 = _ at hdir
  rw [hup] at hdir
  change normalize m = _ at hdir
  refine ⟨‖m‖, hlen, ?_⟩
  dsimp only
  rw [← hdir]
  change update μ (r • u) = _
  rw [hup]
  have hm2 : ‖m‖ • LloydSpiral.Chart.normalize m = m := by
    rw [LloydSpiral.Chart.normalize, smul_smul, mul_inv_cancel₀ hlen.ne', one_smul]
  rw [hm2]

#print axioms actual_spiral_step
#print axioms actual_spiral_step_pair
#print axioms population_chart_gradient
#print axioms chartGradient_congr_add
#print axioms normalized_update_of_local_chart

end
end LloydSupportChart
