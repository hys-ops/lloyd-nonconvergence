import Chart
import Mathlib.Analysis.Calculus.ContDiff.WithLp
import Mathlib.Analysis.Normed.Module.FiniteDimension

noncomputable section
open scoped RealInnerProductSpace ContDiff
namespace LloydNDFrame
abbrev E (m : ℕ) := EuclideanSpace ℝ (Fin m)
variable {m : ℕ}

def pack (z : ℝ) (v : E m) : E (m+1) := WithLp.toLp 2 (Fin.cons z (fun i => v i))
def head (x : E (m+1)) : ℝ := x 0
def tail (x : E (m+1)) : E m := WithLp.toLp 2 (fun i => x i.succ)
def equator (v : E m) := pack 0 v
def dir (z : ℝ) (v : E m) := pack z (LloydSpiral.Chart.radial z • v)

@[simp] theorem pack_zero (z : ℝ) (v : E m) : pack z v 0 = z := rfl
@[simp] theorem pack_succ (z : ℝ) (v : E m) (i : Fin m) : pack z v i.succ = v i := rfl
@[simp] theorem head_pack (z : ℝ) (v : E m) : head (pack z v) = z := rfl
@[simp] theorem tail_pack (z : ℝ) (v : E m) : tail (pack z v) = v := rfl
@[simp] theorem pack_head_tail (x : E (m+1)) : pack (head x) (tail x) = x := by
  ext i; exact Fin.cases rfl (fun _ => rfl) i

def packL : (ℝ × E m) →L[ℝ] E (m+1) :=
  LinearMap.toContinuousLinearMap
    { toFun := fun p => pack p.1 p.2
      map_add' := by intro p q; ext i; exact Fin.cases rfl (fun _ => rfl) i
      map_smul' := by intro c p; ext i; exact Fin.cases rfl (fun _ => rfl) i }
def headL : E (m+1) →L[ℝ] ℝ := EuclideanSpace.proj 0
def tailL : E (m+1) →L[ℝ] E m :=
  LinearMap.toContinuousLinearMap
    { toFun := tail
      map_add' := by intro p q; rfl
      map_smul' := by intro c p; rfl }
@[simp] theorem packL_apply (p : ℝ × E m) : packL p = pack p.1 p.2 := rfl
@[simp] theorem headL_apply (x : E (m+1)) : headL x = head x := rfl
@[simp] theorem tailL_apply (x : E (m+1)) : tailL x = tail x := rfl

theorem inner_pack (z w : ℝ) (u v : E m) :
  ⟪pack z u,pack w v⟫ = z*w + ⟪u,v⟫ := by
  simp only [PiLp.inner_apply,Fin.sum_univ_succ,pack_zero,pack_succ,Real.inner_apply]

theorem norm_pack_sq (z : ℝ) (v : E m) : ‖pack z v‖ ^ 2 = z^2 + ‖v‖ ^ 2 := by
  rw [←real_inner_self_eq_norm_sq,inner_pack,real_inner_self_eq_norm_sq,sq z]

theorem dir_norm {z : ℝ} {v : E m} (hz : 0 < 1-z^2) (hv : ‖v‖=1) : ‖dir z v‖=1 := by
  have hh := norm_pack_sq z (LloydSpiral.Chart.radial z • v)
  rw [norm_smul, hv,mul_one,Real.norm_eq_abs,sq_abs,LloydSpiral.Chart.radial_sq hz] at hh
  change ‖pack z _‖ = 1
  nlinarith [norm_nonneg (pack z (LloydSpiral.Chart.radial z • v))]
end LloydNDFrame
