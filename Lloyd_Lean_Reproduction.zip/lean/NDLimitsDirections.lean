import NDLimitsOrbit
import NDPrescribe
import NDFrame
import Mathlib.Analysis.Calculus.MeanValue

/-! Exact cluster directions of a latitude curve sampled on the reciprocal-height
clock. The angular curve is allowed to be an arbitrary smooth curve with dense tails
and bounded first derivative. -/
noncomputable section
open Filter Topology TopologicalSpace Set
open scoped RealInnerProductSpace NNReal ContDiff
namespace LloydNDLimits
open LloydNDFrame
variable {m : ℕ}
private theorem tendsto_belt {z : ℕ → ℝ} {x : ℕ → LloydNDFrame.E m} {w : LloydNDFrame.E m}
    (hz : Tendsto z atTop (𝓝 0)) (hw : Tendsto x atTop (𝓝 w)) :
    Tendsto (fun n => dir (z n) (x n)) atTop (𝓝 (equator w)) := by
  have hrad : Tendsto (fun n => Real.sqrt (1-(z n)^2)) atTop (𝓝 1) := by
    simpa only [zero_pow two_ne_zero,sub_zero,Real.sqrt_one] using
      ((tendsto_const_nhds (x := (1:ℝ))).sub (hz.pow 2)).sqrt
  have h: Tendsto (fun n=>Real.sqrt (1-(z n)^2) • x n) atTop (𝓝 w) := by
    simpa only [one_smul] using hrad.smul hw
  exact (packL (m:=m)).continuous.continuousAt.tendsto.comp (hz.prodMk_nhds h)

theorem dense_belt_limits {a : ℝ → LloydNDFrame.E m} (hs : ContDiff ℝ ∞ a)
    (ha : ∀ t, ‖a t‖=1) (hbound : ∃ C : ℝ, ∀ t, ‖iteratedFDeriv ℝ 1 a t‖≤C)
    (hdense : ∀ w : LloydNDFrame.E m, ‖w‖=1 → ∃ b : ℕ → ℝ, Tendsto b atTop atTop ∧
      Tendsto (a ∘ b) atTop (𝓝 w))
    {t z : ℕ → ℝ} (ht : Tendsto t atTop atTop)
    (hm : Tendsto (fun n=>t (n+1)-t n) atTop (𝓝 0)) (hz : Tendsto z atTop (𝓝 0))
    (v : LloydNDFrame.E (m+1)) :
    MapClusterPt v atTop (fun n => dir (z n) (a (t n))) ↔
      ∃ w : LloydNDFrame.E m, ‖w‖=1 ∧ v = equator w := by
  obtain ⟨C,hC⟩ := hbound
  let C' : ℝ≥0 := ⟨C, (norm_nonneg _).trans (hC 0)⟩
  have hLip : LipschitzWith C' a := lipschitzWith_of_nnnorm_fderiv_le (hs.differentiable (by simp))
    (fun x => by change ‖fderiv ℝ a x‖≤C; simpa only [norm_iteratedFDeriv_one] using hC x)
  constructor
  · intro H
    obtain ⟨k,hk,hv⟩ := H.tendsto_subseq
    have Hunit (n : ℕ) : a (t (k n)) ∈ Metric.sphere (0:LloydNDFrame.E m) 1 := by simpa using ha _
    obtain ⟨w,hw,j,hj,hlim⟩ := (isCompact_sphere (0:LloydNDFrame.E m) 1).tendsto_subseq Hunit
    refine ⟨w,by simpa using hw,tendsto_nhds_unique (hv.comp hj.tendsto_atTop) ?_⟩
    exact tendsto_belt ((hz.comp hk.tendsto_atTop).comp hj.tendsto_atTop) hlim
  · rintro ⟨w,hw,rfl⟩
    obtain ⟨b,hb',hw'⟩ := hdense w hw
    have H := LloydNDSpiral.sampled_tail hLip ht hm hb' hw'
    obtain ⟨k,hk,hk'⟩ := H.tendsto_subseq
    exact (tendsto_belt (hz.comp hk.tendsto_atTop) hk').mapClusterPt.of_comp hk.tendsto_atTop

#print axioms dense_belt_limits
end LloydNDLimits
