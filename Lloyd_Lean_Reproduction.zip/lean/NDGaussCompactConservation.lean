import NDGaussConservation
import Mathlib.MeasureTheory.Measure.Support

/-! Annular perturbations of smooth compact radial probability densities.
The angular weight can be chosen independently of the radial baseline. -/
noncomputable section
open MeasureTheory ProbabilityTheory Set Filter
open scoped Topology RealInnerProductSpace ENNReal ContDiff
namespace LloydNDRadialSource
open LloydNDPolar LloydNDNeutralShell LloydNDGaussian
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


theorem law_neg {f:Vn→ℝ} (he:∀x, f (-x) = f x) :
    MeasurePreserving (fun x:Vn=>-x) (law f) (law f) := by
  refine ⟨measurable_neg,?_⟩
  ext s hs
  unfold law
  rw [Measure.map_apply measurable_neg hs,withDensity_apply _ (measurable_neg hs),
    withDensity_apply _ hs]
  have H := ((Measure.measurePreserving_neg (volume:Measure Vn)).restrict_preimage hs).lintegral_comp_emb
    (MeasurableEquiv.neg Vn).measurableEmbedding (fun x=>ENNReal.ofReal (f x))
  simpa only [he] using H

theorem law_probability {f:Vn→ℝ} (hc:Continuous f) (hf:Integrable f) (hn:∀x,0≤f x)
    (hm:(∫x,f x)=1) : IsProbabilityMeasure (law f) := by
  let : IsFiniteMeasure (law f) := isFiniteMeasure_withDensity_ofReal hf.hasFiniteIntegral
  have ht := law_integral hc.measurable hn (fun _=>1)
  simp only [integral_const,smul_eq_mul,mul_one,one_mul,hm] at ht
  exact ⟨(ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) ENNReal.one_ne_top).mp (by
    simpa [measureReal_def] using ht)⟩

theorem law_mean {f:Vn→ℝ} (he:∀x, f (-x) = f x) : (∫x:Vn,x ∂law f)=0 := by
  have H := (law_neg he).integral_comp (MeasurableEquiv.neg Vn).measurableEmbedding id
  change (∫x:Vn,-x ∂law f) = ∫x:Vn,x ∂law f at H
  rw [integral_neg] at H
  ext i
  have hi := congrArg (fun x:Vn=>x i) H
  change -(∫x:Vn,x ∂law f) i = (∫x:Vn,x ∂law f) i at hi
  change (∫x:Vn,x ∂law f) i = 0
  linarith

/-- A unit-mass radial profile which is strictly positive on the open radius-three
ball. Agreement beyond that ball is specified by the caller's radial baseline. -/
structure Base where
  pdf : Vn → ℝ
  smooth : ContDiff ℝ ∞ pdf
  compact : HasCompactSupport pdf
  nonneg : ∀ x, 0≤pdf x
  positive : ∀ x, 0<pdf x ↔ ‖x‖<3
  radial : ∀ x y:Vn, ‖x‖=‖y‖ → pdf x=pdf y
  normed : (∫x,pdf x)=1

namespace Base
variable (b : Base (dim:=dim))

private lemma weighted (p:Vn→ℝ) (hc:Continuous p) : Integrable (fun x=>p x*b.pdf x) :=
  (hc.mul b.smooth.continuous).integrable_of_hasCompactSupport b.compact.mul_left

theorem constant_projection : ∃ C:ℝ,0<C ∧ ∀u:Vn,‖u‖=1 →
    (∫x, |⟪u,x⟫| * b.pdf x)=C := by
  let w : Sn := Classical.choice (NormedSpace.sphere_nonempty_rclike (𝕜:=ℝ) (zero_le_one : (0:ℝ)≤1))
  have hw : ‖w.val‖=1 := by simp
  refine ⟨(∫x:Vn, |⟪w.val,x⟫| * b.pdf x),?_,?_⟩
  · apply integral_pos_of_integrable_nonneg_nonzero (x:=w.val)
      (((continuous_const.inner continuous_id).abs).mul b.smooth.continuous) (b.weighted _ (by fun_prop))
    · intro x; exact mul_nonneg (abs_nonneg _) (b.nonneg x)
    · change |⟪w.val,w.val⟫| * b.pdf w.val≠0
      simp [hw,((b.positive w.val).2 (by rw [hw];norm_num)).ne']
  · intro u hu
    let R : Vn ≃ₗᵢ[ℝ] Vn := (ℝ ∙ (u-w.val))ᗮ.reflection
    have hr : R u=w.val := Submodule.reflection_sub (hu.trans hw.symm)
    have h := R.measurePreserving.integral_comp R.toHomeomorph.measurableEmbedding
      (fun x:Vn=> |⟪w.val,x⟫| * b.pdf x)
    refine Eq.trans ?_ h
    apply integral_congr_ae
    filter_upwards [] with x
    rw [←hr,R.inner_map_map,b.radial (R x) x (R.norm_map x)]

def perturbed (a:Vn→ℝ) (x:Vn) := b.pdf x + spatial a x
def measure (a:Vn→ℝ) := law (b.perturbed a)

theorem perturbed_smooth {a:Vn→ℝ} (ha:AngularSmooth a) : ContDiff ℝ ∞ (b.perturbed a) :=
  b.smooth.add (spatial_smooth ha)

theorem perturbed_compact (a:Vn→ℝ) : HasCompactSupport (b.perturbed a) :=
  b.compact.add (spatial_compact a)

theorem off_shell (a:Vn→ℝ) {x:Vn} (hx:‖x‖≤1 ∨ 2≤‖x‖) : b.perturbed a x=b.pdf x := by
  rcases hx with h|h <;> simp [perturbed,spatial,LloydNDFrequency.profile,
    show shell dim ‖x‖=0 by first | exact shell_zero_low dim h | exact shell_zero_high dim h]

theorem even {a:Vn→ℝ} (he:∀w,‖w‖=1→a (-w)=a w) (x:Vn) : b.perturbed a (-x)=b.perturbed a x := by
  rw [perturbed,perturbed,b.radial (-x) x (norm_neg x),spatial_even he]

theorem mass (a:Vn→ℝ) (ha:AngularSmooth a) : (∫x,b.perturbed a x)=1 := by
  unfold perturbed
  rw [integral_add (b.smooth.continuous.integrable_of_hasCompactSupport b.compact)
    ((spatial_smooth ha).continuous.integrable_of_hasCompactSupport (spatial_compact a)),
    b.normed,mass_zero ha,add_zero]

theorem probability {a:Vn→ℝ} (ha:AngularSmooth a) (hn:∀x,0≤b.perturbed a x) :
    IsProbabilityMeasure (b.measure a) :=
  law_probability (b.perturbed_smooth ha).continuous
    ((b.perturbed_smooth ha).continuous.integrable_of_hasCompactSupport (b.perturbed_compact a))
    hn (b.mass a ha)

theorem measure_L2 {a:Vn→ℝ} (ha:AngularSmooth a) (hn:∀x,0≤b.perturbed a x) :
    MemLp id 2 (b.measure a) := by
  apply (memLp_two_iff_integrable_sq_norm aestronglyMeasurable_id).2
  apply (law_integrable_iff (b.perturbed_smooth ha).continuous.measurable hn _).2
  exact ((continuous_norm.pow 2).mul (b.perturbed_smooth ha).continuous).integrable_of_hasCompactSupport
    (b.perturbed_compact a).mul_left

theorem expectation {a:Vn→ℝ} (ha:AngularSmooth a) (hn:∀x,0≤b.perturbed a x) (p:Vn→ℝ)
    (hc:Continuous p) : (∫x,p x ∂b.measure a) = (∫x,p x*b.pdf x)+∫x,p x*spatial a x := by
  rw [measure,law_integral (b.perturbed_smooth ha).continuous.measurable hn]
  simp only [perturbed,mul_add]
  exact integral_add (b.weighted _ hc) (spatial_integrable ha hc)

theorem covariance_preserved {a:Vn→ℝ} (ha:AngularSmooth a) (hn:∀x,0≤b.perturbed a x)
    (he:∀w,‖w‖=1→a (-w)=a w) : covarianceBilin (b.measure a)=covarianceBilin (law b.pdf) := by
  let := b.probability ha hn
  let := law_probability b.smooth.continuous (b.smooth.continuous.integrable_of_hasCompactSupport b.compact)
    b.nonneg b.normed
  have h2 : MemLp id 2 (law b.pdf) := (memLp_two_iff_integrable_sq_norm aestronglyMeasurable_id).2
    ((law_integrable_iff b.smooth.continuous.measurable b.nonneg _).2 (b.weighted _ (by fun_prop)))
  have hmean : (∫x:Vn,x ∂b.measure a)=0 := law_mean (b.even he)
  have h0 := law_mean (fun x=>b.radial (-x) x (norm_neg x))
  ext u v
  rw [covarianceBilin_apply (b.measure_L2 ha hn),covarianceBilin_apply h2]
  simp only [id_eq,hmean,h0,sub_zero]
  rw [b.expectation ha hn _ (by fun_prop),second_moment_zero ha,add_zero,
    law_integral b.smooth.continuous.measurable b.nonneg]

theorem projection {a:Vn→ℝ} (ha:AngularSmooth a) (hn:∀x,0≤b.perturbed a x) (u:Vn) :
    (∫x:Vn, |⟪u,x⟫| ∂b.measure a) = (∫x:Vn, |⟪u,x⟫| * b.pdf x) + cosineTransform (fun w=>a w.val) u := by
  rw [b.expectation ha hn _ (by fun_prop),projection_moment ha]

theorem exact_support {a:Vn→ℝ}
    (hp:∀x, ‖x‖<3 → 0<b.perturbed a x) :
    tsupport (b.perturbed a) = Metric.closedBall (0:Vn) 3 := by
  have hs : Function.support (b.perturbed a) = Metric.ball (0:Vn) 3 := by
    ext x
    simp only [Function.mem_support,Metric.mem_ball,dist_zero_right]
    constructor
    · contrapose!
      intro h
      rw [b.off_shell a (Or.inr (by linarith))]
      exact le_antisymm (not_lt.mp ((b.positive x).not.mpr (not_lt.mpr h))) (b.nonneg x)
    · intro h
      exact (hp x h).ne'
  change closure (Function.support (b.perturbed a))=_
  rw [hs]
  exact closure_ball _ (by norm_num)

end Base
#print axioms Base.constant_projection
#print axioms Base.covariance_preserved
#print axioms Base.exact_support
end LloydNDRadialSource
