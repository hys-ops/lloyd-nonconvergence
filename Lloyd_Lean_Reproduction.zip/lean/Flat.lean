import Mathlib.Analysis.SpecialFunctions.SmoothTransition
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

open Filter Set Polynomial
open scoped Topology

namespace LloydFlat
noncomputable section

/-- One-sided extension of the flat decrement in the height recurrence. -/
def bump (x : ℝ) : ℝ := if 0 < x then Real.exp (-(x⁻¹)^2) else 0

theorem bump_of_pos {x : ℝ} (hx : 0 < x) : bump x = Real.exp (-(1 / x^2)) := by
  simp [bump,hx,inv_pow]

theorem bump_nonneg (x : ℝ) : 0 ≤ bump x := by
  unfold bump; split <;> positivity

/-- The two polynomial coefficients form a family closed under differentiation. -/
def wave (k : ℝ) (p q : ℝ[X]) (x : ℝ) : ℝ :=
  (p.eval x⁻¹ * bump x) * Real.sin (k * Real.log x) +
  (q.eval x⁻¹ * bump x) * Real.cos (k * Real.log x)

def nextSin (k : ℝ) (p q : ℝ[X]) := 2 * X^3 * p - X^2 * p.derivative - C k * X * q

def nextCos (k : ℝ) (p q : ℝ[X]) := 2 * X^3 * q - X^2 * q.derivative + C k * X * p

private theorem amp_tendsto_zero (p : ℝ[X]) :
    Tendsto (fun x => p.eval x⁻¹ * bump x) (𝓝 0) (𝓝 0) := by
  have ht := (expNegInvGlue.tendsto_polynomial_inv_mul_zero p).norm
  apply squeeze_zero_norm' (a := fun x : ℝ => ‖p.eval x⁻¹ * expNegInvGlue x‖) _ (by simpa using ht)
  filter_upwards [gt_mem_nhds (zero_lt_one : (0:ℝ) < 1)] with x hx
  have hb : bump x ≤ expNegInvGlue x := by
    by_cases hp : 0 < x
    · have hinv : 1 ≤ x⁻¹ := (one_le_inv₀ hp).2 hx.le
      simp [bump, hp, expNegInvGlue, not_le.mpr hp]
      rw [← inv_pow]
      nlinarith [mul_nonneg (show 0 ≤ x⁻¹ by positivity) (sub_nonneg.mpr hinv)]
    · simp [bump,hp,expNegInvGlue.zero_of_nonpos (le_of_not_gt hp)]
  simp only [Real.norm_eq_abs, abs_mul, abs_of_nonneg (bump_nonneg x), abs_of_nonneg (expNegInvGlue.nonneg x)]
  exact mul_le_mul_of_nonneg_left hb (abs_nonneg _)

theorem wave_tendsto_zero (k : ℝ) (p q : ℝ[X]) :
    Tendsto (wave k p q) (𝓝 0) (𝓝 0) := by
  have hterm (P : ℝ[X]) (f : ℝ → ℝ) (hf : ∀ x, |f x| ≤ 1) :
      Tendsto (fun x => P.eval x⁻¹ * bump x * f x) (𝓝 0) (𝓝 0) := by
    apply squeeze_zero_norm' (a := fun x : ℝ => ‖P.eval x⁻¹ * bump x‖)
    · filter_upwards with x
      rw [norm_mul]
      exact mul_le_of_le_one_right (norm_nonneg _) (hf x)
    · simpa using (amp_tendsto_zero P).norm
  unfold wave
  simpa only [zero_add] using (hterm p _ (fun x => Real.abs_sin_le_one (k * Real.log x))).add
    (hterm q _ (fun x => Real.abs_cos_le_one (k * Real.log x)))

theorem hasDerivAt_wave (k : ℝ) (p q : ℝ[X]) (x : ℝ) :
    HasDerivAt (wave k p q) (wave k (nextSin k p q) (nextCos k p q) x) x := by
  rcases lt_trichotomy x 0 with hn | rfl | hp
  · have heq : wave k p q =ᶠ[𝓝 x] (fun _ => 0) := by
      filter_upwards [gt_mem_nhds hn] with y hy
      simp [wave,bump,not_lt.mpr hy.le]
    simpa [wave,bump,not_lt.mpr hn.le] using (hasDerivAt_const x (0:ℝ)).congr_of_eventuallyEq heq
  · rw [hasDerivAt_iff_tendsto_slope]
    simp only [wave,bump,lt_self_iff_false,ite_false,mul_zero,zero_mul,add_zero]
    refine ((wave_tendsto_zero k (X*p) (X*q)).mono_left inf_le_left).congr (fun x => ?_)
    by_cases h : 0 < x
    · simp [slope_def_field,wave,bump,h,div_eq_mul_inv]; ring
    · simp [slope_def_field,wave,bump,h,div_eq_mul_inv]
  · have hi := hasDerivAt_inv hp.ne'
    have hB := ((hi.pow 2).neg).exp
    have hp' := (p.hasDerivAt x⁻¹).comp x hi
    have hq' := (q.hasDerivAt x⁻¹).comp x hi
    have hl := (Real.hasDerivAt_log hp.ne').const_mul k
    have hh := (((hp'.mul hB).mul hl.sin).add ((hq'.mul hB).mul hl.cos))
    convert! hh.congr_of_eventuallyEq _ using 1
    · simp [wave,bump,hp,nextSin,nextCos,inv_pow]
      ring
    · filter_upwards [lt_mem_nhds hp] with y hy
      simp [wave,bump,hy]

theorem deriv_wave (k : ℝ) (p q : ℝ[X]) : deriv (wave k p q) = wave k (nextSin k p q) (nextCos k p q) :=
  funext fun x => (hasDerivAt_wave k p q x).deriv

theorem contDiff_wave (k : ℝ) {n : ℕ∞} (p q : ℝ[X]) : ContDiff ℝ n (wave k p q) := by
  apply contDiff_all_iff_nat.2 (fun m => ?_) n
  induction m generalizing p q with
  | zero => exact contDiff_zero.2 (Differentiable.continuous (fun x => (hasDerivAt_wave k p q x).differentiableAt))
  | succ m ih =>
    rw [show ((m+1 : ℕ) : WithTop ℕ∞) = m+1 from rfl]
    exact contDiff_succ_iff_deriv.2 ⟨fun x => (hasDerivAt_wave k p q x).differentiableAt,
      by simp, by rw [deriv_wave]; exact ih _ _⟩

theorem iteratedDeriv_wave_zero (k : ℝ) (n : ℕ) (p q : ℝ[X]) : iteratedDeriv n (wave k p q) 0 = 0 := by
  induction n generalizing p q with
  | zero => simp [wave,bump]
  | succ n ih => rw [iteratedDeriv_succ',deriv_wave]; exact ih _ _

theorem tendsto_iteratedDeriv_wave_zero (k : ℝ) (n : ℕ) (p q : ℝ[X]) :
    Tendsto (iteratedDeriv n (wave k p q)) (𝓝 0) (𝓝 0) := by
  simpa only [iteratedDeriv_wave_zero] using
    ((contDiff_wave k (n := ⊤) p q).continuous_iteratedDeriv n (by simp)).continuousAt (x := 0) |>.tendsto

/-- A frequency-dependent angular germ with an arbitrary inverse-polynomial prefactor. -/
def angular (k φ : ℝ) (p : ℝ[X]) (x : ℝ) : ℝ :=
  (p.eval x⁻¹ * bump x) * Real.sin (φ + k * Real.log x)

theorem angular_eq_wave (k φ : ℝ) (p : ℝ[X]) :
    angular k φ p = wave k (C (Real.cos φ) * p) (C (Real.sin φ) * p) := by
  funext x
  simp [angular,wave,Real.sin_add]
  ring

theorem contDiff_angular (k φ : ℝ) (p : ℝ[X]) : ContDiff ℝ (⊤ : ℕ∞) (angular k φ p) := by
  rw [angular_eq_wave]; exact contDiff_wave _ _ _

theorem iteratedDeriv_angular_zero (k φ : ℝ) (p : ℝ[X]) (n : ℕ) :
    iteratedDeriv n (angular k φ p) 0 = 0 := by
  rw [angular_eq_wave]; exact iteratedDeriv_wave_zero _ _ _ _

theorem tendsto_iteratedDeriv_angular_zero (k φ : ℝ) (p : ℝ[X]) (n : ℕ) :
    Tendsto (iteratedDeriv n (angular k φ p)) (𝓝 0) (𝓝 0) := by
  rw [angular_eq_wave]; exact tendsto_iteratedDeriv_wave_zero _ _ _ _

theorem wave_zero_frequency (p : ℝ[X]) : wave 0 0 p = (fun x : ℝ => p.eval x⁻¹ * bump x) := by
  funext x; simp [wave]

theorem contDiff_amplitude (p : ℝ[X]) :
    ContDiff ℝ (⊤ : ℕ∞) (fun x : ℝ => p.eval x⁻¹ * bump x) := by
  simpa only [wave_zero_frequency] using (contDiff_wave 0 (n := ⊤) 0 p)

theorem iteratedDeriv_amplitude_zero (p : ℝ[X]) (n : ℕ) :
    iteratedDeriv n (fun x : ℝ => p.eval x⁻¹ * bump x) 0 = 0 := by
  simpa only [wave_zero_frequency] using (iteratedDeriv_wave_zero 0 n 0 p)

theorem tendsto_iteratedDeriv_amplitude_zero (p : ℝ[X]) (n : ℕ) :
    Tendsto (iteratedDeriv n (fun x : ℝ => p.eval x⁻¹ * bump x)) (𝓝 0) (𝓝 0) := by
  simpa only [wave_zero_frequency] using (tendsto_iteratedDeriv_wave_zero 0 n 0 p)

theorem angular_of_pos (k φ : ℝ) (p : ℝ[X]) {x : ℝ} (hx : 0 < x) :
    angular k φ p x = (p.eval x⁻¹ * Real.exp (-(1/x^2))) * Real.sin (φ + k * Real.log x) := by
  rw [angular,bump_of_pos hx]

/-- Joint smoothness in height and angle, including across the equator. -/
theorem contDiff_angular_joint (k : ℝ) (p : ℝ[X]) :
    ContDiff ℝ (⊤ : ℕ∞) (fun w : ℝ × ℝ => angular k w.2 p w.1) := by
  have hA := (contDiff_wave k (n := ⊤) p 0).comp (contDiff_fst : ContDiff ℝ (⊤ : ℕ∞) (Prod.fst : ℝ × ℝ → ℝ))
  have hB := (contDiff_wave k (n := ⊤) 0 p).comp (contDiff_fst : ContDiff ℝ (⊤ : ℕ∞) (Prod.fst : ℝ × ℝ → ℝ))
  have hc := Real.contDiff_cos.comp (contDiff_snd : ContDiff ℝ (⊤ : ℕ∞) (Prod.snd : ℝ × ℝ → ℝ))
  have hs := Real.contDiff_sin.comp (contDiff_snd : ContDiff ℝ (⊤ : ℕ∞) (Prod.snd : ℝ × ℝ → ℝ))
  convert! (hA.mul hc).add (hB.mul hs) using 1
  funext w
  simp [wave,angular,Real.sin_add]
  ring

end
end LloydFlat

#print axioms LloydFlat.contDiff_angular_joint
#print axioms LloydFlat.iteratedDeriv_angular_zero
#print axioms LloydFlat.tendsto_iteratedDeriv_angular_zero
#print axioms LloydFlat.tendsto_iteratedDeriv_amplitude_zero
