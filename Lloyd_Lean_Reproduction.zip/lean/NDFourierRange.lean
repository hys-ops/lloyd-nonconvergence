import NDFourierMoment
import NDFrequencyFamily

/-! The Euclidean cosine moment maps real even Schwartz densities onto smooth
even angular data. The inverse uses one fixed annulus, independent of the datum. -/
noncomputable section
open MeasureTheory Filter
open scoped FourierTransform SchwartzMap RealInnerProductSpace Topology ContDiff
namespace LloydNDFourierRange

variable {dim : ℕ}
local notation "Space" => EuclideanSpace ℝ (Fin dim)

/-- Universal signed moment of the radial frequency window. -/
def factor : ℝ :=
  -(∫ t : ℝ, LloydNDFrequency.window |t| / t^2) / LloydNDFourierMoment.normalizer

theorem factor_neg : factor < 0 :=
  div_neg_of_neg_of_pos (neg_lt_zero.mpr LloydNDFrequency.window_moment_pos)
    LloydNDFourierMoment.normalizer_pos

/-- This only uses the prescribed Fourier restriction along the one chosen line. -/
theorem moment_eq {f : 𝓢(Space,ℝ)} {v : ℝ} (u : Space)
    (hray : ∀ t : ℝ, 𝓕 (fun x => (f x : ℂ)) (t • u) =
        ↑(LloydNDFrequency.window |t| * v)) :
    (∫ x, |⟪x,u⟫| * f x) = factor * v := by
  have h0 := hray 0
  simp only [zero_smul,abs_zero,LloydNDFrequency.window_low 0 zero_lt_one,zero_mul,
    Complex.ofReal_zero] at h0
  have hs := LloydNDFourierMoment.schwartz_line_moment f u
  rw [h0] at hs
  simp_rw [hray] at hs
  have ht (t : ℝ) : ((0 : ℂ).re-(↑(LloydNDFrequency.window |t| * v) : ℂ).re)/t^2 =
      (LloydNDFrequency.window |t| / t^2)*(-v) := by simp;ring
  simp only [ht,integral_mul_const] at hs
  apply (mul_left_inj' LloydNDFourierMoment.normalizer_pos.ne').mp
  rw [hs]
  unfold factor
  field_simp [LloydNDFourierMoment.normalizer_pos.ne']

/-- The inverse Fourier transform is the specified real continuous linear operator,
so controlled input families remain controlled as Schwartz functions. -/
theorem canonical_range {h : Space → ℝ} (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u)
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) :
    let f := LloydNDFrequency.inverseRealCLM (LloydNDFrequency.windowSchwartz h hh)
    (∀ x, f (-x) = f x) ∧ ∀ u, ‖u‖ = 1 → (∫ x, |⟪x,u⟫| * f x) = factor * h u := by
  obtain ⟨hf,hray⟩ := LloydNDFrequency.windowSchwartz_spec hh he
  exact ⟨hf, fun u hu => moment_eq u (hray u hu)⟩

theorem exists_range {h : Space → ℝ} (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u)
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) :
    ∃ f : 𝓢(Space,ℝ), (∀ x, f (-x) = f x) ∧
      ∀ u, ‖u‖ = 1 → (∫ x, |⟪x,u⟫| * f x) = factor * h u :=
  ⟨_,canonical_range hh he⟩

/-- A continuously small real Schwartz right inverse, with no normalization
depending on the datum or on the varying parameter. -/
def rightInverse (h : Space → ℝ) (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u) : 𝓢(Space,ℝ) :=
  factor⁻¹ • LloydNDFrequency.inverseRealCLM (LloydNDFrequency.windowSchwartz h hh)

theorem rightInverse_spec {h : Space → ℝ} (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u)
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) :
    (∀ x, rightInverse h hh (-x) = rightInverse h hh x) ∧
    ∀ u, ‖u‖ = 1 → (∫ x, |⟪x,u⟫| * rightInverse h hh x) = h u := by
  let f := LloydNDFrequency.inverseRealCLM (LloydNDFrequency.windowSchwartz h hh)
  obtain ⟨hfe,hm⟩ := canonical_range hh he
  constructor
  · intro x
    change factor⁻¹ * f (-x) = factor⁻¹ * f x
    rw [show f (-x)=f x from hfe x]
  · intro u hu
    calc
      _ = ∫ x, factor⁻¹ * (|⟪x,u⟫| * f x) := by
        congr 1
        funext x
        change |⟪x,u⟫| * (factor⁻¹ * f x) = _
        ring
      _ = factor⁻¹ * (factor * h u) := by rw [integral_const_mul];exact congrArg _ (hm u hu)
      _ = h u := by rw [←mul_assoc,inv_mul_cancel₀ factor_neg.ne,one_mul]

theorem rightInverse_tendsto {H : ℝ × Space → ℝ} (hh : LloydNDFrequency.SmoothOnDirections H)
    (hz : ∀ u, ‖u‖ = 1 → H (0,u) = 0) :
    Tendsto (fun t => rightInverse (fun u => H (t,u)) (LloydNDFrequency.slice_smooth hh t))
      (𝓝 0) (𝓝 0) := by
  simpa only [rightInverse,LloydNDFrequency.windowFamily,smul_zero] using
    (LloydNDFrequency.windowFamily_inverse_tendsto hh hz).const_smul factor⁻¹

#print axioms rightInverse_spec
#print axioms rightInverse_tendsto
#print axioms factor_neg
#print axioms moment_eq
#print axioms canonical_range
#print axioms exists_range
end LloydNDFourierRange
