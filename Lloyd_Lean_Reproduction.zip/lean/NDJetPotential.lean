import NDFlatPrimitive
import NDFrame
import Mathlib.Analysis.InnerProductSpace.Calculus

/-! A scalar potential with a prescribed ambient gradient along a height graph.
The integral compensates the change of the chord coefficient along the graph. -/
noncomputable section
open Filter Set
open scoped Topology ContDiff SchwartzMap RealInnerProductSpace
namespace LloydNDPotential
open LloydNDFlat LloydNDFrame
variable {m : ℕ}
local notation "V" => LloydNDFrame.E (m+1)

def compensation (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) : 𝓢(Plane,ℝ) :=
  -(SchwartzMap.bilinLeftCLM (innerSL ℝ) (hP.comp (ContinuousLinearMap.snd ℝ ℝ ℝ).hasTemperateGrowth)
    (jet (0,1) G))

theorem compensation_apply (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (b : Plane) :
    compensation G P hP b = -⟪jet (0,1) G b,P b.2⟫ := rfl

def north (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) (x : V) : ℝ :=
  primitive (compactify (compensation G P hP)) (δ,head x) + ⟪compactify G (δ,head x),x⟫

def potential (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) (x : V) : ℝ :=
  north G P hP δ x + north G P hP δ (-x)

theorem smooth_north (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) :
    ContDiff ℝ ∞ (fun p : ℝ × V => north G P hP p.1 p.2) := by
  have hp : ContDiff ℝ ∞ (fun p : ℝ × V => (p.1,head p.2)) :=
    contDiff_fst.prodMk (headL.contDiff.comp contDiff_snd)
  exact ((contDiff_primitive (contDiff_compactify (compensation G P hP))).comp hp).add
    (((contDiff_compactify G).comp hp).inner ℝ contDiff_snd)

theorem smooth (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) :
    ContDiff ℝ ∞ (fun p : ℝ × V => potential G P hP p.1 p.2) :=
  (smooth_north G P hP).add ((smooth_north G P hP).comp (contDiff_fst.prodMk contDiff_snd.neg))

theorem even (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) (x : V) :
    potential G P hP δ (-x) = potential G P hP δ x := by simp [potential,add_comm]

private theorem north_nonpos (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (δ : ℝ) (x : V) (hx : head x ≤ 0) : north G P hP δ x = 0 := by
  have hi : primitive (compactify (compensation G P hP)) (δ,head x) = 0 := by
    unfold primitive
    apply (intervalIntegral.integral_congr (g:=fun _ : ℝ => (0:ℝ)) ?_).trans (by simp)
    intro t ht
    rw [uIcc_of_ge hx] at ht
    simp [compactify,not_lt.mpr ht.2]
  simp [north,hi,compactify,not_lt.mpr hx]

theorem seam_value (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) {x : V}
    (hx : head x = 0) : potential G P hP δ x = 0 := by
  have hx' : head (-x)=0 := by change -(head x)=0; rw [hx,neg_zero]
  simp [potential,north_nonpos G P hP δ x hx.le,north_nonpos G P hP δ (-x) hx'.le]

private theorem section_deriv (G : 𝓢(Plane,V)) (δ z : ℝ) :
    HasDerivAt (fun s => compactify G (δ,s)) (compactify (jet (0,1) G) (δ,z)) z := by
  have hh := (differentiable_compactify G (δ,z)).hasFDerivAt.comp_hasDerivAt z
    ((hasDerivAt_const z δ).prodMk (hasDerivAt_id z))
  simpa [LloydNDFlat.deriv_eq,Function.comp_def] using hh

private theorem north_deriv_apply (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (δ : ℝ) (x v : V) :
    fderiv ℝ (north G P hP δ) x v =
      compactify (compensation G P hP) (δ,head x) * head v +
      (⟪compactify G (δ,head x),v⟫ +
        head v * ⟪compactify (jet (0,1) G) (δ,head x),x⟫) := by
  have ha := (hasDerivAt_primitive (contDiff_compactify (compensation G P hP)).continuous δ
    (head x)).hasFDerivAt.comp x (headL (m:=m)).hasFDerivAt
  have hg := (section_deriv G δ (head x)).hasFDerivAt.comp x (headL (m:=m)).hasFDerivAt
  have ht := ha.add (hg.inner ℝ (hasFDerivAt_id x))
  change fderiv ℝ _ x v = _
  rw [show fderiv ℝ (north G P hP δ) x = _ from ht.fderiv]
  simp [real_inner_smul_left,mul_comm]

private theorem north_diff (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (δ : ℝ) (x : V) : DifferentiableAt ℝ (north G P hP δ) x := by
  exact ((smooth_north G P hP).comp (contDiff_const.prodMk contDiff_id)).differentiable (by simp) x

private theorem derivative_apply (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (δ : ℝ) (x v : V) : fderiv ℝ (potential G P hP δ) x v =
      fderiv ℝ (north G P hP δ) x v + fderiv ℝ (north G P hP δ) (-x) (-v) := by
  have hh := (north_diff G P hP δ x).hasFDerivAt.add ((north_diff G P hP δ (-x)).hasFDerivAt.comp x
    (hasFDerivAt_id x).neg)
  rw [show fderiv ℝ (potential G P hP δ) x = _ from hh.fderiv]
  rfl

private theorem potential_diff (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (δ : ℝ) (x : V) : DifferentiableAt ℝ (potential G P hP δ) x :=
  ((smooth G P hP).comp (contDiff_const.prodMk contDiff_id)).differentiable (by simp) x

theorem seam_derivative (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) {x : V}
    (hx : head x = 0) : HasFDerivAt (potential G P hP δ) (0 : V →L[ℝ] ℝ) x := by
  apply (potential_diff G P hP δ x).hasFDerivAt.congr_fderiv
  ext v
  have hx' : head (-x)=0 := by change -(head x)=0; rw [hx,neg_zero]
  simp [derivative_apply,north_deriv_apply,hx,hx',compactify]

theorem track_derivative (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth) (δ : ℝ) {x : V}
    (hx : 0 < head x) (hX : x = P (head x)⁻¹) :
    HasFDerivAt (potential G P hP δ) (innerSL ℝ (G (δ,(head x)⁻¹))) x := by
  apply (potential_diff G P hP δ x).hasFDerivAt.congr_fderiv
  ext v
  have hx' : ¬0<head (-x) := by change ¬0< -(head x); linarith
  simp [derivative_apply,north_deriv_apply,compactify,hx,hx',compensation_apply]
  rw [←hX]
  ring

private theorem section_jet_zero (G : 𝓢(Plane,V)) (hG : ∀ t, G (0,t) = 0) (z : ℝ) :
    compactify (jet (0,1) G) (0,z) = 0 := by
  have hsec : (fun s : ℝ => compactify G (0,s)) = fun _ => 0 := by
    funext s; simp [compactify,hG]
  have hd := (section_deriv G 0 z).deriv
  rw [hsec] at hd
  simpa using hd.symm

theorem zero_parameter (G : 𝓢(Plane,V)) (P : ℝ → V) (hP : P.HasTemperateGrowth)
    (hG : ∀ t, G (0,t) = 0) (x : V) : potential G P hP 0 x = 0 := by
  have hcomp (z:ℝ) : compactify (compensation G P hP) (0,z) = 0 := by
    by_cases hz : 0<z
    · have hj := section_jet_zero G hG z
      simp [compactify,hz] at hj
      simp [compactify,hz,compensation_apply,hj]
    · simp [compactify,hz]
  have hn (v:V) : north G P hP 0 v = 0 := by
    have hprim : primitive (compactify (compensation G P hP)) (0,head v) = 0 := by
      simp [primitive,hcomp]
    simp [north,hprim,compactify,hG]
  simp [potential,hn]
end LloydNDPotential
