import NDGaussCutoff
import NDGaussBase
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

/-! Positive Gaussian density with a small neutral shell. The rank-one term in
the Hessian of minus log is nonnegative; a bound on the relative shell and its
second differential suffices, without a smallness constraint on its first derivative. -/
noncomputable section
open MeasureTheory Filter Set
open scoped RealInnerProductSpace Topology ContDiff SchwartzMap
namespace LloydNDGaussianShape
open LloydNDPolar LloydNDAngular LloydNDNeutralShell
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def base (C : ℝ) (x : Vn) := C * Real.exp (-‖x‖^2/2)

def relativeWindow (C : ℝ) (x : Vn) :=
  (LloydNeutralShell.shell ‖x‖ * (‖x‖^2)^2) / base C x

lemma base_pos {C : ℝ} (hC : 0<C) (x : Vn) : 0 < base C x := mul_pos hC (Real.exp_pos _)

theorem base_smooth (C : ℝ) : ContDiff ℝ ∞ (base (dim:=dim) C) := by
  have hn : ContDiff ℝ ∞ (fun x : Vn => ‖x‖^2) := contDiff_norm_sq ℝ
  unfold base
  fun_prop

theorem relativeWindow_smooth {C : ℝ} (hC : 0<C) : ContDiff ℝ ∞ (relativeWindow (dim:=dim) C) := by
  have hG : ContDiff ℝ ∞ (fun x : Vn => LloydNeutralShell.shell ‖x‖) := by
    have h := LloydNDFrequency.profile_smooth (h:=fun _ : Vn => 1) zero_lt_one
      (fun _ _ => contDiffAt_const) LloydNeutralShell.shell_smooth LloydNeutralShell.shell_low
    convert h using 1
    funext x
    simp [LloydNDFrequency.profile]
  have hn : ContDiff ℝ ∞ (fun x : Vn => ‖x‖^2) := contDiff_norm_sq ℝ
  exact (hG.mul (hn.pow 2)).div (base_smooth C) (fun x => (base_pos hC x).ne')

theorem relativeWindow_compact (C : ℝ) : HasCompactSupport (relativeWindow (dim:=dim) C) := by
  apply (isCompact_closedBall (0:Vn) 2).of_isClosed_subset isClosed_closure
  apply closure_minimal _ Metric.isClosed_closedBall
  intro x hx
  contrapose! hx
  have h : 2 < ‖x‖ := by simpa [Metric.mem_closedBall] using hx
  simp [Function.mem_support,relativeWindow,LloydNeutralShell.shell_high _ h]

theorem relativeWindow_away (C : ℝ) : tsupport (relativeWindow C) ⊆ (away : Set Vn) := by
  have hs : tsupport (relativeWindow C) ⊆ {x:Vn | 1 ≤ ‖x‖} := by
    apply closure_minimal _ (isClosed_le continuous_const continuous_norm)
    intro x hx
    contrapose! hx
    have h : ‖x‖ < 1 := by simpa using hx
    simp [Function.mem_support,relativeWindow,LloydNeutralShell.shell_low _ h]
  intro x hx
  have h := hs hx
  change (1:ℝ)/2 < ‖x‖
  change 1 ≤ ‖x‖ at h
  linarith

/-- The relative multiplier recovers the genuine additive spatial shell on all of space. -/
theorem shell_as_relative {C : ℝ} (hC : 0<C) (f : 𝓢(Vn,ℝ)) (x : Vn) :
    base C x + spatial (radialize f) x =
      base C x * (1 + cutoffMoment (relativeWindow C) (dim+1) f x) := by
  unfold spatial LloydNDFrequency.profile
  change base C x + shell dim ‖x‖ * radialize f (‖x‖⁻¹ • x) =
    base C x * (1 + ((LloydNeutralShell.shell ‖x‖ * (‖x‖^2)^2) / base C x) * radialize f x)
  by_cases hx : x = 0
  · simp [hx,shell_zero_low dim (by norm_num : (0:ℝ)≤1),LloydNeutralShell.shell_low _ zero_lt_one]
  · have hr := norm_pos_iff.mpr hx
    have ht := radialize_homogeneous f (‖x‖⁻¹ • x) hr
    rw [smul_smul,mul_inv_cancel₀ hr.ne',one_smul] at ht
    rw [←ht]
    rw [show ‖x‖^(dim+2) = ‖x‖^dim * ‖x‖^2 by rw [pow_add]]
    have hc := unweight dim hr
    field_simp [(base_pos hC x).ne']
    linear_combination (‖x‖^2 * radialize f x) * hc

/-- Exact Hessian of log(1+b), with no linewise or formal differentiation assumptions. -/
theorem log_hessian {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b) (hp : ∀ x, 0<1+b x) (x v : Vn) :
    fderiv ℝ (fderiv ℝ (fun y => Real.log (1+b y))) x v v =
      (1+b x)⁻¹ * fderiv ℝ (fderiv ℝ b) x v v -
      ((1+b x)^2)⁻¹ * (fderiv ℝ b x v)^2 := by
  have h1 (y:Vn) : HasFDerivAt (fun z => 1+b z) (fderiv ℝ b y) y :=
    ((hb.differentiable (by simp) y).hasFDerivAt.const_add 1)
  have he : fderiv ℝ (fun z => Real.log (1+b z)) =
      fun y => (1+b y)⁻¹ • fderiv ℝ b y :=
    funext fun y => ((h1 y).log (hp y).ne').fderiv
  have ha := (hasDerivAt_inv (hp x).ne').comp_hasFDerivAt x (h1 x)
  have hdb := ((hb.fderiv_right (m:=1) (by simp)).differentiable (by norm_num) x).hasFDerivAt
  rw [he]
  change (fderiv ℝ (((fun y : ℝ => y⁻¹) ∘ fun z => 1+b z) • fderiv ℝ b) x) v v = _
  rw [(ha.smul hdb).fderiv]
  simp [ContinuousLinearMap.smulRight_apply]
  ring

theorem negative_log_hessian {C : ℝ} (hC : 0<C) {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b)
    (hp : ∀ x, 0<1+b x) (x v : Vn) :
    fderiv ℝ (fderiv ℝ (fun y => -Real.log (base C y*(1+b y)))) x v v =
      ‖v‖^2 - fderiv ℝ (fderiv ℝ (fun y => Real.log (1+b y))) x v v := by
  let J := fun y : Vn => Real.log (1+b y)
  have hJ : ContDiff ℝ ∞ J := (contDiff_const.add hb).log (fun y => (hp y).ne')
  have he : (fun y => -Real.log (base C y*(1+b y))) = fun y => ‖y‖^2/2-J y-Real.log C := by
    funext y
    rw [Real.log_mul (base_pos hC y).ne' (hp y).ne',base,Real.log_mul hC.ne' (Real.exp_pos _).ne',
      Real.log_exp]; dsimp [J]; ring
  have hsq (y:Vn) : HasFDerivAt (fun z : Vn => ‖z‖^2/2) (innerSL ℝ y) y := by
    have h := (hasStrictFDerivAt_norm_sq y).hasFDerivAt.const_smul (1/2:ℝ)
    convert! h using 1
    · funext z
      change ‖z‖^2/2 = (1/2)*‖z‖^2
      ring
    · ext v
      simp [two_nsmul]
      ring
  have hd : fderiv ℝ (fun y : Vn => ‖y‖^2/2-J y-Real.log C) =
      ⇑(innerSL ℝ (E:=Vn)) - fderiv ℝ J := by
    funext y
    exact (((hsq y).sub ((hJ.differentiable (by simp)) y).hasFDerivAt).sub_const (Real.log C)).fderiv
  rw [he,hd,((innerSL ℝ (E:=Vn)).hasFDerivAt.sub
    ((hJ.fderiv_right (m:=1) (by simp)).differentiable (by norm_num) x).hasFDerivAt).fderiv]
  change ⟪v,v⟫ - _ = _
  rw [real_inner_self_eq_norm_sq]
  rfl

/-- Smooth positive full-space shell perturbations of a Gaussian satisfy the
pointwise lower curvature target of the manuscript. -/
theorem eventually_positive_gaussian {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) {C : ℝ} (hC : 0<C) :
    ∀ᶠ i in l, let ρ := fun x : Vn => base C x + spatial (radialize (F i)) x
      (∀ x, 0 < ρ x) ∧ ContDiff ℝ ∞ ρ ∧
      ∀ x v : Vn, ‖v‖^2/2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v := by
  have hs := relativeWindow_smooth (dim:=dim) hC
  have he := cutoff_eventually_small hF hs (relativeWindow_compact C)
    (relativeWindow_away C) (dim+1) (by norm_num : (0:ℝ)<1/4)
  filter_upwards [he] with i hi
  let b := cutoffMoment (relativeWindow C) (dim+1) (F i)
  have hb := cutoffMoment_smooth hs (relativeWindow_away C) (dim+1) (F i)
  have hr (x:Vn) : 1/2 < 1+b x := by
    have hh : |b x| < 1/4 := (hi x).1
    linarith [(abs_lt.mp hh).1]
  have hp (x:Vn) : 0 < 1+b x := by linarith [hr x]
  have hρ : (fun x:Vn => base C x + spatial (radialize (F i)) x) =
      fun x => base C x*(1+b x) := funext (shell_as_relative hC (F i))
  change (∀ x, 0 < base C x + spatial (radialize (F i)) x) ∧ _ ∧ _
  refine ⟨fun x => (shell_as_relative hC (F i) x) ▸ mul_pos (base_pos hC x) (hp x),?_,?_⟩
  · rw [hρ]
    exact (base_smooth C).mul (contDiff_const.add hb)
  · intro x v
    rw [hρ,negative_log_hessian hC hb hp,log_hessian hb hp]
    let D := fderiv ℝ (fderiv ℝ b) x
    have hd : D v v ≤ (1/4)*‖v‖^2 := calc
      _ ≤ ‖D v v‖ := Real.le_norm_self _
      _ ≤ ‖D v‖*‖v‖ := (D v).le_opNorm _
      _ ≤ (‖D‖*‖v‖)*‖v‖ := by gcongr; exact D.le_opNorm _
      _ ≤ ((1/4)*‖v‖)*‖v‖ := by gcongr; exact (hi x).2.2.le
      _ = _ := by ring
    have hi2 : (1+b x)⁻¹ ≤ 2 := by
      rw [inv_eq_one_div,div_le_iff₀ (hp x)]
      linarith [hr x]
    have hu : (1+b x)⁻¹ * D v v ≤ (1/2)*‖v‖^2 := calc
      _ ≤ (1+b x)⁻¹ * ((1/4)*‖v‖^2) := by gcongr; exact inv_nonneg.mpr (hp x).le
      _ ≤ 2*((1/4)*‖v‖^2) := by gcongr
      _ = _ := by ring
    have hgood : 0 ≤ ((1+b x)^2)⁻¹ * (fderiv ℝ b x v)^2 := by positivity
    change ‖v‖^2/2 ≤ ‖v‖^2 - ((1+b x)⁻¹ * D v v - _)
    linarith

/-- The perturbed *standard* Gaussian agrees pointwise with its reference
density also at both boundary spheres. Its volume density is strictly positive
on all of space, so every nonempty open set has positive probability. -/
theorem eventually_standard_shell {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) :
    ∀ᶠ i in l, let ρ := fun x : Vn => LloydNDGaussian.pdf x + spatial (radialize (F i)) x
      (∀ x, 0 < ρ x) ∧ ContDiff ℝ ∞ ρ ∧
      (∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x = LloydNDGaussian.pdf x) ∧
      Measure.IsOpenPosMeasure (LloydNDGaussian.law ρ) ∧
      ∀ x v : Vn, ‖v‖^2/2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v := by
  have hpdf : base (LloydNDGaussian.Z dim)⁻¹ = LloydNDGaussian.pdf (dim:=dim) := by
    funext x
    unfold base LloydNDGaussian.pdf
    congr 2
    ring
  have h := eventually_positive_gaussian hF (C:=(LloydNDGaussian.Z dim)⁻¹) (inv_pos.mpr (LloydNDGaussian.Z_pos dim))
  rw [hpdf] at h
  filter_upwards [h] with i hi
  obtain ⟨hp,hs,hb⟩ := hi
  refine ⟨hp,hs,?_,?_,hb⟩
  · intro x hx
    have hz : shell dim ‖x‖ = 0 := by
      by_cases hlow : ‖x‖ ≤ 1
      · exact shell_zero_low dim hlow
      · exact shell_zero_high dim (le_of_not_gt (fun hh => hx ⟨lt_of_not_ge hlow,hh⟩))
    change LloydNDGaussian.pdf x + shell dim ‖x‖ * _ = LloydNDGaussian.pdf x
    rw [hz,zero_mul,add_zero]
  · apply Measure.AbsolutelyContinuous.isOpenPosMeasure (μ:=(volume : Measure Vn))
    exact withDensity_absolutelyContinuous' hs.continuous.measurable.ennreal_ofReal.aemeasurable
      (.of_forall (fun x => (ENNReal.ofReal_pos.mpr (hp x)).ne'))

#print axioms eventually_standard_shell
#print axioms log_hessian
#print axioms eventually_positive_gaussian
end LloydNDGaussianShape
