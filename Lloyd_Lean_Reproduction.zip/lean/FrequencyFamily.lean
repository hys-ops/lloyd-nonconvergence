import FrequencyAnnulus
import SchwartzFamily

/-! The real inverse constructed by the annular prescription varies continuously
in the Schwartz topology at zero. Only joint smoothness at unit directions is used. -/
noncomputable section
open MeasureTheory Filter Set SchwartzMap FourierTransform
open scoped FourierTransform RealInnerProductSpace Topology ContDiff
namespace LloydFrequency

abbrev SmoothOnDirections (H : ℝ × E → ℝ) :=
  ∀ p : ℝ × E, ‖p.2‖ = 1 → ContDiffAt ℝ ∞ H p

lemma slice_smooth {H : ℝ × E → ℝ} (hh : SmoothOnDirections H) (t : ℝ) (u : E) (hu : ‖u‖=1) :
    ContDiffAt ℝ ∞ (fun v => H (t,v)) u := by
  apply (hh (t,u) hu).comp (f := fun v : E => (t,v)) u
  exact contDiffAt_const.prodMk contDiffAt_id

/-- Complex Schwartz frequency data with the same compact annular support for
every parameter. -/
def windowFamily (H : ℝ × E → ℝ) (hh : SmoothOnDirections H) (t : ℝ) : 𝓢(E,ℂ) :=
  windowSchwartz (fun v => H (t,v)) (slice_smooth hh t)

theorem windowFamily_smooth {H : ℝ × E → ℝ} (hh : SmoothOnDirections H) :
    ContDiff ℝ ∞ (fun w : ℝ × E => windowFamily H hh w.1 w.2) := by
  apply contDiff_iff_contDiffAt.2
  rintro ⟨t,x⟩
  by_cases hx : x = 0
  · subst x
    apply (contDiffAt_const (c:=(0:ℂ))).congr_of_eventuallyEq
    filter_upwards [continuous_snd.continuousAt.preimage_mem_nhds
      (Metric.ball_mem_nhds (0:E) zero_lt_one)] with q hq
    have hm : ‖q.2‖ < 1 := by simpa [Metric.mem_ball] using hq
    simp [windowFamily,windowSchwartz_apply,window_low _ hm]
  · have hnorm : ContDiffAt ℝ ∞ (fun w : ℝ × E => ‖w.2‖) (t,x) :=
      contDiffAt_snd.norm ℝ hx
    have hdir : ContDiffAt ℝ ∞ (fun w : ℝ × E => ‖w.2‖⁻¹ • w.2) (t,x) :=
      (hnorm.inv (norm_ne_zero_iff.mpr hx)).smul contDiffAt_snd
    have hunit : ‖‖x‖⁻¹ • x‖ = 1 := by
      rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr (norm_nonneg x)),
        inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)]
    have harg := (hh (t,‖x‖⁻¹ • x) hunit).comp (f := fun w : ℝ × E => (w.1,‖w.2‖⁻¹ • w.2))
      (t,x) (contDiffAt_fst.prodMk hdir)
    have hout := (window.contDiff.contDiffAt.comp (f:=fun w : ℝ × E => ‖w.2‖) (t,x) hnorm).mul harg
    exact Complex.ofRealCLM.contDiff.contDiffAt.comp (t,x) hout

theorem windowFamily_tsupport {H : ℝ × E → ℝ} (hh : SmoothOnDirections H) (t : ℝ) :
    tsupport (windowFamily H hh t : E → ℂ) ⊆ Metric.closedBall (0:E) 3 := by
  apply closure_minimal _ Metric.isClosed_closedBall
  intro x hx
  contrapose! hx
  have hn : 3 < ‖x‖ := by simpa [Metric.mem_closedBall] using hx
  simp [Function.mem_support,windowFamily,windowSchwartz_apply,window_high _ hn]

theorem windowFamily_zero {H : ℝ × E → ℝ} (hh : SmoothOnDirections H)
    (hz : ∀ u, ‖u‖=1 → H (0,u) = 0) : windowFamily H hh 0 = 0 := by
  ext x
  by_cases hx : x = 0
  · simp [windowFamily,windowSchwartz_apply,hx,window_low _ zero_lt_one]
  · have hunit : ‖‖x‖⁻¹ • x‖ = 1 := by
      rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr (norm_nonneg x)),
        inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)]
    simp [windowFamily,windowSchwartz_apply,hz _ hunit]

/-- A fixed right inverse carries smooth perturbations vanishing on the sphere
at parameter zero to small signed Euclidean Schwartz densities. -/
theorem windowFamily_inverse_tendsto {H : ℝ × E → ℝ} (hh : SmoothOnDirections H)
    (hz : ∀ u, ‖u‖=1 → H (0,u) = 0) :
    Tendsto (fun t => inverseRealCLM (windowFamily H hh t)) (𝓝 0) (𝓝 0) := by
  have h := LloydSchwartz.tendsto_zero_of_compact_slices _ (windowFamily_smooth hh)
    (windowFamily_zero hh hz) _ (isCompact_closedBall (0:E) 3) (windowFamily_tsupport hh)
  rw [←inverseRealCLM.map_zero]
  exact inverseRealCLM.continuous.continuousAt.tendsto.comp h

#print axioms windowFamily_inverse_tendsto
end LloydFrequency
