import NDMainData
import NDSpan
import Mathlib.Topology.Homeomorph.Lemmas

/-! Topology of the unordered cluster set. The projective space is given its
usual sphere-quotient topology, with u and -u identified. The cluster set has
the subspace topology in the hyperspace of nonempty compact configurations. -/
noncomputable section
open Filter Set Topology TopologicalSpace MeasureTheory
namespace LloydNDProjective
open LloydNDFrame LloydNDLimits LloydNDMain
abbrev UnitSphere (m:ℕ) := Metric.sphere (0:E m) 1

def antipodal (m:ℕ) : Setoid (UnitSphere m) where
  r u v := (u:E m)=(v:E m) ∨ (u:E m) = -(v:E m)
  iseqv := {
    refl := fun _ => Or.inl rfl
    symm := by
      intro u v h
      rcases h with e|e
      · exact Or.inl e.symm
      · exact Or.inr (by rw [e,neg_neg])
    trans := by
      intro u v w h h'
      rcases h with e|e <;> rcases h' with f|f <;> simp [e,f]
  }

/-- RP^(m-1) in its sphere-quotient model. -/
abbrev RealProjective (m:ℕ) := Quotient (antipodal m)

def axisMap {m:ℕ} (c:ℝ) (u:UnitSphere m) : NonemptyCompacts (E (m+1)) :=
  axis (c • equator (u:E m))

theorem continuous_axisMap {m:ℕ} (c:ℝ) : Continuous (axisMap (m:=m) c) :=
  continuous_axis.comp ((continuous_const (X:=UnitSphere m) (y:=c)).smul ((equatorL (m:=m)).continuous.comp continuous_subtype_val))

private theorem axis_eq {m:ℕ} {x y:E m} : axis x = axis y ↔ x=y ∨ x=-y := by
  constructor
  · intro h
    have hx : x ∈ (axis x : Set (E m)) := by simp [axis,LloydProduct.unordered]
    rw [h] at hx
    simpa [axis,LloydProduct.unordered,or_comm] using hx
  · rintro (rfl|rfl)
    · rfl
    · simp [axis,LloydProduct.unordered,sup_comm]

theorem axes_eq_iff {m:ℕ} {c:ℝ} (hc:c≠0) (u v:UnitSphere m) :
    axisMap c u=axisMap c v ↔ (antipodal m).r u v := by
  change axis (c • equatorL (u:E m)) = axis (c • equatorL (v:E m)) ↔ _ 
  rw [axis_eq]
  have h (x y:E m) (e:c • equatorL x = c • equatorL y) : x=y := by
    have h' := congrArg (fun z:E (m+1) => tailL (c⁻¹ • z)) e
    simpa [smul_smul,hc,equator] using h'
  constructor
  · rintro (e|e)
    · exact Or.inl (h _ _ e)
    · exact Or.inr (h _ _ (by simpa [map_neg] using e))
  · rintro (e|e)
    · exact Or.inl (by rw [e])
    · exact Or.inr (by rw [e,map_neg,smul_neg])

def quotientToAxes {m:ℕ} {c:ℝ} (hc:c≠0) :
    RealProjective m → range (axisMap (m:=m) c) :=
  Quotient.lift (fun u => ⟨axisMap c u,mem_range_self u⟩)
    (fun u v h => Subtype.ext ((axes_eq_iff hc u v).2 h))

theorem quotientToAxes_bijective {m:ℕ} {c:ℝ} (hc:c≠0) :
    Function.Bijective (quotientToAxes (m:=m) hc) := by
  constructor
  · intro u v
    induction u using Quotient.inductionOn with
    | _ u =>
      induction v using Quotient.inductionOn with
      | _ v =>
        intro h
        exact Quotient.sound ((axes_eq_iff hc u v).1 (congrArg Subtype.val h))
  · rintro ⟨P,u,rfl⟩
    exact ⟨Quotient.mk _ u,rfl⟩

/-- The canonical map sends the class of u to the unordered pair {±c·(0,u)}. -/
def axesHomeomorph {m:ℕ} {c:ℝ} (hc:c≠0) :
    RealProjective m ≃ₜ range (axisMap (m:=m) c) := by
  let e := Equiv.ofBijective (quotientToAxes (m:=m) hc) (quotientToAxes_bijective hc)
  apply Continuous.homeoOfEquivCompactToT2 (f:=e)
  exact ((continuous_axisMap c).subtype_mk (fun u => mem_range_self u)).quotient_lift _

def clusterSet {m:ℕ} (μ:Measure (E m)) (y:E m) : Set (NonemptyCompacts (E m)) :=
  {P | MapClusterPt P atTop (fun n => LloydProduct.unordered (trajectory μ y n))}

theorem cluster_homeomorphic {m:ℕ} {μ:Measure (E (m+1))} {y:E (m+1)}
    (h:ProjectiveOrbit μ y) : Nonempty (RealProjective m ≃ₜ clusterSet μ y) := by
  obtain ⟨c,hc,he,_,_⟩ := h
  have eqs : range (axisMap (m:=m) c) = clusterSet μ y := by
    ext P
    change (_ ↔ MapClusterPt _ _ _)
    rw [he]
    constructor
    · rintro ⟨u,rfl⟩
      exact ⟨u.1,by simpa using u.2,rfl⟩
    · rintro ⟨u,hu,rfl⟩
      exact ⟨⟨u,by simpa using hu⟩,rfl⟩
  exact ⟨(axesHomeomorph hc.ne').trans (Homeomorph.setCongr eqs)⟩

#print axioms cluster_homeomorphic
end LloydNDProjective
