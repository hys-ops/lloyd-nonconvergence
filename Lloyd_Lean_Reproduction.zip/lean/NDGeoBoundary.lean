import NDGeoConvex
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Analysis.Calculus.Gradient.Basic
import Mathlib.Analysis.Calculus.LocalExtr.Basic
import Mathlib.Tactic

/-! Regular smooth boundaries and positive curvature for the actual perturbed ball.
The second fundamental form is computed from the derivative of the outward unit
normal; the tangent test is the kernel of the differential of the defining level. -/
noncomputable section
open Set Filter
open scoped RealInnerProductSpace Topology ContDiff
namespace LloydNDGeom
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim

def level (b : Vn → ℝ) (x : Vn) := ‖x‖^2-b x

def outerNormal (J : Vn → ℝ) (x : Vn) : Vn := ‖gradient J x‖⁻¹ • gradient J x

theorem level_smooth {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b) : ContDiff ℝ ∞ (level b) :=
  (contDiff_norm_sq ℝ).sub hb

theorem level_fderiv {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b) (x : Vn) :
    fderiv ℝ (level b) x = 2 • innerSL ℝ x - fderiv ℝ b x :=
  ((hasStrictFDerivAt_norm_sq x).hasFDerivAt.sub ((hb.differentiable (by simp)) x).hasFDerivAt).fderiv

theorem level_hessian {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b) (x v : Vn) :
    fderiv ℝ (fderiv ℝ (level b)) x v v = 2 * ‖v‖^2 - fderiv ℝ (fderiv ℝ b) x v v := by
  have he : fderiv ℝ (level b) = (⇑(innerSL ℝ (E:=Vn)) + ⇑(innerSL ℝ (E:=Vn))) - fderiv ℝ b := by
    funext y
    simpa only [Pi.sub_apply,Pi.add_apply,two_nsmul] using level_fderiv hb y
  have hd : DifferentiableAt ℝ (fderiv ℝ b) x :=
    (hb.fderiv_right (m:=1) (by simp)).differentiable (by norm_num) x
  have h2 := (innerSL ℝ (E:=Vn)).hasFDerivAt (x:=x)
  rw [he,((h2.add h2).sub hd.hasFDerivAt).fderiv]
  simp [two_mul]
  change ⟪v,v⟫ + ⟪v,v⟫ = _
  rw [real_inner_self_eq_norm_sq]

/-- Unit normal of a regular level and its true differential on tangent vectors.
The right-hand side is the implicit-level Hessian formula for the second
fundamental form, with outward convention (strictly positive on a sphere). -/
theorem normal_derivative_tangent {J : Vn → ℝ} (hJ : ContDiff ℝ ∞ J) {x v : Vn}
    (hn : gradient J x ≠ 0) (ht : fderiv ℝ J x v = 0) :
    ⟪fderiv ℝ (outerNormal J) x v,v⟫ =
      ‖gradient J x‖⁻¹ * fderiv ℝ (fderiv ℝ J) x v v := by
  let A := (InnerProductSpace.toDual ℝ Vn).symm.toContinuousLinearEquiv.toContinuousLinearMap
  have hA : HasFDerivAt (gradient J) (A.comp (fderiv ℝ (fderiv ℝ J) x)) x :=
    A.hasFDerivAt.comp x
      ((hJ.fderiv_right (m:=1) (by simp)).differentiable (by norm_num) x).hasFDerivAt
  have hr : DifferentiableAt ℝ (fun y => ‖gradient J y‖⁻¹) x :=
    (hA.differentiableAt.norm ℝ hn).inv (norm_ne_zero_iff.mpr hn)
  have ht' : ⟪gradient J x,v⟫ = 0 := by
    rwa [gradient, InnerProductSpace.toDual_symm_apply]
  unfold outerNormal
  rw [fderiv_fun_smul hr hA.differentiableAt,hA.fderiv]
  simp [A,ContinuousLinearMap.smulRight_apply,inner_add_left,real_inner_smul_left,ht',
    InnerProductSpace.toDual_symm_apply]

/-- On the actual unit sublevel boundary the radial derivative is strictly
positive; this provides an explicit direction of transversality. -/
theorem level_regular {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b)
    (h0 : ∀ x, |b x| ≤ 1/4) (h1 : ∀ x, ‖fderiv ℝ b x‖ ≤ 1)
    {x : Vn} (hx : level b x = 1) : 0 < fderiv ℝ (level b) x x := by
  have hnorm : 1/2 < ‖x‖ := by
    have h := (abs_le.mp (h0 x)).1
    unfold level at hx
    nlinarith [norm_nonneg x]
  have hle : fderiv ℝ b x x ≤ ‖x‖ := calc
    _ ≤ ‖fderiv ℝ b x x‖ := Real.le_norm_self _
    _ ≤ ‖fderiv ℝ b x‖ * ‖x‖ := (fderiv ℝ b x).le_opNorm x
    _ ≤ 1 * ‖x‖ := by gcongr; exact h1 x
    _ = ‖x‖ := one_mul _
  rw [level_fderiv hb]
  simp only [sub_apply,two_nsmul,add_apply,
    innerSL_apply_apply,real_inner_self_eq_norm_sq]
  nlinarith [mul_pos (show 0 < ‖x‖ by linarith) (show 0 < 2*‖x‖-1 by linarith)]

theorem level_frontier {J : Vn → ℝ} (hJ : Continuous J)
    (hn : ∀ x, J x = 1 → fderiv ℝ J x ≠ 0) :
    frontier {x | J x ≤ 1} = {x | J x = 1} := by
  apply Set.Subset.antisymm (frontier_le_subset_eq hJ continuous_const)
  intro x hx
  change J x = 1 at hx
  rw [frontier,(isClosed_le hJ continuous_const).closure_eq]
  refine ⟨hx.le,?_⟩
  intro hInt
  have hmax : IsLocalMax J x := by
    filter_upwards [mem_interior_iff_mem_nhds.mp hInt] with y hy
    exact hx ▸ (show J y ≤ 1 from hy)
  exact hn x hx hmax.fderiv_eq_zero

/-- Extrinsic positive curvature of a smooth regular level. A unit tangent vector
has positive normal curvature, as computed from the differential of the actual
outward unit normal. -/
def HasPositiveCurvedBoundary (K : Set Vn) : Prop :=
  ∃ J : Vn → ℝ, ContDiff ℝ ∞ J ∧ K = {x | J x ≤ 1} ∧
    frontier K = {x | J x = 1} ∧ ∀ x ∈ frontier K,
      fderiv ℝ J x ≠ 0 ∧ ‖outerNormal J x‖=1 ∧
      ∀ v : Vn, v ≠ 0 → fderiv ℝ J x v = 0 → 0 < ⟪fderiv ℝ (outerNormal J) x v,v⟫

theorem regular_curved_sublevel {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b)
    (h0 : ∀ x, |b x| ≤ 1/4) (h1 : ∀ x, ‖fderiv ℝ b x‖ ≤ 1)
    (h2 : ∀ x, ‖fderiv ℝ (fderiv ℝ b) x‖ ≤ 1) :
    HasPositiveCurvedBoundary {x | ‖x‖^2 - b x ≤ 1} := by
  have hreg (x : Vn) (hx : level b x = 1) : fderiv ℝ (level b) x ≠ 0 := by
    intro he
    have h := level_regular hb h0 h1 hx
    rw [he] at h
    exact lt_irrefl _ h
  have hf := level_frontier (level_smooth hb).continuous hreg
  refine ⟨level b,level_smooth hb,rfl,hf,?_⟩
  intro x hx
  have hxJ : level b x = 1 := by
    exact (Set.ext_iff.mp hf x).mp hx
  have hn : gradient (level b) x ≠ 0 := by
    intro h
    apply hreg x hxJ
    rw [←toDual_gradient,h,map_zero]
  refine ⟨hreg x hxJ,?_,?_⟩
  · simp [outerNormal,norm_smul,inv_mul_cancel₀ (norm_ne_zero_iff.mpr hn)]
  · intro v hv htan
    rw [normal_derivative_tangent (level_smooth hb) hn htan,level_hessian hb]
    apply mul_pos (inv_pos.mpr (norm_pos_iff.mpr hn))
    let H := fderiv ℝ (fderiv ℝ b) x
    have h : H v v ≤ ‖v‖^2 := calc
      _ ≤ ‖H v v‖ := Real.le_norm_self _
      _ ≤ ‖H v‖*‖v‖ := (H v).le_opNorm v
      _ ≤ (‖H‖*‖v‖)*‖v‖ := by gcongr; exact H.le_opNorm v
      _ ≤ (1*‖v‖)*‖v‖ := by gcongr; exact h2 x
      _ = _ := by ring
    change 0 < 2*‖v‖^2 - H v v
    linarith [sq_pos_of_pos (norm_pos_iff.mpr hv)]

#print axioms normal_derivative_tangent
#print axioms regular_curved_sublevel
end LloydNDGeom
