import Centroid
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.Analysis.Calculus.Deriv.Abs
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.Gradient.Basic
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-!
# Derivative of the population centroid support

The null hyperplane condition is needed only at the direction of differentiation.
The sample, its law, and the Hilbert-space dimension are arbitrary.
-/

noncomputable section

open MeasureTheory Filter
open scoped RealInnerProductSpace Topology

namespace LloydCentroid

variable {Ω E : Type*} [MeasurableSpace Ω] [NormedAddCommGroup E]
  [InnerProductSpace ℝ E] [CompleteSpace E] {μ : Measure Ω}

/-- Exact Fréchet derivative of the expectation of the absolute projection. -/
theorem hasFDerivAt_absProjectionIntegral {X : Ω → E} (hX : Integrable X μ)
    {u : E} (htie : ∀ᵐ ω ∂μ, ⟪u, X ω⟫ ≠ 0) :
    HasFDerivAt (fun v : E => ∫ ω, |⟪v, X ω⟫| ∂μ)
      (innerSL ℝ (∫ ω, if 0 < ⟪u, X ω⟫ then X ω else -X ω ∂μ)) u := by
  classical
  let Y : Ω → E := fun ω => if 0 < ⟪u, X ω⟫ then X ω else -X ω
  have hproj (v : E) : Integrable (fun ω => ⟪v, X ω⟫) μ :=
    (innerSL ℝ v).integrable_comp hX
  have hY : Integrable Y μ := by
    let pom := (hproj u).aestronglyMeasurable
    let s := {ω | 0 < pom.mk (fun a => ⟪u, X a⟫) ω}
    have hs : MeasurableSet s := measurableSet_lt measurable_const pom.stronglyMeasurable_mk.measurable
    have hy := Integrable.piecewise hs hX.integrableOn hX.neg.integrableOn
    apply hy.congr
    filter_upwards [pom.ae_eq_mk] with ω hω
    simp only [Set.piecewise, s, Set.mem_ofPred_eq, Y, hω, Pi.neg_apply]
  have hp : HasFDerivAt (fun v : E => ∫ ω, |⟪X ω, v⟫| ∂μ)
      (∫ ω, innerSL ℝ (Y ω) ∂μ) u := by
    apply (hasFDerivAt_integral_of_dominated_loc_of_lip'
      (F := fun v ω => |⟪X ω, v⟫|)
      (F' := fun ω => innerSL ℝ (Y ω))
      (bound := fun ω => ‖X ω‖)
      (s := Set.univ) Filter.univ_mem ?_ ?_ ?_ ?_ hX.norm ?_).2
    · intro v _
      simpa only [Real.norm_eq_abs, real_inner_comm (X _) v] using (hproj v).norm.aestronglyMeasurable
    · simpa only [Real.norm_eq_abs, real_inner_comm (X _) u] using (hproj u).norm
    · exact (innerSL ℝ : E →L[ℝ] E →L[ℝ] ℝ).continuous.comp_aestronglyMeasurable
        hY.aestronglyMeasurable
    · filter_upwards [] with ω
      intro v _
      calc ‖|⟪X ω, v⟫| - |⟪X ω, u⟫|‖ ≤ |⟪X ω, v⟫ - ⟪X ω, u⟫| :=
             abs_abs_sub_abs_le _ _
        _ = |⟪X ω, v-u⟫| := by rw [inner_sub_right]
        _ ≤ ‖X ω‖ * ‖v-u‖ := abs_real_inner_le_norm _ _
    · filter_upwards [htie] with ω hω
      have hd := (innerSL ℝ (X ω)).hasFDerivAt (x := u)
      by_cases hpos : 0 < ⟪u, X ω⟫
      · have hp : 0 < (innerSL ℝ (X ω)) u := by
          simpa [innerSL_apply_apply, real_inner_comm (X ω) u] using hpos
        simpa [Y, hpos, innerSL_apply_apply] using hd.abs_of_pos hp
      · have hn : (innerSL ℝ (X ω)) u < 0 := by
          simpa [innerSL_apply_apply, real_inner_comm (X ω) u] using lt_of_le_of_ne
            (le_of_not_gt hpos) hω
        simpa [Y, hpos, innerSL_apply_apply] using hd.abs_of_neg hn
  rw [(innerSL ℝ : E →L[ℝ] E →L[ℝ] ℝ).integral_comp_comm hY] at hp
  simpa only [Y, real_inner_comm (X _) _] using hp

/-- The Hilbert-space gradient itself is the signed moment. -/
theorem hasGradientAt_absProjectionIntegral {X : Ω → E} (hX : Integrable X μ)
    {u : E} (htie : ∀ᵐ ω ∂μ, ⟪u, X ω⟫ ≠ 0) :
    HasGradientAt (fun v : E => ∫ ω, |⟪v, X ω⟫| ∂μ)
      (∫ ω, if 0 < ⟪u, X ω⟫ then X ω else -X ω ∂μ) u :=
  (hasGradientAt_iff_hasFDerivAt).2 (hasFDerivAt_absProjectionIntegral hX htie)

/-- The homogeneous population support on the actual three-dimensional source. -/
def populationSupport (μ : Measure LloydCentroid.E) (u : LloydCentroid.E) : ℝ :=
  ∫ x, |⟪x, u⟫| ∂μ

/-- The derivative and the Voronoi-cell computation give the same vector. -/
theorem signedMoment_hasGradientAt (μ : Measure LloydCentroid.E) (u : LloydCentroid.E)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) :
    HasGradientAt (populationSupport μ) (signedMoment μ u) u := by
  have h : ∀ᵐ x ∂μ, ⟪u, id x⟫ ≠ 0 := by
    apply ae_iff.mpr
    simpa only [id_eq, real_inner_comm u _, not_not] using ht
  have hg := hasGradientAt_absProjectionIntegral hi h
  have hfun : populationSupport μ = (fun v => ∫ x : LloydCentroid.E, |⟪v, x⟫| ∂μ) := by
    funext v
    simp only [populationSupport, real_inner_comm v _]
  rw [hfun]
  simpa only [signedMoment, signedPoint, id_eq, real_inner_comm u _] using hg

open scoped Gradient in
/-- The ordinary Lloyd update equals the two signed gradients of the same scalar support. -/
theorem update_eq_supportGradient (μ : Measure LloydCentroid.E) [IsProbabilityMeasure μ]
    (u : LloydCentroid.E) {r : ℝ} (hr : 0 < r)
    (hμ : MeasurePreserving (fun x : LloydCentroid.E => -x) μ μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) :
    update μ (r • u) = (∇ (populationSupport μ) u, -∇ (populationSupport μ) u) := by
  rw [(signedMoment_hasGradientAt μ u ht hi).gradient]
  exact (reflection_update μ u hr hμ ht hi).2.2

/-- Euler's radial identity, including at directions where ties have positive mass. -/
theorem inner_signedMoment (μ : Measure LloydCentroid.E) (u : LloydCentroid.E)
    (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) :
    ⟪u, signedMoment μ u⟫ = populationSupport μ u := by
  classical
  have hs : Integrable (signedPoint u) μ := by
    have heq : signedPoint u = (positive u).piecewise id (-id) := by
      funext x
      by_cases h : 0 < ⟪x,u⟫ <;> simp [positive, Set.piecewise, signedPoint, h]
    rw [heq]
    exact Integrable.piecewise (positive_meas u) hi.integrableOn hi.neg.integrableOn
  change innerSL ℝ u (∫ x, signedPoint u x ∂μ) = _
  rw [← (innerSL ℝ u).integral_comp_comm hs]
  apply integral_congr_ae
  filter_upwards [] with x
  by_cases h : 0 < ⟪x,u⟫
  · simp only [signedPoint, h, ite_true, innerSL_apply_apply, abs_of_pos h]
    exact real_inner_comm _ _
  · simp only [signedPoint, h, ite_false, innerSL_apply_apply, inner_neg_right,
      abs_of_nonpos (le_of_not_gt h)]
    rw [real_inner_comm u x]

/-- The support is positive under the null-tie condition for a probability source. -/
theorem populationSupport_pos (μ : Measure LloydCentroid.E) [IsProbabilityMeasure μ]
    (u : LloydCentroid.E) (ht : μ {x | ⟪x,u⟫ = 0} = 0)
    (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) : 0 < populationSupport μ u := by
  have hpi : Integrable (fun x : LloydCentroid.E => |⟪x,u⟫|) μ := by
    simpa only [Real.norm_eq_abs, id_eq, innerSL_apply_apply, real_inner_comm u _] using
      ((innerSL ℝ u).integrable_comp hi).norm
  apply (integral_pos_iff_support_of_nonneg (fun x => abs_nonneg ⟪x,u⟫) hpi).2
  have hs : Function.support (fun x : LloydCentroid.E => |⟪x,u⟫|) = {x | ⟪x,u⟫ = 0}ᶜ := by
    ext x
    simp [Function.support]
  rw [hs, (prob_compl_eq_one_iff₀ (.of_null ht)).2 ht]
  exact zero_lt_one

/-- Tangent logarithmic gradient on the unit sphere, represented in ambient coordinates. -/
def tangentLogSupport (μ : Measure LloydCentroid.E) (u : LloydCentroid.E) : LloydCentroid.E :=
  (populationSupport μ u)⁻¹ • signedMoment μ u - u

theorem tangentLogSupport_spec (μ : Measure LloydCentroid.E) [IsProbabilityMeasure μ]
    (u : LloydCentroid.E) (hu : ‖u‖ = 1) (ht : μ {x | ⟪x,u⟫ = 0} = 0)
    (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) :
    ⟪u, tangentLogSupport μ u⟫ = 0 ∧
    ∀ w : LloydCentroid.E, ⟪u,w⟫ = 0 →
      fderiv ℝ (fun v => Real.log (populationSupport μ v)) u w = ⟪tangentLogSupport μ u, w⟫ := by
  have hne := (populationSupport_pos μ u ht hi).ne'
  constructor
  · simp [tangentLogSupport, inner_sub_right, real_inner_smul_right, inner_signedMoment μ u hi, hu, hne]
  · intro w hw
    rw [((signedMoment_hasGradientAt μ u ht hi).hasFDerivAt.log hne).fderiv]
    simp [tangentLogSupport, inner_sub_left, real_inner_smul_left, hw, InnerProductSpace.toDual_apply_apply]

/-- The positive centroid is the scalar support times the normal plus tangent correction. -/
theorem update_pos_sphere (μ : Measure LloydCentroid.E) [IsProbabilityMeasure μ]
    (u : LloydCentroid.E) {r : ℝ} (hr : 0 < r)
    (hμ : MeasurePreserving (fun x : LloydCentroid.E => -x) μ μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : LloydCentroid.E → LloydCentroid.E) μ) :
    (update μ (r • u)).1 = populationSupport μ u • (u + tangentLogSupport μ u) := by
  rw [(reflection_update μ u hr hμ ht hi).2.2]
  simp [tangentLogSupport, smul_smul, (populationSupport_pos μ u ht hi).ne']

#print axioms inner_signedMoment
#print axioms populationSupport_pos
#print axioms tangentLogSupport_spec
#print axioms update_pos_sphere
#print axioms signedMoment_hasGradientAt
#print axioms update_eq_supportGradient

#print axioms hasFDerivAt_absProjectionIntegral
#print axioms hasGradientAt_absProjectionIntegral

end LloydCentroid
