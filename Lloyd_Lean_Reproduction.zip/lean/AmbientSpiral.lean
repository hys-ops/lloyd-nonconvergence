import LocalPotential
import Mathlib.Analysis.Calculus.Gradient.Basic
import Mathlib.Analysis.Calculus.ContDiff.WithLp

/-! A single autonomous map on three-dimensional Euclidean space, obtained from
the projected ordinary Fréchet gradient of an explicit scalar function. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LloydAmbient
open LloydSpiral.Chart LloydLocal

def lift (δ : ℝ) (x : E3) : ℝ :=
  primitive δ (x 2) + q δ (x 2) / radial (x 2) *
    (x 1 * Real.cos (azimuth (x 2)) - x 0 * Real.sin (azimuth (x 2)))

def tangentGradient (f : E3 → ℝ) (u : E3) : E3 :=
  _root_.gradient f u - inner ℝ (_root_.gradient f u) u • u

def iterateMap (δ : ℝ) (u : E3) : E3 := normalize (u + tangentGradient (lift δ) u)

theorem lift_point {z : ℝ} (hz : 0<1-z^2) (δ φ : ℝ) :
    lift δ (point z φ) = surface δ z φ := by
  change primitive δ z + q δ z / radial z *
    (radial z * Real.sin φ * Real.cos (azimuth z) -
     radial z * Real.cos φ * Real.sin (azimuth z)) = _
  unfold surface potential
  rw [Real.sin_sub]
  have hr : radial z ≠ 0 := (Real.sqrt_pos.mpr hz).ne'
  field_simp [hr]

theorem lift_smooth {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) {x : E3} (hz : x 2 ∈ belt) :
    ContDiffAt ℝ ∞ (lift δ) x := by
  have hF := (primitive_smooth (gate_all hd hd')).contDiffAt
    ((show IsOpen belt from isOpen_Ioo).mem_nhds hz)
  have hQ := (smooth_coefficients (gate_all hd hd' (x 2) hz)).2.1
  have hreg := gate_all hd hd' (x 2) hz
  have hZ : x 2 ≠ 0 := hreg.1.ne'
  have hG : 1-(x 2)^2 ≠ 0 := hreg.2.1.ne'
  have hR : radial (x 2) ≠ 0 := (Real.sqrt_pos.mpr hreg.2.1).ne'
  have hrad : ContDiffAt ℝ ∞ radial (x 2) := by
    unfold radial
    fun_prop (disch := assumption)
  have hphase : ContDiffAt ℝ ∞ azimuth (x 2) := by
    unfold azimuth
    fun_prop (disch := assumption)
  unfold lift
  fun_prop (disch := assumption)

theorem ambient_chart_gradient {δ z φ : ℝ} (hd : 0<δ) (hd' : δ≤1) (hz : z ∈ belt) :
    IsChartGradient (surface δ) z φ (tangentGradient (lift δ) (point z φ)) := by
  let u := point z φ
  let v := _root_.gradient (lift δ) u
  have hrad := (gate_all hd hd' z hz).2.1
  have hunit : ‖u‖=1 := point_norm hrad
  have hf : HasGradientAt (lift δ) v u :=
    ((lift_smooth hd hd' (x:=u) hz).differentiableAt (by simp)).hasGradientAt
  obtain ⟨hh,ha⟩ := point_partials (φ:=φ) hrad
  constructor
  · change inner ℝ (v - inner ℝ v u • u) u=0
    simp [inner_sub_left, real_inner_smul_left, hunit]
  have hproj {y : E3} (hy : inner ℝ u y = 0) :
      inner ℝ (tangentGradient (lift δ) u) y = inner ℝ v y := by
    simp only [tangentGradient, inner_sub_left, real_inner_smul_left, hy, mul_zero, sub_zero]
    rfl
  constructor
  · rw [show inner ℝ (tangentGradient (lift δ) (point z φ)) (heightVec z φ) =
      inner ℝ v (heightVec z φ) from hproj (tangent_height hrad)]
    apply (hf.hasFDerivAt.comp_hasDerivAt z hh).congr_of_eventuallyEq
    filter_upwards [(show IsOpen belt from isOpen_Ioo).mem_nhds hz] with t ht
    exact (lift_point (gate_all hd hd' t ht).2.1 δ φ).symm
  · rw [show inner ℝ (tangentGradient (lift δ) (point z φ)) (angleVec z φ) =
      inner ℝ v (angleVec z φ) from hproj (tangent_angle z φ)]
    apply (hf.hasFDerivAt.comp_hasDerivAt φ ha).congr_of_eventuallyEq
    exact Filter.Eventually.of_forall (fun t => (lift_point hrad δ t).symm)

theorem autonomous_step {δ z : ℝ} (hd : 0<δ) (hd' : δ≤1) (hz : z ∈ belt) :
    iterateMap δ (point z (azimuth z)) = point (nextHeight δ z) (azimuth (nextHeight δ z)) := by
  obtain ⟨g,⟨hg,he⟩,_⟩ := exact_step hd hd' hz
  have heq := grad_unique (gate_all hd hd' z hz).2.1 (ambient_chart_gradient hd hd' hz) hg
  simpa only [iterateMap,heq] using he

theorem iterates {δ : ℝ} (hd : 0<δ) (hd' : δ≤1) (n : ℕ) :
    (iterateMap δ)^[n] (point (1/8) (azimuth (1/8))) =
      point (LloydHeight.height δ n) (LloydHeight.phase δ n) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    obtain ⟨hp,hu⟩ := LloydHeight.height_bounds hd hd' n
    rw [Function.iterate_succ_apply', ih]
    exact autonomous_step hd hd' (show LloydHeight.height δ n ∈ belt from ⟨hp, by linarith⟩)

#print axioms lift_smooth
#print axioms iterates
end LloydAmbient
