import NDMainData
import NDDensePath
import NDJet
import NDGaussModels
import NDSpan

/-! End-to-end, simultaneous higher-dimensional population Lloyd counterexamples. -/
noncomputable section
open MeasureTheory Filter Set Topology TopologicalSpace
open scoped RealInnerProductSpace ContDiff
namespace LloydNDMain
open LloydNDFrame LloydNDLimits LloydNDJet LloydNDClock LloydNDDensePath LloydNDModels

/-- Actual sites, with all their positive radii, span the ambient Euclidean space. -/
def FullSpan {m : ℕ} (μ : Measure (E m)) (y:E m) : Prop :=
  Submodule.span ℝ (range (fun n => (trajectory μ y n).1)) = ⊤

/-- Direction agreement at every antipodal input, for every choice of the two
initial positive radii. Both sides use the original Voronoi centroids. -/
def SameDirections {m:ℕ} (μ ν : Measure (E m)) : Prop :=
  ∀ (u:E m), u ≠ 0 → ∀ {r t : ℝ}, 0<r → 0<t →
    ‖(update μ (r • u)).1‖⁻¹ • (update μ (r • u)).1 =
    ‖(update ν (t • u)).1‖⁻¹ • (update ν (t • u)).1

/-- The complete shape and dynamical conclusions for the three actual populations.
The uniform source is also checked against all optimal half-mass transport plans. -/
structure JointExample {k:ℕ} (m:ℕ) (ε:ℝ) (K : Set (E (k+3)))
    (ρ σ : E (k+3) → ℝ) (y : E (k+3)) : Prop where
  uniform : UniformExample m ε K y
  gaussian : GaussianShape ρ
  compact_density : CompactShape σ
  gaussian_probability : IsProbabilityMeasure (LloydNDGaussian.law ρ)
  compact_probability : IsProbabilityMeasure (LloydNDGaussian.law σ)
  gaussian_orbit : ProjectiveOrbit (LloydNDGaussian.law ρ) y
  compact_orbit : ProjectiveOrbit (LloydNDGaussian.law σ) y
  uniform_span : FullSpan (uniformOn K) y
  gaussian_span : FullSpan (LloydNDGaussian.law ρ) y
  compact_span : FullSpan (LloydNDGaussian.law σ) y
  same_gaussian : SameDirections (uniformOn K) (LloydNDGaussian.law ρ)
  same_compact : SameDirections (uniformOn K) (LloydNDGaussian.law σ)

private theorem realized_orbit {k:ℕ} {P:ℝ→E (k+3)} {δ:ℝ} {f:E (k+3)→ℝ} {c:ℝ}
    {μ : Measure (E (k+3))} (p : Profile μ (fun x=> Real.exp (f x)) c)
    (hu : ∀ T:ℝ, ‖P T‖=1) (hd:0<δ)
    (hjet : ∀ T:ℝ,8≤T → let u:=P T; let v:=P (T+increment (δ,T));
      0<⟪u,v⟫ ∧ HasFDerivAt f (innerSL ℝ (LloydNDSpiral.kick u v)) u)
    (hlim : ∀ v, MapClusterPt v atTop (fun n=>P (time δ n)) ↔
      ∃ w:E (k+2), ‖w‖=1 ∧ v=equator w)
    (hhead : head (P (time δ 0))≠0) :
    let y := (1/4:ℝ) • P (time δ 0)
    ProjectiveOrbit μ y ∧ FullSpan μ y := by
  let u := fun n => P (time δ n)
  have : IsProbabilityMeasure μ := p.probability
  have hun (n:ℕ) : ‖u n‖=1 := hu _
  have step (n:ℕ) : signedMoment μ (u n)=‖signedMoment μ (u n)‖ • u (n+1) := by
    obtain ⟨hip,hg⟩ := hjet (time δ n) (time_ge hd n)
    apply signedMoment_of_kick p.ac p.first p.positive p.moment (hun n) (hun (n+1)) hip hg.differentiableAt
    intro w _
    exact congrArg (fun L : E (k+3) →L[ℝ] ℝ => L w) hg.fderiv
  refine ⟨projective_from_steps p.even p.ac p.first hun step hlim (by norm_num),?_⟩
  let r := orbitRadius μ u (1/4)
  have hcoords := orbit_dynamics p.even p.ac p.first hun step (by norm_num : 0<(1/4:ℝ))
  have hsites : (fun n => (trajectory μ ((1/4:ℝ) • P (time δ 0)) n).1) = fun n => r n • u n := by
    funext n
    exact congrArg Prod.fst (hcoords n).2
  unfold FullSpan
  rw [hsites,span_smul_range (fun n => (hcoords n).1.ne')]
  exact span_of_equatorial_limits u (fun w hw => (hlim _).mpr ⟨w,hw,rfl⟩) hhead

set_option maxHeartbeats 1000000 in
/-- For any ambient dimension k+3 and any prescribed finite order of closeness
to the unit ball, the actual two-site population Lloyd orbit admits exactly the
full equatorial projective configuration space as its limit set. -/
theorem projective_equator_counterexample (k m:ℕ) (ε:ℝ) (hε:0<ε) :
    ∃ (K : Set (E (k+3))) (ρ σ : E (k+3) → ℝ) (y : E (k+3)), JointExample m ε K ρ σ y := by
  obtain ⟨a,hs,ha,hbounds,hdense⟩ := LloydNDDense.exists_curve k
  let P := path a
  have hP : BoundedJets P := path_bounded ⟨hs,hbounds⟩
  have unitP : ∀ T, ‖P T‖=1 := path_unit ha
  have headP (T:ℝ) (hT : 8≤T) : head (P T) = T⁻¹ := by
    change head (path a T)=_
    rw [path_eq a (by linarith : 5≤T)]
    rfl
  let f := logProfile P hP
  have hsm := profile_smooth P hP
  let h := fun p : ℝ × E (k+3) => Real.exp (f p)
  have hsmh : LloydNDFrequency.SmoothOnDirections h := fun p _=> (Real.contDiff_exp.comp hsm).contDiffAt
  have eh (t:ℝ) (v:E (k+3)) (_:‖v‖=1) : h (t,-v)=h (t,v) := by
    dsimp [h,f]; rw [profile_even]
  have zh (v:E (k+3)) (_:‖v‖=1) : h (0,v)=1 := by
    dsimp [h,f]; rw [profile_zero,Real.exp_zero]
  obtain ⟨η,hη,hjet⟩ := profile_exact P hP (fun T _ => unitP T) headP
  have He := LloydNDModels.realize hsmh eh zh m ε hε
  have H₁ : ∀ᶠ t in 𝓝[>] (0:ℝ), 0<t := self_mem_nhdsWithin
  have H₂ : ∀ᶠ t in 𝓝[>] (0:ℝ), t<η := (gt_mem_nhds hη).filter_mono nhdsWithin_le_nhds
  have Hpos := H₁.and (H₂.mono fun _ h => h.le)
  obtain ⟨δ,⟨hd,hδη⟩,K,ρ,σ,c,b,e,hK,hρ,hσ,pK,pρ,pσ⟩ :=
    (Hpos.and (He.filter_mono nhdsWithin_le_nhds)).exists
  let z := fun n => (time δ n)⁻¹
  have hz : Tendsto z atTop (𝓝 0) := tendsto_inv_atTop_zero.comp (time_atTop hd)
  have hb (n:ℕ) : P (time δ n) = dir (z n) (a (time δ n)) :=
    path_eq a (by linarith [time_ge hd n])
  have hlim (v:E (k+3)) : MapClusterPt v atTop (fun n => P (time δ n)) ↔
      ∃ w:E (k+2), ‖w‖=1 ∧ v=equator w := by
    simp only [hb]
    exact dense_belt_limits hs ha (hbounds 1) hdense (time_atTop hd) (time_mesh hd) hz v
  have hnhead : head (P (time δ 0))≠0 := by rw [headP _ (time_ge hd _)]; exact inv_ne_zero (by linarith [time_ge hd 0])
  let y := (1/4:ℝ) • P (time δ 0)
  have hkO := realized_orbit pK unitP hd (hjet δ hd hδη) hlim hnhead
  have hgO := realized_orbit pρ unitP hd (hjet δ hd hδη) hlim hnhead
  have hcO := realized_orbit pσ unitP hd (hjet δ hd hδη) hlim hnhead
  refine ⟨K,ρ,σ,y,⟨?_,hρ,hσ,pρ.probability,pσ.probability,hgO.1,hcO.1,hkO.2,hgO.2,hcO.2,?_,?_⟩⟩
  · exact ⟨hK.compact,hK.volume_pos,hK.even,hK.strict,hK.curved,hK.ball_subset,pK.probability,
      hK.near,hkO.1,interior_balanced hK.compact hK.volume_pos hK.strict hK.even hK.ball_subset (unitP _)⟩
  · exact fun u hu _ _ hr ht => (pK.same_update pρ u hu hr ht).2
  · exact fun u hu _ _ hr ht => (pK.same_update pσ u hu hr ht).2

#print axioms projective_equator_counterexample
end LloydNDMain
