import AngularDensity
import FourierRange
import GlobalFamily
import Stationarity

/-! Common analytical input and dynamical conclusion for shell perturbations of radial laws. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set TopologicalSpace
open scoped RealInnerProductSpace Topology ContDiff SchwartzMap
namespace LloydGaussianExample
open LloydCosine LloydAngular LloydCentroid LloydSpiral.Chart LloydVerification
abbrev E := LloydCosine.E

def HasEquatorialOrbit (μ : Measure E) (δ : ℝ) : Prop :=
  ∀ r₀ : ℝ, 0 < r₀ → ∃ c : ℝ, 0 < c ∧
    (∀ P : NonemptyCompacts E, MapClusterPt P atTop (fun n => unlabel (sites μ δ r₀ n)) ↔
      ∃ θ : ℝ, P = LloydOrbit.antipodes (c • LloydOrbit.equator θ)) ∧
    (∀ θ : ℝ, let x := c • LloydOrbit.equator θ
      ordinaryStep μ (x,-x) = (x,-x)) ∧
    ¬∃ P, Tendsto (fun n => unlabel (sites μ δ r₀ n)) atTop (𝓝 P)

theorem orbit_from_belt {μ : Measure E} [IsProbabilityMeasure μ]
    (he : MeasurePreserving (fun x:E => -x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {δ : ℝ} (hd : 0<δ) (h1 : δ≤1) (hm : MatchesBelt μ δ) :
    HasEquatorialOrbit μ δ := by
  intro r₀ h₀
  obtain ⟨c,hc,hl⟩ := radius_tendsto he hac hi hd h1 hm r₀
  have hA := axis_limits hd h1 hl hc
  have hh : (fun n => unlabel (sites μ δ r₀ n)) =
      (fun n => LloydOrbit.antipodes (radius μ δ r₀ n • dir δ n)) := by
    funext n
    rw [(sites_coords he hac hi hd h1 hm h₀ n).2]; rfl
  exact ⟨c,hc,hh ▸ hA.1,fun θ => (equator_stationary he hac hi hd h1 hm hc hl θ).2,hh ▸ hA.2⟩

/-- An even, small, real angular correction for an arbitrary radial reference scale. -/
theorem prescribed_family (C : ℝ) :
    ∃ (a : ℝ) (F : ℝ → 𝓢(E,ℝ)), 0<a ∧ a≤1 ∧ Tendsto F (𝓝 0) (𝓝 0) ∧
      (∀ t x, F t (-x) = F t x) ∧ ∀ t u, ‖u‖=1 →
        cosineTransform (fun w => radialize (F t) w.val) u = C*(LloydFamily.angular a t u-1) := by
  obtain ⟨a,ha,h1,hsm⟩ := LloydFamily.exists_smooth_scale
  let H := fun w : ℝ × E => C*(LloydFamily.angular a w.1 w.2-1)
  have hH : LloydFrequency.SmoothOnDirections H := fun w _ =>
    (contDiff_const.mul (hsm.sub contDiff_const)).contDiffAt
  let F := fun t => LloydFourierRange.rightInverse (fun u => H (t,u)) (LloydFrequency.slice_smooth hH t)
  have hzero : ∀ u, ‖u‖=1 → H (0,u)=0 := by intro u _; simp [H]
  have evenH (t:ℝ) (u:E) (_ : ‖u‖=1) : H (t,-u) = H (t,u) := by simp [H,LloydFamily.angular_even]
  have hs (t:ℝ) := LloydFourierRange.rightInverse_spec (LloydFrequency.slice_smooth hH t) (evenH t)
  refine ⟨a,F,ha,h1,LloydFourierRange.rightInverse_tendsto hH hzero,fun t => (hs t).1,?_⟩
  intro t u hu
  rw [schwartz_cosine]
  conv_lhs => arg 2; ext x; rw [real_inner_comm x u]
  exact (hs t).2 u hu

/-- An absolutely continuous even law with the specified scalar projection has
the whole equatorial circle of fixed cluster sites for its actual Lloyd map. -/
theorem orbit_of_projection {μ : Measure E} [IsProbabilityMeasure μ]
    (he : MeasurePreserving (fun x:E => -x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {a t C : ℝ} (ha : 0<a) (h1 : a≤1)
    (ht : t≠0) (hC : 0<C) (hproj : ∀ u:E, ‖u‖ = 1 →
      populationSupport μ u = C*LloydFamily.angular a t u) :
    HasEquatorialOrbit μ (LloydFamily.parameter a t) := by
  obtain ⟨c,hc,hm⟩ := LloydFamily.angular_matches ha h1 ht
  apply orbit_from_belt he hac hi (LloydFamily.parameter_pos ha ht) ((LloydFamily.parameter_range ha t).2.le.trans h1)
  refine ⟨Real.log (C*c),fun z hz φ => ?_⟩
  have hz' : 0<1-z^2 := by nlinarith [mul_pos hz.1 (sub_pos.mpr hz.2)]
  rw [LloydSupportChart.logChart,hproj _ (point_norm hz'),hm z hz φ,←mul_assoc,
    Real.log_mul (mul_pos hC hc).ne' (Real.exp_pos _).ne',Real.log_exp]

#print axioms prescribed_family
#print axioms orbit_of_projection
end LloydGaussianExample
