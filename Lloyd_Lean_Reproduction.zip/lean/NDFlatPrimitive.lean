import NDFlat
import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-! Parameter-dependent primitives through the equatorial seam. All local
parameter derivatives can be taken under the integral over a fixed interval. -/
noncomputable section
open MeasureTheory Metric Set Filter
open scoped ContDiff Topology Interval
namespace LloydNDFlat
universe u
variable {E : Type u} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def avg (b : Plane × ℝ → E) (p : Plane) := ∫ s in (0:ℝ)..1, b (p,s)

private def paramDeriv (b : Plane × ℝ → E) (p : Plane × ℝ) : Plane →L[ℝ] E :=
  (fderiv ℝ b p).comp (ContinuousLinearMap.inl ℝ Plane ℝ)

private theorem smooth_paramDeriv {b : Plane × ℝ → E} (hb : ContDiff ℝ ∞ b) :
    ContDiff ℝ ∞ (paramDeriv b) := by
  exact (contDiff_infty_iff_fderiv.mp hb).2.clm_comp contDiff_const

private theorem hasFDerivAt_avg {b : Plane × ℝ → E} (hb : ContDiff ℝ ∞ b) (p : Plane) :
    HasFDerivAt (avg b) (avg (paramDeriv b) p) p := by
  have hs := smooth_paramDeriv hb
  obtain ⟨C,hC⟩ := ((isCompact_closedBall p 1).prod (isCompact_Icc (a:=(0:ℝ)) (b:=1))).exists_bound_of_continuousOn hs.continuous.continuousOn
  apply intervalIntegral.hasFDerivAt_integral_of_dominated_of_fderiv_le
    (F:=fun x s => b (x,s)) (F':=fun x s => paramDeriv b (x,s)) (bound:=fun _ => C) (ball_mem_nhds p zero_lt_one)
  · exact Eventually.of_forall fun x => (hb.continuous.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
  · exact (hb.continuous.comp (continuous_const.prodMk continuous_id)).intervalIntegrable _ _
  · exact (hs.continuous.comp (continuous_const.prodMk continuous_id)).aestronglyMeasurable
  · filter_upwards with s ht x hx
    rw [uIoc_of_le zero_le_one] at ht
    exact hC (x,s) ⟨ball_subset_closedBall hx,ht.1.le,ht.2⟩
  · exact intervalIntegrable_const
  · filter_upwards with s _ x _
    have h := (hb.differentiable (by simp)).differentiableAt (x:=(x,s)) |>.hasFDerivAt
    exact h.comp x ((hasFDerivAt_id x).prodMk (hasFDerivAt_const (𝕜:=ℝ) s x))

theorem contDiff_avg {b : Plane × ℝ → E} (hb : ContDiff ℝ ∞ b) :
    ContDiff ℝ ∞ (avg b) := by
  apply contDiff_infty.2
  intro n
  induction n generalizing E with
  | zero => exact contDiff_zero.mpr (Differentiable.continuous (𝕜:=ℝ) (fun p => (hasFDerivAt_avg hb p).differentiableAt))
  | succ n ih =>
    rw [Nat.cast_succ,contDiff_succ_iff_fderiv]
    refine ⟨fun p => (hasFDerivAt_avg hb p).differentiableAt,by simp,?_⟩
    have heq : fderiv ℝ (avg b) = avg (paramDeriv b) := funext fun p => (hasFDerivAt_avg hb p).fderiv
    rw [heq]
    exact ih (smooth_paramDeriv hb)

def primitive (L : Plane → E) (p : Plane) : E := ∫ s in 0..p.2, L (p.1,s)

theorem contDiff_primitive {L : Plane → E} (hL : ContDiff ℝ ∞ L) :
    ContDiff ℝ ∞ (primitive L) := by
  have hb : ContDiff ℝ ∞ (fun w : Plane × ℝ => L (w.1.1, w.1.2 * w.2)) :=
    hL.comp ((contDiff_fst.comp contDiff_fst).prodMk ((contDiff_snd.comp contDiff_fst).mul contDiff_snd))
  have h := contDiff_snd.smul (contDiff_avg hb)
  convert h using 1
  ext p
  change (∫ s in 0..p.2, L (p.1,s)) = p.2 • (∫ s in (0:ℝ)..1, L (p.1,p.2*s))
  simpa using (intervalIntegral.smul_integral_comp_mul_left (fun s => L (p.1,s)) (a:=0) (b:=1) p.2).symm

theorem hasDerivAt_primitive {L : Plane → E} (hL : Continuous L) (δ z : ℝ) :
    HasDerivAt (fun s => primitive L (δ,s)) (L (δ,z)) z := by
  have hc : Continuous (fun u : ℝ => L (δ,u)) := hL.comp (continuous_const.prodMk continuous_id)
  exact intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable _ _) hc.stronglyMeasurable.stronglyMeasurableAtFilter hc.continuousAt

end LloydNDFlat
