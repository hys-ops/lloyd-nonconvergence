import NDAngular
import NDFourierRange
import Mathlib.Analysis.Calculus.ContDiff.Bounds
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv

noncomputable section
open MeasureTheory Set Filter Function
open scoped ContDiff Topology SchwartzMap
namespace LloydNDGeom
open LloydNDAngular LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim
local notation "Sn" => S dim
/-- Every fixed ambient derivative order of a radial moment is uniformly small on the
same unbounded open set surrounding the unit sphere. -/
theorem moment_jets {ι : Type*} {l : Filter ι} {V : Type*} [NormedAddCommGroup V]
    [NormedSpace ℝ V] [CompleteSpace V] {F : ι → 𝓢(Vn,V)} (hF : Tendsto F l (𝓝 0))
    (k n : ℕ) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in l, ∀ w ∈ away, ‖iteratedFDeriv ℝ n (moment k (F i)) w‖ < ε := by
  induction n generalizing V k with
  | zero =>
    filter_upwards [eventually_C2_small hF k hε] with i hi w hw
    simpa only [norm_iteratedFDeriv_zero] using (hi w hw).1
  | succ n ih =>
    let L := SchwartzMap.fderivCLM ℝ Vn V
    have hL : Tendsto (fun i => L (F i)) l (𝓝 0) := by simpa only [Function.comp_def,L.map_zero] using (L.continuous.tendsto 0).comp hF
    filter_upwards [ih hL (k+1)] with i hi w hw
    have he : fderiv ℝ (moment k (F i)) =ᶠ[𝓝 w] moment (k+1) (L (F i)) :=
      eventually_of_mem ((away_open (dim:=dim)).mem_nhds hw) fun x hx => (moment_hasFDerivAt k (F i) hx).fderiv
    rw [← norm_iteratedFDeriv_fderiv,(he.iteratedFDeriv (𝕜:=ℝ) n).eq_of_nhds]
    exact hi w hw

/-- Uniform smallness for a whole neighborhood condition in the value coordinate. -/
private theorem values_in {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) {s : Set ℝ} (hs : s ∈ 𝓝 0) :
    ∀ᶠ i in l, ∀ w ∈ away, radialize (F i) w ∈ s := by
  obtain ⟨r,hr,hsub⟩ := Metric.mem_nhds_iff.1 hs
  filter_upwards [eventually_C2_small hF (dim+1) hr] with i hi w hw
  apply hsub
  rw [Metric.mem_ball,dist_zero_right]
  exact (hi w hw).1

/-- Smooth changes of the scalar radial profile preserve uniform convergence of all its
spatial derivatives. The constant value g(0) has been subtracted in the input specification. -/
theorem compose_jets {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)} (hF : Tendsto F l (𝓝 0))
    {g : ℝ → ℝ} {T : Set ℝ} (hT : IsOpen T) (h0 : 0 ∈ T) (hg : ContDiffOn ℝ ∞ g T)
    (hg0 : g 0 = 0) (n : ℕ) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ i in l, ∀ w ∈ away, ‖iteratedFDeriv ℝ n (g ∘ radialize (F i)) w‖ < ε := by
  have hgAt := hg.contDiffAt (hT.mem_nhds h0)
  cases n with
  | zero =>
    have hev : {x | ‖g x‖ < ε} ∈ 𝓝 0 := hgAt.continuousAt.norm.tendsto.eventually_lt_const (by simpa [hg0])
    filter_upwards [values_in hF hev] with i hi w hw
    rw [norm_iteratedFDeriv_zero]
    exact hi w hw
  | succ n =>
    let N := n+1
    let C := 1 + ∑ j ∈ Finset.range (N+1), ‖iteratedFDeriv ℝ j g 0‖
    have hC : 0 < C := by dsimp [C]; positivity
    have hbound (j : ℕ) (hj : j ∈ Finset.range (N+1)) :
        {x : ℝ | ‖iteratedFDeriv ℝ j g x‖ < C} ∈ 𝓝 0 := by
      apply ((hgAt.continuousAt_iteratedFDeriv (k:=j) (by simp)).norm.tendsto).eventually_lt_const
      have hl := Finset.single_le_sum (f := fun j => ‖iteratedFDeriv ℝ j g 0‖)
        (fun j _ => norm_nonneg _) hj
      dsimp [C]
      linarith
    let B := (N.factorial:ℝ)*C
    have hB : 0<B := by dsimp [B]; positivity
    let D := min (1:ℝ) (ε/(2*B))
    have hD : 0<D := lt_min zero_lt_one (div_pos hε (by positivity))
    have hD1 : D≤1 := min_le_left _ _
    have hDe : B*D < ε := by
      have he := (le_div_iff₀ (by positivity : 0<2*B)).mp (min_le_right 1 (ε/(2*B)))
      dsimp [D]
      linarith
    have eB : ∀ᶠ i in l, ∀ j ∈ Finset.range (N+1), ∀ w ∈ away,
        ‖iteratedFDeriv ℝ j g (radialize (F i) w)‖ < C :=
      (eventually_all_finset _).2 (fun j hj => values_in hF (hbound j hj))
    have eD : ∀ᶠ i in l, ∀ j ∈ Finset.range (N+1), ∀ w ∈ away,
        ‖iteratedFDeriv ℝ j (radialize (F i)) w‖ < D^j :=
      (eventually_all_finset _).2 (fun j _ => moment_jets hF (dim+1) j (pow_pos hD _))
    filter_upwards [eB,eD,values_in hF (hT.mem_nhds h0)] with i hi hj hV w hw
    have hN : N ≤ (∞ : ℕ∞ω) := by simp
    have hcomp := norm_iteratedFDerivWithin_comp_le (n:=N) (C:=C) (D:=D) hg
      (schwartz_radialize_smooth (F i)) hN hT.uniqueDiffOn (away_open (dim:=dim)).uniqueDiffOn
      (fun x hx => hV x hx) hw
      (fun j hj' => by rw [iteratedFDerivWithin_of_isOpen j hT (hV w hw)]; exact (hi j (Finset.mem_range.mpr (by omega)) w hw).le)
      (fun j _ hj' => by rw [iteratedFDerivWithin_of_isOpen j (away_open (dim:=dim)) hw]; exact (hj j (Finset.mem_range.mpr (by omega)) w hw).le)
    rw [iteratedFDerivWithin_of_isOpen N (away_open (dim:=dim)) hw] at hcomp
    have hpow : D^N ≤ D := by
      dsimp [N]
      rw [pow_succ]
      exact le_of_eq_of_le (by ring : D^n*D = D*(D^n)) (mul_le_of_le_one_right hD.le (pow_le_one₀ hD.le hD1))
    exact hcomp.trans_lt ((mul_le_mul_of_nonneg_left hpow hB.le).trans_lt hDe)


def radExt (f : 𝓢(Vn,ℝ)) (x : Vn) : ℝ := (1+radialize f x)^(((dim:ℝ)+2)⁻¹)
theorem radExt_jets {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) (n : ℕ) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in l, ∀ w ∈ away, ‖iteratedFDeriv ℝ n (fun x => radExt (F i) x-1) w‖ < ε := by
  let T := {z : ℝ | 0 < 1+z}
  have hT : IsOpen T := isOpen_lt continuous_const (continuous_const.add continuous_id)
  apply compose_jets hF hT (show (0:ℝ) ∈ T by simp [T])
    (g := fun z : ℝ => (1+z)^(((dim:ℝ)+2)⁻¹)-1) _ (by norm_num) n hε
  intro z hz
  have h : 0<1+z := hz
  apply ContDiffAt.contDiffWithinAt
  fun_prop (disch := positivity)

theorem eventually_radExt_smooth {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) :
    ∀ᶠ i in l, ContDiffOn ℝ ∞ (radExt (F i)) away := by
  filter_upwards [eventually_C2_small hF (dim+1) (by norm_num : (0:ℝ)<1/2)] with i hi x hx
  have h := (hi x hx).1
  change |radialize (F i) x| < 1/2 at h
  have hz : 0<1+radialize (F i) x := by linarith [(abs_lt.mp h).1]
  have hcont := (schwartz_radialize_smooth (F i)).contDiffAt (away_open.mem_nhds hx)
  apply ContDiffAt.contDiffWithinAt
  unfold radExt
  fun_prop (disch := positivity)
end LloydNDGeom
