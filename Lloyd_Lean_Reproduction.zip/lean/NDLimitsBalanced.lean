import NDLimitsCentroid
import Mathlib.MeasureTheory.Measure.Prod

/-! Squared Euclidean transportation cost for arbitrary joint Borel measures.
The nearest-site graph is an admissible equal-capacity coupling and minimizes
against every joint measure with the prescribed marginals. -/
noncomputable section
open MeasureTheory Set Filter
open scoped RealInnerProductSpace Topology ENNReal
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)

/-- The two equal-capacity target atoms. -/
def twoAtoms (y : E) : Measure E := (2 : ℝ≥0∞)⁻¹ • (Measure.dirac y + Measure.dirac (-y))

/-- The actual Voronoi assignment, breaking ties toward the negative site. -/
def nearestSite (y x : E) : E := by
  classical
  exact if x ∈ nearestPlus y then y else -y

lemma nearestPlus_measurable (y : E) : MeasurableSet (nearestPlus y) :=
  measurableSet_lt (measurable_id.dist measurable_const) (measurable_id.dist measurable_const)

lemma nearestSite_measurable (y : E) : Measurable (nearestSite y) :=
  measurable_const.ite (nearestPlus_measurable y) measurable_const

/-- Graph coupling for the actual nearest-site assignment. -/
def nearestCoupling (μ : Measure E) (y : E) : Measure (E × E) :=
  μ.map (fun x => (x,nearestSite y x))

def squaredTransportCost (π : Measure (E × E)) : ℝ≥0∞ :=
  ∫⁻ p, ENNReal.ofReal (dist p.1 p.2 ^ 2) ∂π

private def floorCost (y x : E) : ℝ≥0∞ :=
  min (ENNReal.ofReal (dist x y ^ 2)) (ENNReal.ofReal (dist x (-y) ^ 2))

private lemma measurable_floor (y : E) : Measurable (floorCost y) :=
  (((measurable_id.dist measurable_const).pow_const _).ennreal_ofReal).min
    (((measurable_id.dist measurable_const).pow_const _).ennreal_ofReal)

private lemma nearest_eq_floor (y x : E) : ENNReal.ofReal (dist x (nearestSite y x) ^ 2) = floorCost y x := by
  by_cases hx : x ∈ nearestPlus y
  · simp only [nearestSite,hx,ite_true,floorCost]
    exact (min_eq_left (ENNReal.ofReal_le_ofReal (pow_le_pow_left₀ dist_nonneg (le_of_lt hx) _))).symm
  · simp only [nearestSite,hx,ite_false,floorCost]
    exact (min_eq_right (ENNReal.ofReal_le_ofReal (pow_le_pow_left₀ dist_nonneg (le_of_not_gt hx) _))).symm

private lemma half_of_real {μ : Measure E} [IsFiniteMeasure μ] {A : Set E}
    (hm : μ.real A = 1/2) : μ A = (2 : ℝ≥0∞)⁻¹ := by
  apply (ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) (by simp)).mp
  simpa [Measure.real,one_div] using hm

/-- The pushforward onto the sites equals the sum of the prescribed half masses. -/
theorem nearestCoupling_marginals (μ : Measure E) [IsProbabilityMeasure μ] (y : E)
    (hp : μ.real (nearestPlus y) = 1/2) (hm : μ.real (nearestMinus y) = 1/2) :
    (nearestCoupling μ y).fst = μ ∧ (nearestCoupling μ y).snd = twoAtoms y := by
  classical
  have hsite := nearestSite_measurable y
  constructor
  · exact (Measure.fst_map_prodMk measurable_id hsite).trans Measure.map_id
  · change (μ.map (fun x => (id x, nearestSite y x))).snd = _
    rw [Measure.snd_map_prodMk measurable_id hsite]
    ext s hs
    rw [Measure.map_apply hsite hs]
    have hdir (v : E) : Measure.dirac v s = if v ∈ s then 1 else 0 := by
      simp [Measure.dirac_apply' _ hs,Set.indicator]
    rw [twoAtoms,Measure.smul_apply,Measure.add_apply,hdir,hdir]
    have evaluate (A : Set E) (he : ∀ x : E, nearestSite y x ∈ s ↔ x ∈ A) :
        μ ((nearestSite y) ⁻¹' s) = μ A := by rw [show (nearestSite y) ⁻¹' s = A from Set.ext he]
    by_cases hpos : y ∈ s <;> by_cases hneg : -y ∈ s
    · rw [evaluate univ (fun x => by by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,h,hpos,hneg])]
      norm_num [hpos,hneg,ENNReal.inv_mul_cancel]
    · rw [evaluate (nearestPlus y) (fun x => by by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,h,hpos,hneg])]
      simp [hpos,hneg,half_of_real hp]
    · rw [evaluate (nearestMinus y) (fun x => by by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,nearestMinus,h,hpos,hneg])]
      simp [hpos,hneg,half_of_real hm]
    · rw [evaluate ∅ (fun x => by by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,h,hpos,hneg])]
      simp [hpos,hneg]

private lemma target_ae_sites (y : E) : ∀ᵐ z ∂twoAtoms y, z = y ∨ z = -y := by
  apply ae_iff.mpr
  simp [twoAtoms,Measure.smul_apply,Measure.add_apply,Set.indicator]

private lemma on_sites (π : Measure (E × E)) (y : E) (hs : π.snd = twoAtoms y) :
    ∀ᵐ p ∂π, p.2 = y ∨ p.2 = -y := by
  have ha : ∀ᵐ z ∂π.snd, z ∈ ({y,-y} : Set E) := by rw [hs]; simpa using target_ae_sites y
  have hb := (ae_map_iff (f := (Prod.snd : E × E → E)) measurable_snd.aemeasurable
      ((measurableSet_singleton _).insert _)).mp ha
  filter_upwards [hb] with p hp
  change p.2 ∈ ({y,-y} : Set E) at hp
  simpa using hp

private lemma cost_measurable : Measurable (fun p : E × E => ENNReal.ofReal (dist p.1 p.2 ^ 2)) :=
  ((measurable_fst.dist measurable_snd).pow_const _).ennreal_ofReal

private lemma cost_of_nearest (μ : Measure E) (y : E) :
    squaredTransportCost (nearestCoupling μ y) = ∫⁻ x, floorCost y x ∂μ := by
  unfold squaredTransportCost nearestCoupling
  have hg : Measurable (fun x : E => (x,nearestSite y x)) := measurable_id.prodMk (nearestSite_measurable y)
  rw [lintegral_map cost_measurable hg]
  exact lintegral_congr (nearest_eq_floor y)

private lemma cost_on_first (π : Measure (E × E)) (y : E) :
    squaredTransportCost (nearestCoupling π.fst y) = ∫⁻ p, floorCost y p.1 ∂π := by
  rw [cost_of_nearest,Measure.fst,lintegral_map (measurable_floor y) measurable_fst]

private lemma ae_lower (π : Measure (E × E)) (y : E) (hs : π.snd = twoAtoms y) :
    ∀ᵐ p ∂π, floorCost y p.1 ≤ ENNReal.ofReal (dist p.1 p.2 ^ 2) := by
  filter_upwards [on_sites π y hs] with p hp
  rcases hp with h | h
  · simp only [h,floorCost,min_le_left]
  · simp only [h,floorCost,min_le_right]

/-- Every competitor is an arbitrary joint measure. No conditional kernel,
Monge map, deterministic assignment, density or disintegration is assumed. -/
theorem nearestCoupling_minimal (μ : Measure E) (y : E) (π : Measure (E × E))
    (hf : π.fst = μ) (hs : π.snd = twoAtoms y) :
    squaredTransportCost (nearestCoupling μ y) ≤ squaredTransportCost π := by
  rw [←hf,cost_on_first]
  exact lintegral_mono_ae (ae_lower π y hs)

/-- A conditional uniform distribution on a positive-volume compact set gives finite cost. -/
theorem nearestCoupling_cost_finite (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0) (y : E) :
    squaredTransportCost (nearestCoupling (uniformOn K) y) ≠ ∞ := by
  have hr : Integrable (fun x => dist x y ^ 2) (volume.restrict K) :=
    (((continuous_id.dist continuous_const).pow 2).continuousOn).integrableOn_compact compact
  have hi : Integrable (fun x => dist x y ^ 2) (uniformOn K) := hr.smul_measure (ENNReal.inv_ne_top.mpr volpos)
  have hf := (lintegral_ofReal_ne_top_iff_integrable hi.aestronglyMeasurable (.of_forall (fun x => sq_nonneg (dist x y)))).mpr hi
  rw [cost_of_nearest]
  exact ne_top_of_le_ne_top hf (lintegral_mono (fun _ => min_le_left _ _))

private lemma assigned_on_equality (y x z : E) (sites : z = y ∨ z = -y)
    (notie : dist x y ≠ dist x (-y)) (he : floorCost y x = ENNReal.ofReal (dist x z ^ 2)) :
    nearestSite y x = z := by
  have eq' := congrArg ENNReal.toReal ((nearest_eq_floor y x).trans he)
  simp only [ENNReal.toReal_ofReal (sq_nonneg _)] at eq'
  have hdist : dist x (nearestSite y x) = dist x z := by
    nlinarith [dist_nonneg (x := x) (y := nearestSite y x),dist_nonneg (x := x) (y := z)]
  by_cases h : x ∈ nearestPlus y <;> simp only [nearestSite,h,ite_true,ite_false] at hdist ⊢
  · rcases sites with rfl | rfl
    · rfl
    · exact (notie hdist).elim
  · rcases sites with rfl | rfl
    · exact (notie hdist.symm).elim
    · rfl

/-- Strict Voronoi comparison on a null-bisector-free source ensures that the entire
optimal joint law, including its assignment, is unique. -/
theorem nearestCoupling_unique (μ : Measure E) (y : E) (π : Measure (E × E))
    (hf : π.fst = μ) (hs : π.snd = twoAtoms y)
    (notie : ∀ᵐ x ∂μ, dist x y ≠ dist x (-y))
    (finite : squaredTransportCost (nearestCoupling μ y) ≠ ∞)
    (opt : squaredTransportCost π ≤ squaredTransportCost (nearestCoupling μ y)) :
    π = nearestCoupling μ y := by
  have ff := cost_on_first π y
  rw [hf] at ff
  rw [ff] at finite opt
  have eqc := ae_eq_of_ae_le_of_lintegral_le (ae_lower π y hs) finite cost_measurable.aemeasurable opt
  have nh : ∀ᵐ p ∂π, dist p.1 y ≠ dist p.1 (-y) := by
    rw [←hf] at notie
    exact (ae_map_iff measurable_fst.aemeasurable
      ((measurableSet_eq_fun (measurable_id.dist measurable_const) (measurable_id.dist measurable_const)).compl)).mp notie
  have hg : (fun p : E × E => (p.1,nearestSite y p.1)) =ᵐ[π] id := by
    filter_upwards [on_sites π y hs,nh,eqc] with p hp hn he
    exact Prod.ext rfl (assigned_on_equality y _ _ hp hn he)
  have hgr : Measurable (fun x : E => (x,nearestSite y x)) := measurable_id.prodMk (nearestSite_measurable y)
  rw [←hf,nearestCoupling,Measure.fst,Measure.map_map hgr measurable_fst]
  exact (Measure.map_congr hg).trans Measure.map_id |>.symm

private lemma dist_bisector (x y : E) : dist x y = dist x (-y) → ⟪x,y⟫ = 0 := by
  simp only [dist_eq_norm,sub_neg_eq_add]
  intro h
  have hh := norm_sub_sq_real x y
  rw [h,norm_add_sq_real] at hh
  linarith

/-- Solver independence: for a compact symmetric volume source, the nearest graph
is the unique optimal half/half coupling at every nonzero antipodal site pair. -/
theorem uniform_balanced_unique (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (u : E) (hu : u ≠ 0) {r : ℝ} (hr : 0 < r) (π : Measure (E × E))
    (hf : π.fst = uniformOn K) (hs : π.snd = twoAtoms (r • u))
    (opt : squaredTransportCost π ≤ squaredTransportCost (nearestCoupling (uniformOn K) (r • u))) :
    π = nearestCoupling (uniformOn K) (r • u) := by
  have hne : r • u ≠ 0 := smul_ne_zero hr.ne' hu
  have h := no_ties_of_ac (uniformOn K) ProbabilityTheory.cond_absolutelyContinuous (r • u) hne
  have nh : ∀ᵐ x ∂uniformOn K, ⟪x,r • u⟫ ≠ 0 := by
    apply ae_iff.mpr
    simpa only [not_not] using h
  exact nearestCoupling_unique _ _ π hf hs (nh.mono fun x hh he => hh (dist_bisector x _ he))
    (nearestCoupling_cost_finite K compact volpos _) opt

/-- Uniform compact symmetric positive-volume sources yield an actual optimal
half/half transport coupling at all nonzero antipodal site pairs. -/
theorem uniform_balanced_optimal (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (symm : ∀ x : E, -x ∈ K ↔ x ∈ K) (u : E) (hu : u ≠ 0) {r : ℝ} (hr : 0 < r) :
    let μ := uniformOn K
    let y := r • u
    let γ := nearestCoupling μ y
    γ.fst = μ ∧ γ.snd = twoAtoms y ∧ ∀ π : Measure (E × E), π.fst = μ → π.snd = twoAtoms y →
      squaredTransportCost γ ≤ squaredTransportCost π := by
  let _ : IsProbabilityMeasure (uniformOn K) := ProbabilityTheory.cond_isProbabilityMeasure_of_finite volpos compact.measure_lt_top.ne
  obtain ⟨hp,hm,_⟩ := uniform_update K compact volpos symm u hu hr
  have h := nearestCoupling_marginals _ _ hp hm
  exact ⟨h.1,h.2,nearestCoupling_minimal _ _⟩

#print axioms nearestCoupling_marginals
#print axioms nearestCoupling_minimal
#print axioms uniform_balanced_optimal
#print axioms nearestCoupling_cost_finite
#print axioms nearestCoupling_unique
#print axioms uniform_balanced_unique
end LloydNDLimits
