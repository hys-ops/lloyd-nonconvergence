import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
import Mathlib.Tactic

/-! A right inverse to the restriction of the Fourier transform to the rays:
a real even angular datum and a smooth annular radial multiplier yield a real even
Schwartz function. The Fourier convention is mathlib's exp(-2πi⟪x,ξ⟫). -/
noncomputable section
open MeasureTheory Filter Set SchwartzMap FourierTransform
open scoped FourierTransform RealInnerProductSpace Topology ComplexConjugate ContDiff
namespace LloydNDFrequency

variable {dim : ℕ}
local notation "Space" => EuclideanSpace ℝ (Fin dim)

/-- Annular frequency prescription. At the origin all choices give zero. -/
def profile (h : Space → ℝ) (g : ℝ → ℝ) (x : Space) : ℝ :=
  g ‖x‖ * h (‖x‖⁻¹ • x)

private lemma unit_normal (x : Space) (hx : x ≠ 0) : ‖‖x‖⁻¹ • x‖ = 1 := by
  rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr (norm_nonneg x)),
    inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)]

theorem profile_smooth {h : Space → ℝ} {g : ℝ → ℝ} {a : ℝ} (ha : 0 < a)
    (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u) (hg : ContDiff ℝ ∞ g)
    (hlow : ∀ s < a, g s = 0) : ContDiff ℝ ∞ (profile h g) := by
  apply contDiff_iff_contDiffAt.2
  intro x
  by_cases hx : x = 0
  · subst x
    apply (contDiffAt_const (c:=(0:ℝ))).congr_of_eventuallyEq
    filter_upwards [Metric.ball_mem_nhds (0:Space) ha] with v hv
    simp only [Metric.mem_ball,dist_zero_right] at hv
    simp [profile,hlow _ hv]
  · have hn : ContDiffAt ℝ ∞ (norm : Space → ℝ) x := contDiffAt_norm ℝ hx
    have hdir : ContDiffAt ℝ ∞ (fun y : Space => ‖y‖⁻¹ • y) x :=
      (hn.inv (norm_ne_zero_iff.mpr hx)).smul contDiffAt_id
    exact (hg.contDiffAt.comp x hn).mul ((hh _ (unit_normal x hx)).comp (f := fun y : Space => ‖y‖⁻¹ • y) x hdir)

theorem profile_compact {h : Space → ℝ} {g : ℝ → ℝ} {b : ℝ}
    (hhigh : ∀ s, b < s → g s = 0) : HasCompactSupport (profile h g) := by
  apply (isCompact_closedBall (0:Space) b).of_isClosed_subset isClosed_closure
  apply closure_minimal _ Metric.isClosed_closedBall
  intro x hx
  contrapose! hx
  have hn : b < ‖x‖ := by simpa [Metric.mem_closedBall] using hx
  simp [Function.mem_support,profile,hhigh _ hn]

theorem profile_ray {h : Space → ℝ} {g : ℝ → ℝ} (he : ∀ u, ‖u‖ = 1 → h (-u) = h u)
    (hzero : g 0 = 0) {u : Space} (hu : ‖u‖ = 1) (t : ℝ) :
    profile h g (t • u) = g |t| * h u := by
  simp only [profile,norm_smul,Real.norm_eq_abs,hu,mul_one,smul_smul]
  rcases lt_trichotomy t 0 with hn|hz|hp
  · rw [abs_of_neg hn,inv_neg,neg_mul,inv_mul_cancel₀ hn.ne,neg_one_smul,he u hu]
  · simp [hz,hzero]
  · rw [abs_of_pos hp,inv_mul_cancel₀ hp.ne',one_smul]

theorem profile_even {h : Space → ℝ} {g : ℝ → ℝ}
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) (x : Space) : profile h g (-x) = profile h g x := by
  by_cases hx : x = 0
  · simp [hx]
  · simp only [profile,norm_neg,smul_neg]
    rw [he _ (unit_normal x hx)]

/-- A single continuous real-linear operator converts all Schwartz frequency data
to the real part of their inverse. No parameter-dependent choices are involved. -/
def inverseRealCLM : 𝓢(Space,ℂ) →L[ℝ] 𝓢(Space,ℝ) :=
  (SchwartzMap.postcompCLM Complex.reCLM).comp (fourierInvCLM ℝ 𝓢(Space,ℂ))

/-- Even, real frequency data have a pointwise even, real inverse, with exact
inversion in both the Schwartz and ordinary integral conventions. -/
theorem inverse_real_even (G : 𝓢(Space,ℂ)) (he : ∀ x, G (-x) = G x)
    (hr : ∀ x, conj (G x) = G x) :
    let f := inverseRealCLM G
    (∀ x, f (-x) = f x) ∧ (fun x => (f x : ℂ)) = (𝓕⁻ G : 𝓢(Space,ℂ)) ∧
      ∀ ξ, 𝓕 (fun x => (f x : ℂ)) ξ = G ξ := by
  have same : 𝓕⁻ (G : Space → ℂ) = 𝓕 (G : Space → ℂ) := by
    rw [Real.fourierInv_eq_fourier_comp_neg]
    congr 1
    funext x
    exact he x
  have even (x : Space) : (𝓕⁻ G : 𝓢(Space,ℂ)) (-x) = (𝓕⁻ G : 𝓢(Space,ℂ)) x := by
    rw [SchwartzMap.fourierInv_coe,Real.fourierInv_eq_fourier_neg,neg_neg,same]
  have realInv (x : Space) : conj ((𝓕⁻ G : 𝓢(Space,ℂ)) x) = (𝓕⁻ G : 𝓢(Space,ℂ)) x := by
    rw [SchwartzMap.fourierInv_coe]
    conv_rhs => rw [same,Real.fourier_eq']
    rw [Real.fourierInv_eq',←integral_conj]
    apply integral_congr_ae
    filter_upwards [] with v
    simp only [smul_eq_mul,map_mul,hr,←Complex.exp_conj,Complex.conj_I,Complex.conj_ofReal]
    congr 2
    push_cast
    ring
  let f := (𝓕⁻ G : 𝓢(Space,ℂ)).postcompCLM Complex.reCLM
  have eqn : (fun x => (f x : ℂ)) = (𝓕⁻ G : 𝓢(Space,ℂ)) := by
    funext x
    apply Complex.ext
    · rfl
    · have hi := congrArg Complex.im (realInv x)
      simp only [Complex.conj_im] at hi
      change 0 = _
      linarith
  refine ⟨fun x => congrArg Complex.re (even x),eqn,?_⟩
  intro ξ
  change 𝓕 (fun x => (f x : ℂ)) ξ = G ξ
  rw [eqn,←SchwartzMap.fourier_coe,fourier_fourierInv_eq]

/-- A real Schwartz inverse with the exact prescribed one-dimensional traces. -/
theorem annular_inverse {h : Space → ℝ} {g : ℝ → ℝ} {a b : ℝ}
    (ha : 0 < a) (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u)
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) (hg : ContDiff ℝ ∞ g)
    (hlow : ∀ s < a, g s = 0) (hhigh : ∀ s, b < s → g s = 0) :
    ∃ f : 𝓢(Space,ℝ), (∀ x, f (-x) = f x) ∧
      ∀ u, ‖u‖ = 1 → ∀ t : ℝ, 𝓕 (fun x => (f x : ℂ)) (t • u) = ↑(g |t| * h u) := by
  let G0 : 𝓢(Space,ℝ) := (profile_compact hhigh).toSchwartzMap (profile_smooth ha hh hg hlow)
  let G : 𝓢(Space,ℂ) := G0.postcompCLM Complex.ofRealCLM
  have GP (x:Space) : G x = ↑(profile h g x) := rfl
  obtain ⟨hf,_,hinv⟩ := inverse_real_even G (fun x => by rw [GP,GP,profile_even he])
    (fun x => by simp [GP])
  exact ⟨inverseRealCLM G,hf,fun u hu t => (hinv _).trans (by rw [GP,profile_ray he (hlow 0 ha) hu])⟩

def window : ContDiffBump (2:ℝ) := ⟨1/2,1,by norm_num,by norm_num⟩

theorem window_low (s : ℝ) (hs : s < 1) : window s = 0 := by
  apply window.zero_of_le_dist
  change 1 ≤ |s-2|
  rw [abs_of_neg (by linarith)]
  linarith

theorem window_high (s : ℝ) (hs : 3 < s) : window s = 0 := by
  apply window.zero_of_le_dist
  change 1 ≤ |s-2|
  rw [abs_of_pos (by linarith)]
  linarith

theorem window_eq_one {s : ℝ} (hs : |s-2| ≤ 1/2) : window s = 1 :=
  window.one_of_mem_closedBall hs

theorem window_inverse {h : Space → ℝ}
    (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u) (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) :
    ∃ f : 𝓢(Space,ℝ), (∀ x, f (-x) = f x) ∧
      ∀ u, ‖u‖ = 1 → ∀ t : ℝ, 𝓕 (fun x => (f x : ℂ)) (t • u) = ↑(window |t| * h u) :=
  annular_inverse zero_lt_one hh he window.contDiff window_low window_high

/-- A canonical Schwartz frequency extension of the angular datum, using the same
fixed window for every parameter. -/
def windowSchwartz (h : Space → ℝ) (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u) : 𝓢(Space,ℂ) :=
  ((profile_compact (h:=h) window_high).toSchwartzMap
    (profile_smooth zero_lt_one hh window.contDiff window_low)).postcompCLM Complex.ofRealCLM

theorem windowSchwartz_apply {h : Space → ℝ} (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u) (x:Space) :
    windowSchwartz h hh x = ↑(window ‖x‖ * h (‖x‖⁻¹ • x)) := rfl

theorem windowSchwartz_spec {h : Space → ℝ} (hh : ∀ u, ‖u‖ = 1 → ContDiffAt ℝ ∞ h u)
    (he : ∀ u, ‖u‖ = 1 → h (-u) = h u) :
    let f := inverseRealCLM (windowSchwartz h hh)
    (∀ x, f (-x) = f x) ∧
      ∀ u, ‖u‖ = 1 → ∀ t : ℝ, 𝓕 (fun x => (f x : ℂ)) (t • u) = ↑(window |t| * h u) := by
  let G := windowSchwartz h hh
  have hG (x:Space) : G x = ↑(profile h window x) := rfl
  obtain ⟨hf,_,hinv⟩ := inverse_real_even G (fun x => by rw [hG,hG,profile_even he])
    (fun x => by simp [hG])
  exact ⟨hf,fun u hu t => (hinv _).trans (by rw [hG,profile_ray he (window_low 0 zero_lt_one) hu])⟩

theorem window_weight_continuous : Continuous (fun t : ℝ => window |t| / t^2) := by
  apply continuous_iff_continuousAt.2
  intro t
  by_cases ht : t = 0
  · subst t
    apply (continuousAt_const (y:=(0:ℝ))).congr_of_eventuallyEq
    filter_upwards [Metric.ball_mem_nhds (0:ℝ) zero_lt_one] with s hs
    have hsmall : |s| < 1 := by simpa [Metric.mem_ball,Real.norm_eq_abs] using hs
    simp [window_low _ hsmall]
  · exact ((window.contDiff (n:=⊤)).continuous.comp continuous_abs).continuousAt.div
      (continuous_id.pow 2).continuousAt (pow_ne_zero _ ht)

theorem window_weight_integrable : Integrable (fun t : ℝ => window |t| / t^2) := by
  apply window_weight_continuous.integrable_of_hasCompactSupport
  apply (isCompact_closedBall (0:ℝ) 3).of_isClosed_subset isClosed_closure
  apply closure_minimal _ Metric.isClosed_closedBall
  intro x hx
  contrapose! hx
  have hbig : 3 < |x| := by simpa [Metric.mem_closedBall,Real.norm_eq_abs] using hx
  simp [Function.mem_support,window_high _ hbig]

theorem window_moment_pos : 0 < ∫ t : ℝ, window |t| / t^2 := by
  apply integral_pos_of_integrable_nonneg_nonzero (x:=2) window_weight_continuous
    window_weight_integrable (fun x => div_nonneg window.nonneg (sq_nonneg _))
  have hcenter : window |(2:ℝ)| = 1 := window_eq_one (by norm_num)
  rw [hcenter]
  norm_num

#print axioms windowSchwartz_spec
#print axioms window_moment_pos
#print axioms annular_inverse
#print axioms window_inverse
end LloydNDFrequency
