import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Calculus.FDeriv.WithLp
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Tactic

noncomputable section
open scoped RealInnerProductSpace
namespace LloydSpiral.Chart

def nextHeight (δ z : ℝ) : ℝ := z - δ * Real.exp (-(1 / z^2))
def azimuth (z : ℝ) : ℝ := -Real.log z

def potential (F q Φ : ℝ → ℝ) (z φ : ℝ) : ℝ := F z + q z * Real.sin (φ - Φ z)

/-- Actual partial derivatives for the prescribed jet on the spiral. -/
theorem potential_partials {F q Φ : ℝ → ℝ} {z p q' Φ' : ℝ}
    (hF : HasDerivAt F (p + q z * Φ') z) (hq : HasDerivAt q q' z)
    (hΦ : HasDerivAt Φ Φ' z) :
    HasDerivAt (fun x => potential F q Φ x (Φ z)) p z ∧
    HasDerivAt (potential F q Φ z) (q z) (Φ z) := by
  constructor
  · simpa [potential, Pi.add_def, Pi.mul_def] using!
        hF.add (hq.mul (((hasDerivAt_const z (Φ z)).sub hΦ).sin))
  · change HasDerivAt (fun x => F z + q z * Real.sin (x-Φ z)) _ _
    simpa [Pi.add_def, Pi.mul_def] using!
        (hasDerivAt_const (Φ z) (F z)).add
          ((hasDerivAt_const (Φ z) (q z)).mul
            (((hasDerivAt_id (Φ z)).sub (hasDerivAt_const (Φ z) (Φ z))).sin))

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- The tangent increment that sends a unit source to the specified unit target. -/
def chord (u v : E) : E := (inner ℝ u v)⁻¹ • v - u

def normalize (x : E) : E := ‖x‖⁻¹ • x

theorem chord_tangent {u v : E} (hu : ‖u‖ = 1) (h : 0 < inner ℝ u v) :
    inner ℝ u (chord u v) = 0 := by
  simp [chord, inner_sub_right, real_inner_smul_right, hu, ne_of_gt h]

theorem normalized_chord {u v : E} (hv : ‖v‖ = 1) (h : 0 < inner ℝ u v) :
    normalize (u + chord u v) = v := by
  rw [chord, add_sub_cancel, normalize, norm_smul, hv, mul_one,
    Real.norm_eq_abs, abs_of_pos (inv_pos.mpr h), smul_smul,
    inv_inv, mul_inv_cancel₀ (ne_of_gt h), one_smul]

abbrev E3 := EuclideanSpace ℝ (Fin 3)
def radial (z : ℝ) : ℝ := Real.sqrt (1 - z^2)
def point (z φ : ℝ) : E3 :=
  !₂[radial z * Real.cos φ, radial z * Real.sin φ, z]
def heightVec (z φ : ℝ) : E3 :=
  !₂[-z/radial z * Real.cos φ, -z/radial z * Real.sin φ, 1]
def angleVec (z φ : ℝ) : E3 :=
  !₂[-radial z * Real.sin φ, radial z * Real.cos φ, 0]

theorem radial_sq {z : ℝ} (hz : 0 < 1-z^2) : (radial z)^2 = 1-z^2 :=
  Real.sq_sqrt (le_of_lt hz)

theorem point_norm {z φ : ℝ} (hz : 0 < 1-z^2) : ‖point z φ‖ = 1 := by
  have hi : inner ℝ (point z φ) (point z φ) = 1 := by
    rw [PiLp.inner_apply]
    simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero, Real.inner_apply]
    change (radial z * Real.cos φ) * (radial z * Real.cos φ) + ((radial z * Real.sin φ) * (radial z * Real.sin φ) + z * z) = 1
    nlinarith [congrArg (fun x : ℝ => (radial z)^2 * x) (Real.sin_sq_add_cos_sq φ),
               radial_sq hz]
  rw [real_inner_self_eq_norm_sq] at hi
  nlinarith [norm_nonneg (point z φ)]


theorem radial_derivative {z : ℝ} (hz : 0 < 1-z^2) :
    HasDerivAt radial (-z/radial z) z := by
  have hh := ((hasDerivAt_const z (1:ℝ)).sub ((hasDerivAt_id z).pow 2)).sqrt
    (show (1:ℝ) - z^2 ≠ 0 from ne_of_gt hz)
  convert hh using 1
  · rfl
  · dsimp [radial]
    norm_num
    field_simp [(Real.sqrt_pos.mpr hz).ne']

theorem vec_hasDerivAt {a b c : ℝ → ℝ} {a' b' c' x : ℝ}
    (ha : HasDerivAt a a' x) (hb : HasDerivAt b b' x) (hc : HasDerivAt c c' x) :
    HasDerivAt (fun t => (!₂[a t,b t,c t] : E3)) (!₂[a',b',c'] : E3) x := by
  let v (t : ℝ) : Fin 3 → ℝ := ![a t,b t,c t]
  let dv : Fin 3 → ℝ := ![a',b',c']
  have h : HasDerivAt v dv x := hasDerivAt_pi.mpr (by
    intro i
    fin_cases i <;> first | exact ha | exact hb | exact hc)
  exact (PiLp.hasFDerivAt_toLp (𝕜 := ℝ) 2 (v x)).comp_hasDerivAt x h

theorem point_partials {z φ : ℝ} (hz : 0 < 1-z^2) :
    HasDerivAt (fun t => point t φ) (heightVec z φ) z ∧
    HasDerivAt (point z) (angleVec z φ) φ := by
  constructor
  · exact vec_hasDerivAt ((radial_derivative hz).mul_const _) ((radial_derivative hz).mul_const _)
      (hasDerivAt_id z)
  · apply vec_hasDerivAt
    · simpa using! (Real.hasDerivAt_cos φ).const_mul (radial z)
    · exact (Real.hasDerivAt_sin φ).const_mul _
    · exact hasDerivAt_const _ _

theorem inner3 (x y : E3) :
    inner ℝ x y = y 0 * x 0 + (y 1 * x 1 + y 2 * x 2) := by
  rw [PiLp.inner_apply]
  simp [Fin.sum_univ_succ]

theorem dot_points (z s φ ψ : ℝ) :
    inner ℝ (point z φ) (point s ψ) =
      radial z * radial s * Real.cos (ψ-φ) + z*s := by
  rw [inner3]
  simp [point, Real.cos_sub]
  ring

theorem dot_height (z s φ ψ : ℝ) :
    inner ℝ (point s ψ) (heightVec z φ) =
      s - z * radial s * Real.cos (ψ-φ) / radial z := by
  rw [inner3]
  simp [point, heightVec, Real.cos_sub, div_eq_mul_inv]
  ring

theorem dot_angle (z s φ ψ : ℝ) :
    inner ℝ (point s ψ) (angleVec z φ) =
      radial z * radial s * Real.sin (ψ-φ) := by
  rw [inner3]
  simp [point, angleVec, Real.sin_sub]
  ring

theorem tangent_height {z φ : ℝ} (hz : 0 < 1-z^2) :
    inner ℝ (point z φ) (heightVec z φ) = 0 := by
  rw [dot_height]
  simp [ne_of_gt (Real.sqrt_pos.mpr hz) , radial]

theorem tangent_angle (z φ : ℝ) :
    inner ℝ (point z φ) (angleVec z φ) = 0 := by simp [dot_angle]


/-- A tangent vector is uniquely specified by its two pairings with the coordinate tangents. -/
theorem frame_separates {z φ : ℝ} (hz : 0 < 1-z^2) {x : E3}
    (hu : inner ℝ x (point z φ) = 0) (hh : inner ℝ x (heightVec z φ) = 0)
    (ha : inner ℝ x (angleVec z φ) = 0) : x = 0 := by
  let r := radial z
  let C := Real.cos φ
  let S := Real.sin φ
  let A := C*x 0 + S*x 1
  let B := -S*x 0 + C*x 1
  have hr : 0 < r := Real.sqrt_pos.mpr hz
  have hrad : r^2 + z^2=1 := by linarith [radial_sq hz]
  have htri : S^2+C^2=1 := Real.sin_sq_add_cos_sq φ
  rw [inner3] at hu hh ha
  change (r*C) * x 0 + ((r*S) * x 1 + z*x 2) = 0 at hu
  change (-z/r*C) * x 0 + ((-z/r*S) * x 1 + 1*x 2) = 0 at hh
  change (-r*S) * x 0 + ((r*C) * x 1 + 0*x 2) = 0 at ha
  have h0 : r*A+z*x 2=0 := by dsimp [A]; linear_combination hu
  have h1 : -z*A+r*x 2=0 := by
    field_simp [hr.ne'] at hh
    dsimp [A]; linear_combination hh
  have h2 : r*B=0 := by dsimp [B]; linear_combination ha
  have hB : B=0 := (mul_eq_zero.mp h2).resolve_left hr.ne'
  have hA : A=0 := by linear_combination r*h0 - z*h1 - A*hrad
  have hx2 : x 2=0 := by
    rw [hA] at h1
    simpa [hr.ne', or_iff_right hr.ne'] using h1
  have hx0 : x 0=0 := by
    dsimp [A] at hA; dsimp [B] at hB
    linear_combination C*hA - S*hB - (x 0)*htri
  have hx1 : x 1=0 := by
    dsimp [A] at hA; dsimp [B] at hB
    linear_combination S*hA + C*hB - (x 1)*htri
  ext i
  fin_cases i <;> first | exact hx0 | exact hx1 | exact hx2

/-- Characterization of the spherical gradient by its differential in the height/angle chart. -/
def IsChartGradient (f : ℝ → ℝ → ℝ) (z φ : ℝ) (g : E3) : Prop :=
  inner ℝ g (point z φ)=0 ∧
  HasDerivAt (fun t => f t φ) (inner ℝ g (heightVec z φ)) z ∧
  HasDerivAt (f z) (inner ℝ g (angleVec z φ)) φ

theorem grad_unique {z φ : ℝ} (hz : 0 < 1-z^2)
    {f : ℝ → ℝ → ℝ} {g k : E3}
    (hg : IsChartGradient f z φ g) (hk : IsChartGradient f z φ k) : g=k := by
  obtain ⟨g0, gz, gp⟩ := hg
  obtain ⟨k0, kz, kp⟩ := hk
  apply sub_eq_zero.mp
  apply frame_separates hz (φ := φ)
  · rw [inner_sub_left, g0, k0, sub_self]
  · rw [inner_sub_left, gz.unique kz, sub_self]
  · rw [inner_sub_left, gp.unique kp, sub_self]

def zComponent (z s φ ψ : ℝ) : ℝ :=
  (s - z*radial s*Real.cos (ψ-φ)/radial z) / inner ℝ (point z φ) (point s ψ)
def phiComponent (z s φ ψ : ℝ) : ℝ :=
  (radial z*radial s*Real.sin (ψ-φ)) / inner ℝ (point z φ) (point s ψ)

theorem chord_components {z s φ ψ : ℝ} (hz : 0 < 1-z^2) :
  inner ℝ (chord (point z φ) (point s ψ)) (heightVec z φ) = zComponent z s φ ψ ∧
  inner ℝ (chord (point z φ) (point s ψ)) (angleVec z φ) = phiComponent z s φ ψ := by
  constructor
  · simp only [chord, inner_sub_left, real_inner_smul_left, tangent_height hz, sub_zero,
      dot_height, zComponent, div_eq_inv_mul]
  · simp only [chord, inner_sub_left, real_inner_smul_left, tangent_angle, sub_zero,
      dot_angle, phiComponent, div_eq_inv_mul]

/-- From a prescribed jet along a graph, identify the genuine chart gradient and its normalized update. -/
theorem chart_reconstruction {F q Φ : ℝ → ℝ} {z s ψ q' Φ' : ℝ}
    (hz : 0 < 1-z^2) (hs : 0 < 1-s^2) (hD : 0 < inner ℝ (point z (Φ z)) (point s ψ))
    (hF : HasDerivAt F (zComponent z s (Φ z) ψ + q z * Φ') z)
    (hq : HasDerivAt q q' z) (hΦ : HasDerivAt Φ Φ' z)
    (hval : q z = phiComponent z s (Φ z) ψ) :
    ∃! g, IsChartGradient (potential F q Φ) z (Φ z) g ∧
      normalize (point z (Φ z) + g) = point s ψ := by
  let u := point z (Φ z)
  let v := point s ψ
  obtain ⟨P,Q⟩ := chord_components (s:=s) (ψ:=ψ) (φ:=Φ z) hz
  obtain ⟨p1,p2⟩ := potential_partials hF hq hΦ
  have grad : IsChartGradient (potential F q Φ) z (Φ z) (chord u v) := by
    refine ⟨?_, ?_, ?_⟩
    · exact (real_inner_comm _ _).trans (chord_tangent (point_norm hz) hD)
    · dsimp [u,v]; rwa [P]
    · dsimp [u,v]; rwa [Q, ←hval]
  exact ⟨chord u v, ⟨grad, normalized_chord (point_norm hs) hD⟩,
    fun _ hg => grad_unique hz hg.1 grad⟩

#print axioms potential_partials
#print axioms point_partials
#print axioms chart_reconstruction
end LloydSpiral.Chart


