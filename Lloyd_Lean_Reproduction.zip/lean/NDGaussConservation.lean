import NDGaussBase

/-! A positive annular perturbation of the standard normal with exactly the
same probability mass, center and covariance, and prescribed projection change. -/
noncomputable section
open MeasureTheory ProbabilityTheory Set Filter
open scoped Topology RealInnerProductSpace ENNReal ContDiff
namespace LloydNDGaussian
open LloydNDPolar LloydNDNeutralShell
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def density (a:Vn→ℝ) (x:Vn) : ℝ := pdf x + spatial a x
def source (a:Vn→ℝ) : Measure Vn := law (density a)

theorem density_smooth {a:Vn→ℝ} (ha:AngularSmooth a) : ContDiff ℝ ∞ (density a) :=
  pdf_smooth.add (spatial_smooth ha)

theorem density_off_shell (a:Vn→ℝ) {x:Vn} (hx:‖x‖≤1 ∨ 2≤‖x‖) : density a x=pdf x := by
  rcases hx with h|h <;> simp [density,spatial,LloydNDFrequency.profile,
    show shell dim ‖x‖=0 by first | exact shell_zero_low dim h | exact shell_zero_high dim h]

theorem density_even {a:Vn→ℝ} (he:∀w,‖w‖=1→a (-w)=a w) (x:Vn) : density a (-x)=density a x := by
  simp [density,pdf,spatial_even he]

theorem law_integrable_iff {f:Vn→ℝ} (hf:Measurable f) (hp:∀x,0≤f x) (g:Vn→ℝ) :
    Integrable g (law f) ↔ Integrable (fun x=>g x*f x) := by
  unfold law
  rw [integrable_withDensity_iff_integrable_smul' hf.ennreal_ofReal (by simp)]
  simp only [ENNReal.toReal_ofReal (hp _),smul_eq_mul,mul_comm]

theorem source_mutual_ac {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0<density a x) :
    source a ≪ volume ∧ volume ≪ source a :=
  ⟨withDensity_absolutelyContinuous _ _, withDensity_absolutelyContinuous'
    (density_smooth ha).continuous.measurable.ennreal_ofReal.aemeasurable
    (Eventually.of_forall fun x=>(ENNReal.ofReal_pos.mpr (hp x)).ne')⟩

theorem source_neg {a:Vn→ℝ} (he:∀w,‖w‖=1→a (-w)=a w) :
    MeasurePreserving (fun x:Vn=>-x) (source a) (source a) := by
  refine ⟨measurable_neg,?_⟩
  ext s hs
  unfold source law
  rw [Measure.map_apply measurable_neg hs,withDensity_apply _ (measurable_neg hs),
    withDensity_apply _ hs]
  have H := ((Measure.measurePreserving_neg (volume:Measure Vn)).restrict_preimage hs).lintegral_comp_emb
    (MeasurableEquiv.neg Vn).measurableEmbedding (fun x=>ENNReal.ofReal (density a x))
  simpa only [density_even he] using H

theorem source_mean {a:Vn→ℝ} (he:∀w,‖w‖=1→a (-w)=a w) : (∫ x:Vn,x ∂source a)=0 := by
  have H := (source_neg he).integral_comp (MeasurableEquiv.neg Vn).measurableEmbedding id
  change (∫ x:Vn,-x ∂source a) = ∫ x:Vn,x ∂source a at H
  rw [integral_neg] at H
  ext i
  have hi := congrArg (fun w:Vn=>w i) H
  change -(∫ x:Vn,x ∂source a) i = (∫ x:Vn,x ∂source a) i at hi
  change (∫ x:Vn,x ∂source a) i = 0
  linarith

private lemma gaussian_weighted {p:Vn→ℝ} (hp:Integrable p (stdGaussian Vn)) :
    Integrable (fun x=>p x*pdf x) := by
  rw [←law_pdf] at hp
  exact (law_integrable_iff pdf_smooth.continuous.measurable (fun x=>(pdf_pos x).le) _).mp hp

theorem expectation_add {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x) (p:Vn→ℝ)
    (hc:Continuous p) (hi:Integrable p (stdGaussian Vn)) :
    (∫ x,p x ∂source a) = (∫ x,p x ∂stdGaussian Vn) + ∫ x,p x*spatial a x := by
  rw [source,law_integral (density_smooth ha).continuous.measurable hp,←law_pdf,
    law_integral pdf_smooth.continuous.measurable (fun x=>(pdf_pos x).le)]
  simp only [density,mul_add]
  exact integral_add (gaussian_weighted hi) (spatial_integrable ha hc)

theorem source_probability {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x) :
    IsProbabilityMeasure (source a) := by
  have hi : Integrable (density a) := pdf_integrable.add
    ((spatial_smooth ha).continuous.integrable_of_hasCompactSupport (spatial_compact a))
  let : IsFiniteMeasure (source a) := isFiniteMeasure_withDensity_ofReal hi.hasFiniteIntegral
  have h := expectation_add ha hp (fun _=>1) continuous_const (integrable_const _)
  simp only [integral_const,smul_eq_mul,mul_one,mass_zero ha,add_zero,
    one_mul] at h
  refine ⟨?_⟩
  apply (ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) ENNReal.one_ne_top).mp
  simpa [measureReal_def,mass_zero ha] using h

private theorem gauss_sq : Integrable (fun x:Vn=>‖x‖^2) (stdGaussian Vn) :=
  (memLp_two_iff_integrable_sq_norm aestronglyMeasurable_id).mp IsGaussian.memLp_two_id

private theorem gauss_bilinear (u v:Vn) :
    Integrable (fun x:Vn=>⟪u,x⟫*⟪v,x⟫) (stdGaussian Vn) := by
  apply (gauss_sq.const_mul (‖u‖*‖v‖)).mono' (by fun_prop)
  filter_upwards [] with x
  simp only [Real.norm_eq_abs,abs_mul]
  calc _ ≤ (‖u‖*‖x‖)*(‖v‖*‖x‖) :=
          mul_le_mul (abs_real_inner_le_norm _ _) (abs_real_inner_le_norm _ _) (abs_nonneg _) (by positivity)
       _ = _ := by ring

theorem source_second {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x) (u v:Vn) :
    (∫ x:Vn,⟪u,x⟫*⟪v,x⟫ ∂source a) = ⟪u,v⟫ := by
  rw [expectation_add ha hp _ (by fun_prop) (gauss_bilinear u v),second_moment_zero ha,add_zero]
  have h := covarianceBilin_apply (μ:=stdGaussian Vn) IsGaussian.memLp_two_id u v
  simpa [covarianceBilin_stdGaussian,innerSL_apply_apply ℝ] using h.symm

theorem source_L2 {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x) :
    MemLp id 2 (source a) := by
  apply (memLp_two_iff_integrable_sq_norm aestronglyMeasurable_id).mpr
  apply (law_integrable_iff (density_smooth ha).continuous.measurable hp _).mpr
  change Integrable (fun x:Vn=>‖x‖^2*density a x)
  simp only [density,mul_add]
  exact (gaussian_weighted gauss_sq).add (spatial_integrable ha (by fun_prop))

theorem source_covariance {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x)
    (he:∀w,‖w‖=1→a (-w)=a w) : covarianceBilin (source a)=innerSL ℝ := by
  let := source_probability ha hp
  ext u v
  rw [covarianceBilin_apply (source_L2 ha hp)]
  simpa [source_mean he,innerSL_apply_apply ℝ] using source_second ha hp u v

theorem source_projection {a:Vn→ℝ} (ha:AngularSmooth a) (hp:∀x,0≤density a x) (u:Vn) :
    (∫ x:Vn, |⟪u,x⟫| ∂source a) = (∫ x:Vn, |⟪u,x⟫| ∂stdGaussian Vn) +
        cosineTransform (fun w=>a w.val) u := by
  rw [expectation_add ha hp _ (by fun_prop),projection_moment ha]
  exact ((innerSL ℝ u).integrable_comp (IsGaussian.integrable_id (μ:=stdGaussian Vn))).abs

/-- The absolute projection of the genuine standard normal is the same
strictly positive constant in every unit direction. -/
theorem standard_projection : ∃ C : ℝ, 0 < C ∧ ∀ u:Vn, ‖u‖=1 →
    (∫ x:Vn, |⟪u,x⟫| ∂stdGaussian Vn)=C := by
  let w : Sn := Classical.choice (NormedSpace.sphere_nonempty_rclike (𝕜:=ℝ) (zero_le_one : (0:ℝ)≤1))
  have hw : ‖w.val‖=1 := by simp
  have hi : Integrable (fun x:Vn=> |⟪w.val,x⟫|) (stdGaussian Vn) :=
    ((innerSL ℝ w.val).integrable_comp (IsGaussian.integrable_id (μ:=stdGaussian Vn))).abs
  refine ⟨(∫ x:Vn, |⟪w.val,x⟫| ∂stdGaussian Vn),?_,?_⟩
  · rw [←law_pdf,law_integral pdf_smooth.continuous.measurable (fun x=>(pdf_pos x).le)]
    apply integral_pos_of_integrable_nonneg_nonzero (x:=w.val)
      (((continuous_const.inner continuous_id).abs).mul pdf_smooth.continuous) (gaussian_weighted hi)
    · intro x;exact mul_nonneg (abs_nonneg _) (pdf_pos x).le
    · change |⟪w.val,w.val⟫| *pdf w.val ≠0
      simp [hw,(pdf_pos _).ne']
  · intro u hu
    let R : Vn ≃ₗᵢ[ℝ] Vn := (ℝ ∙ (u-w.val))ᗮ.reflection
    have hr : R u=w.val := Submodule.reflection_sub (hu.trans hw.symm)
    have hpres : MeasurePreserving R (stdGaussian Vn) (stdGaussian Vn) := ⟨R.continuous.measurable,stdGaussian_map R⟩
    have h := hpres.integral_comp R.toHomeomorph.measurableEmbedding (fun x:Vn=> |⟪w.val,x⟫|)
    refine Eq.trans ?_ h
    apply integral_congr_ae
    filter_upwards [] with x
    rw [←hr,R.inner_map_map]

#print axioms standard_projection
#print axioms density_off_shell
#print axioms source_mutual_ac
#print axioms source_neg
#print axioms source_mean
#print axioms source_probability
#print axioms source_covariance
#print axioms source_projection
end LloydNDGaussian
