import Mathlib.Analysis.Calculus.BumpFunction.FiniteDimension
import Mathlib.Analysis.Distribution.TemperateGrowth
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Inverse
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Algebra.Order.Round
import Mathlib.Data.Nat.Pairing
import Mathlib.Tactic

/-! An explicit bounded-jet smooth curve with dense positive tails on each sphere.
A fixed compact family of circular excursions visits a repeated dense sequence.
Disjoint supports permit independent interpolation at all integer times. -/

noncomputable section
open Filter Set Topology TopologicalSpace Real
open scoped ContDiff RealInnerProductSpace
namespace LloydNDDense
set_option maxHeartbeats 210000

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

private def bump : ContDiffBump (0:ℝ) := ⟨1/8, 1/4, by norm_num, by norm_num⟩

private def arc (e w : E) (θ : ℝ) (s : ℝ) : E :=
  cos (θ * bump s) • e + sin (θ * bump s) • w

private theorem arc_unit {e w : E} (he : ‖e‖=1) (hw : ‖w‖=1) (ho : ⟪e,w⟫=0)
    (θ s : ℝ) : ‖arc e w θ s‖=1 := by
  have h := norm_add_sq_real (cos (θ*bump s) • e) (sin (θ*bump s) • w)
  simp only [real_inner_smul_left,real_inner_smul_right,ho,mul_zero,add_zero,
    norm_smul,Real.norm_eq_abs,he,hw,mul_one,sq_abs] at h
  change ‖cos (θ*bump s) • e + sin (θ*bump s) • w‖ = 1
  nlinarith [norm_nonneg (cos (θ*bump s) • e + sin (θ*bump s) • w),sin_sq_add_cos_sq (θ*bump s)]

private theorem represent {e b u : E} (he : ‖e‖=1) (hb : ‖b‖=1) (ho : ⟪e,b⟫=0)
    (hu : ‖u‖=1) :
    ∃ (θ : ℝ) (w : E), θ ∈ Icc 0 π ∧ ‖w‖=1 ∧ ⟪e,w⟫=0 ∧ arc e w θ 0 = u := by
  let c := ⟪e,u⟫
  let v := u - c • e
  have hc : |c| ≤ 1 := by simpa [c,he,hu] using abs_real_inner_le_norm e u
  have hin : ⟪e,v⟫ = 0 := by simp [v,inner_sub_right,real_inner_smul_right,he,c]
  have hv : ‖v‖^2 = 1-c^2 := by
    dsimp [v]
    rw [norm_sub_sq_real,real_inner_smul_right,real_inner_comm e u,norm_smul,he,hu,Real.norm_eq_abs]
    simp [c,sq_abs]; ring
  have hsin : sin (arccos c) = ‖v‖ := by rw [sin_arccos,← hv,Real.sqrt_sq (norm_nonneg _)]
  have hone : bump 0 = 1 := bump.one_of_mem_closedBall (by simp [bump])
  refine ⟨arccos c,if ‖v‖=0 then b else ‖v‖⁻¹ • v,⟨arccos_nonneg _, arccos_le_pi _⟩,?_,?_,?_⟩
  · split_ifs with hz
    · exact hb
    · rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (by positivity),inv_mul_cancel₀ hz]
  · split_ifs
    · exact ho
    · simp [real_inner_smul_right,hin]
  · simp only [arc,hone,mul_one,cos_arccos (abs_le.mp hc).1 (abs_le.mp hc).2,hsin]
    split_ifs with hz
    · have hv0 := norm_eq_zero.mp hz
      rw [hz,zero_smul,add_zero]
      exact (sub_eq_zero.mp hv0).symm
    · rw [smul_smul,mul_inv_cancel₀ hz,one_smul]
      dsimp [v]; abel

private def curve (e : E) (θ : ℤ → ℝ) (w : ℤ → E) (t : ℝ) : E :=
  e + ∑' i : ℤ, (arc e (w i) (θ i) (t-i) - e)

private theorem local_formula (e : E) (θ : ℤ → ℝ) (w : ℤ → E) (i : ℤ) {t : ℝ}
    (ht : |t - (i:ℝ)| < 2/3) : curve e θ w t = arc e (w i) (θ i) (t-i) := by
  unfold curve
  rw [tsum_eq_single i]
  · abel
  · intro j hji
    have hd : (1:ℝ) ≤ |(j:ℝ) - i| := by exact_mod_cast Int.one_le_abs (sub_ne_zero.mpr hji)
    have hn : (1:ℝ)/4 ≤ |t-j| := by
      have h := abs_sub_le (j:ℝ) t i
      rw [abs_sub_comm (j:ℝ) t] at h
      linarith
    have hz : bump (t-j) = 0 := bump.zero_of_le_dist (by simpa [bump,Real.dist_eq] using hn)
    simp [arc,hz]

private theorem near_formula (e : E) (θ : ℤ → ℝ) (w : ℤ → E) (t : ℝ) :
    curve e θ w =ᶠ[𝓝 t] fun s => arc e (w (round t)) (θ (round t)) (s-round t) := by
  have hlt : |t - (round t:ℝ)| < 2/3 := lt_of_le_of_lt (abs_sub_round t) (by norm_num)
  have he : ContinuousAt (fun s:ℝ => |s-(round t:ℝ)|) t := by fun_prop
  filter_upwards [he.eventually_lt continuousAt_const hlt] with s hs
  exact local_formula e θ w (round t) hs

private theorem arc_smooth (e w : E) (θ : ℝ) : ContDiff ℝ ∞ (arc e w θ) := by
  unfold arc
  have hs : ContDiff ℝ ∞ ((bump : ContDiffBump (0:ℝ)) : ℝ → ℝ) := bump.contDiff
  fun_prop

private theorem curve_smooth (e : E) (θ : ℤ → ℝ) (w : ℤ → E) : ContDiff ℝ ∞ (curve e θ w) := by
  apply contDiff_iff_contDiffAt.mpr
  intro t
  exact ((arc_smooth e (w (round t)) (θ (round t))).comp (contDiff_id.sub contDiff_const)).contDiffAt.congr_of_eventuallyEq (near_formula e θ w t)

private theorem partial_smooth {P : Type*} [NormedAddCommGroup P] [NormedSpace ℝ P]
    {F : P → ℝ → E} (h : ContDiff ℝ ∞ (Function.uncurry F)) (j : ℕ) :
    ContDiff ℝ ∞ (fun q:P × ℝ => iteratedDeriv j (F q.1) q.2) := by
  induction j with
  | zero => simpa [Function.uncurry_def] using h
  | succ j ih =>
    let G (q:P × ℝ) (s:ℝ) := iteratedDeriv j (F q.1) s
    have hG : ContDiff ℝ ∞ (Function.uncurry G) :=
      ih.comp (contDiff_fst.fst.prodMk contDiff_snd)
    have hh := hG.fderiv_apply (g:=fun q:P × ℝ => q.2) contDiff_snd
      (k:=fun _ => (1:ℝ)) (contDiff_const (n:=∞)) (by simp)
    simpa only [iteratedDeriv_succ,deriv, G] using hh

private def family (e : E) (p : ℝ × E) (s:ℝ) := arc e p.2 p.1 s

private theorem family_smooth (e:E) : ContDiff ℝ ∞ (Function.uncurry (family e)) := by
  change ContDiff ℝ ∞ (fun q:(ℝ × E) × ℝ => cos (q.1.1*bump q.2) • e + sin (q.1.1*bump q.2) • q.1.2)
  have hs : ContDiff ℝ ∞ ((bump : ContDiffBump (0:ℝ)) : ℝ → ℝ) := bump.contDiff
  exact ((contDiff_fst.fst.mul (hs.comp contDiff_snd)).cos.smul contDiff_const).add
    ((contDiff_fst.fst.mul (hs.comp contDiff_snd)).sin.smul contDiff_fst.snd)

private theorem family_bound [FiniteDimensional ℝ E] (e:E) (j:ℕ) :
    ∃ C:ℝ, ∀ x ∈ ((Icc 0 π ×ˢ Metric.closedBall (0:E) 1) ×ˢ Icc (-1:ℝ) 1),
    ‖iteratedDeriv j (family e x.1) x.2‖ ≤ C := by
  have hc := (isCompact_Icc (a:=(0:ℝ)) (b:=π)).prod (isCompact_closedBall (0:E) 1)
  exact (hc.prod (isCompact_Icc (a:=(-1:ℝ)) (b:=1))).exists_bound_of_continuousOn
    (partial_smooth (F:=family e) (family_smooth e) j).continuous.continuousOn

private theorem translated_derivative (e:E) (θ:ℤ → ℝ) (w:ℤ → E) (j:ℕ) (t:ℝ) :
    ‖iteratedFDeriv ℝ j (curve e θ w) t‖ =
    ‖iteratedDeriv j (family e (θ (round t),w (round t))) (t-round t)‖ := by
  have eqf := ((near_formula e θ w t).iteratedFDeriv (𝕜:=ℝ) j).eq_of_nhds
  change ‖iteratedFDeriv ℝ j (curve e θ w) t‖ =
    ‖iteratedDeriv j (arc e (w (round t)) (θ (round t))) (t-round t)‖
  rw [eqf,iteratedFDeriv_comp_sub,norm_iteratedFDeriv_eq_norm_iteratedDeriv]

private theorem uniform_bounds [FiniteDimensional ℝ E] (e:E) (θ:ℤ → ℝ) (w:ℤ → E)
    (hθ : ∀ i, θ i ∈ Icc 0 π) (hw : ∀ i, ‖w i‖=1) (j:ℕ) :
    ∃ C:ℝ, ∀ t:ℝ, ‖iteratedFDeriv ℝ j (curve e θ w) t‖ ≤ C := by
  obtain ⟨C,hC⟩ := family_bound e j
  refine ⟨C,fun t => (translated_derivative e θ w j t).le.trans ?_⟩
  apply hC ((θ (round t),w (round t)),t-(round t:ℝ))
  have hi := abs_le.mp (abs_sub_round t)
  have hw' : w (round t) ∈ Metric.closedBall (0:E) 1 := by
    rw [Metric.mem_closedBall,dist_zero_right]; exact (hw _).le
  refine ⟨⟨hθ _,hw'⟩,?_,?_⟩
  · change -1 ≤ t - (round t:ℝ)
    linarith [hi.1]
  · change t - (round t:ℝ) ≤ 1
    linarith [hi.2]

theorem exists_curve (k : ℕ) :
    ∃ a : ℝ → EuclideanSpace ℝ (Fin (k+2)), ContDiff ℝ ∞ a ∧
      (∀ t, ‖a t‖=1) ∧
      (∀ j:ℕ, ∃ C:ℝ, ∀ t:ℝ, ‖iteratedFDeriv ℝ j a t‖ ≤ C) ∧
      ∀ u, ‖u‖=1 → ∃ T : ℕ → ℝ, Tendsto T atTop atTop ∧ Tendsto (a ∘ T) atTop (𝓝 u) := by
  classical
  let V := EuclideanSpace ℝ (Fin (k+2))
  let e : V := EuclideanSpace.single (0:Fin (k+2)) (1:ℝ)
  let b : V := EuclideanSpace.single (⟨1,by omega⟩:Fin (k+2)) (1:ℝ)
  have he : ‖e‖=1 := (PiLp.norm_single 2 (fun _:Fin (k+2) => ℝ) (0:Fin (k+2)) (1:ℝ)).trans norm_one
  have hb : ‖b‖=1 := (PiLp.norm_single 2 (fun _:Fin (k+2) => ℝ) (⟨1,by omega⟩:Fin (k+2)) (1:ℝ)).trans norm_one
  have ho : ⟪e,b⟫ = 0 := by
    change ⟪EuclideanSpace.single (0:Fin (k+2)) (1:ℝ), EuclideanSpace.single (⟨1,by omega⟩:Fin (k+2)) (1:ℝ)⟫ = 0
    rw [EuclideanSpace.inner_single_left]; simp
  let S := Metric.sphere (0:V) 1
  let : Nonempty S := ⟨⟨e,by simpa [S] using he⟩⟩
  let d := denseSeq S
  let target (i:ℤ) : V := (d (Nat.unpair i.toNat).1).1
  have htarget (i:ℤ) : ‖target i‖=1 := by simpa [target,S] using (d (Nat.unpair i.toNat).1).2
  choose θ w hθ hw how hit using (fun i:ℤ => represent he hb ho (htarget i))
  refine ⟨curve e θ w,curve_smooth e θ w,fun t => ?_,uniform_bounds e θ w hθ hw,?_⟩
  · rw [(near_formula e θ w t).eq_of_nhds]
    exact arc_unit he (hw _) (how _) _ _
  · intro u hu
    let su : S := ⟨u,by simpa [S] using hu⟩
    obtain ⟨y,hy,ht⟩ := mem_closure_iff_seq_limit.mp ((denseRange_denseSeq S) su)
    choose g hg using hy
    let t (n:ℕ) : ℝ := Nat.pair (g n) n
    refine ⟨t,tendsto_atTop_mono (fun n => (by dsimp [t]; exact_mod_cast Nat.right_le_pair (g n) n : (n:ℝ) ≤ t n))
      tendsto_natCast_atTop_atTop,?_⟩
    have eqt (n:ℕ) : curve e θ w (t n) = (y n).1 := by
      let j : ℤ := Nat.pair (g n) n
      have heq : t n = (j:ℝ) := by simp [t,j]
      rw [heq,local_formula e θ w j (by simp),sub_self,hit]
      simp [target,j,d,hg n]
    exact (continuous_subtype_val.continuousAt.tendsto.comp ht).congr (fun n => (eqt n).symm)

/-- The same orbit generator has a global speed bound and temperate derivatives. -/
theorem exists_temperate_curve (k : ℕ) :
    ∃ (a : ℝ → EuclideanSpace ℝ (Fin (k+2))) (K : NNReal),
      a.HasTemperateGrowth ∧ LipschitzWith K a ∧ (∀ t, ‖a t‖ = 1) ∧
      (∀ j:ℕ, ∃ C:ℝ, ∀ t:ℝ, ‖iteratedFDeriv ℝ j a t‖ ≤ C) ∧
      ∀ u, ‖u‖=1 → ∃ T : ℕ → ℝ, Tendsto T atTop atTop ∧ Tendsto (a ∘ T) atTop (𝓝 u) := by
  obtain ⟨a,hs,hu,hb,ht⟩ := exists_curve k
  obtain ⟨B,hB⟩ := hb 1
  have hB0 : 0 ≤ B := (norm_nonneg _).trans (hB 0)
  refine ⟨a,⟨B,hB0⟩,⟨hs,?_⟩,?_,hu,hb,ht⟩
  · intro j
    obtain ⟨C,hC⟩ := hb j
    refine ⟨0,C,?_⟩
    simpa using hC
  · apply lipschitzWith_of_nnnorm_fderiv_le (hs.differentiable (by simp))
    intro t
    change ‖fderiv ℝ a t‖ ≤ B
    simpa only [norm_iteratedFDeriv_one] using hB t

#print axioms exists_curve
#print axioms exists_temperate_curve
end LloydNDDense
