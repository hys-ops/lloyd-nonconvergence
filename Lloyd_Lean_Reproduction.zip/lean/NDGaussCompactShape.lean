import NDGaussCompactHessian

/-! Smooth compact sources with exactly neutral shell perturbations. -/
noncomputable section
open Set Filter
open scoped RealInnerProductSpace Topology ContDiff SchwartzMap
namespace LloydNDCompactDensity
open LloydNDPolar LloydNDAngular LloydNDNeutralShell
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def relativeCut (C : ℝ) (x : Vn) := (LloydNeutralShell.shell ‖x‖ * (‖x‖^2)^2) / (C * base x)

private theorem shell_norm_smooth : ContDiff ℝ ∞ (fun x:Vn => LloydNeutralShell.shell ‖x‖) := by
  have h := LloydNDFrequency.profile_smooth (h:=fun _ : Vn => 1) zero_lt_one
    (fun _ _ => contDiffAt_const) LloydNeutralShell.shell_smooth LloydNeutralShell.shell_low
  convert! h using 1
  funext x
  simp [LloydNDFrequency.profile]

theorem relativeCut_smooth {C : ℝ} (hC : 0<C) : ContDiff ℝ ∞ (relativeCut (dim:=dim) C) := by
  apply contDiff_iff_contDiffAt.mpr
  intro x
  by_cases hx : ‖x‖ < 3
  · have hn := (contDiff_norm_sq (𝕜:=ℝ) (E:=Vn) (n:=∞)).pow 2
    exact (shell_norm_smooth.mul hn).contDiffAt.div (contDiff_const.mul base_smooth).contDiffAt
      (mul_pos hC ((base_pos_iff x).mpr hx)).ne'
  · have hd : 2 < ‖x‖ := by linarith
    apply (show ContDiffAt ℝ ∞ (fun _:Vn => (0:ℝ)) x from contDiffAt_const).congr_of_eventuallyEq
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Ioi_mem_nhds hd)] with y hy
    simp [relativeCut,LloydNeutralShell.shell_high _ hy]

theorem relativeCut_compact (C : ℝ) : HasCompactSupport (relativeCut (dim:=dim) C) := by
  apply (isCompact_closedBall (0:Vn) 2).of_isClosed_subset isClosed_closure
  apply closure_minimal _ Metric.isClosed_closedBall
  intro x hx
  contrapose! hx
  have h : 2 < ‖x‖ := by simpa [Metric.mem_closedBall] using hx
  simp [Function.mem_support,relativeCut,LloydNeutralShell.shell_high _ h]

theorem relativeCut_away (C : ℝ) : tsupport (relativeCut C) ⊆ (away : Set Vn) := by
  have hs : tsupport (relativeCut C) ⊆ {x:Vn | 1 ≤ ‖x‖} := by
    apply closure_minimal _ (isClosed_le continuous_const continuous_norm)
    intro x hx
    contrapose! hx
    have h : ‖x‖ < 1 := by simpa using hx
    simp [Function.mem_support,relativeCut,LloydNeutralShell.shell_low _ h]
  intro x hx
  have h := hs hx
  change (1:ℝ)/2 < ‖x‖
  change 1 ≤ ‖x‖ at h
  linarith

private theorem relative_eq {C : ℝ} (hC : 0<C) (f : 𝓢(Vn,ℝ)) (x : Vn) :
    C*base x + spatial (radialize f) x = (C*base x) * (1 + cutoffMoment (relativeCut C) (dim+1) f x) := by
  change C*base x + shell dim ‖x‖ * radialize f (‖x‖⁻¹ • x) =
    (C*base x) * (1 + ((LloydNeutralShell.shell ‖x‖ * (‖x‖^2)^2) / (C*base x)) * radialize f x)
  by_cases hx : x = 0
  · simp [hx,shell_zero_low dim (by norm_num : (0:ℝ)≤1),LloydNeutralShell.shell_low _ zero_lt_one]
  by_cases hi : ‖x‖ < 3
  · have hr := norm_pos_iff.mpr hx
    have ht := radialize_homogeneous f (‖x‖⁻¹ • x) hr
    rw [smul_smul,mul_inv_cancel₀ hr.ne',one_smul] at ht
    rw [←ht]
    rw [show ‖x‖^(dim+2) = ‖x‖^dim * ‖x‖^2 by rw [pow_add]]
    have hc := unweight dim hr
    field_simp [hC.ne',((base_pos_iff x).mpr hi).ne']
    linear_combination (‖x‖^2 * radialize f x) * hc
  · have hz := shell_zero_high dim (show 2 ≤ ‖x‖ by linarith)
    simp [hz,LloydNeutralShell.shell_zero_high (show 2 ≤ ‖x‖ by linarith)]

private theorem perturb_Hessian_split {C : ℝ} (hC : 0<C) {b : Vn → ℝ} (hb : ContDiff ℝ ∞ b)
    (hp : ∀ x, 0<1+b x) {x : Vn} (hx : ‖x‖ < 3) (v : Vn) :
    fderiv ℝ (fderiv ℝ (fun z => -Real.log (C*base z*(1+b z)))) x v v =
      fderiv ℝ (fderiv ℝ (fun z => -Real.log (C*base z))) x v v -
      fderiv ℝ (fderiv ℝ (fun z => Real.log (1+b z))) x v v := by
  let A := fun z:Vn => -Real.log (C*base z)
  let B := fun z:Vn => Real.log (1+b z)
  have hA {z:Vn} (hz : ‖z‖ < 3) : ContDiffAt ℝ ∞ A z :=
    ((contDiff_const.mul base_smooth).contDiffAt.log (mul_pos hC ((base_pos_iff z).mpr hz)).ne').neg
  have hB : ContDiff ℝ ∞ B := (contDiff_const.add hb).log (fun z => (hp z).ne')
  have hEq : (fun z:Vn => -Real.log (C*base z*(1+b z))) =ᶠ[𝓝 x] (A - B) := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Iio_mem_nhds hx)] with z hz
    simp only [A,B,Pi.sub_apply,Real.log_mul (mul_pos hC ((base_pos_iff z).mpr hz)).ne' (hp z).ne']; ring
  have hdEq : fderiv ℝ (A-B) =ᶠ[𝓝 x] fderiv ℝ A - fderiv ℝ B := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Iio_mem_nhds hx)] with z hz
    exact (((hA hz).differentiableAt (by simp)).hasFDerivAt.sub ((hB.differentiable (by simp)) z).hasFDerivAt).fderiv
  have dA := ((hA hx).fderiv_right (m:=1) (by simp)).differentiableAt (by norm_num)
  have dB := ((hB.fderiv_right (m:=1) (by simp)).differentiable (by norm_num)) x
  rw [hEq.fderiv.fderiv_eq,hdEq.fderiv_eq,(dA.hasFDerivAt.sub dB.hasFDerivAt).fderiv]
  rfl

/-- With no unproved Hessian or positivity assumptions, small Schwartz perturbations
preserve the exact support, smoothness, shell agreement, and an interior uniform
lower bound on the Fréchet Hessian of the actual negative log-density. -/
theorem eventually_compact_shell {ι : Type*} {l : Filter ι} {F : ι → 𝓢(Vn,ℝ)}
    (hF : Tendsto F l (𝓝 0)) {C : ℝ} (hC : 0<C) :
    ∀ᶠ i in l, let ρ := fun x:Vn => C*base x + spatial (radialize (F i)) x
      ContDiff ℝ ∞ ρ ∧ (∀ x, 0 ≤ ρ x) ∧ (∀ x, 0 < ρ x ↔ ‖x‖ < 3) ∧
      (∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x = C*base x) ∧
      (∀ x, ‖x‖<3 → ∀ v:Vn, ‖v‖^2 ≤ fderiv ℝ (fderiv ℝ (fun z => -Real.log (ρ z))) x v v) := by
  filter_upwards [cutoff_eventually_small hF (relativeCut_smooth hC) (relativeCut_compact C)
    (relativeCut_away C) (dim+1) (by norm_num : (0:ℝ)<1/4)] with i h
  let b := cutoffMoment (relativeCut C) (dim+1) (F i)
  have hb := cutoffMoment_smooth (relativeCut_smooth hC) (relativeCut_away C) (dim+1) (F i)
  have hr (x:Vn) : 1/2 < 1+b x := by
    have hh : |b x| < 1/4 := (h x).1
    linarith [(abs_lt.mp hh).1]
  have hp (x:Vn) : 0<1+b x := by linarith [hr x]
  have he : (fun x:Vn => C*base x+spatial (radialize (F i)) x) = fun x => C*base x*(1+b x) := funext (relative_eq hC _)
  refine ⟨?_,?_,?_,?_,?_⟩
  · rw [he]; exact (contDiff_const.mul base_smooth).mul (contDiff_const.add hb)
  · intro x; rw [he]; exact mul_nonneg (mul_nonneg hC.le (base_nonneg x)) (hp x).le
  · intro x; rw [he]; simp only [mul_pos_iff_of_pos_right (hp x),mul_pos_iff_of_pos_left hC,base_pos_iff]
  · intro x hx
    have hz : shell dim ‖x‖ = 0 := by
      by_cases lo : ‖x‖ ≤ 1
      · exact shell_zero_low dim lo
      · exact shell_zero_high dim (le_of_not_gt (fun hi => hx ⟨lt_of_not_ge lo,hi⟩))
    change C*base x + shell dim ‖x‖ * _ = C*base x
    rw [hz,zero_mul,add_zero]
  · intro x hx v
    change ‖v‖^2 ≤ fderiv ℝ (fderiv ℝ (fun z => -Real.log ((fun y => C*base y+spatial (radialize (F i)) y) z))) x v v
    rw [he,perturb_Hessian_split hC hb hp hx v,LloydNDGaussianShape.log_hessian hb hp]
    have hl := base_hessian_ge C hC hx v
    let D := fderiv ℝ (fderiv ℝ b) x
    have hd : D v v ≤ (1/4)*‖v‖^2 := calc
      _ ≤ ‖D v v‖ := Real.le_norm_self _
      _ ≤ ‖D v‖*‖v‖ := (D v).le_opNorm _
      _ ≤ (‖D‖*‖v‖)*‖v‖ := by gcongr; exact D.le_opNorm _
      _ ≤ ((1/4)*‖v‖)*‖v‖ := by gcongr; exact (h x).2.2.le
      _ = _ := by ring
    have hi2 : (1+b x)⁻¹ ≤ 2 := by rw [inv_eq_one_div,div_le_iff₀ (hp x)]; linarith [hr x]
    have hu : (1+b x)⁻¹ * D v v ≤ (1/2)*‖v‖^2 := calc
      _ ≤ (1+b x)⁻¹ * ((1/4)*‖v‖^2) := by gcongr; exact inv_nonneg.mpr (hp x).le
      _ ≤ 2*((1/4)*‖v‖^2) := by gcongr
      _ = _ := by ring
    have hgood : 0 ≤ ((1+b x)^2)⁻¹ * (fderiv ℝ b x v)^2 := by positivity
    change ‖v‖^2 ≤ _ - ((1+b x)⁻¹*D v v - _)
    linarith [sq_nonneg ‖v‖]

#print axioms relativeCut_smooth
#print axioms eventually_compact_shell
end LloydNDCompactDensity
