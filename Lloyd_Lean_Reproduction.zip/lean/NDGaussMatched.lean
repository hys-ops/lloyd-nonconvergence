import NDLimitsSupport

/-! Equality of the full direction maps from a proportional moment profile,
including the actual nearest-cell means at arbitrary antipodal radii. -/
noncomputable section
open MeasureTheory Filter
open scoped RealInnerProductSpace
namespace LloydNDLimits
variable {d : ℕ}
local notation "Vn" => EuclideanSpace ℝ (Fin d)

theorem support_homogeneous (μ : Measure Vn) (r : ℝ) (u : Vn) :
    populationSupport μ (r • u) = |r| *populationSupport μ u := by
  simp only [populationSupport,real_inner_smul_right,abs_mul,integral_const_mul]

theorem support_proportional {μ ν : Measure Vn} {s : ℝ}
    (h : ∀ u:Vn, ‖u‖=1 → populationSupport μ u = s*populationSupport ν u) :
    ∀ x, populationSupport μ x = s*populationSupport ν x := by
  intro x
  by_cases hx : x=0
  · simp [hx,populationSupport]
  · have hp := norm_pos_iff.mpr hx
    let u := ‖x‖⁻¹ • x
    have hu : ‖u‖=1 := by simp [u,norm_smul,hp.ne']
    have he : ‖x‖ • u=x := by simp [u,smul_smul,hp.ne']
    calc
      _ = populationSupport μ (‖x‖ • u) := congrArg _ he.symm
      _ = s*populationSupport ν (‖x‖ • u) := by rw [support_homogeneous μ ‖x‖ u,support_homogeneous ν ‖x‖ u,h u hu]; ring
      _ = _ := by rw [he]

theorem signedMoment_proportional {μ ν : Measure Vn} {s : ℝ}
    (hac : μ ≪ volume) (hbc : ν ≪ volume)
    (hi : Integrable (id:Vn→Vn) μ) (hj : Integrable (id:Vn→Vn) ν)
    (h : ∀ u:Vn, ‖u‖=1 → populationSupport μ u = s*populationSupport ν u)
    (u:Vn) (hu : u≠0) : signedMoment μ u = s • signedMoment ν u := by
  have hm := (signedMoment_hasGradientAt μ u (no_ties_of_ac μ hac u hu) hi).hasFDerivAt
  have hn := ((signedMoment_hasGradientAt ν u (no_ties_of_ac ν hbc u hu) hj).hasFDerivAt).const_smul s
  have he : populationSupport μ = fun x => s • populationSupport ν x := funext (support_proportional h)
  rw [he] at hm
  have hf := hm.unique hn
  apply (InnerProductSpace.toDual ℝ Vn).injective
  simpa only [map_smul] using hf

theorem antipodal_updates_proportional {μ ν : Measure Vn} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (he : MeasurePreserving (fun x:Vn => -x) μ μ) (hf : MeasurePreserving (fun x:Vn => -x) ν ν)
    (hac : μ ≪ volume) (hbc : ν ≪ volume)
    (hi : Integrable (id:Vn→Vn) μ) (hj : Integrable (id:Vn→Vn) ν)
    {s : ℝ} (hs : 0<s)
    (h : ∀ u:Vn, ‖u‖=1 → populationSupport μ u = s*populationSupport ν u)
    (u:Vn) (hu : u≠0) {r t:ℝ} (hr : 0<r) (ht : 0<t) :
    update μ (r • u) = s • update ν (t • u) ∧
      ‖(update μ (r • u)).1‖⁻¹ • (update μ (r • u)).1 =
      ‖(update ν (t • u)).1‖⁻¹ • (update ν (t • u)).1 := by
  rw [(reflection_update μ u hr he (no_ties_of_ac μ hac u hu) hi).2.2,
    (reflection_update ν u ht hf (no_ties_of_ac ν hbc u hu) hj).2.2,
    signedMoment_proportional hac hbc hi hj h u hu]
  constructor
  · ext <;> simp
  · simp [norm_smul,smul_smul,Real.norm_eq_abs,abs_of_pos hs,hs.ne']

#print axioms antipodal_updates_proportional
end LloydNDLimits
