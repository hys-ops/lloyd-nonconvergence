import NDGaussMatched
import NDGaussRealization
import NDGaussCompactRealization
import NDGeoRealize
import NDLimitsRadius

/-! The same prescribed moment profile is realized simultaneously by three actual
sources in one dimension and at one parameter. Their exact antipodal centroid
steps agree up to a scalar fixed by the pair of sources. -/
noncomputable section
open Set MeasureTheory ProbabilityTheory Filter
open scoped Topology RealInnerProductSpace ContDiff
namespace LloydNDModels
variable {k : ℕ}
local notation "Vn" => LloydNDPolar.E k
open LloydNDLimits

structure Profile (μ : Measure Vn) (h : Vn → ℝ) (c : ℝ) : Prop where
  positive : 0<c
  probability : IsProbabilityMeasure μ
  even : MeasurePreserving (fun x:Vn => -x) μ μ
  ac : μ ≪ volume
  first : Integrable (id:Vn→Vn) μ
  moment : ∀ u:Vn, ‖u‖=1 → populationSupport μ u = c*h u

structure UniformShape (K : Set Vn) (m : ℕ) (ε : ℝ) : Prop where
  compact : IsCompact K
  volume_pos : 0 < volume K
  even : ∀ x:Vn, -x ∈ K ↔ x ∈ K
  strict : StrictConvex ℝ K
  curved : LloydNDGeom.HasPositiveCurvedBoundary K
  ball_subset : Metric.closedBall (0:Vn) (1/2:ℝ) ⊆ K
  near : LloydNDGeom.NearRound K m ε

structure GaussianShape (ρ : Vn→ℝ) : Prop where
  pos : ∀ x,0<ρ x
  smooth : ContDiff ℝ ∞ ρ
  shell : ∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x=LloydNDGaussian.pdf x
  even : ∀ x,ρ (-x)=ρ x
  open_pos : Measure.IsOpenPosMeasure (LloydNDGaussian.law ρ)
  equivalent : volume ≪ LloydNDGaussian.law ρ
  centered : (∫ x:Vn,x ∂LloydNDGaussian.law ρ)=0
  variance : MemLp id 2 (LloydNDGaussian.law ρ)
  covariance : covarianceBilin (LloydNDGaussian.law ρ)=innerSL ℝ
  log_hessian : ∀ x v:Vn, ‖v‖^2/2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v

structure CompactShape (ρ : Vn→ℝ) : Prop where
  smooth : ContDiff ℝ ∞ ρ
  nonneg : ∀ x,0≤ρ x
  positive_set : ∀ x, 0<ρ x ↔ ‖x‖<3
  support : tsupport ρ=Metric.closedBall (0:Vn) 3
  measure_support : (LloydNDGaussian.law ρ).support=Metric.closedBall (0:Vn) 3
  shell : ∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x=LloydNDCompactSource.pdf x
  even : ∀ x,ρ (-x)=ρ x
  centered : (∫ x:Vn,x ∂LloydNDGaussian.law ρ)=0
  variance : MemLp id 2 (LloydNDGaussian.law ρ)
  covariance : covarianceBilin (LloydNDGaussian.law ρ)=covarianceBilin (LloydNDGaussian.law LloydNDCompactSource.pdf)
  log_hessian : ∀ x, ‖x‖<3 → ∀ v:Vn, ‖v‖^2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v
  log_concave : ∀ (x y:Vn) (a b:ℝ), 0≤a → 0≤b → a+b=1 → (ρ x)^a*(ρ y)^b ≤ ρ (a • x+b • y)

theorem Profile.same_update {μ ν : Measure Vn} {h : Vn → ℝ} {c b : ℝ}
    (p : Profile μ h c) (q : Profile ν h b) (u:Vn) (hu:u≠0)
    {r t : ℝ} (hr:0<r) (ht:0<t) :
    update μ (r • u) = (c/b) • update ν (t • u) ∧
      ‖(update μ (r • u)).1‖⁻¹ • (update μ (r • u)).1 =
      ‖(update ν (t • u)).1‖⁻¹ • (update ν (t • u)).1 := by
  have : IsProbabilityMeasure μ := p.probability
  have : IsProbabilityMeasure ν := q.probability
  apply antipodal_updates_proportional p.even q.even p.ac q.ac p.first q.first
    (div_pos p.positive q.positive) _ u hu hr ht
  intro w hw
  rw [p.moment w hw,q.moment w hw]
  field_simp [q.positive.ne']

private theorem uniform_even {K : Set Vn} (compact : IsCompact K)
    (symm : ∀ x:Vn, -x ∈ K ↔ x ∈ K) :
    MeasurePreserving (fun x:Vn => -x) (LloydNDLimits.uniformOn K) (LloydNDLimits.uniformOn K) := by
  have h0 : (fun x:Vn => -x) ⁻¹' K = K := Set.ext symm
  have hneg : MeasurePreserving (fun x:Vn => -x) volume volume :=
    (LinearIsometryEquiv.neg ℝ : Vn ≃ₗᵢ[ℝ] Vn).measurePreserving
  have hm := hneg.restrict_preimage compact.measurableSet
  rw [h0] at hm
  refine ⟨measurable_neg,?_⟩
  unfold LloydNDLimits.uniformOn ProbabilityTheory.cond
  rw [Measure.map_smul _ measurable_neg.aemeasurable,hm.map_eq]

theorem realize {h : ℝ × Vn → ℝ} (hs : LloydNDFrequency.SmoothOnDirections h)
    (he : ∀ t (u:Vn), ‖u‖=1 → h (t,-u)=h (t,u)) (hz : ∀ u:Vn, ‖u‖=1 → h (0,u)=1)
    (m : ℕ) (ε : ℝ) (hε:0<ε) :
    ∀ᶠ t in 𝓝 (0:ℝ), ∃ (K : Set Vn) (ρ σ : Vn → ℝ) (c b e : ℝ),
      UniformShape K m ε ∧ GaussianShape ρ ∧ CompactShape σ ∧
      Profile (LloydNDLimits.uniformOn K) (fun u => h (t,u)) c ∧
      Profile (LloydNDGaussian.law ρ) (fun u => h (t,u)) b ∧
      Profile (LloydNDGaussian.law σ) (fun u => h (t,u)) e := by
  obtain ⟨K,c,Hu⟩ := LloydNDGeom.local_profile_realization hs he hz
  obtain ⟨b,hb,Hg⟩ := LloydNDGaussian.gaussian_realization h hs he hz
  obtain ⟨e,he',Hc⟩ := LloydNDCompactSource.compact_realization h hs he hz
  filter_upwards [Hu m ε hε,Hg,Hc] with t U G C
  obtain ⟨hcu,hcomp,hvol,hsym,hstrict,hcurv,hball,hpu,hnear,hu⟩ := U
  obtain ⟨ρ,hgp,hgs,hgsh,hge,hpg,hopen,hes,hac,hca,hgm,hg2,hgc,hgh,hg⟩ := G
  obtain ⟨σ,hcs,hcn,hcp,hss,hms,hcsh,hce,hpc,hcse,hcac,hcm,hc2,hcc,hch,hcl,hc⟩ := C
  refine ⟨K t,ρ,σ,c t,b,e,⟨hcomp,hvol,hsym,hstrict,hcurv,hball,hnear⟩,
    ⟨hgp,hgs,hgsh,hge,hopen,hca,hgm,hg2,hgc,hgh⟩,⟨hcs,hcn,hcp,hss,hms,hcsh,hce,hcm,hc2,hcc,hch,hcl⟩,
    ⟨hcu,hpu,uniform_even hcomp hsym,ProbabilityTheory.cond_absolutelyContinuous,
      uniform_id_integrable _ hcomp hvol.ne',?_⟩,
    ⟨hb,hpg,hes,hac,hg2.integrable (by norm_num),?_⟩,
    ⟨he',hpc,hcse,hcac,hc2.integrable (by norm_num),?_⟩⟩
  · intro u hw
    simpa only [populationSupport,LloydNDLimits.uniformOn,real_inner_comm u _] using hu u hw
  · intro u hw
    simpa only [populationSupport,real_inner_comm u _] using hg u hw
  · intro u hw
    simpa only [populationSupport,real_inner_comm u _] using hc u hw

#print axioms realize
#print axioms Profile.same_update
end LloydNDModels
