import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier
import Mathlib.Analysis.Calculus.ContDiff.Comp
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic

open Filter Topology Set
open scoped SchwartzMap ContDiff
namespace LloydNDSchwartz
noncomputable section
variable {dim : ℕ}
local notation "Space" => EuclideanSpace ℝ (Fin dim)

/-- Differentiating a slice is restricting the ambient derivative to its last coordinates. -/
theorem slice_derivative (f : ℝ × Space → ℂ) (hf : ContDiff ℝ ∞ f) (n : ℕ) (t : ℝ) (x : Space) :
    iteratedFDeriv ℝ n (fun y => f (t,y)) x =
       (iteratedFDeriv ℝ n f (t,x)).compContinuousLinearMap
         (fun _ => ContinuousLinearMap.inr ℝ ℝ Space) := by
  let i := ContinuousLinearMap.inr ℝ ℝ Space
  let a : ℝ × Space := (t,0)
  let F := fun w => f (a+w)
  have hF : ContDiff ℝ ∞ F := hf.comp (contDiff_const.add contDiff_id)
  have hi := i.iteratedFDeriv_comp_right hF x (i:=n) (by simp)
  have heq : F ∘ i = fun y => f (t,y) := by funext y; simp [F,i,a,Function.comp_def]
  rw [heq] at hi
  simpa [F,i,a,iteratedFDeriv_comp_add_left] using hi

theorem continuous_slice_derivative (f : ℝ × Space → ℂ) (hf : ContDiff ℝ ∞ f) (n : ℕ) :
    Continuous (fun w : ℝ × Space => iteratedFDeriv ℝ n (fun y => f (w.1,y)) w.2) := by
  simp_rw [slice_derivative f hf]
  exact (ContinuousMultilinearMap.compContinuousLinearMapL
    (F:=ℂ) (fun _ : Fin n => ContinuousLinearMap.inr ℝ ℝ Space)).continuous.comp
      (hf.continuous_iteratedFDeriv (by simp))

/-- A jointly smooth frequency perturbation with fixed compact frequency support
and zero initial slice tends to zero in the full Schwartz topology. -/
theorem tendsto_zero_of_compact_slices (F : ℝ → 𝓢(Space,ℂ))
    (hf : ContDiff ℝ ∞ (fun w : ℝ × Space => F w.1 w.2))
    (hzero : F 0 = 0) (K : Set Space) (hK : IsCompact K)
    (hsupp : ∀ t, tsupport (F t : Space → ℂ) ⊆ K) : Tendsto F (𝓝 0) (𝓝 0) := by
  rw [(schwartz_withSeminorms ℝ Space ℂ).tendsto_nhds]
  rintro ⟨k,n⟩ ε hε
  simp only [sub_zero]
  let W (w : ℝ × Space) := ‖w.2‖^k * ‖iteratedFDeriv ℝ n (F w.1 : Space → ℂ) w.2‖
  have hW : Continuous W := (continuous_snd.norm.pow k).mul
    (continuous_slice_derivative (fun w : ℝ × Space => F w.1 w.2) hf n).norm
  have hopen : IsOpen {w | W w < ε/2} := isOpen_lt hW continuous_const
  have hsub : ({0} : Set ℝ) ×ˢ K ⊆ {w | W w < ε/2} := by
    rintro ⟨t,x⟩ ⟨ht,_⟩
    change t=0 at ht
    subst t
    change ‖x‖^k * ‖iteratedFDeriv ℝ n (F 0 : Space → ℂ) x‖ < ε/2
    simp [hzero,half_pos hε]
  obtain ⟨U,V,hU,_,h0,hV,hUV⟩ := generalized_tube_lemma isCompact_singleton hK hopen hsub
  filter_upwards [hU.mem_nhds (h0 (mem_singleton _))] with t ht
  apply lt_of_le_of_lt _ (half_lt_self hε)
  apply SchwartzMap.seminorm_le_bound ℝ k n (F t) (by positivity)
  intro x
  by_cases hx : x ∈ K
  · exact (hUV (show (t,x) ∈ U ×ˢ V from ⟨ht,hV hx⟩)).le
  · have houtside : x ∉ Function.support (iteratedFDeriv ℝ n (F t : Space → ℂ)) :=
      fun hm => hx (hsupp t (support_iteratedFDeriv_subset n hm))
    rw [Function.notMem_support.mp houtside, norm_zero, mul_zero]
    positivity
end
end LloydNDSchwartz
