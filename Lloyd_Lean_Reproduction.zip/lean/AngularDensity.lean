import Cosine
import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.Calculus.ParametricIntegral

open MeasureTheory Set Filter
open scoped RealInnerProductSpace SchwartzMap ENNReal Topology ContDiff
namespace LloydAngular
noncomputable section
open LloydCosine

/-- The signed angular density obtained by radial integration. -/
def radialize (f : E → ℝ) (w : E) : ℝ :=
  ∫ r in Ioi (0:ℝ), r^3 * f (r • w)

private lemma fiber (f : E → ℝ) (w : S) :
    ∫ t : Ray, t.val * f (t.val • w.val) ∂Measure.volumeIoiPow 2 =
    radialize f w.val := by
  unfold Measure.volumeIoiPow radialize
  rw [integral_withDensity_eq_integral_toReal_smul (by fun_prop) (by simp)]
  rw [← integral_subtype_comap (μ := (volume : Measure ℝ)) measurableSet_Ioi]
  apply integral_congr_ae
  filter_upwards [] with r
  have hn : 0 ≤ r.val^2 := sq_nonneg _
  simp only [ENNReal.toReal_ofReal hn,smul_eq_mul]
  ring

/-- General signed polar identity in dimension three. The actual absolute projection
of ambient volume, weighted by f, is the spherical cosine transform of its
radially integrated signed density. -/
theorem polar_signed (f : E → ℝ) (u : E)
    (hi : Integrable (fun x : E => |⟪u,x⟫| * f x)) :
    (∫ x:E, |⟪u,x⟫| * f x) = cosineTransform (fun w => radialize f w.val) u := by
  let e := homeomorphUnitSphereProd E
  let h := fun x:E => |⟪u,x⟫| * f x
  let g := fun p:S × Ray => h (e.symm p).val
  have rank : Module.finrank ℝ E - 1 = 2 := by simp [E]
  have hsub : Integrable (fun y : punctured => h y.val) (volume.comap Subtype.val) :=
    (integrableOn_iff_comap_subtypeVal (measurableSet_singleton _).compl).1 hi.integrableOn
  have hg : Integrable g ((volume : Measure E).toSphere.prod (Measure.volumeIoiPow 2)) := by
    rw [← rank]
    apply ((volume : Measure E).measurePreserving_homeomorphUnitSphereProd.integrable_comp_emb
      e.measurableEmbedding).mp
    change Integrable (fun y : punctured => h (e.symm (e y)).val) _
    simpa only [Homeomorph.symm_apply_apply] using hsub
  calc
    _ = ∫ y : punctured, h y.val ∂(volume.comap Subtype.val) := by
      rw [integral_subtype_comap (measurableSet_singleton _).compl, restrict_compl_singleton]
    _ = ∫ y : punctured, g (e y) ∂(volume.comap Subtype.val) := by simp [g]
    _ = ∫ p, g p ∂((volume:Measure E).toSphere.prod (Measure.volumeIoiPow 2)) := by
      simpa [rank] using
        (volume:Measure E).measurePreserving_homeomorphUnitSphereProd.integral_comp
          e.measurableEmbedding g
    _ = _ := by
      rw [integral_prod g hg]
      unfold cosineTransform
      apply integral_congr_ae
      filter_upwards [] with w
      rw [← fiber f w, ← integral_const_mul]
      apply integral_congr_ae
      filter_upwards [] with r
      have hr : 0 < r.val := r.2
      simp [g,e,h,real_inner_smul_right,abs_mul,abs_of_pos hr]
      ring

/-- Schwartz regularity discharges integrability of every signed projection, so the
bridge can be applied directly to an inverse Fourier transform in the real Schwartz space. -/
theorem schwartz_cosine (f : 𝓢(E,ℝ)) (u : E) :
    cosineTransform (fun w => radialize f w.val) u = ∫ x : E, |⟪u,x⟫| * f x := by
  symm
  apply polar_signed
  have hi := (f.integrable_pow_mul volume 1).const_mul ‖u‖
  apply hi.mono' (by fun_prop)
  filter_upwards [] with x
  simp only [norm_mul,Real.norm_eq_abs, abs_abs,pow_one]
  calc
    _ ≤ (‖u‖*‖x‖)*|f x| := by gcongr; exact abs_real_inner_le_norm _ _
    _ = _ := by ring

section Estimates
variable {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V] [CompleteSpace V]

/-- The radial moment as an operator on vector-valued Schwartz functions. -/
def moment (k : ℕ) (f : 𝓢(E,V)) (w : E) : V :=
  ∫ r in Ioi (0:ℝ), r^k • f (r • w)

def control (k : ℕ) (f : 𝓢(E,V)) : ℝ :=
  2^(k+2) * (2^(k+2) * (Finset.Iic (k+2,0)).sup (fun m => SchwartzMap.seminorm ℝ m.1 m.2) f)

omit [CompleteSpace V] in
/-- Explicit local integrable majorant for every derivative order and every Schwartz input.
The half-unit lower bound on |w| includes an open neighborhood of the sphere. -/
theorem moment_bound (k : ℕ) (f : 𝓢(E,V)) {w : E} (hw : 1/2 ≤ ‖w‖) {r : ℝ} (hr : 0 ≤ r) :
    ‖r^k • f (r • w)‖ ≤ control k f * (1+r^2)⁻¹ := by
  have hS := SchwartzMap.one_add_le_sup_seminorm_apply (𝕜 := ℝ) (m := (k+2,0))
    (k := k+2) (n := 0) le_rfl le_rfl f (r • w)
  rw [norm_iteratedFDeriv_zero] at hS
  have hnorm : ‖r • w‖ = r * ‖w‖ := by simp [norm_smul,Real.norm_eq_abs,abs_of_nonneg hr]
  have h1 : 1+r ≤ 2*(1+‖r • w‖) := by rw [hnorm]; nlinarith
  have h2 : r^k * (1+r^2) ≤ (1+r)^(k+2) := by
    rw [pow_add]
    gcongr
    · linarith
    · nlinarith
  rw [norm_smul,Real.norm_eq_abs,abs_of_nonneg (pow_nonneg hr _),←div_eq_mul_inv,
    le_div_iff₀ (show 0 < 1+r^2 by positivity)]
  calc
    _ = (r^k * (1+r^2)) * ‖f (r • w)‖ := by ring
    _ ≤ (1+r)^(k+2) * ‖f (r • w)‖ := by gcongr
    _ ≤ (2*(1+‖r • w‖))^(k+2) * ‖f (r • w)‖ := by gcongr
    _ = 2^(k+2) * ((1+‖r•w‖)^(k+2) * ‖f (r•w)‖) := by rw [mul_pow]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hS (by positivity)

omit [CompleteSpace V] in
lemma moment_integrable (k : ℕ) (f : 𝓢(E,V)) {w : E} (hw : 1/2 ≤ ‖w‖) :
    IntegrableOn (fun r : ℝ => r^k • f (r • w)) (Ioi (0:ℝ)) := by
  apply ((integrable_inv_one_add_sq.const_mul (control k f)).integrableOn).mono' (by fun_prop)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with r hr
  exact moment_bound k f hw (le_of_lt hr)

def away : Set E := {x | 1/2 < ‖x‖}
lemma away_open : IsOpen away := isOpen_lt continuous_const continuous_norm

omit [CompleteSpace V] in
/-- Differentiating a signed radial moment raises its radial order and differentiates
the Schwartz input, with the actual Bochner integral of continuous linear maps. -/
theorem moment_hasFDerivAt (k : ℕ) (f : 𝓢(E,V)) {w : E} (hw : w ∈ away) :
    HasFDerivAt (moment k f) (moment (k+1) (SchwartzMap.fderivCLM ℝ E V f) w) w := by
  let F := fun x : E => fun r : ℝ => r^k • f (r • x)
  let df := SchwartzMap.fderivCLM ℝ E V f
  let DF := fun x : E => fun r : ℝ => r^(k+1) • df (r • x)
  apply hasFDerivAt_integral_of_dominated_of_fderiv_le (μ := volume.restrict (Ioi (0:ℝ)))
    (F := F) (F' := DF) (s := away) (bound := fun r => control (k+1) df * (1+r^2)⁻¹)
    (away_open.mem_nhds hw)
  · exact Filter.Eventually.of_forall fun _ => by dsimp [F]; fun_prop
  · exact moment_integrable k f (le_of_lt hw)
  · dsimp [DF]; fun_prop
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with r hr
    exact fun x hx => moment_bound (k+1) df (le_of_lt hx) (le_of_lt hr)
  · exact (integrable_inv_one_add_sq.const_mul _).integrableOn
  · filter_upwards [] with r x _
    have hs : HasFDerivAt (fun x : E => r • x) (r • ContinuousLinearMap.id ℝ E) x := by
      convert! (hasFDerivAt_id x).const_smul r using 1
    have h := (((f.smooth 1).differentiable (by norm_num) (r • x)).hasFDerivAt.comp x hs).const_smul (r^k)
    convert! h using 1
    ext z
    simp [DF,df,SchwartzMap.fderivCLM_apply,pow_succ,smul_smul]

/-- Every finite order, and hence smoothness, follows from the same vector-valued recurrence. -/
theorem moment_contDiffOn_nat (n k : ℕ) (f : 𝓢(E,V)) :
    ContDiffOn ℝ n (moment k f) away := by
  induction n generalizing V k with
  | zero =>
    rw [Nat.cast_zero,contDiffOn_zero]
    exact fun w hw => (moment_hasFDerivAt k f hw).continuousAt.continuousWithinAt
  | succ n ih =>
    rw [Nat.cast_add_one,contDiffOn_succ_iff_fderiv_of_isOpen away_open]
    refine ⟨fun w hw => (moment_hasFDerivAt k f hw).differentiableAt.differentiableWithinAt,
      by simp, ?_⟩
    apply (ih (k+1) (SchwartzMap.fderivCLM ℝ E V f)).congr
    exact fun w hw => (moment_hasFDerivAt k f hw).fderiv

theorem moment_smooth (k : ℕ) (f : 𝓢(E,V)) : ContDiffOn ℝ ∞ (moment k f) away :=
  contDiffOn_infty.mpr (fun n => moment_contDiffOn_nat n k f)

omit [CompleteSpace V] in
theorem moment_norm (k : ℕ) (f : 𝓢(E,V)) {w : E} (hw : 1/2 ≤ ‖w‖) :
    ‖moment k f w‖ ≤ control k f * (Real.pi/2) := by
  unfold moment
  calc
    _ ≤ ∫ r in Ioi (0:ℝ), control k f * (1+r^2)⁻¹ := by
      apply norm_integral_le_of_norm_le ((integrable_inv_one_add_sq.const_mul _).integrableOn)
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with r hr
      exact moment_bound k f hw (le_of_lt hr)
    _ = _ := by rw [integral_const_mul,integral_Ioi_inv_one_add_sq]; simp

omit [CompleteSpace V] in
/-- Visible zero-, first-, and second-order control on one fixed neighborhood of S². -/
theorem moment_C2_bound (k : ℕ) (f : 𝓢(E,V)) {w : E} (hw : w ∈ away) :
    let df := SchwartzMap.fderivCLM ℝ E V f
    let ddf := SchwartzMap.fderivCLM ℝ E (E →L[ℝ] V) df
    ‖moment k f w‖ ≤ control k f * (Real.pi/2) ∧
    ‖fderiv ℝ (moment k f) w‖ ≤ control (k+1) df * (Real.pi/2) ∧
    ‖fderiv ℝ (fderiv ℝ (moment k f)) w‖ ≤ control (k+1+1) ddf * (Real.pi/2) := by
  let df := SchwartzMap.fderivCLM ℝ E V f
  have heq : fderiv ℝ (moment k f) =ᶠ[𝓝 w] moment (k+1) df :=
    eventually_of_mem (away_open.mem_nhds hw) (fun x hx => (moment_hasFDerivAt k f hx).fderiv)
  refine ⟨moment_norm k f (le_of_lt hw), ?_, ?_⟩
  · rw [(moment_hasFDerivAt k f hw).fderiv]
    exact moment_norm _ _ (le_of_lt hw)
  · rw [heq.fderiv_eq, (moment_hasFDerivAt (k+1) df hw).fderiv]
    exact moment_norm _ _ (le_of_lt hw)

theorem schwartz_radialize_smooth (f : 𝓢(E,ℝ)) : ContDiffOn ℝ ∞ (radialize f) away := by
  exact moment_smooth 3 f

omit [CompleteSpace V] in
theorem control_continuous (k : ℕ) : Continuous (control k : 𝓢(E,V) → ℝ) :=
  continuous_const.mul <| continuous_const.mul <| Seminorm.continuous_finsetSup
    (fun i _ => (schwartz_withSeminorms ℝ E V).continuous_seminorm i)

omit [CompleteSpace V] in
@[simp] lemma control_zero (k : ℕ) : control k (0 : 𝓢(E,V)) = 0 := by simp [control]

omit [CompleteSpace V] in
private theorem control_eventually_small {ι : Type*} {l : Filter ι} {a : ι → 𝓢(E,V)}
    (n : ℕ) (h : Tendsto a l (𝓝 0)) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ i in l, control n (a i) * (Real.pi/2) < ε := by
  have h' := (((control_continuous (V := V) n).tendsto 0).comp h).mul_const (Real.pi/2)
  have hz : Tendsto (fun i => control n (a i) * (Real.pi/2)) l (𝓝 0) := by
    simpa [control] using h'
  exact hz.eventually_lt_const hε

/-- Schwartz convergence to zero gives uniform C² convergence of the angular density
on a fixed open neighborhood of the entire unit sphere. -/
theorem eventually_C2_small {ι : Type*} {l : Filter ι} {f : ι → 𝓢(E,V)}
    (hf : Tendsto f l (𝓝 0)) (k : ℕ) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ i in l, ∀ w ∈ away, ‖moment k (f i) w‖ < ε ∧
      ‖fderiv ℝ (moment k (f i)) w‖ < ε ∧ ‖fderiv ℝ (fderiv ℝ (moment k (f i))) w‖ < ε := by
  let A := SchwartzMap.fderivCLM ℝ E V
  let B := SchwartzMap.fderivCLM ℝ E (E →L[ℝ] V)
  have ha : Tendsto (fun i => A (f i)) l (𝓝 0) := by simpa [Function.comp_def] using (A.continuous.tendsto 0).comp hf
  have hb : Tendsto (fun i => B (A (f i))) l (𝓝 0) := by simpa [Function.comp_def] using (B.continuous.tendsto 0).comp ha
  filter_upwards [control_eventually_small k hf hε,control_eventually_small (k+1) ha hε,
    control_eventually_small (k+1+1) hb hε] with i hi hj hk w hw
  obtain ⟨h0,h1,h2⟩ := moment_C2_bound k (f i) hw
  exact ⟨h0.trans_lt hi,h1.trans_lt hj,h2.trans_lt hk⟩

end Estimates

/-- The negative fourth degree of the angular extension is the change-of-variables
Jacobian together with the third radial moment. No regularity or integrability is required. -/
theorem radialize_homogeneous (f : E → ℝ) (w : E) {a : ℝ} (ha : 0 < a) :
    a^4 * radialize f (a • w) = radialize f w := by
  let g := fun r : ℝ => r^3 * f (r • w)
  have h := integral_comp_mul_right_Ioi' g 0 ha
  simp only [zero_mul,smul_eq_mul] at h
  change a^4 * (∫ r in Ioi (0:ℝ), r^3 * f (r • a • w)) = _
  calc
    _ = a * (∫ r in Ioi (0:ℝ), a^3 * (r^3 * f (r • a • w))) := by
      rw [integral_const_mul]; ring
    _ = a * ∫ r in Ioi (0:ℝ), g (r*a) := by
      congr 1
      apply integral_congr_ae
      filter_upwards [] with r
      simp [g,mul_pow,smul_smul]
      ring
    _ = _ := h

theorem radialize_even {f : E → ℝ} (hf : ∀ x, f (-x) = f x) (w : E) :
    radialize f (-w) = radialize f w := by simp [radialize,smul_neg,hf]

theorem sphere_radialize_continuous (f : 𝓢(E,ℝ)) :
    Continuous (fun w : S => radialize f w.val) := by
  apply (schwartz_radialize_smooth f).continuousOn.comp_continuous continuous_subtype_val
  intro w
  change 1/2 < ‖w.val‖
  have h : ‖w.val‖ = 1 := by simp
  rw [h]; norm_num

#print axioms polar_signed
#print axioms schwartz_cosine
#print axioms moment_bound
#print axioms moment_hasFDerivAt
#print axioms schwartz_radialize_smooth
#print axioms moment_C2_bound
#print axioms eventually_C2_small
#print axioms sphere_radialize_continuous
#print axioms radialize_homogeneous
end
end LloydAngular
