import NDMain
import NDGaussBalanced

noncomputable section
open MeasureTheory Filter Set Topology TopologicalSpace
open scoped RealInnerProductSpace
namespace LloydNDMain
open LloydNDFrame LloydNDLimits LloydNDModels

/-- Along the trajectory from the stated initialization, the barycentres of all
optimal 1/2--1/2 couplings are exactly the ordinary next Lloyd sites. -/
def BalancedOrbit {d:ℕ} (μ : Measure (E d)) (y:E d) : Prop :=
  ∀ n p, IsBalancedStep μ (trajectory μ y n).1 p ↔ p = trajectory μ y (n+1)

theorem axis_eq_iff {d:ℕ} (x y:E d) : axis x = axis y ↔ x=y ∨ x = -y := by
  constructor
  · intro h
    have hm : x∈ (axis x:Set _) := by simp [axis,LloydProduct.unordered]
    rw [h] at hm
    simpa only [axis,LloydProduct.unordered,NonemptyCompacts.coe_sup,NonemptyCompacts.coe_singleton,
      mem_union,mem_singleton_iff] using hm
  · rintro (rfl|rfl)
    · rfl
    · simp [axis,LloydProduct.unordered,sup_comm]

/-- The geometric indexing of the exact limits has exactly the projective
identification, including in higher dimensions. -/
theorem equatorial_axis_eq_iff {d:ℕ} {c:ℝ} (hc:0<c) (v w:E d) :
    axis (c • equator v) = axis (c • equator w) ↔ v=w ∨ v= -w := by
  rw [axis_eq_iff]
  have inj : Function.Injective (fun x : E d=>c • equator x) := by
    intro a b h
    have h' := congrArg (fun x : E (d+1)=> tailL (c⁻¹ • x)) h
    simpa [smul_smul,hc.ne',equator] using h'
  have neg (x:E d) : c • equator (-x) = -(c • equator x) := by
    change c • equatorL (-x) = -(c • equatorL x)
    rw [map_neg,smul_neg]
  rw [← neg]
  exact or_congr inj.eq_iff inj.eq_iff

private theorem nonzero_seed {d:ℕ} {μ : Measure (E (d+1))} {y:E (d+1)}
    (hm:(∫ x:E (d+1), x ∂μ)=0) (h : ProjectiveOrbit μ y) : y≠0 := by
  rintro rfl
  obtain ⟨c,hc,_,_,hd⟩ := h
  have hz : LloydProduct.step μ (0,0) = (0,0) := by
    simp [LloydProduct.step,LloydProduct.center,hm]
  refine hd ⟨LloydProduct.unordered (0,0),?_⟩
  apply tendsto_const_nhds.congr
  intro n
  rw [trajectory,neg_zero,(show Function.IsFixedPt (LloydProduct.step μ) (0,0) from hz).iterate n]

/-- All three sources simultaneously have the full equatorial cluster set,
including when the equal-mass Lloyd solver is allowed to select any optimal plan. -/
theorem projective_equator_all_solvers (k m:ℕ) (ε:ℝ) (hε:0<ε) :
    ∃ (K : Set (E (k+3))) (ρ σ : E (k+3) → ℝ) (y : E (k+3)),
      JointExample m ε K ρ σ y ∧ BalancedOrbit (uniformOn K) y ∧
      BalancedOrbit (LloydNDGaussian.law ρ) y ∧ BalancedOrbit (LloydNDGaussian.law σ) y := by
  obtain ⟨K,ρ,σ,y,H⟩ := projective_equator_counterexample k m ε hε
  have hy := nonzero_seed H.gaussian.centered H.gaussian_orbit
  refine ⟨K,ρ,σ,y,H,fun n => (H.uniform.2.2.2.2.2.2.2.2.2 n).2.2,?_,?_⟩
  · exact balanced_of_even_law H.gaussian.even H.gaussian_probability H.gaussian.variance hy
  · exact balanced_of_even_law H.compact_density.even H.compact_probability H.compact_density.variance hy

#print axioms projective_equator_all_solvers
#print axioms equatorial_axis_eq_iff
end LloydNDMain
