import NDLimitsOrbit
import NDLimitsBalancedUpdate
import Mathlib.Analysis.Convex.Integral

/-! A volume-source Lloyd orbit with strictly positive separation may be initialized
and kept inside the interior of the convex sampling body. -/
open Set Filter MeasureTheory MeasureTheory.Measure
open scoped Topology RealInnerProductSpace
noncomputable section
namespace LloydNDLimits
variable {m : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin (m+1))

theorem interior_neg_mem {K : Set E} (h : ∀ x:E, -x∈K ↔ x∈K)
    {x : E} (hx : x∈interior K) : -x ∈ interior K := by
  let T := (fun y:E => -y) ⁻¹' interior K
  have ho : IsOpen T := isOpen_interior.preimage continuous_neg
  have hs : T ⊆ K := fun y hy => (h y).mp (interior_subset hy)
  exact interior_maximal hs ho (by simpa [T] using hx : -x∈T)

/-- Strict Jensen has only one exceptional case, a constant random vector.
The folded source cannot be a.e. constant for a positive-volume source,
because each point has at most two preimages. -/
theorem signedMoment_interior {K : Set E} (hk : IsCompact K) (hp : volume K ≠ 0)
    (hs : StrictConvex ℝ K) (hn : ∀ x:E, -x∈K ↔ x∈K) (u : E) :
    signedMoment (uniformOn K) u ∈ interior K := by
  let μ := uniformOn K
  let _ : IsProbabilityMeasure μ := uniform_probability K hk hp
  have hac : μ ≪ volume := ProbabilityTheory.cond_absolutelyContinuous
  have hkμ : ∀ᵐ x ∂μ, x∈K := ae_mono' smul_absolutelyContinuous (ae_restrict_mem hk.measurableSet)
  have hfold : ∀ᵐ x ∂μ, signedPoint u x ∈ K := by
    filter_upwards [hkμ] with x hx
    unfold signedPoint
    split_ifs <;> first | exact hx | exact (hn x).mpr hx
  have hv := hs.ae_eq_const_or_average_mem_interior hk.isClosed hfold
    (signedPoint_integrable μ u (uniform_id_integrable K hk hp))
  rw [average_eq_integral] at hv
  rcases hv with heq | hinside
  · let y := signedMoment μ u
    have hpos : ∀ᵐ x ∂μ, x ≠ y := ae_mono' hac (volume.ae_ne y)
    have hneg : ∀ᵐ x ∂μ, x ≠ -y := ae_mono' hac (volume.ae_ne (-y))
    obtain ⟨x,hx,hnp,hnn⟩ := (heq.and (hpos.and hneg)).exists
    change signedPoint u x = y at hx
    by_cases hsg : 0 < inner ℝ x u
    · exact (hnp (by simpa [signedPoint,hsg] using hx)).elim
    · have hny : -x=y := by simpa [signedPoint,hsg] using hx
      exact (hnn ((neg_eq_iff_eq_neg).mp hny)).elim
  · exact hinside

theorem closedBall_interior_start {K : Set E} {R r : ℝ}
    (hb : Metric.closedBall (0:E) R ⊆ K) (hr : 0<r) (hrR : r<R) {u:E} (hu : ‖u‖=1) :
    r • u ∈ interior K ∧ -(r • u) ∈ interior K := by
  have hi : Metric.ball (0:E) R ⊆ interior K :=
    interior_maximal (Metric.ball_subset_closedBall.trans hb) Metric.isOpen_ball
  constructor <;> apply hi <;>
    simpa [Metric.mem_ball,dist_zero_right, norm_smul,Real.norm_eq_abs,abs_of_pos hr,hu] using hrR

/-- Any nonzero interior antipodal start remains nonzero, interior and antipodal
at every iteration, regardless of the angular recurrence. -/
theorem all_antipodal_sites_interior {K : Set E} (hk : IsCompact K) (hp : volume K ≠ 0)
    (hs : StrictConvex ℝ K) (hn : ∀ x:E, -x∈K ↔ x∈K)
    {y : E} (hy : y≠0) (hyin : y ∈ interior K) (n : ℕ) :
    ∃ v:E, v≠0 ∧ v ∈ interior K ∧ -v ∈ interior K ∧
      (LloydProduct.step (uniformOn K))^[n] (y,-y) = (v,-v) := by
  let μ := uniformOn K
  let _ : IsProbabilityMeasure μ := uniform_probability K hk hp
  induction n with
  | zero => exact ⟨y,hy,hyin,interior_neg_mem hn hyin,rfl⟩
  | succ n ih =>
    obtain ⟨v,hv,_,_,he⟩ := ih
    let m := signedMoment μ v
    have hmem : m ∈ interior K := signedMoment_interior hk hp hs hn v
    have hne : m ≠ 0 := by
      intro h0
      have h := inner_signedMoment μ v (uniform_id_integrable K hk hp)
      change inner ℝ v m = _ at h
      rw [h0,inner_zero_right] at h
      exact (populationSupport_pos μ v (uniform_no_ties K v hv) (uniform_id_integrable K hk hp)).ne' h.symm
    refine ⟨m,hne,hmem,interior_neg_mem hn hmem,?_⟩
    rw [Function.iterate_succ_apply',he]
    simpa [LloydProduct.step,LloydProduct.center,update,nearestMinus,nearestPlus,cellCentroid] using!
      (uniform_update K hk hp hn v hv (r:=1) zero_lt_one).2.2

/-- Once initialized inside, any half-capacity optimizer takes the same two sites as the ordinary update. -/
theorem uniform_orbit_interior_balanced {K : Set E} (hk : IsCompact K) (hp : volume K ≠ 0)
    (hs : StrictConvex ℝ K) (hn : ∀ x:E, -x∈K ↔ x∈K)
    {y : E} (hy : y≠0) (hyin : y ∈ interior K) (n : ℕ) :
    let Y := (LloydProduct.step (uniformOn K))^[n] (y,-y)
    Y.1 ∈ interior K ∧ Y.2 ∈ interior K ∧ ∀ p,
      IsBalancedStep (uniformOn K) Y.1 p ↔ p = LloydProduct.step (uniformOn K) Y := by
  obtain ⟨v,hv,hin,hneg,he⟩ := all_antipodal_sites_interior hk hp hs hn hy hyin n
  dsimp only
  rw [he]
  exact ⟨hin,hneg,uniform_balanced_step_iff K hk hp hn v hv⟩

#print axioms uniform_orbit_interior_balanced
end LloydNDLimits
