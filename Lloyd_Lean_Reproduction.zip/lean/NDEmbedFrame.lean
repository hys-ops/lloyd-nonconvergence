import NDFrame
import GlobalFamily
import NDPrescribe
open scoped RealInnerProductSpace ContDiff
noncomputable section
namespace LloydNDEmbed
open LloydNDFrame (E)
def extend : (k : ℕ) → E 3 →L[ℝ] E (k+3)
  | 0 => ContinuousLinearMap.id ℝ _
  | k+1 => LloydNDFrame.packL.comp ((0 : E 3 →L[ℝ] ℝ).prod (extend k))
def proj : (k : ℕ) → E (k+3) →L[ℝ] E 3
  | 0 => ContinuousLinearMap.id ℝ _
  | k+1 => (proj k).comp LloydNDFrame.tailL
@[simp] theorem proj_extend (k : ℕ) (u : E 3) : proj k (extend k u) = u := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change proj k (LloydNDFrame.tail (LloydNDFrame.pack 0 (extend k u))) = u
    exact ih
theorem inner_extend (k : ℕ) (u : E 3) (x : E (k+3)) : ⟪extend k u,x⟫ = ⟪u,proj k x⟫ := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change ⟪LloydNDFrame.pack 0 (extend k u),x⟫ = ⟪u,proj k (LloydNDFrame.tail x)⟫
    conv_lhs => rhs; rw [←LloydNDFrame.pack_head_tail x]
    rw [LloydNDFrame.inner_pack,zero_mul,zero_add,ih]
@[simp] theorem norm_extend (k : ℕ) (u : E 3) : ‖extend k u‖=‖u‖ := by
  have h := inner_extend k u (extend k u)
  rw [proj_extend,real_inner_self_eq_norm_sq,real_inner_self_eq_norm_sq] at h
  nlinarith [norm_nonneg u,norm_nonneg (extend k u)]

/-- The tangent vector of the original scalar potential equals the tangent
kick determined by the discrete map. -/
theorem mapped_kick {f : E 3 → ℝ} {u : E 3} (hu : ‖u‖=1) :
    let v := LloydGlobal.mapping f u
    0 < ⟪u,v⟫ ∧ LloydNDSpiral.kick u v = LloydAmbient.tangentGradient f u := by
  let g := LloydAmbient.tangentGradient f u
  have ht : ⟪u,g⟫=0 := by
    simp only [g,LloydAmbient.tangentGradient,inner_sub_right,real_inner_smul_right,
      real_inner_self_eq_norm_sq,hu,one_pow,mul_one,real_inner_comm u (gradient f u),sub_self]
  have hi : ⟪u,u+g⟫=1 := by rw [inner_add_right,ht,real_inner_self_eq_norm_sq,hu]; norm_num
  have hn : 0 < ‖u+g‖ := norm_pos_iff.mpr fun h => by simpa [h] using hi
  change 0 < ⟪u,‖u+g‖⁻¹ • (u+g)⟫ ∧ LloydNDSpiral.kick u (‖u+g‖⁻¹ • (u+g)) = g
  simp only [real_inner_smul_right,hi,mul_one,LloydNDSpiral.kick,inv_inv,smul_smul,
    mul_inv_cancel₀ hn.ne',one_smul]
  exact ⟨inv_pos.mpr hn,by abel⟩

theorem extend_jet {k : ℕ} {f : E 3 → ℝ} {u v : E 3} (hu : ‖u‖=1)
    (hv : LloydGlobal.mapping f u=v) (hf : DifferentiableAt ℝ f u) :
    0 < ⟪extend k u, extend k v⟫ ∧ ∀ w : E (k+3), ⟪extend k u,w⟫=0 →
      fderiv ℝ (f ∘ proj k) (extend k u) w = ⟪LloydNDSpiral.kick (extend k u) (extend k v),w⟫ := by
  obtain ⟨hpos,hg⟩ := mapped_kick (f:=f) hu
  change 0 < ⟪u,LloydGlobal.mapping f u⟫ at hpos
  change LloydNDSpiral.kick u (LloydGlobal.mapping f u) = _ at hg
  rw [hv] at hpos hg
  have he : ⟪extend k u,extend k v⟫ = ⟪u,v⟫ := by simp only [inner_extend,proj_extend]
  refine ⟨he ▸ hpos,?_⟩
  intro w hw
  have ht := (inner_extend k u w).symm.trans hw
  have hk : LloydNDSpiral.kick (extend k u) (extend k v) = extend k (LloydAmbient.tangentGradient f u) := by
    rw [←hg]
    simp only [LloydNDSpiral.kick,he,map_sub,map_smul]
  have dif := fderiv_comp (extend k u) (by simpa only [proj_extend] using hf : DifferentiableAt ℝ f (proj k (extend k u))) (proj k).differentiableAt
  rw [dif,ContinuousLinearMap.comp_apply,ContinuousLinearMap.fderiv,proj_extend,hk,inner_extend,
    LloydAmbient.tangentGradient,inner_sub_left,real_inner_smul_left,ht,mul_zero,sub_zero]
  exact InnerProductSpace.toDual_symm_apply.symm
end LloydNDEmbed
