import NDLimitsCentroid
import SupportDerivative
noncomputable section
open MeasureTheory Filter
open scoped RealInnerProductSpace Topology
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)
/-- The homogeneous population support on the given Euclidean source. -/
def populationSupport (μ : Measure E) (u : E) : ℝ :=
  ∫ x, |⟪x, u⟫| ∂μ

/-- The derivative and the Voronoi-cell computation give the same vector. -/
theorem signedMoment_hasGradientAt (μ : Measure E) (u : E)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : E → E) μ) :
    HasGradientAt (populationSupport μ) (signedMoment μ u) u := by
  have h : ∀ᵐ x ∂μ, ⟪u, id x⟫ ≠ 0 := by
    apply ae_iff.mpr
    simpa only [id_eq, real_inner_comm u _, not_not] using ht
  have hg := LloydCentroid.hasGradientAt_absProjectionIntegral hi h
  have hfun : populationSupport μ = (fun v => ∫ x : E, |⟪v, x⟫| ∂μ) := by
    funext v
    simp only [populationSupport, real_inner_comm v _]
  rw [hfun]
  simpa only [signedMoment, signedPoint, id_eq, real_inner_comm u _] using hg

open scoped Gradient in
/-- The ordinary Lloyd update equals the two signed gradients of the same scalar support. -/
theorem update_eq_supportGradient (μ : Measure E) [IsProbabilityMeasure μ]
    (u : E) {r : ℝ} (hr : 0 < r)
    (hμ : MeasurePreserving (fun x : E => -x) μ μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : E → E) μ) :
    update μ (r • u) = (∇ (populationSupport μ) u, -∇ (populationSupport μ) u) := by
  rw [(signedMoment_hasGradientAt μ u ht hi).gradient]
  exact (reflection_update μ u hr hμ ht hi).2.2

/-- Euler's radial identity, including at directions where ties have positive mass. -/
theorem inner_signedMoment (μ : Measure E) (u : E)
    (hi : Integrable (id : E → E) μ) :
    ⟪u, signedMoment μ u⟫ = populationSupport μ u := by
  classical
  have hs : Integrable (signedPoint u) μ := by
    have heq : signedPoint u = (positive u).piecewise id (-id) := by
      funext x
      by_cases h : 0 < ⟪x,u⟫ <;> simp [positive, Set.piecewise, signedPoint, h]
    rw [heq]
    exact Integrable.piecewise (positive_meas u) hi.integrableOn hi.neg.integrableOn
  change innerSL ℝ u (∫ x, signedPoint u x ∂μ) = _
  rw [← (innerSL ℝ u).integral_comp_comm hs]
  apply integral_congr_ae
  filter_upwards [] with x
  by_cases h : 0 < ⟪x,u⟫
  · simp only [signedPoint, h, ite_true, innerSL_apply_apply, abs_of_pos h]
    exact real_inner_comm _ _
  · simp only [signedPoint, h, ite_false, innerSL_apply_apply, inner_neg_right,
      abs_of_nonpos (le_of_not_gt h)]
    rw [real_inner_comm u x]

/-- The support is positive under the null-tie condition for a probability source. -/
theorem populationSupport_pos (μ : Measure E) [IsProbabilityMeasure μ]
    (u : E) (ht : μ {x | ⟪x,u⟫ = 0} = 0)
    (hi : Integrable (id : E → E) μ) : 0 < populationSupport μ u := by
  have hpi : Integrable (fun x : E => |⟪x,u⟫|) μ := by
    simpa only [Real.norm_eq_abs, id_eq, innerSL_apply_apply, real_inner_comm u _] using
      ((innerSL ℝ u).integrable_comp hi).norm
  apply (integral_pos_iff_support_of_nonneg (fun x => abs_nonneg ⟪x,u⟫) hpi).2
  have hs : Function.support (fun x : E => |⟪x,u⟫|) = {x | ⟪x,u⟫ = 0}ᶜ := by
    ext x
    simp [Function.support]
  rw [hs, (prob_compl_eq_one_iff₀ (.of_null ht)).2 ht]
  exact zero_lt_one

/-- Tangent logarithmic gradient on the unit sphere, represented in ambient coordinates. -/
def tangentLogSupport (μ : Measure E) (u : E) : E :=
  (populationSupport μ u)⁻¹ • signedMoment μ u - u

theorem tangentLogSupport_spec (μ : Measure E) [IsProbabilityMeasure μ]
    (u : E) (hu : ‖u‖ = 1) (ht : μ {x | ⟪x,u⟫ = 0} = 0)
    (hi : Integrable (id : E → E) μ) :
    ⟪u, tangentLogSupport μ u⟫ = 0 ∧
    ∀ w : E, ⟪u,w⟫ = 0 →
      fderiv ℝ (fun v => Real.log (populationSupport μ v)) u w = ⟪tangentLogSupport μ u, w⟫ := by
  have hne := (populationSupport_pos μ u ht hi).ne'
  constructor
  · simp [tangentLogSupport, inner_sub_right, real_inner_smul_right, inner_signedMoment μ u hi, hu, hne]
  · intro w hw
    rw [((signedMoment_hasGradientAt μ u ht hi).hasFDerivAt.log hne).fderiv]
    simp [tangentLogSupport, inner_sub_left, real_inner_smul_left, hw, InnerProductSpace.toDual_apply_apply]

/-- The positive centroid is the scalar support times the normal plus tangent correction. -/
theorem update_pos_sphere (μ : Measure E) [IsProbabilityMeasure μ]
    (u : E) {r : ℝ} (hr : 0 < r)
    (hμ : MeasurePreserving (fun x : E => -x) μ μ)
    (ht : μ {x | ⟪x,u⟫ = 0} = 0) (hi : Integrable (id : E → E) μ) :
    (update μ (r • u)).1 = populationSupport μ u • (u + tangentLogSupport μ u) := by
  rw [(reflection_update μ u hr hμ ht hi).2.2]
  simp [tangentLogSupport, smul_smul, (populationSupport_pos μ u ht hi).ne']

#print axioms inner_signedMoment
#print axioms populationSupport_pos
#print axioms tangentLogSupport_spec
#print axioms update_pos_sphere
#print axioms signedMoment_hasGradientAt
#print axioms update_eq_supportGradient

end LloydNDLimits
