import Mathlib.Analysis.Fourier.FourierTransform
import Mathlib.Analysis.Distribution.SchwartzSpace.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.Normed.Lp.MeasurableSpace
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic

open MeasureTheory Set Filter
open scoped RealInnerProductSpace FourierTransform SchwartzMap
noncomputable section
namespace LloydFourierMoment

def kernel (s t : ℝ) : ℝ := (1-Real.cos (2*Real.pi*(t*s)))/t^2
def normalizer : ℝ := ∫ t:ℝ,kernel 1 t

theorem kernel_nonneg (s t : ℝ) : 0≤kernel s t :=
  div_nonneg (sub_nonneg.mpr (Real.cos_le_one _)) (sq_nonneg _)

lemma trig_identity (v : ℝ) : 1-Real.cos (2*v)=2*(Real.sin v)^2 := by
  rw [Real.cos_two_mul]
  nlinarith [Real.sin_sq_add_cos_sq v]

theorem base_integrable : Integrable (kernel 1) := by
  have hi := integrable_inv_one_add_sq.const_mul (2*Real.pi^2+2)
  apply hi.mono' (by apply Measurable.aestronglyMeasurable; unfold kernel; measurability)
  apply Eventually.of_forall
  intro t
  rw [Real.norm_eq_abs,abs_of_nonneg (kernel_nonneg _ _)]
  rw [←div_eq_mul_inv,le_div_iff₀ (by positivity)]
  by_cases ht:t=0
  · subst t; simp [kernel];positivity
  have eqn : kernel 1 t*t^2=1-Real.cos (2*(Real.pi*t)) := by
    unfold kernel;rw [div_mul_cancel₀ _ (pow_ne_zero _ ht),mul_one,mul_assoc]
  have hsmall : kernel 1 t ≤2*Real.pi^2 := by
    apply (mul_le_mul_iff_left₀ (sq_pos_of_ne_zero ht)).mp
    rw [eqn,trig_identity]
    nlinarith only [Real.sin_sq_le_sq (x:=Real.pi*t)]
  nlinarith only [eqn,hsmall,Real.neg_one_le_cos (2*(Real.pi*t))]

theorem normalizer_pos : 0<normalizer := by
  apply (integral_pos_iff_support_of_nonneg (fun x =>kernel_nonneg 1 x) base_integrable).mpr
  have hpos : 0<volume (Set.Ioo (0:ℝ) 1) := by simp
  apply hpos.trans_le (measure_mono ?_)
  intro t ht
  change kernel 1 t≠0
  have hpi : Real.pi*t<Real.pi := by nlinarith [mul_pos Real.pi_pos (sub_pos.mpr ht.2)]
  have hs := Real.sin_pos_of_pos_of_lt_pi (mul_pos Real.pi_pos ht.1) hpi
  unfold kernel;rw [mul_one,mul_assoc,trig_identity]
  exact (div_pos (by positivity) (sq_pos_of_pos ht.1)).ne'

lemma kernel_rescale (s t : ℝ) : kernel s t=s^2*kernel 1 (s*t) := by
  by_cases hs:s=0
  · subst s;simp [kernel]
  by_cases ht:t=0
  · subst t;simp [kernel]
  unfold kernel
  rw [mul_one,mul_comm t s]
  field_simp

theorem kernel_integrable (s : ℝ) : Integrable (kernel s) := by
  by_cases hs:s=0
  · subst s;rw [show kernel 0 = (0 : ℝ→ℝ) from funext (fun t=>by simp [kernel])]
    exact integrable_zero ℝ ℝ volume
  rw [show kernel s=(fun t:ℝ => s^2*kernel 1 (s*t)) from funext (kernel_rescale s)]
  exact ((integrable_comp_mul_left_iff _ hs).mpr base_integrable).const_mul (s^2)

theorem kernel_integral (s : ℝ) : (∫ t:ℝ,kernel s t)=|s| *normalizer := by
  simp_rw [kernel_rescale s]
  rw [integral_const_mul,Measure.integral_comp_mul_left]
  by_cases hs:s=0
  · subst s;simp
  simp only [smul_eq_mul,abs_inv,normalizer]
  rw [show s^2=(|s|)^2 by rw [sq_abs]]
  field_simp [abs_ne_zero.mpr hs]


theorem kernel_fubini {X : Type*} [MeasurableSpace X] (μ : Measure X) [SFinite μ]
    (f u : X→ℝ) (hf : Measurable f) (hu : Measurable u)
    (hm : Integrable (fun x=> |u x| * |f x|) μ) :
    (∫ x, |u x| * f x ∂μ)*normalizer =
       ∫ t:ℝ, ∫ x,kernel (u x) t*f x ∂μ := by
  let F := fun x t => kernel (u x) t * f x
  have hmeas : Measurable (Function.uncurry F) := by
    dsimp [Function.uncurry,F,kernel]; measurability
  have intnorm (x) : (∫ t:ℝ,‖F x t‖) = (|u x| * |f x|)*normalizer := by
    simp only [F,Real.norm_eq_abs,abs_mul,abs_of_nonneg (kernel_nonneg _ _),
      integral_mul_const,kernel_integral];ring
  have hprod : Integrable (Function.uncurry F) (μ.prod volume) := by
    apply (integrable_prod_iff hmeas.aestronglyMeasurable).mpr
    constructor
    · exact Eventually.of_forall (fun x=>(kernel_integrable (u x)).mul_const (f x))
    · change Integrable (fun x=>∫ t:ℝ,‖F x t‖) μ
      simp only [intnorm]
      exact hm.mul_const normalizer
  rw [←integral_integral_swap hprod]
  simp only [F,integral_mul_const,kernel_integral]
  rw [←integral_mul_const]
  apply integral_congr_ae;filter_upwards [] with x;ring

abbrev E := EuclideanSpace ℝ (Fin 3)

lemma cos_integrable (f : E→ℝ) (u : E) (t : ℝ) (hf : Integrable f) :
    Integrable (fun x => Real.cos (2*Real.pi*(t*⟪x,u⟫))*f x) := by
  apply hf.norm.mono' ((by fun_prop : Continuous (fun x:E=>Real.cos (2*Real.pi*(t*⟪x,u⟫)))).aestronglyMeasurable.mul hf.aestronglyMeasurable)
  filter_upwards [] with x
  change ‖Real.cos (2*Real.pi*(t*⟪x,u⟫))*f x‖≤‖f x‖
  rw [norm_mul,Real.norm_eq_abs]
  exact mul_le_of_le_one_left (abs_nonneg _) (abs_le.mpr ⟨Real.neg_one_le_cos _,Real.cos_le_one _⟩)

lemma real_fourier_line (f : E→ℝ) (u : E) (t : ℝ) (hf : Integrable f) :
    (𝓕 (fun x=>(f x:ℂ)) (t • u)).re =
      ∫ x,Real.cos (2*Real.pi*(t*⟪x,u⟫))*f x := by
  let H := fun x:E => Complex.exp ((↑(-2*Real.pi*⟪x,t • u⟫) :ℂ)*Complex.I) • (f x:ℂ)
  have hh : Integrable H := by
    apply hf.norm.mono'
    · exact (by fun_prop : Continuous (fun x:E => Complex.exp ((↑(-2*Real.pi*⟪x,t • u⟫):ℂ)*Complex.I))).aestronglyMeasurable.smul
        (Complex.continuous_ofReal.comp_aestronglyMeasurable hf.aestronglyMeasurable)
    · filter_upwards [] with x
      change ‖Complex.exp ((↑(-2*Real.pi*⟪x,t • u⟫):ℂ)*Complex.I) • (f x:ℂ)‖ ≤ ‖f x‖
      rw [norm_smul,Complex.norm_exp_ofReal_mul_I,one_mul,Complex.norm_real]
  rw [Real.fourier_eq']
  change RCLike.re (∫ x,H x) = _
  rw [←integral_re hh]
  apply integral_congr_ae
  filter_upwards [] with x
  change (Complex.exp ((↑(-2*Real.pi*⟪x,t • u⟫):ℂ)*Complex.I)*(f x:ℂ)).re=_
  simp only [Complex.mul_re, Complex.exp_ofReal_mul_I_re, Complex.ofReal_re,Complex.ofReal_im,
    mul_zero,sub_zero,real_inner_smul_right]
  rw [show -2*Real.pi*(t*⟪x,u⟫)= -(2*Real.pi*(t*⟪x,u⟫)) by ring,Real.cos_neg]

theorem fourier_line_moment (f : E→ℝ) (u : E) (hf : Measurable f) (hfi : Integrable f)
    (hm : Integrable (fun x=>|⟪x,u⟫| * |f x|)) :
    (∫ x,|⟪x,u⟫| * f x)*normalizer =
       ∫ t:ℝ, ((𝓕 (fun x=>(f x:ℂ)) 0).re -
          (𝓕 (fun x=>(f x:ℂ)) (t • u)).re)/t^2 := by
  have H := kernel_fubini volume f (fun x=>⟪x,u⟫) hf ((continuous_id.inner continuous_const).measurable) hm
  rw [H]
  apply integral_congr_ae
  filter_upwards [] with t
  have zero := real_fourier_line f u 0 hfi
  simp only [zero_smul,zero_mul,mul_zero,Real.cos_zero,one_mul] at zero
  rw [zero,real_fourier_line f u t hfi,←integral_sub hfi (cos_integrable f u t hfi),
    ←integral_div]
  apply integral_congr_ae
  filter_upwards [] with x
  dsimp [kernel];ring


theorem schwartz_line_moment (f : 𝓢(E,ℝ)) (u : E) :
    (∫ x, |⟪x,u⟫| * f x)*normalizer =
      ∫ t:ℝ, ((𝓕 (fun x=>(f x:ℂ)) 0).re -
          (𝓕 (fun x=>(f x:ℂ)) (t • u)).re)/t^2 := by
  apply fourier_line_moment f u f.continuous.measurable f.integrable
  have hm : Integrable (fun x:E=>‖x‖ * |f x|) := by
    simpa only [pow_one,Real.norm_eq_abs] using f.integrable_pow_mul volume 1
  apply (hm.const_mul ‖u‖).mono' (by apply Measurable.aestronglyMeasurable;fun_prop)
  filter_upwards [] with x
  change ‖|⟪x,u⟫| * |f x|‖≤ ‖u‖*(‖x‖ * |f x|)
  rw [Real.norm_eq_abs,abs_of_nonneg (mul_nonneg (abs_nonneg _) (abs_nonneg _))]
  calc
    _ ≤ (‖x‖*‖u‖)* |f x| := mul_le_mul_of_nonneg_right (abs_real_inner_le_norm _ _) (abs_nonneg _)
    _ = _ := by ring

#print axioms normalizer_pos
#print axioms kernel_integral
#print axioms kernel_fubini
#print axioms fourier_line_moment
#print axioms schwartz_line_moment
end LloydFourierMoment
