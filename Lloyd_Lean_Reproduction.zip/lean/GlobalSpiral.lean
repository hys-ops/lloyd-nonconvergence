import AmbientSpiral
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
import Mathlib.Analysis.Calculus.TangentCone.Real

/-! Compactly supported cutoff in latitude followed by central symmetrization. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LloydGlobal
open LloydSpiral.Chart LloydLocal LloydAmbient

def band : Set ℝ := Ioo (-(1/4)) (1/4)
def cap : Set ℝ := Ioo 0 (1/5)
def cutoff : ContDiffBump (0 : ℝ) := ⟨1/5,9/40,by norm_num,by norm_num⟩

def cut (f : ℝ → ℝ) (z : ℝ) := cutoff z * f z

theorem cut_smooth {f : ℝ → ℝ} (hf : ∀ z ∈ band, ContDiffAt ℝ ∞ f z) :
    ContDiff ℝ ∞ (cut f) := by
  apply contDiff_iff_contDiffAt.mpr
  intro z
  by_cases hz : z ∈ band
  · exact cutoff.contDiffAt.mul (hf z hz)
  · have h : 9/40 < |z| := by
      simp only [band,mem_Ioo,not_and_or,not_lt] at hz
      rcases hz with hz|hz
      · rw [abs_of_neg (by linarith : z<0)]; linarith
      · rw [abs_of_pos (by linarith : 0<z)]; linarith
    have he : cut f =ᶠ[𝓝 z] fun _ => 0 := by
      filter_upwards [continuous_abs.continuousAt.preimage_mem_nhds (Ioi_mem_nhds h)] with a ha
      have hzero : cutoff a = 0 := cutoff.zero_of_le_dist (by
        change 9/40 ≤ dist a 0; simpa [Real.dist_eq] using (show 9/40 < |a| from ha).le)
      simp [cut,hzero]
    exact contDiffAt_const.congr_of_eventuallyEq he

theorem cutoff_cap {z : ℝ} (hz : z ∈ cap) : cutoff z = 1 := by
  apply cutoff.one_of_mem_closedBall
  rw [Metric.mem_closedBall, Real.dist_eq, sub_zero, abs_of_pos hz.1]
  exact hz.2.le

def north (A B C : ℝ → ℝ) (u : E3) : ℝ :=
  cut A (u 2) + (u 1 * cut B (u 2) - u 0 * cut C (u 2))
def evenLift (A B C : ℝ → ℝ) (u : E3) : ℝ :=
  north A B C u + north A B C (-u)
def mapping (f : E3 → ℝ) (u : E3) : E3 := normalize (u + tangentGradient f u)

theorem evenLift_neg (A B C : ℝ → ℝ) (u : E3) : evenLift A B C (-u) = evenLift A B C u := by
  simp [evenLift,add_comm]

theorem smooth_evenLift {A B C : ℝ → ℝ}
    (hA : ∀ z ∈ band, ContDiffAt ℝ ∞ A z) (hB : ∀ z ∈ band, ContDiffAt ℝ ∞ B z)
    (hC : ∀ z ∈ band, ContDiffAt ℝ ∞ C z) : ContDiff ℝ ∞ (evenLift A B C) := by
  have a := cut_smooth hA; have b := cut_smooth hB; have c := cut_smooth hC
  have hn : ContDiff ℝ ∞ (north A B C) := by unfold north; fun_prop
  exact hn.add (hn.comp contDiff_neg)

structure SideData (δ : ℝ) where
  A : ℝ → ℝ
  B : ℝ → ℝ
  C : ℝ → ℝ
  offset : ℝ
  smoothA : ∀ z ∈ band, ContDiffAt ℝ ∞ A z
  smoothB : ∀ z ∈ band, ContDiffAt ℝ ∞ B z
  smoothC : ∀ z ∈ band, ContDiffAt ℝ ∞ C z
  zero : ∀ z ∈ band, z ≤ 0 → A z=0 ∧ B z=0 ∧ C z=0
  agree : ∀ z ∈ cap, A z = offset + primitive δ z ∧
    B z = q δ z * Real.cos (azimuth z)/radial z ∧
    C z = q δ z * Real.sin (azimuth z)/radial z

def SideData.full {δ : ℝ} (d : SideData δ) := evenLift d.A d.B d.C

theorem SideData.smooth {δ : ℝ} (d : SideData δ) : ContDiff ℝ ∞ d.full :=
  smooth_evenLift d.smoothA d.smoothB d.smoothC

theorem SideData.even {δ : ℝ} (d : SideData δ) (u : E3) : d.full (-u) = d.full u :=
  evenLift_neg _ _ _ _

theorem SideData.match {δ : ℝ} (d : SideData δ) {u : E3} (hu : u 2 ∈ cap) :
    d.full u = d.offset + lift δ u := by
  have hz : -(u 2) ∈ band := ⟨by linarith [hu.2], by linarith [hu.1]⟩
  obtain ⟨zA,zB,zC⟩ := d.zero _ hz (by linarith [hu.1])
  obtain ⟨a,b,c⟩ := d.agree _ hu
  unfold SideData.full evenLift north cut lift
  change _ + (cutoff (-(u 2)) * d.A (-(u 2)) +
    ((-(u 1)) * (cutoff (-(u 2)) * d.B (-(u 2))) -
     (-(u 0)) * (cutoff (-(u 2)) * d.C (-(u 2))))) = _
  rw [zA,zB,zC,a,b,c,cutoff_cap hu]
  ring

theorem SideData.gradient_agrees {δ : ℝ} (d : SideData δ) {u : E3} (hu : u 2 ∈ cap) :
    _root_.gradient d.full u = _root_.gradient (lift δ) u := by
  have heq : d.full =ᶠ[𝓝 u] (fun v => d.offset + lift δ v) := by
    have hc : Continuous (fun v : E3 => v 2) := (PiLp.continuous_apply 2 _ 2)
    filter_upwards [hc.continuousAt.preimage_mem_nhds (isOpen_Ioo.mem_nhds hu)] with v hv
    exact d.match hv
  unfold _root_.gradient
  rw [heq.fderiv_eq]
  simp

theorem SideData.map_step {δ z : ℝ} (d : SideData δ) (hd : 0<δ) (hd' : δ≤1) (hz : z ∈ cap) :
    mapping d.full (point z (azimuth z)) =
      point (nextHeight δ z) (azimuth (nextHeight δ z)) := by
  have hcap : (point z (azimuth z)) 2 ∈ cap := hz
  have hbelt : z ∈ belt := ⟨hz.1, by linarith [hz.2]⟩
  simpa only [mapping,tangentGradient, d.gradient_agrees hcap, iterateMap] using!
    autonomous_step hd hd' hbelt

theorem SideData.iterates {δ : ℝ} (d : SideData δ) (hd : 0<δ) (hd' : δ≤1) (n : ℕ) :
    (mapping d.full)^[n] (point (1/8) (azimuth (1/8))) =
      point (LloydHeight.height δ n) (LloydHeight.phase δ n) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    obtain ⟨hp,hu⟩ := LloydHeight.height_bounds hd hd' n
    rw [Function.iterate_succ_apply', ih]
    exact d.map_step hd hd' (show LloydHeight.height δ n ∈ cap from ⟨hp, by linarith⟩)


private theorem cut_zero_nonpositive {f : ℝ → ℝ} (hf : ∀ z ∈ band, z ≤ 0 → f z=0)
    {z : ℝ} (hz : z ≤ 0) : cut f z=0 := by
  by_cases h : z ∈ band
  · simp [cut,hf z h hz]
  · have hneg : z ≤ -(1/4) := by
      by_contra! hn
      exact h ⟨hn, by linarith⟩
    have hc : cutoff z = 0 := cutoff.zero_of_le_dist (by
      change 9/40 ≤ dist z 0
      rw [Real.dist_eq, sub_zero, abs_of_nonpos hz]
      linarith)
    simp [cut,hc]

private theorem cut_flat_one {f : ℝ → ℝ} (hs : ∀ z ∈ band, ContDiffAt ℝ ∞ f z)
    (hf : ∀ z ∈ band, z ≤ 0 → f z=0) :
    HasDerivAt (cut f) 0 0 := by
  have h := ((cut_smooth hs).differentiable (by simp) 0).hasDerivAt
  have hh : HasDerivWithinAt (cut f) 0 (Iic 0) 0 :=
    (hasDerivWithinAt_const (0:ℝ) (Iic 0) (0:ℝ)).congr
      (fun z hz => cut_zero_nonpositive hf hz)
      (cut_zero_nonpositive hf le_rfl)
  have h' := (uniqueDiffWithinAt_Iic 0).eq_deriv _ h.hasDerivWithinAt hh
  rwa [h'] at h

private theorem north_flat {A B C : ℝ → ℝ}
    (hA : ∀ z ∈ band, ContDiffAt ℝ ∞ A z) (hB : ∀ z ∈ band, ContDiffAt ℝ ∞ B z)
    (hC : ∀ z ∈ band, ContDiffAt ℝ ∞ C z)
    (h0 : ∀ z ∈ band, z ≤ 0 → A z=0 ∧ B z=0 ∧ C z=0)
    {u : E3} (hz : u 2=0) : HasFDerivAt (north A B C) (0 : E3 →L[ℝ] ℝ) u := by
  have hcut (f : ℝ → ℝ) (hs : ∀ z ∈ band, ContDiffAt ℝ ∞ f z)
      (hf : ∀ z ∈ band, z ≤ 0 → f z=0) :
      HasFDerivAt (fun v : E3 => cut f (v 2)) (0 : E3 →L[ℝ] ℝ) u := by
    have hh : HasDerivAt (cut f) 0 (u 2) := hz ▸ cut_flat_one hs hf
    simpa using! hh.hasFDerivAt.comp u (PiLp.hasFDerivAt_apply (𝕜:=ℝ) 2 u 2)
  have a := hcut A hA (fun t ht h => (h0 t ht h).1)
  have b := hcut B hB (fun t ht h => (h0 t ht h).2.1)
  have c := hcut C hC (fun t ht h => (h0 t ht h).2.2)
  have b0 : cut B (u 2)=0 := hz ▸ cut_zero_nonpositive (fun t ht h => (h0 t ht h).2.1) le_rfl
  have c0 : cut C (u 2)=0 := hz ▸ cut_zero_nonpositive (fun t ht h => (h0 t ht h).2.2) le_rfl
  have dB := (PiLp.hasFDerivAt_apply (𝕜:=ℝ) 2 u 1).mul b
  have dC := (PiLp.hasFDerivAt_apply (𝕜:=ℝ) 2 u 0).mul c
  simpa [b0,c0,north,Pi.add_def,Pi.sub_def,Pi.mul_def] using! a.add (dB.sub dC)

theorem SideData.gradient_equator {δ : ℝ} (d : SideData δ) {u : E3} (hz : u 2=0) :
    _root_.gradient d.full u = 0 := by
  have ha := north_flat d.smoothA d.smoothB d.smoothC d.zero hz
  have hneg : (-u) 2=0 := by simpa using hz
  have hb := (north_flat d.smoothA d.smoothB d.smoothC d.zero hneg).comp u
    ((hasFDerivAt_id u).neg)
  have hd : HasFDerivAt d.full (0 : E3 →L[ℝ] ℝ) u := by
    simpa [SideData.full,evenLift,Pi.add_def] using! ha.add hb
  simp [_root_.gradient,hd.fderiv]

theorem SideData.fixed_equator {δ : ℝ} (d : SideData δ) {u : E3} (hz : u 2=0) (hu : ‖u‖=1) :
    mapping d.full u=u := by
  simp [mapping, tangentGradient, d.gradient_equator hz, LloydSpiral.Chart.normalize,hu]

#print axioms SideData.iterates
#print axioms SideData.fixed_equator
end LloydGlobal
