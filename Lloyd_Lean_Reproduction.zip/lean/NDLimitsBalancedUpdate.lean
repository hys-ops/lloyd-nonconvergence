import NDLimitsBalanced

/-! The barycentric update of any optimal balanced coupling equals the ordinary
Voronoi Lloyd update for the actual symmetric normalized-volume source. -/
open MeasureTheory Set
noncomputable section
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)

/-- Source-coordinate barycenter of the slice of a transport plan arriving at a fixed atom. -/
def transportBarycenter (π : Measure (E × E)) (y : E) : E :=
  (π.real {p | p.2 = y})⁻¹ • ∫ p in {p | p.2 = y}, p.1 ∂π

private theorem graph_barycenter (μ : Measure E) (y z : E) (A : Set E)
    (he : ∀ x, nearestSite y x = z ↔ x ∈ A) :
    transportBarycenter (nearestCoupling μ y) z = cellCentroid μ A := by
  let G := fun x : E => (x, nearestSite y x)
  let T := {p : E × E | p.2 = z}
  have hT : MeasurableSet T := measurable_snd (measurableSet_singleton z)
  have hG : Measurable G := measurable_id.prodMk (nearestSite_measurable y)
  have hp : G ⁻¹' T = A := Set.ext he
  change ((μ.map G).real T)⁻¹ • (∫ p in T, p.1 ∂(μ.map G)) = _
  rw [Measure.real,Measure.map_apply hG hT,setIntegral_map hT continuous_fst.aestronglyMeasurable hG.aemeasurable,hp]
  rfl

theorem graph_barycenters_eq_update (μ : Measure E) (y : E) (hy : y ≠ 0) :
    (transportBarycenter (nearestCoupling μ y) y, transportBarycenter (nearestCoupling μ y) (-y)) =
      update μ y := by
  have hd : -y ≠ y := by
    intro h
    apply smul_ne_zero (by norm_num : (2:ℝ) ≠ 0) hy
    rw [two_smul]
    calc y+y = y+(-y) := congrArg (y+·) h.symm
         _ = 0 := add_neg_cancel _
  apply Prod.ext
  · apply graph_barycenter
    intro x
    by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,h,hd]
  · apply graph_barycenter
    intro x
    by_cases h : x ∈ nearestPlus y <;> simp [nearestSite,nearestMinus,h,hd.symm]

/-- No optimal-plan selector can change the equal-capacity update at a nonzero
antipodal pair of sites: both output points are actual conditional barycenters. -/
theorem uniform_balanced_barycenters (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (u : E) (hu : u ≠ 0) {r : ℝ} (hr : 0 < r) (π : Measure (E × E))
    (hf : π.fst = uniformOn K) (hs : π.snd = twoAtoms (r • u))
    (opt : squaredTransportCost π ≤ squaredTransportCost (nearestCoupling (uniformOn K) (r • u))) :
    (transportBarycenter π (r • u),transportBarycenter π (-(r • u))) = update (uniformOn K) (r • u) := by
  rw [uniform_balanced_unique K compact volpos u hu hr π hf hs opt]
  exact graph_barycenters_eq_update _ _ (smul_ne_zero hr.ne' hu)

/-- A balanced Lloyd solver may choose any optimal joint measure. The output is
its actual two conditional barycenters, with the positive label listed first. -/
def IsBalancedStep (μ : Measure E) (y : E) (p : E × E) : Prop :=
  ∃ π : Measure (E × E), π.fst = μ ∧ π.snd = twoAtoms y ∧
    (∀ σ : Measure (E × E), σ.fst = μ → σ.snd = twoAtoms y →
      squaredTransportCost π ≤ squaredTransportCost σ) ∧
    p = (transportBarycenter π y,transportBarycenter π (-y))

/-- Solver-independent identification; feasibility and existence are part of the reverse implication. -/
theorem uniform_balanced_step_iff (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (symm : ∀ x : E, -x ∈ K ↔ x ∈ K) (y : E) (hy : y ≠ 0) (p : E × E) :
    IsBalancedStep (uniformOn K) y p ↔ p = update (uniformOn K) y := by
  have h := uniform_balanced_optimal K compact volpos symm y hy (r:=1) zero_lt_one
  simp only [one_smul] at h
  constructor
  · rintro ⟨π,hf,hs,ho,rfl⟩
    have hh := ho _ h.1 h.2.1
    simpa only [one_smul] using uniform_balanced_barycenters K compact volpos y hy
      (r:=1) zero_lt_one π hf (by simpa only [one_smul] using hs) (by simpa only [one_smul] using hh)
  · rintro rfl
    exact ⟨_,h.1,h.2.1,h.2.2,(graph_barycenters_eq_update _ y hy).symm⟩

/-- Every sequence of arbitrary optimal-plan choices with the same start equals the
ordinary trajectory for every step on which that ordinary trajectory stays nonzero. -/
theorem balanced_trajectory_eq (K : Set E) (compact : IsCompact K) (volpos : volume K ≠ 0)
    (symm : ∀ x : E, -x ∈ K ↔ x ∈ K) (ordinary candidate : ℕ → E × E)
    (h0 : candidate 0 = ordinary 0) (hn : ∀ n, (ordinary n).1 ≠ 0)
    (hO : ∀ n, ordinary (n+1) = update (uniformOn K) (ordinary n).1)
    (hC : ∀ n, IsBalancedStep (uniformOn K) (candidate n).1 (candidate (n+1))) :
    candidate = ordinary := by
  funext n
  induction n with
  | zero => exact h0
  | succ n ih =>
    have h := hC n
    rw [ih] at h
    exact ((uniform_balanced_step_iff K compact volpos symm _ (hn n) _).mp h).trans (hO n).symm

#print axioms uniform_balanced_step_iff
#print axioms balanced_trajectory_eq
#print axioms graph_barycenters_eq_update
#print axioms uniform_balanced_barycenters
end LloydNDLimits
