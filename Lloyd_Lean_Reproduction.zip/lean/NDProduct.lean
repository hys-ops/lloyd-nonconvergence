import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Topology.Sets.VietorisTopology
import Mathlib.Analysis.InnerProductSpace.ProdL2
import Mathlib.Tactic

/-! The true squared Euclidean cost on a Cartesian product, written in its two coordinates.
Ties go to the second site. The second input law can be any centered integrable probability. -/
open MeasureTheory Set Filter TopologicalSpace
open scoped Topology
noncomputable section
namespace LloydProduct
variable {E F : Type*} [NormedAddCommGroup E] [NormedAddCommGroup F]
  [InnerProductSpace ℝ E] [InnerProductSpace ℝ F] [CompleteSpace E] [CompleteSpace F]
  [MeasurableSpace E] [BorelSpace E] [MeasurableSpace F] [BorelSpace F]
  [SecondCountableTopology E] [SecondCountableTopology F]

def center {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V] [MeasurableSpace V]
    (μ : Measure V) (A : Set V) : V := (μ.real A)⁻¹ • ∫ x in A, x ∂μ

def step (μ : Measure E) (Y : E × E) : E × E :=
  let A := {x : E | dist x Y.1 < dist x Y.2}
  (center μ A, center μ Aᶜ)

def cost (x y : E × F) : ℝ := dist x.1 y.1 ^ 2 + dist x.2 y.2 ^ 2

def productStep (μ : Measure (E × F)) (Y : (E × F) × (E × F)) :=
  let A := {x | cost x Y.1 < cost x Y.2}
  (center μ A, center μ Aᶜ)

def liftPair (Y : E × E) : (E × F) × (E × F) := ((Y.1,0),(Y.2,0))

theorem cost_eq_euclidean (x y : E × F) :
    cost x y = dist (WithLp.toLp 2 x) (WithLp.toLp 2 y) ^ 2 := by
  simp only [cost, dist_eq_norm, WithLp.prod_norm_sq_eq_of_L2]
  rfl

theorem cylinder_center (μ : Measure E) (ν : Measure F) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hi : Integrable (id : E → E) μ) (hj : Integrable (id : F → F) ν)
    (hz : (∫ z:F, z ∂ν) = 0) (A : Set E) :
    center (μ.prod ν) (A ×ˢ univ) = (center μ A, 0) := by
  unfold center
  rw [measureReal_prod_prod, show ν.real univ = 1 by simp [Measure.real], mul_one, ← Measure.restrict_prod_eq_prod_univ]
  have h₁ : Integrable (fun w : E × F => w.1) ((μ.restrict A).prod ν) := (hi.restrict).comp_fst ν
  have h₂ : Integrable (fun w : E × F => w.2) ((μ.restrict A).prod ν) := hj.comp_snd (μ.restrict A)
  change _ • (∫ w : E × F, (w.1,w.2) ∂(μ.restrict A).prod ν) = _
  rw [integral_pair h₁ h₂, integral_fun_fst (fun x:E => x), integral_fun_snd (fun z:F => z), hz]
  simp

theorem product_step (μ : Measure E) (ν : Measure F) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hi : Integrable (id : E → E) μ) (hj : Integrable (id : F → F) ν)
    (hz : (∫ z:F, z ∂ν) = 0) (Y : E × E) :
    productStep (μ.prod ν) (liftPair Y) = liftPair (step μ Y) := by
  let A := {x : E | dist x Y.1 < dist x Y.2}
  have he : {x : E × F | cost x (liftPair (F:=F) Y).1 < cost x (liftPair (F:=F) Y).2} = A ×ˢ univ := by
    ext x
    simp only [cost,liftPair,A,mem_setOf_eq,mem_prod,mem_univ,and_true,add_lt_add_iff_right]
    exact (sq_lt_sq₀ dist_nonneg dist_nonneg)
  have hc : (A ×ˢ (univ:Set F))ᶜ = Aᶜ ×ˢ univ := by ext; simp
  unfold productStep
  dsimp only
  rw [he,hc,cylinder_center μ ν hi hj hz,cylinder_center μ ν hi hj hz]
  rfl

theorem product_iterate (μ : Measure E) (ν : Measure F) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hi : Integrable (id : E → E) μ) (hj : Integrable (id : F → F) ν)
    (hz : (∫ z:F, z ∂ν) = 0) (Y : E × E) (n : ℕ) :
    (productStep (μ.prod ν))^[n] (liftPair Y) = liftPair ((step μ)^[n] Y) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [Function.iterate_succ_apply',Function.iterate_succ_apply',ih,product_step μ ν hi hj hz]

def unordered {V : Type*} [TopologicalSpace V] (p : V × V) : NonemptyCompacts V :=
  ({p.1} : NonemptyCompacts V) ⊔ {p.2}

theorem projected (Y : E × E) :
    (unordered (liftPair (F:=F) Y)).map Prod.fst continuous_fst = unordered Y := by
  apply SetLike.coe_injective
  simp [unordered, liftPair, Set.image_union]

theorem product_diverges (μ : Measure E) (ν : Measure F) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hi : Integrable (id : E → E) μ) (hj : Integrable (id : F → F) ν)
    (hz : (∫ z:F, z ∂ν) = 0) (Y : E × E)
    (diverges : ¬ ∃ P, Tendsto (fun n => unordered ((step μ)^[n] Y)) atTop (𝓝 P)) :
     ¬ ∃ P, Tendsto (fun n => unordered ((productStep (μ.prod ν))^[n] (liftPair Y))) atTop (𝓝 P) := by
  rintro ⟨P,hP⟩
  have h := (continuous_fst (X:=E) (Y:=F)).nonemptyCompacts_map.continuousAt.tendsto.comp hP
  apply diverges
  refine ⟨P.map Prod.fst continuous_fst,?_⟩
  simpa only [Function.comp_def, product_iterate μ ν hi hj hz, projected] using h

#print axioms product_iterate
#print axioms product_diverges
end LloydProduct
