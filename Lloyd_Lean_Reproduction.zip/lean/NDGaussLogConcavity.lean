import NDPolar
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

/-! The positivity set supplies the exact boundary convention in the
multiplicative log-concavity inequality, including arguments outside the ball. -/
noncomputable section
open Set
open scoped ContDiff RealInnerProductSpace Topology
namespace LloydNDLogConcave
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


/-- Pointwise second-derivative criterion on an arbitrary open convex set.
Local hypotheses are only used along the line segments contained in that set. -/
theorem convex_on_of_hessian {s:Set Vn} (hs:Convex ℝ s) {g:Vn→ℝ}
    (hg:∀x∈s,ContDiffAt ℝ 2 g x)
    (hH:∀x∈s,∀v:Vn,0≤fderiv ℝ (fderiv ℝ g) x v v) : ConvexOn ℝ s g := by
  refine ⟨hs,?_⟩
  intro x hx y hy a b ha hb hab
  let v := y-x
  let p := fun t:ℝ=>x+t • v
  have heq (t:ℝ) : p t=(1-t) • x+t • y := by dsimp [p,v];module
  have hseg (t:ℝ) (ht:t∈Icc 0 1) : p t∈s := by
    rw [heq]
    exact hs hx hy (sub_nonneg.mpr ht.2) ht.1 (by ring)
  have hp (t:ℝ) : HasDerivAt p v t := by
    simpa [p] using ((hasDerivAt_id t).smul_const v).const_add x
  let G := fun t:ℝ=>g (p t)
  let D := fun t:ℝ=>fderiv ℝ g (p t) v
  let D2 := fun t:ℝ=>fderiv ℝ (fderiv ℝ g) (p t) v v
  have h1 (t:ℝ) (ht:t∈Icc 0 1) : HasDerivAt G (D t) t :=
    ((hg _ (hseg t ht)).differentiableAt (by norm_num)).hasFDerivAt.comp_hasDerivAt t (hp t)
  have h2 (t:ℝ) (ht:t∈Icc 0 1) : HasDerivAt D (D2 t) t := by
    have hf := ((hg _ (hseg t ht)).fderiv_right (m:=1) (by norm_num)).differentiableAt (by norm_num)
    have hv := (hf.hasFDerivAt.comp_hasDerivAt t (hp t)).clm_apply (hasDerivAt_const t v)
    simpa [D2] using hv
  have hcv : ConvexOn ℝ (Icc (0:ℝ) 1) G := convexOn_of_hasDerivWithinAt2_nonneg
    (f':=D) (f'':=D2) (convex_Icc _ _)
    (fun t ht=>(h1 t ht).continuousAt.continuousWithinAt)
    (fun t ht=>(h1 t (interior_subset ht)).hasDerivWithinAt)
    (fun t ht=>(h2 t (interior_subset ht)).hasDerivWithinAt)
    (fun t ht=>hH _ (hseg t (interior_subset ht)) v)
  have h := hcv.2 (show (0:ℝ)∈Icc 0 1 by norm_num) (show (1:ℝ)∈Icc 0 1 by norm_num) ha hb hab
  simp only [smul_eq_mul,mul_zero,mul_one,zero_add] at h
  have hp0 : p 0=x := by simp [p]
  have hp1 : p 1=y := by simp [p,v]
  simpa only [G,hp0,hp1,heq b,(show 1-b=a by linarith),smul_eq_mul] using h

theorem zero_extended_logconcavity {ρ:Vn→ℝ} (smooth:ContDiff ℝ ∞ ρ)
    (hn:∀x,0≤ρ x) (hpos:∀x,0<ρ x ↔ ‖x‖<3)
    (hh:∀x:Vn, ‖x‖<3 → ∀v:Vn,0≤fderiv ℝ (fderiv ℝ (fun z=> -Real.log (ρ z))) x v v) :
    ∀ (x y:Vn) (a b:ℝ), 0≤a → 0≤b → a+b=1 →
      (ρ x)^a*(ρ y)^b ≤ ρ (a • x+b • y) := by
  let s := Metric.ball (0:Vn) 3
  have hmem (x:Vn) : x∈s ↔ ‖x‖<3 := by simp [s,Metric.mem_ball]
  have hcv : ConvexOn ℝ s (fun z=> -Real.log (ρ z)) := by
    apply convex_on_of_hessian (convex_ball _ _)
    · intro x hx
      have hp : ρ x≠0 := ((hpos x).2 ((hmem _).mp hx)).ne'
      exact ((smooth.of_le (by norm_num : (2:ℕ∞ω)≤∞)).contDiffAt.log hp).neg
    · intro x hx
      exact hh x ((hmem _).mp hx)
  intro x y a b ha hb hab
  rcases ha.eq_or_lt with h0|ha'
  · subst a;simp_all
  rcases hb.eq_or_lt with h0|hb'
  · subst b;simp_all
  by_cases hx:0<ρ x
  · by_cases hy:0<ρ y
    · have hxs := (hmem x).2 ((hpos x).mp hx)
      have hys := (hmem y).2 ((hpos y).mp hy)
      have hp := (hpos _).2 ((hmem _).mp (hcv.1 hxs hys ha hb hab))
      have h := hcv.2 hxs hys ha hb hab
      change -Real.log (ρ (a • x+b • y)) ≤ a*(-Real.log (ρ x))+b*(-Real.log (ρ y)) at h
      rw [Real.rpow_def_of_pos hx,Real.rpow_def_of_pos hy,←Real.exp_add,←Real.exp_log hp,
        Real.exp_le_exp]
      linarith
    · rw [le_antisymm (not_lt.mp hy) (hn y),Real.zero_rpow hb'.ne',mul_zero]
      exact hn _
  · rw [le_antisymm (not_lt.mp hx) (hn x),Real.zero_rpow ha'.ne',zero_mul]
    exact hn _

#print axioms convex_on_of_hessian
#print axioms zero_extended_logconcavity
end LloydNDLogConcave
