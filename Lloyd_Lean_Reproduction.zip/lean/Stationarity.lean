import Reduction

/-! Stationarity of every equatorial antipodal limit of the ordinary population Lloyd map. -/

open Filter Topology MeasureTheory
open scoped RealInnerProductSpace
open LloydCentroid
namespace LloydVerification
noncomputable section

/-- Current and immediately following directions approach the same prescribed equatorial
point along the same times. The vanishing phase increment prevents a jump at the limit. -/
theorem equator_current_and_next {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (θ : ℝ) :
    ∃ k : ℕ → ℕ, Tendsto k atTop atTop ∧
      Tendsto (fun n => dir δ (k n)) atTop (𝓝 (LloydOrbit.equator θ)) ∧
      Tendsto (fun n => dir δ (k n + 1)) atTop (𝓝 (LloydOrbit.equator θ)) := by
  let a := LloydHeight.phase δ
  obtain ⟨k,hk,hcos,hsin⟩ := LloydCrossing.trig_crossing a
    (LloydHeight.phase_tendsto_atTop hd hd') (LloydHeight.phase_step_tendsto_zero hd hd') θ
  have hs : Tendsto (fun n => a (k n+1) - a (k n)) atTop (𝓝 0) :=
    (LloydHeight.phase_step_tendsto_zero hd hd').comp hk
  have hdc : Tendsto (fun n => Real.cos (a (k n+1)-a (k n))) atTop (𝓝 1) := by
    rw [←Real.cos_zero]
    exact Real.continuous_cos.continuousAt.tendsto.comp hs
  have hds : Tendsto (fun n => Real.sin (a (k n+1)-a (k n))) atTop (𝓝 0) := by
    conv => rhs; rw [←Real.sin_zero]
    exact Real.continuous_sin.continuousAt.tendsto.comp hs
  have hcnext : Tendsto (fun n => Real.cos (a (k n+1))) atTop (𝓝 (Real.cos θ)) := by
    have h := (hcos.mul hdc).sub (hsin.mul hds)
    simp only [mul_one,mul_zero,sub_zero] at h
    apply h.congr
    intro n
    rw [←Real.cos_add,add_sub_cancel]
  have hsnext : Tendsto (fun n => Real.sin (a (k n+1))) atTop (𝓝 (Real.sin θ)) := by
    have h := (hsin.mul hdc).add (hcos.mul hds)
    simp only [mul_one,mul_zero,add_zero] at h
    apply h.congr
    intro n
    rw [←Real.sin_add,add_sub_cancel]
  have hz := LloydHeight.height_tendsto_zero hd hd'
  exact ⟨k,hk,LloydOrbit.tendsto_direction (hz.comp hk) hcos hsin,
    LloydOrbit.tendsto_direction (hz.comp ((tendsto_add_atTop_nat 1).comp hk)) hcnext hsnext⟩

/-- The signed moment at each equatorial limit has no tangential component; the
ordinary two-site map fixes the corresponding pair with its actual limiting radius. -/
theorem equator_stationary {μ : Measure E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x : E => -x) μ μ)
    (hac : μ ≪ volume) (hi : Integrable (id : E → E) μ)
    {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hm : MatchesBelt μ δ)
    {r₀ c : ℝ} (hc : 0 < c) (hr : Tendsto (radius μ δ r₀) atTop (𝓝 c)) (θ : ℝ) :
    let v := LloydOrbit.equator θ
    signedMoment μ v = c • v ∧ ordinaryStep μ (c • v, -(c • v)) = (c • v, -(c • v)) := by
  obtain ⟨k,hk,hu,hv⟩ := equator_current_and_next hd hd' θ
  have hn := hu.norm
  have hunit : ‖LloydOrbit.equator θ‖ = 1 := by
    exact tendsto_nhds_unique hn (by simpa only [dir_norm hd hd'] using (tendsto_const_nhds (x:=(1:ℝ)) : Tendsto (fun _ : ℕ => (1:ℝ)) atTop (𝓝 1)))
  have hnz : LloydOrbit.equator θ ≠ 0 := by
    intro h
    rw [h,norm_zero] at hunit
    norm_num at hunit
  have ht := no_ties_of_ac μ hac _ hnz
  have hleft := (continuousAt_signedMoment μ (LloydOrbit.equator θ) hi ht).tendsto.comp hu
  have hrs : Tendsto (fun n => radius μ δ r₀ (k n+1)) atTop (𝓝 c) :=
    hr.comp ((tendsto_add_atTop_nat 1).comp hk)
  have hright : Tendsto (fun n => signedMoment μ (dir δ (k n))) atTop
      (𝓝 (c • LloydOrbit.equator θ)) := by
    apply (hrs.smul hv).congr
    exact fun n => (actual_vector hsym hac hi hd hd' hm (k n) (r:=1) zero_lt_one).2.1.symm
  have heq := tendsto_nhds_unique hleft hright
  have hfixed := (reflection_update μ (LloydOrbit.equator θ) hc hsym ht hi).2.2
  rw [heq] at hfixed
  exact ⟨heq,hfixed⟩

#print axioms equator_current_and_next
#print axioms equator_stationary

end
end LloydVerification
