import NDPlanarSource
import NDGaussBalanced

/-! With finite quadratic cost, every choice of an optimal balanced plan has
the same limiting ordered pair as the ordinary planar orbit. -/
noncomputable section
open MeasureTheory Filter
open scoped Topology ContDiff ENNReal
namespace LloydNDPlanar
open LloydNDLimits LloydNDModels

theorem balanced_convergence (μ : Measure E2) [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hsym : MeasurePreserving (fun x:E2 => -x) μ μ) (h₂ : MemLp id 2 μ)
    (hs : ContDiff ℝ 2 (profile μ)) (x:E2) (hx : x≠0) :
    ∃ y : E2, let ordinary := fun n:ℕ => (LloydProduct.step μ)^[n] (x,-x)
              Tendsto ordinary atTop (𝓝 (y,-y)) ∧
              (∀ (n:ℕ) (P:E2×E2), IsBalancedStep μ (ordinary n).1 P ↔ P=ordinary (n+1)) ∧
              ∀ (Y:ℕ → E2×E2), Y 0=(x,-x) →
                (∀ n,IsBalancedStep μ (Y n).1 (Y (n+1))) →
                Y=ordinary ∧ Tendsto Y atTop (𝓝 (y,-y)) := by
  have hi : Integrable (id:E2→E2) μ := h₂.integrable (by norm_num)
  obtain ⟨y,hy⟩ := convergence μ hac hsym hi hs x hx
  let p : LloydNDModels.Profile (k:=1) μ (populationSupport μ) 1 :=
    ⟨zero_lt_one,inferInstance,hsym,hac,hi,fun u _ => by ring⟩
  let ordinary := fun n:ℕ => (LloydProduct.step μ)^[n] (x,-x)
  have eqv (n:ℕ) (P:E2×E2) : IsBalancedStep μ (ordinary n).1 P ↔ P=ordinary (n+1) :=
    p.balanced_trajectory h₂ hx n P
  refine ⟨y,hy,eqv,fun Y h₀ hY => ?_⟩
  have e : Y=ordinary := by
    funext n
    induction n with
    | zero => exact h₀
    | succ n ih =>
      apply (eqv n _).mp
      rw [←ih]
      exact hY n
  exact ⟨e,e ▸ hy⟩

#print axioms balanced_convergence
end LloydNDPlanar
