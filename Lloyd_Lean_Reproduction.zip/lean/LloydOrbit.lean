import SpiralOrbit
import Crossing
import LocalPotential
import SupportChart

open MeasureTheory Filter Topology TopologicalSpace
open scoped RealInnerProductSpace
open LloydSpiral.Chart
namespace LloydVerification
noncomputable section
abbrev E := EuclideanSpace ℝ (Fin 3)
def dir (δ : ℝ) (n : ℕ) : E := point (LloydHeight.height δ n) (LloydHeight.phase δ n)

theorem dir_norm {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (n : ℕ) : ‖dir δ n‖=1 := by
  obtain ⟨a,b⟩ := LloydHeight.height_bounds hd hd' n
  apply point_norm
  nlinarith [mul_pos a (show 0 < 1/4-LloydHeight.height δ n by linarith)]

theorem axis_limits {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) {r : ℕ → ℝ} {c : ℝ}
    (hr : Tendsto r atTop (𝓝 c)) (hc : 0 < c) :
    (∀ K : NonemptyCompacts E, MapClusterPt K atTop (fun n => LloydOrbit.antipodes (r n • dir δ n))
      ↔ ∃ θ : ℝ, K = LloydOrbit.antipodes (c • LloydOrbit.equator θ)) ∧
    ¬∃ K, Tendsto (fun n => LloydOrbit.antipodes (r n • dir δ n)) atTop (𝓝 K) := by
  have hz := LloydHeight.height_tendsto_zero hd hd'
  have hall := LloydOrbit.all_axes hz hr
    (LloydCrossing.trig_crossing _ (LloydHeight.phase_tendsto_atTop hd hd')
      (LloydHeight.phase_step_tendsto_zero hd hd'))
  refine ⟨fun K => ⟨fun h => LloydOrbit.only_axes hz hr h, ?_⟩,
    LloydOrbit.nonconvergence_of_all_axes hc.ne' hall⟩
  rintro ⟨θ,rfl⟩
  obtain ⟨k,hk,ht⟩ := hall θ
  exact ht.mapClusterPt.of_comp hk

/-- The prescribed model has exactly the claimed limits, with no realization
hypothesis. The unsigned pair is an element of the compact-set hyperspace. -/
theorem model_counterexample {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) :
    (∀ n, ∃! g, IsChartGradient (LloydLocal.surface δ) (LloydHeight.height δ n)
        (LloydHeight.phase δ n) g ∧ normalize (dir δ n + g) = dir δ (n+1)) ∧
    (∀ K : NonemptyCompacts E, MapClusterPt K atTop (fun n => LloydOrbit.antipodes (dir δ n)) ↔
      ∃ θ : ℝ, K = LloydOrbit.antipodes (LloydOrbit.equator θ)) ∧
    ¬∃ K, Tendsto (fun n => LloydOrbit.antipodes (dir δ n)) atTop (𝓝 K) := by
  refine ⟨fun n => LloydLocal.exact_step_on_orbit hd hd' n, ?_⟩
  simpa using axis_limits hd hd' (tendsto_const_nhds (x := (1:ℝ))) (by norm_num)

/-- Ordinary nearest-site Lloyd on arbitrary ordered pairs. -/
def ordinaryStep (μ : Measure E) (Y : E × E) : E × E :=
  let A := {x : E | dist x Y.1 < dist x Y.2}
  (LloydCentroid.cellCentroid μ A, LloydCentroid.cellCentroid μ Aᶜ)

def unlabel (Y : E × E) : NonemptyCompacts E :=
  ({Y.1} : NonemptyCompacts E) ⊔ ({Y.2} : NonemptyCompacts E)

/-- A scalar condition on the support integral on an open band. It makes no
reference to the desired iterates, any centroid vector, or any limit set. -/
def MatchesBelt (μ : Measure E) (δ : ℝ) : Prop :=
  ∃ b : ℝ, ∀ z ∈ Set.Ioo (0:ℝ) (1/5), ∀ φ : ℝ,
    LloydSupportChart.logChart μ z φ = b + LloydLocal.surface δ z φ

theorem actual_vector {μ : Measure E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x : E => -x) μ μ)
    (hac : μ ≪ volume) (hi : Integrable (id : E → E) μ)
    {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hm : MatchesBelt μ δ)
    (n : ℕ) {r : ℝ} (hr : 0 < r) :
    let v := LloydCentroid.signedMoment μ (dir δ n)
    0 < ‖v‖ ∧ v = ‖v‖ • dir δ (n+1) ∧
    ordinaryStep μ (r • dir δ n, -(r • dir δ n)) = (v,-v) := by
  let z := LloydHeight.height δ n
  let φ := LloydHeight.phase δ n
  have normu := dir_norm hd hd' n
  have hu : dir δ n ≠ 0 := fun hh => by rw [hh,norm_zero] at normu; norm_num at normu
  have ht := LloydCentroid.no_ties_of_ac μ hac _ hu
  have hs := (LloydCentroid.reflection_update μ _ hr hsym ht hi).2.2
  obtain ⟨zp,zu⟩ := LloydHeight.height_bounds hd hd' n
  have hzone : z ∈ Set.Ioo (0:ℝ) (1/5) := ⟨zp, by dsimp [z]; linarith⟩
  obtain ⟨b,hb⟩ := hm
  have heq : (fun a : ℝ × ℝ => LloydSupportChart.logChart μ a.1 a.2) =ᶠ[𝓝 (z,φ)]
      (fun a => b + LloydLocal.surface δ a.1 a.2) := by
    filter_upwards [continuous_fst.continuousAt.preimage_mem_nhds (isOpen_Ioo.mem_nhds hzone)]
      with a ha using hb a.1 ha a.2
  obtain ⟨g,⟨hg,hn⟩,_⟩ := LloydLocal.exact_step_on_orbit hd hd' n
  have hz : 0 < 1-z^2 := by nlinarith [mul_pos hzone.1 (sub_pos.mpr hzone.2)]
  have hnorm := (LloydSupportChart.normalized_update_of_local_chart μ hz hr hsym ht hi heq hg).trans hn
  change normalize (LloydCentroid.update μ (r • dir δ n)).1 = dir δ (n+1) at hnorm
  rw [hs] at hnorm
  change normalize (LloydCentroid.signedMoment μ (dir δ n)) = dir δ (n+1) at hnorm
  have hnz : LloydCentroid.signedMoment μ (dir δ n) ≠ 0 := by
    rintro h
    rw [h] at hnorm
    have hc := congrArg norm hnorm
    simpa [LloydSpiral.Chart.normalize,dir_norm hd hd'] using hc
  refine ⟨norm_pos_iff.mpr hnz, ?_, hs⟩
  rw [←hnorm, LloydSpiral.Chart.normalize, smul_smul, mul_inv_cancel₀ (norm_ne_zero_iff.mpr hnz), one_smul]

#print axioms model_counterexample
#print axioms actual_vector
end
end LloydVerification
