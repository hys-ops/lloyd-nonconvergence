import NDGaussShell
import Mathlib.Probability.Distributions.Gaussian.Multivariate
import Mathlib.Analysis.SpecialFunctions.Gaussian.FourierTransform

/-! A normalized smooth positive Lebesgue density for mathlib's actual standard
Gaussian in each positive Euclidean dimension, verified by its characteristic function. -/
noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped Topology RealInnerProductSpace ENNReal ContDiff
namespace LloydNDGaussian
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def Z (rankIndex : ℕ) : ℝ := (Real.pi/(1/2:ℝ))^((Module.finrank ℝ (E rankIndex):ℝ)/2)
def pdf (x:Vn) : ℝ := (Z dim)⁻¹*Real.exp (-(1/2:ℝ)*‖x‖^2)

theorem Z_pos (dim : ℕ) : 0<Z dim := by unfold Z;positivity
theorem pdf_pos (x : Vn) : 0<pdf x := mul_pos (inv_pos.mpr (Z_pos dim)) (Real.exp_pos _)
theorem pdf_smooth : ContDiff ℝ ∞ (pdf (dim:=dim)) := by
  have h : ContDiff ℝ ∞ (fun x:Vn => ‖x‖^2) := contDiff_norm_sq ℝ
  unfold pdf
  fun_prop

theorem pdf_integrable : Integrable (pdf (dim:=dim)) := by
  have h := (GaussianFourier.integrable_cexp_neg_mul_sq_norm_add
    (b:=((1/2:ℝ):ℂ)) (by norm_num) 0 (0:Vn)).norm
  have h1 : Integrable (fun x:Vn => Real.exp (-(1/2:ℝ)*‖x‖^2)) := by
    simpa [Complex.norm_exp,←Complex.ofReal_pow] using h
  exact h1.const_mul _

def law (f:Vn→ℝ) : Measure Vn := volume.withDensity (fun x => ENNReal.ofReal (f x))

theorem law_integral {f:Vn→ℝ} (hf:Measurable f) (hp:∀x,0≤f x) (g:Vn→ℝ) :
    (∫ x,g x ∂law f) = ∫ x, g x*f x := by
  unfold law
  rw [integral_withDensity_eq_integral_toReal_smul hf.ennreal_ofReal (by simp)]
  apply integral_congr_ae
  filter_upwards [] with x
  rw [ENNReal.toReal_ofReal (hp x),smul_eq_mul,mul_comm]

theorem law_pdf : law pdf=stdGaussian Vn := by
  let : IsFiniteMeasure (law (pdf (dim:=dim))) := isFiniteMeasure_withDensity_ofReal pdf_integrable.hasFiniteIntegral
  apply Measure.ext_of_charFun
  funext u
  rw [charFun_stdGaussian,charFun_apply]
  unfold law
  rw [integral_withDensity_eq_integral_toReal_smul pdf_smooth.continuous.measurable.ennreal_ofReal
    (by simp)]
  have point (x:Vn) : (ENNReal.ofReal (pdf x)).toReal • Complex.exp (↑⟪x,u⟫ * Complex.I) =
      ((↑(Z dim):ℂ)⁻¹)*Complex.exp (-(↑(1/2:ℝ):ℂ)*‖x‖^2+Complex.I*⟪u,x⟫) := by
    rw [ENNReal.toReal_ofReal (pdf_pos x).le,Complex.real_smul,pdf,Complex.ofReal_mul,
      Complex.ofReal_inv,Complex.exp_add,Complex.ofReal_exp,real_inner_comm x u]
    push_cast
    ring_nf
  simp_rw [point]
  rw [integral_const_mul,GaussianFourier.integral_cexp_neg_mul_sq_norm_add (by norm_num)]
  have hZ : (↑(Z dim):ℂ) = (↑Real.pi/(↑(1/2:ℝ):ℂ))^((Module.finrank ℝ Vn:ℂ)/2) := by
    unfold Z
    rw [Complex.ofReal_cpow (by positivity)]
    push_cast
    rfl
  rw [←hZ,←mul_assoc,inv_mul_cancel₀ (Complex.ofReal_ne_zero.mpr (Z_pos dim).ne'),one_mul,
    Complex.I_sq]
  congr 1
  push_cast
  ring

#print axioms law_pdf
end LloydNDGaussian
