import Mathlib.MeasureTheory.Constructions.HaarToSphere
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Normed.Lp.MeasurableSpace
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.Probability.ConditionalProbability
import Mathlib.Tactic

open MeasureTheory Set
open scoped ENNReal RealInnerProductSpace
noncomputable section

namespace LloydNDPolar
abbrev E (dim : ℕ) := EuclideanSpace ℝ (Fin (dim+1))
variable {dim : ℕ}
local notation "Vn" => E dim
abbrev S (dim : ℕ) := Metric.sphere (0 : E dim) 1
local notation "Sn" => S dim
abbrev Ray := Ioi (0 : ℝ)
local notation "punctured" => ({0}ᶜ : Set Vn)

lemma density_radial_succ (n : ℕ) :
    (Measure.volumeIoiPow n).withDensity (fun t : Ray => ENNReal.ofReal t.val) =
      Measure.volumeIoiPow (n+1) := by
  unfold Measure.volumeIoiPow
  rw [← withDensity_mul _ (by fun_prop) (by fun_prop)]
  congr 1
  ext t
  simp [pow_succ, ENNReal.ofReal_mul (pow_nonneg t.2.le n)]

lemma radial_first_moment (dim : ℕ) (r : Ray) :
    ∫⁻ t in Iio r, ENNReal.ofReal t.val ∂(Measure.volumeIoiPow dim) =
      ENNReal.ofReal (r.val^(dim+2) / ((dim:ℝ)+2)) := by
  rw [← withDensity_apply _ measurableSet_Iio, density_radial_succ, Measure.volumeIoiPow_apply_Iio]
  push_cast
  congr 2 <;> ring

/-- Open radial star domain. Its negligible origin can be added without changing a moment. -/
def star (ρ : Sn → Ray) : Set Vn := {x | ∃ hx : x ∈ punctured,
  ((homeomorphUnitSphereProd Vn) ⟨x,hx⟩).2 < ρ ((homeomorphUnitSphereProd Vn) ⟨x,hx⟩).1}

lemma star_polar (ρ : Sn → Ray) (p : Sn × Ray) :
    (↑((homeomorphUnitSphereProd Vn).symm p) : Vn) ∈ star ρ ↔ p.2 < ρ p.1 := by
  constructor
  · rintro ⟨h, hh⟩
    change ((homeomorphUnitSphereProd Vn) ((homeomorphUnitSphereProd Vn).symm p)).2 <
      ρ ((homeomorphUnitSphereProd Vn) ((homeomorphUnitSphereProd Vn).symm p)).1 at hh
    simpa only [Homeomorph.apply_symm_apply] using hh
  · intro h
    refine ⟨((homeomorphUnitSphereProd Vn).symm p).2, ?_⟩
    change ((homeomorphUnitSphereProd Vn) ((homeomorphUnitSphereProd Vn).symm p)).2 <
      ρ ((homeomorphUnitSphereProd Vn) ((homeomorphUnitSphereProd Vn).symm p)).1
    simpa only [Homeomorph.apply_symm_apply] using h

lemma measurableSet_star {ρ : Sn → Ray} (hρ : Measurable ρ) : MeasurableSet (star ρ) := by
  let e := homeomorphUnitSphereProd Vn
  have eq : star ρ = (Subtype.val : punctured → Vn) ''
      (e ⁻¹' {p : Sn × Ray | p.2 < ρ p.1}) := by
    ext x
    constructor
    · rintro ⟨hx,h⟩
      exact ⟨⟨x,hx⟩,h,rfl⟩
    · rintro ⟨⟨x,hx⟩,h,rfl⟩
      exact ⟨hx,h⟩
  rw [eq]
  exact (MeasurableEmbedding.subtype_coe (measurableSet_singleton _).compl).measurableSet_image'
    (e.measurable (measurableSet_lt measurable_snd (hρ.comp measurable_fst)))

/-- The unnormalised cosine moment of Lebesgue measure restricted to the star
domain is the sphere cosine transform of the dimension-plus-one power of its radial function. -/
theorem star_abs_moment {ρ : Sn → Ray} (hρ : Measurable ρ) (u : Vn) :
    ∫⁻ x in star ρ, ENNReal.ofReal |⟪u,x⟫| =
      ∫⁻ w : Sn, ENNReal.ofReal |⟪u,(w:Vn)⟫| * ENNReal.ofReal ((ρ w).val^(dim+2) / ((dim:ℝ)+2))
        ∂(volume : Measure Vn).toSphere := by
  classical
  let e := homeomorphUnitSphereProd Vn
  let f := (star ρ).indicator (fun x : Vn => ENNReal.ofReal |⟪u,x⟫|)
  let g := fun p : Sn × Ray => if p.2 < ρ p.1 then
    ENNReal.ofReal |⟪u,(p.1:Vn)⟫| * ENNReal.ofReal p.2.val else 0
  have hg : Measurable g := by
    dsimp [g]
    exact Measurable.ite (measurableSet_lt measurable_snd (hρ.comp measurable_fst))
      (by fun_prop) measurable_const
  have eval (p : Sn × Ray) : f ((e.symm p).val) = g p := by
    by_cases h : p.2 < ρ p.1
    · rw [show f ((e.symm p).val) = ENNReal.ofReal |⟪u,((e.symm p).val)⟫| from
          Set.indicator_of_mem ((star_polar ρ p).2 h) _]
      have hpos : 0 < p.2.val := p.2.property
      simp [g, h, e, real_inner_smul_right, abs_mul, abs_of_pos hpos, ENNReal.ofReal_mul hpos.le, mul_comm]
    · rw [show f ((e.symm p).val) = 0 from
          Set.indicator_of_notMem (mt (star_polar ρ p).1 h) _]
      simp [g,h]
  have rank : Module.finrank ℝ Vn - 1 = dim := by simp [E]
  rw [← lintegral_indicator (measurableSet_star hρ)]
  change (∫⁻ x, f x) = _
  calc
    _ = ∫⁻ x : punctured, f x.val ∂(volume.comap Subtype.val) := by
      rw [lintegral_subtype_comap (measurableSet_singleton _).compl, restrict_compl_singleton]
    _ = ∫⁻ x : punctured, g (e x) ∂(volume.comap Subtype.val) := by
      apply lintegral_congr
      intro x
      simpa using eval (e x)
    _ = ∫⁻ p, g p ∂((volume : Measure Vn).toSphere.prod (Measure.volumeIoiPow dim)) := by
      simpa [rank] using
        (volume : Measure Vn).measurePreserving_homeomorphUnitSphereProd.lintegral_comp_emb
          e.measurableEmbedding g
    _ = _ := by
      rw [lintegral_prod g hg.aemeasurable]
      apply lintegral_congr
      intro w
      change (∫⁻ t : Ray, (if t < ρ w then _ else 0) ∂(Measure.volumeIoiPow dim)) = _
      rw [show (fun t : Ray => if t < ρ w then ENNReal.ofReal |⟪u,(w:Vn)⟫| *
          ENNReal.ofReal t.val else 0) = (Iio (ρ w)).indicator
            (fun t : Ray => ENNReal.ofReal |⟪u,(w:Vn)⟫| * ENNReal.ofReal t.val) from rfl,
        lintegral_indicator measurableSet_Iio, lintegral_const_mul _ (by fun_prop), radial_first_moment]

/-- Real-valued first moment. Smooth positive bounded radial functions are included. -/
theorem real_star_abs_moment {ρ : Sn → Ray} (hρ : Measurable ρ) (u : Vn) :
    ∫ x in star ρ, |⟪u,x⟫| =
      ∫ w : Sn, |⟪u,(w:Vn)⟫| * ((ρ w).val^(dim+2) / ((dim:ℝ)+2)) ∂(volume : Measure Vn).toSphere := by
  have h := congrArg ENNReal.toReal (star_abs_moment hρ u)
  have hm : Measurable (fun w : Sn => ENNReal.ofReal |⟪u,(w:Vn)⟫| *
      ENNReal.ofReal ((ρ w).val ^(dim+2) / ((dim:ℝ)+2))) := by fun_prop
  rw [← integral_toReal (by fun_prop) (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top),
    ← integral_toReal hm.aemeasurable (Filter.Eventually.of_forall fun _ =>
      ENNReal.mul_lt_top ENNReal.ofReal_lt_top ENNReal.ofReal_lt_top)] at h
  have hn (w : Sn) : 0 ≤ (ρ w).val ^(dim+2) / ((dim:ℝ)+2) := div_nonneg (pow_nonneg (ρ w).property.le _) (by positivity)
  simpa only [ENNReal.toReal_mul, ENNReal.toReal_ofReal (abs_nonneg _),
    ENNReal.toReal_ofReal (hn _)] using h

/-- Uniform measure obtained by normalising Lebesgue measure on the open radial body. -/
def uniformStar (ρ : Sn → Ray) : Measure Vn :=
  (volume (star ρ))⁻¹ • volume.restrict (star ρ)

/-- Exact normalization of the radial cosine transform for the population expectation. -/
theorem uniformStar_abs_moment {ρ : Sn → Ray} (hρ : Measurable ρ) (u : Vn) :
    ∫ x, |⟪u,x⟫| ∂uniformStar ρ =
      (volume.real (star ρ))⁻¹ * ∫ w : Sn, |⟪u,(w:Vn)⟫| * ((ρ w).val^(dim+2) / ((dim:ℝ)+2))
        ∂(volume : Measure Vn).toSphere := by
  rw [uniformStar, integral_smul_measure, real_star_abs_moment hρ]
  simp [Measure.real, smul_eq_mul]

/-- A positive inner radius and finite outer radius suffice for genuine probability normalization. -/
theorem uniformStar_isProbability {ρ : Sn → Ray} {l L : ℝ} (hl : 0 < l)
    (hb : ∀ w, l ≤ (ρ w).val ∧ (ρ w).val ≤ L) : IsProbabilityMeasure (uniformStar ρ) := by
  let e := homeomorphUnitSphereProd Vn
  have lower : Metric.ball (0:Vn) l \ {0} ⊆ star ρ := by
    intro x hx
    have hx0 : x ∈ punctured := hx.2
    refine ⟨hx0, ?_⟩
    change (e ⟨x,hx0⟩).2.val < (ρ (e ⟨x,hx0⟩).1).val
    calc
      _ = ‖x‖ := homeomorphUnitSphereProd_apply_snd_coe _ _
      _ < l := by simpa using hx.1
      _ ≤ _ := (hb _).1
  have upper : star ρ ⊆ Metric.ball (0:Vn) L := by
    rintro x ⟨hx0,hx⟩
    change (e ⟨x,hx0⟩).2.val < (ρ (e ⟨x,hx0⟩).1).val at hx
    simpa [e] using hx.trans_le (hb _).2
  have hpos : 0 < volume (star ρ) := by
    have h := measure_mono (μ := volume) lower
    rw [measure_sdiff_null (measure_singleton _)] at h
    exact (Metric.measure_ball_pos volume _ hl).trans_le h
  have hfin : volume (star ρ) < ∞ := (measure_mono upper).trans_lt measure_ball_lt_top
  constructor
  simpa [uniformStar, Measure.smul_apply] using ENNReal.inv_mul_cancel hpos.ne' hfin.ne

/-- The radial boundary as the polar-coordinate graph of the radius. -/
def radialBoundary (ρ : Sn → Ray) : Set Vn :=
  (Subtype.val : punctured → Vn) '' ((homeomorphUnitSphereProd Vn) ⁻¹'
    {p : Sn × Ray | p.2 = ρ p.1})

/-- Even a merely measurable radial function has a Lebesgue-null radial boundary. -/
theorem null_radialBoundary {ρ : Sn → Ray} (hρ : Measurable ρ) : volume (radialBoundary ρ) = 0 := by
  let A := {p : Sn × Ray | p.2 = ρ p.1}
  have hA : MeasurableSet A := measurableSet_eq_fun measurable_snd (hρ.comp measurable_fst)
  have hem := MeasurableEmbedding.subtype_coe (measurableSet_singleton (0:Vn)).compl
  unfold radialBoundary
  rw [← hem.comap_apply, (volume : Measure Vn).measurePreserving_homeomorphUnitSphereProd.measure_preimage_emb
    (homeomorphUnitSphereProd Vn).measurableEmbedding A, Measure.prod_apply hA]
  convert lintegral_zero (μ := (volume : Measure Vn).toSphere) using 1
  apply lintegral_congr
  intro w
  change Measure.volumeIoiPow _ {ρ w} = 0
  unfold Measure.volumeIoiPow
  apply withDensity_absolutelyContinuous
  rw [(MeasurableEmbedding.subtype_coe measurableSet_Ioi).comap_apply, Set.image_singleton]
  exact measure_singleton _

def solidStar (ρ : Sn → Ray) : Set Vn := (star ρ ∪ radialBoundary ρ) ∪ {0}

theorem solidStar_ae {ρ : Sn → Ray} (hρ : Measurable ρ) : solidStar ρ =ᵐ[volume] star ρ := by
  have hb := measure_eq_zero_iff_ae_notMem.mp (null_radialBoundary hρ)
  have ho := measure_eq_zero_iff_ae_notMem.mp (measure_singleton (μ := (volume:Measure Vn)) (0:Vn))
  filter_upwards [hb,ho] with x hx hz
  apply propext
  change (x ∈ star ρ ∨ x ∈ radialBoundary ρ) ∨ x ∈ ({0}:Set Vn) ↔ x ∈ star ρ
  tauto

theorem uniform_closed_eq {ρ : Sn → Ray} (hρ : Measurable ρ) :
    (volume (solidStar ρ))⁻¹ • volume.restrict (solidStar ρ) = uniformStar ρ := by
  unfold uniformStar
  rw [Measure.restrict_congr_set (solidStar_ae hρ), measure_congr (solidStar_ae hρ)]

/-- Closed radial intervals really do describe the solid away from the origin. -/
theorem solidStar_polar (ρ : Sn → Ray) (p : Sn × Ray) :
    ((homeomorphUnitSphereProd Vn).symm p).val ∈ solidStar ρ ↔ p.2 ≤ ρ p.1 := by
  let e := homeomorphUnitSphereProd Vn
  have hb : (e.symm p).val ∈ radialBoundary ρ ↔ p.2 = ρ p.1 := by
    constructor
    · rintro ⟨x,hx,heq⟩
      change (e x).2 = ρ (e x).1 at hx
      have h : x = e.symm p := Subtype.ext heq
      simpa only [h,Homeomorph.apply_symm_apply] using hx
    · intro h
      refine ⟨e.symm p, ?_, rfl⟩
      change (e (e.symm p)).2 = ρ (e (e.symm p)).1
      simpa only [Homeomorph.apply_symm_apply] using h
  have hzero : (e.symm p).val ∉ ({0}:Set Vn) := (e.symm p).property
  change ((e.symm p).val ∈ star ρ ∨ (e.symm p).val ∈ radialBoundary ρ) ∨
    (e.symm p).val ∈ ({0}:Set Vn) ↔ _
  rw [hb,star_polar]
  exact (or_iff_left hzero).trans le_iff_lt_or_eq.symm

theorem continuous_star_isProbability {ρ : Sn → Ray} (hc : Continuous ρ) :
    IsProbabilityMeasure (uniformStar ρ) := by
  let : Nonempty Sn := NormedSpace.sphere_nonempty_rclike (𝕜 := ℝ) zero_le_one
  have h : Continuous (fun w => (ρ w).val) := continuous_subtype_val.comp hc
  obtain ⟨a,_,ha⟩ := isCompact_univ.exists_isMinOn (s := (univ : Set Sn)) univ_nonempty h.continuousOn
  obtain ⟨b,_,hb⟩ := isCompact_univ.exists_isMaxOn (s := (univ : Set Sn)) univ_nonempty h.continuousOn
  exact uniformStar_isProbability (ρ a).property (fun w =>
    ⟨isMinOn_univ_iff.mp ha w,isMaxOn_univ_iff.mp hb w⟩)

/-- A continuous positive radial graph, including the origin and boundary, is compact. -/
theorem compact_solidStar {ρ : Sn → Ray} (hc : Continuous ρ) : IsCompact (solidStar ρ) := by
  let J := Icc (0:ℝ) 1
  let sweep := fun p : Sn × J => (p.2.val * (ρ p.1).val) • (p.1.val : Vn)
  have hcont : Continuous sweep := by dsimp [sweep]; fun_prop
  suffices solidStar ρ = range sweep by rw [this]; exact isCompact_range hcont
  ext x
  constructor
  · intro hx
    by_cases hzero : x = 0
    · let w : Sn := (NormedSpace.sphere_nonempty_rclike (𝕜 := ℝ) (E := Vn) zero_le_one).some
      exact ⟨(w, ⟨0,le_rfl,zero_le_one⟩), by simp [sweep,hzero]⟩
    · let y := homeomorphUnitSphereProd Vn ⟨x,hzero⟩
      have he : ((homeomorphUnitSphereProd Vn).symm y).val = x := by
        simp only [y,Homeomorph.symm_apply_apply]
      have hbound := (solidStar_polar ρ y).1 (he.symm ▸ hx)
      let t := y.2.val / (ρ y.1).val
      have ht : t ∈ J := ⟨div_nonneg y.2.2.le (ρ y.1).2.le, (div_le_one (ρ y.1).2).2 hbound⟩
      refine ⟨(y.1,⟨t,ht⟩), ?_⟩
      have hn : (ρ y.1).val ≠ 0 := (show 0 < (ρ y.1).val from (ρ y.1).2).ne'
      simpa [sweep,t,div_mul_cancel₀ _ hn,homeomorphUnitSphereProd_symm_apply_coe] using he
  · rintro ⟨⟨w,t⟩,rfl⟩
    by_cases hz : t.val = 0
    · simp [sweep,hz,solidStar]
    · have ht : 0 < t.val := lt_of_le_of_ne t.property.1 (Ne.symm hz)
      let r : Ray := ⟨t.val * (ρ w).val,mul_pos ht (ρ w).2⟩
      have hr : r ≤ ρ w := by
        change t.val * (ρ w).val ≤ (ρ w).val
        nlinarith [mul_le_mul_of_nonneg_right t.property.2 (ρ w).2.le]
      exact (solidStar_polar ρ (w,r)).2 hr

/-- Antipodal involution on the unit sphere. -/
def antipode (w : Sn) : Sn := ⟨-(w:Vn), by simp⟩

theorem neg_preimage_star {ρ : Sn → Ray} (heven : ∀ w, ρ (antipode w) = ρ w) :
    (Neg.neg : Vn → Vn) ⁻¹' star ρ = star ρ := by
  let e := homeomorphUnitSphereProd Vn
  have H (y : Vn) (hy : y ∈ punctured) :
      y ∈ star ρ ↔ (e ⟨y,hy⟩).2 < ρ (e ⟨y,hy⟩).1 :=
    ⟨fun ⟨_,h⟩ => h,fun h => ⟨hy,h⟩⟩
  ext x
  change -x ∈ star ρ ↔ x ∈ star ρ
  by_cases h0 : x = 0
  · simp [h0]
  have hx : x ∈ punctured := h0
  have hm : -x ∈ punctured := neg_ne_zero.mpr h0
  have hdir : (e ⟨-x,hm⟩).1 = antipode (e ⟨x,hx⟩).1 := by
    apply Subtype.ext
    simp [e,antipode]
  have hrad : (e ⟨-x,hm⟩).2 = (e ⟨x,hx⟩).2 := by
    apply Subtype.ext
    simp [e]
  rw [H _ hm, H _ hx, hdir, hrad, heven]

/-- The actual uniform distribution is invariant under reversal for every even radius. -/
theorem uniformStar_neg {ρ : Sn → Ray} (heven : ∀ w, ρ (antipode w) = ρ w) :
    (uniformStar ρ).map Neg.neg = uniformStar ρ := by
  unfold uniformStar
  rw [Measure.map_smul _ (by fun_prop)]
  congr 1
  have h := measurableEmbedding_neg.restrict_map (volume : Measure Vn) (star ρ)
  have hn : MeasurePreserving (Neg.neg : Vn → Vn) volume volume :=
    (LinearIsometryEquiv.neg ℝ : Vn ≃ₗᵢ[ℝ] Vn).measurePreserving
  rw [hn.map_eq, neg_preimage_star heven] at h
  exact h.symm

/-- A strictly positive angular density gives an actual positive radial function. -/
def positiveRoot (q : Sn → ℝ) (hq : ∀ w, 0 < q w) (w : Sn) : Ray :=
  ⟨(q w)^(((dim:ℝ)+2)⁻¹), Real.rpow_pos_of_pos (hq w) _⟩

theorem positiveRoot_pow (q : Sn → ℝ) (hq : ∀ w, 0 < q w) (w : Sn) :
    (positiveRoot q hq w).val ^ (dim + 2) = q w := by
  change ((q w)^(((dim:ℝ)+2)⁻¹))^(dim+2) = q w
  rw [← Real.rpow_natCast, ← Real.rpow_mul (hq w).le]
  push_cast
  rw [inv_mul_cancel₀ (by positivity), Real.rpow_one]

def cosineTransform (q : Sn → ℝ) (u : Vn) : ℝ :=
  ∫ w : Sn, |⟪u,(w:Vn)⟫| * q w ∂(volume : Measure Vn).toSphere

/-- Realization of the full cosine transform of every strictly positive measurable
angular density by the first moment of one explicitly constructed uniform star.
Constructing a preimage of a prescribed smooth function is a separate question. -/
theorem positive_density_realization {q : Sn → ℝ} (hm : Measurable q) (hq : ∀ w, 0 < q w) (u : Vn) :
    ∫ x, |⟪u,x⟫| ∂uniformStar (positiveRoot q hq) =
      (volume.real (star (positiveRoot q hq)))⁻¹ * (cosineTransform q u / ((dim:ℝ)+2)) := by
  have hr : Measurable (positiveRoot q hq) := by unfold positiveRoot; fun_prop
  rw [uniformStar_abs_moment hr]
  congr 1
  simp only [positiveRoot_pow, ←mul_div_assoc, cosineTransform, integral_div]

/-- Geometric realization, with compactness, probability, reflection invariance,
and every cosine moment for the same closed set. The input is an arbitrary strictly
positive continuous even angular density, not an assumed convex body. -/
theorem solid_uniform_data {q : Sn → ℝ} (hc : Continuous q) (hq : ∀ w, 0 < q w)
    (he : ∀ w, q (antipode w) = q w) :
    let K := solidStar (positiveRoot q hq)
    IsCompact K ∧ IsProbabilityMeasure (ProbabilityTheory.cond volume K) ∧
      (ProbabilityTheory.cond volume K).map Neg.neg = ProbabilityTheory.cond volume K ∧
      ∀ u : Vn, (∫ x, |⟪u,x⟫| ∂ProbabilityTheory.cond volume K) =
        (volume.real K)⁻¹ * (cosineTransform q u / ((dim:ℝ)+2)) := by
  let ρ := positiveRoot q hq
  have hr : Continuous ρ := by
    apply Continuous.subtype_mk
    exact hc.rpow_const (fun w => Or.inl (hq w).ne')
  have hev (w : Sn) : ρ (antipode w) = ρ w := by
    apply Subtype.ext
    simp [ρ,positiveRoot,he]
  have hcond : ProbabilityTheory.cond volume (solidStar ρ) = uniformStar ρ :=
    uniform_closed_eq hr.measurable
  refine ⟨compact_solidStar hr, hcond.symm ▸ continuous_star_isProbability hr, ?_, ?_⟩
  · rw [hcond]
    exact uniformStar_neg hev
  · intro u
    rw [hcond, Measure.real, measure_congr (solidStar_ae hr.measurable)]
    exact positive_density_realization hc.measurable hq u

theorem compact_uniform_realization {q : Sn → ℝ} (hc : Continuous q) (hq : ∀ w, 0 < q w)
    (he : ∀ w, q (antipode w) = q w) :
    ∃ K : Set Vn, IsCompact K ∧ IsProbabilityMeasure (ProbabilityTheory.cond volume K) ∧
      (ProbabilityTheory.cond volume K).map Neg.neg = ProbabilityTheory.cond volume K ∧
      ∀ u : Vn, (∫ x, |⟪u,x⟫| ∂ProbabilityTheory.cond volume K) =
        (volume.real K)⁻¹ * (cosineTransform q u / ((dim:ℝ)+2)) := by
  exact ⟨_, solid_uniform_data hc hq he⟩

#print axioms star_abs_moment
#print axioms real_star_abs_moment
#print axioms uniformStar_abs_moment
#print axioms uniformStar_isProbability
#print axioms null_radialBoundary
#print axioms uniform_closed_eq
#print axioms continuous_star_isProbability
#print axioms compact_solidStar
#print axioms uniformStar_neg
#print axioms solidStar_polar
#print axioms positive_density_realization
#print axioms compact_uniform_realization
end LloydNDPolar
