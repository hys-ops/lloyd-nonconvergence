import NDFrame
import Mathlib.Topology.Sequences
import Mathlib.Tactic
noncomputable section
open Filter Topology Set
namespace LloydNDFrame
variable {m : ℕ}

def equatorL : E m →L[ℝ] E (m+1) := packL.comp ((0 : E m →L[ℝ] ℝ).prod (ContinuousLinearMap.id ℝ _))
@[simp] theorem equatorL_apply (y : E m) : equatorL y = equator y := rfl

/-- Every equatorial unit vector recurs and one iterate leaves the equatorial plane.
Together these force the span of the actual direction sequence to be the full space. -/
theorem span_of_equatorial_limits (u : ℕ → E (m+1))
    (hlim : ∀ w : E m, ‖w‖=1 → MapClusterPt (equator w) atTop u)
    (h0 : head (u 0) ≠ 0) : Submodule.span ℝ (range u) = ⊤ := by
  let S := Submodule.span ℝ (range u)
  have hu (n) : u n ∈ S := Submodule.subset_span (mem_range_self n)
  have hequ (w:E m) (hw:‖w‖=1) : equator w ∈ S := by
    obtain ⟨j,hj,ht⟩ := (hlim w hw).tendsto_subseq
    exact S.closed_of_finiteDimensional.mem_of_tendsto ht (.of_forall (fun n => hu (j n)))
  have heq (y:E m) : equator y ∈ S := by
    by_cases hy : y=0
    · subst y; change equatorL 0 ∈ S; rw [map_zero]; exact S.zero_mem
    have hpos : 0 < ‖y‖ := norm_pos_iff.mpr hy
    have hn : ‖‖y‖⁻¹ • y‖=1 := by rw [norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hpos),inv_mul_cancel₀ hpos.ne']
    have hh := S.smul_mem ‖y‖ (hequ _ hn)
    change ‖y‖ • equatorL (‖y‖⁻¹ • y) ∈ S at hh
    simpa [←map_smul,smul_smul,hpos.ne'] using hh
  apply top_unique
  intro x _
  let coeff := head x / head (u 0)
  let y := x - coeff • u 0
  have hhead : head y = 0 := by
    change headL (x - coeff • u 0) = 0
    rw [map_sub,map_smul,smul_eq_mul,headL_apply,headL_apply]
    dsimp [coeff]
    field_simp <;> ring
  have hy : y ∈ S := by
    have e : equator (tail y) = y := by
      unfold equator
      rw [←hhead,pack_head_tail]
    exact e ▸ heq (tail y)
  have hx := S.add_mem hy (S.smul_mem coeff (hu 0))
  simpa [y] using hx

theorem span_smul_range {u : ℕ → E m} {r : ℕ → ℝ} (hr : ∀ n, r n ≠ 0) :
    Submodule.span ℝ (range (fun n => r n • u n)) = Submodule.span ℝ (range u) := by
  apply le_antisymm <;> apply Submodule.span_le.mpr
  · rintro _ ⟨n,rfl⟩
    exact Submodule.smul_mem _ _ (Submodule.subset_span (mem_range_self n))
  · rintro _ ⟨n,rfl⟩
    let S := Submodule.span ℝ (range (fun n => r n • u n))
    have hp : r n • u n ∈ S := Submodule.subset_span (mem_range_self n)
    simpa [smul_smul,hr] using S.smul_mem (r n)⁻¹ hp
end LloydNDFrame
