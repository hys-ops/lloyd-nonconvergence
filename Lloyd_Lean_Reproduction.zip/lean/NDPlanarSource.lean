import NDPlanarAngles
import NDLimitsOrbit
import SpiralOrbit

/-! In the plane smoothness of the actual directional support forces exact
two-site Lloyd convergence from every nonzero antipodal initialization. -/
noncomputable section
open Filter Set MeasureTheory Function
open scoped ContDiff Topology RealInnerProductSpace
namespace LloydNDPlanar
open LloydNDLimits
abbrev E2 := EuclideanSpace ℝ (Fin 2)

def circle (θ : ℝ) : E2 := WithLp.toLp 2 ![Real.cos θ,Real.sin θ]

theorem norm_circle (θ:ℝ) : ‖circle θ‖ = 1 := by
  have h : ‖circle θ‖^2 = 1 := by
    rw [EuclideanSpace.norm_sq_eq]
    simpa [Fin.sum_univ_two,circle,Real.norm_eq_abs,add_comm] using Real.sin_sq_add_cos_sq θ
  nlinarith [norm_nonneg (circle θ)]

theorem continuous_circle : Continuous circle := by
  apply (PiLp.continuous_toLp _ _).comp
  apply continuous_pi
  intro i
  fin_cases i
  · exact Real.continuous_cos
  · exact Real.continuous_sin

def profile (μ : Measure E2) (θ : ℝ) := populationSupport μ (circle θ)
def lin (v : E2) (θ:ℝ) := v 0 * Real.cos θ + v 1 * Real.sin θ
def linD (v : E2) (θ:ℝ) := -(v 0)*Real.sin θ + v 1 * Real.cos θ

private theorem hasDeriv_lin (v : E2) (t:ℝ) : HasDerivAt (lin v) (linD v t) t := by
  simpa [lin,linD,Pi.add_def] using! ((Real.hasDerivAt_cos t).const_mul (v 0)).add ((Real.hasDerivAt_sin t).const_mul (v 1))
private theorem hasDeriv_linD (v : E2) (t:ℝ) : HasDerivAt (linD v) (-(lin v t)) t := by
  change HasDerivAt (fun y => -(v 0)*Real.sin y + v 1*Real.cos y) _ t
  simpa [lin,linD,neg_add,Pi.add_def,add_comm] using! ((Real.hasDerivAt_sin t).const_mul (-(v 0))).add ((Real.hasDerivAt_cos t).const_mul (v 1))

private theorem inner_eq_lin (v : E2) (θ:ℝ) : ⟪circle θ,v⟫= lin v θ := by
  simp [PiLp.inner_apply,Fin.sum_univ_two,circle,lin,Real.inner_apply]

/-- The first two jets of the support at a direction are controlled by its
actual signed centroid, using its globally supporting linear functional. -/
theorem profile_contact (μ : Measure E2) (hi : Integrable (id:E2→E2) μ)
    (hs : ContDiff ℝ 2 (profile μ)) (θ : ℝ) :
    let h := profile μ
    let v := signedMoment μ (circle θ)
    h θ = lin v θ ∧ deriv h θ = linD v θ ∧ 0 ≤ h θ + deriv (deriv h) θ := by
  let h := profile μ
  let v := signedMoment μ (circle θ)
  change h θ = lin v θ ∧ deriv h θ = linD v θ ∧ _
  have h0 : h θ = lin v θ := (inner_eq_lin v θ ▸ inner_signedMoment μ (circle θ) hi).symm
  have hle (t:ℝ) : lin v t ≤ h t := inner_eq_lin v t ▸ inner_signedMoment_le μ (circle θ) (circle t) hi
  let g := fun t => h t - lin v t
  have hgmin : IsLocalMin g θ := .of_forall (fun t => by change h θ - lin v θ ≤ h t-lin v t; rw [h0,sub_self]; exact sub_nonneg.mpr (hle t))
  have dh : Differentiable ℝ h := hs.differentiable (by norm_num)
  have ddh : Differentiable ℝ (deriv h) := by
    have h2 : ContDiff ℝ (1+1) h := by convert hs using 1 <;> norm_num
    exact h2.deriv'.differentiable (by norm_num)
  have dg (t:ℝ) : HasDerivAt g (deriv h t - linD v t) t := (dh t).hasDerivAt.sub (hasDeriv_lin v t)
  have dg0 := hgmin.deriv_eq_zero
  rw [(dg θ).deriv] at dg0
  refine ⟨h0,sub_eq_zero.mp dg0,?_⟩
  have hdd := second_nonneg hgmin (dg θ).continuousAt
  have dgfun : deriv g = fun t => deriv h t - linD v t := funext (fun t => (dg t).deriv)
  rw [dgfun] at hdd
  change 0 ≤ deriv (deriv h - linD v) θ at hdd
  rw [((ddh θ).hasDerivAt.sub (hasDeriv_linD v θ)).deriv] at hdd
  change 0 ≤ h θ + deriv (deriv h) θ
  linarith

private theorem contact_direction {v : E2} {θ a b : ℝ} (ha : 0<a) (h : a=lin v θ) (hd : b=linD v θ) :
    v = ‖v‖ • circle (θ+Real.arctan (b/a)) := by
  let φ := Real.arctan (b/a)
  have hc : 0 < Real.cos φ := Real.cos_arctan_pos (b/a)
  have hsφ : Real.sin φ = (b/a)*Real.cos φ := by
    simp [φ,Real.sin_arctan,Real.cos_arctan,div_eq_mul_inv]
  have eq0 : a*Real.cos θ-b*Real.sin θ=v 0 := by
    rw [h,hd]; unfold lin linD; nlinarith [congrArg (fun s:ℝ => v 0*s) (Real.sin_sq_add_cos_sq θ)]
  have eq1 : a*Real.sin θ+b*Real.cos θ=v 1 := by
    rw [h,hd]; unfold lin linD; nlinarith [congrArg (fun s:ℝ => v 1*s) (Real.sin_sq_add_cos_sq θ)]
  have eq : v=(a/Real.cos φ) • circle (θ+φ) := by
    ext i; fin_cases i
    · change v 0 = (a/Real.cos φ) * Real.cos (θ+φ)
      rw [←eq0,Real.cos_add,hsφ]; field_simp [ha.ne',hc.ne']
    · change v 1 = (a/Real.cos φ) * Real.sin (θ+φ)
      rw [←eq1,Real.sin_add,hsφ]; field_simp [ha.ne',hc.ne']
  have hn := congrArg norm eq
  rw [norm_smul, norm_circle, mul_one,Real.norm_eq_abs,abs_of_pos (div_pos ha hc)] at hn
  exact hn.symm ▸ eq

/-- The ordinary population iteration converges as an ordered pair. Every
nonzero antipodal initialization in the plane has a positive radius and angle. -/
theorem convergence_angles (μ : Measure E2) [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hsym : MeasurePreserving (fun x : E2 => -x) μ μ) (hi : Integrable (id:E2→E2) μ)
    (hs : ContDiff ℝ 2 (profile μ)) (θ r : ℝ) (hr : 0<r) :
    ∃ y:E2, Tendsto (fun n:ℕ => (LloydProduct.step μ)^[n] (r • circle θ,-(r • circle θ)))
      atTop (𝓝 (y,-y)) := by
  let h := profile μ
  have hp (x:ℝ) : 0 < h x :=
    populationSupport_pos μ _ (no_ties_of_ac μ hac _ (by intro he; simpa [he] using norm_circle x)) hi
  have hperiod : Periodic h (2*Real.pi) := by
    intro x
    change populationSupport μ (circle (x+2*Real.pi)) = _
    congr 1; ext i; fin_cases i <;> simp [circle]
  obtain ⟨t,ht⟩ := angle_convergence hs hp (fun x => (profile_contact μ hi hs x).2.2)
    (by positivity : 0<2*Real.pi) hperiod θ
  let u := fun n:ℕ => circle ((angleStep h)^[n] θ)
  have hsstep (n : ℕ) : signedMoment μ (u n) = ‖signedMoment μ (u n)‖ • u (n+1) := by
    let x := (angleStep h)^[n] θ
    obtain ⟨hv,hv',_⟩ := profile_contact μ hi hs x
    change _ = _ • circle ((angleStep h)^[n+1] θ)
    rw [iterate_succ_apply']
    exact contact_direction (hp x) hv hv'
  obtain ⟨c,_,_,hc⟩ := radial_ascent hac hi (fun n => norm_circle _) hsstep r
  have hu : Tendsto u atTop (𝓝 (circle t)) := continuous_circle.continuousAt.tendsto.comp ht
  have hpairs := (hc.smul hu).prodMk_nhds (hc.smul hu).neg
  refine ⟨c • circle t, hpairs.congr' (.of_forall fun n => ?_)⟩
  exact (orbit_dynamics hsym hac hi (fun n => norm_circle _) hsstep hr n).2.symm

theorem convergence (μ : Measure E2) [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hsym : MeasurePreserving (fun x : E2 => -x) μ μ) (hi : Integrable (id:E2→E2) μ)
    (hs : ContDiff ℝ 2 (profile μ)) (x : E2) (hx : x ≠ 0) :
    ∃ y:E2, Tendsto (fun n:ℕ => (LloydProduct.step μ)^[n] (x,-x)) atTop (𝓝 (y,-y)) := by
  have hr : 0<‖x‖ := norm_pos_iff.mpr hx
  let u := ‖x‖⁻¹ • x
  have un : ‖u‖=1 := by simp [u,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hr),hr.ne']
  have hsqu : (u 0)^2+(u 1)^2=1 := by
    have hh : ‖u‖ ^ 2 = 1 := by rw [un]; norm_num
    rw [EuclideanSpace.norm_sq_eq] at hh
    simpa [Fin.sum_univ_two,Real.norm_eq_abs] using hh
  obtain ⟨θ,hc,hs'⟩ := LloydOrbit.cos_sin_surj hsqu
  have he : circle θ = u := by ext i; fin_cases i <;> simp [circle,hc,hs']
  have he' : ‖x‖ • circle θ = x := by simp [he,u,smul_smul,hr.ne']
  simpa only [he'] using convergence_angles μ hac hsym hi hs θ ‖x‖ hr

#print axioms convergence
end LloydNDPlanar
