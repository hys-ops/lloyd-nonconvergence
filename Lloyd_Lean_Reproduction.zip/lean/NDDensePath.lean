import NDDense
import NDFrame
import NDJetShift
import Mathlib.Analysis.Calculus.Deriv.ZPow
import Mathlib.Analysis.Calculus.ContDiff.Bounds
import Mathlib.Analysis.SpecialFunctions.SmoothTransition
import Mathlib.Analysis.SpecialFunctions.Sqrt

noncomputable section
open Filter Set Topology Real
open scoped ContDiff RealInnerProductSpace
namespace LloydNDDensePath
open LloydNDFrame LloydNDJet
variable {F G:Type*} [NormedAddCommGroup F] [NormedSpace ℝ F] [NormedAddCommGroup G] [NormedSpace ℝ G]

/-- A positive reciprocal at large positive times, with a smooth switch at 4. -/
def height (t:ℝ) : ℝ := Real.smoothTransition (t-4) * t⁻¹
theorem height_eq {t:ℝ} (ht:5 ≤ t) : height t = t⁻¹ := by
  simp [height,Real.smoothTransition.one_of_one_le (show 1 ≤ t-4 by linarith)]
private theorem height_flat {t:ℝ} (ht:t≤4) : height t=0 := by
  simp [height,Real.smoothTransition.zero_of_nonpos (show t-4≤0 by linarith)]
theorem height_range (t:ℝ) : height t ∈ Icc 0 (1/4:ℝ) := by
  by_cases h : t ≤ 4
  · simp [height_flat h]
  · have ht : 0<t := by linarith
    constructor
    · exact mul_nonneg (Real.smoothTransition.nonneg _) (inv_nonneg.mpr ht.le)
    · change Real.smoothTransition (t-4) * t⁻¹ ≤ 1/4
      calc _ ≤ 1*t⁻¹ := mul_le_mul_of_nonneg_right (Real.smoothTransition.le_one _) (by positivity)
           _ ≤ _ := by rw [one_mul,←one_div]; exact one_div_le_one_div_of_le (by norm_num) (by linarith)
private theorem height_smooth : ContDiff ℝ ∞ height := by
  apply contDiff_iff_contDiffAt.mpr
  intro t
  by_cases h : t=0
  · subst t; apply (contDiffAt_const (c:=0)).congr_of_eventuallyEq
    filter_upwards [gt_mem_nhds (show (0:ℝ)<4 by norm_num)] with y hy using height_flat hy.le
  · exact (Real.smoothTransition.contDiff.comp (contDiff_id.sub contDiff_const)).contDiffAt.mul
      (contDiffAt_id.inv h)

theorem height_bounded : BoundedJets height := by
  refine ⟨height_smooth,fun n => ?_⟩
  obtain ⟨C,hC⟩ := (isCompact_Icc (a:=(0:ℝ)) (b:=6)).exists_bound_of_continuousOn
    (height_smooth.continuous_iteratedFDeriv (m:=n) (by simp)).continuousOn
  refine ⟨max C (n.factorial:ℝ), fun t => ?_⟩
  by_cases hl : t<0
  · have hz : height =ᶠ[𝓝 t] fun _ => (0:ℝ) := by
      filter_upwards [gt_mem_nhds (show t<4 by linarith)] with _ hy using height_flat hy.le
    rw [norm_iteratedFDeriv_eq_norm_iteratedDeriv,hz.iteratedDeriv_eq n]
    simp [le_max_iff]
  by_cases hr : 6<t
  · have hz : height =ᶠ[𝓝 t] (Inv.inv : ℝ → ℝ) := by
      filter_upwards [lt_mem_nhds (show 5<t by linarith)] with _ hy using height_eq hy.le
    rw [norm_iteratedFDeriv_eq_norm_iteratedDeriv,hz.iteratedDeriv_eq n,iteratedDeriv_eq_iterate,iter_deriv_inv]
    have hex : (-1-(n:ℤ))= -((n+1:ℕ):ℤ) := by omega
    rw [hex,zpow_neg,zpow_natCast,norm_mul,norm_mul,norm_pow,norm_neg,norm_one,one_pow,one_mul,
      Real.norm_of_nonneg (by positivity : (0:ℝ) ≤ n.factorial),norm_inv,norm_pow]
    apply le_trans _ (le_max_right _ _)
    apply mul_le_of_le_one_right (by positivity)
    apply inv_le_one_of_one_le₀
    exact one_le_pow₀ (by rw [Real.norm_eq_abs,abs_of_pos (show 0<t by linarith)]; linarith)
  exact (hC t ⟨by linarith,by linarith⟩).trans (le_max_left _ _)

private def smallBump : ContDiffBump (0:ℝ) := ⟨1/3,1/2,by norm_num,by norm_num⟩
private def core (s:ℝ) : ℝ := smallBump s*s
private theorem core_abs (s:ℝ) : |core s| ≤ 1/2 := by
  by_cases h : |s| ≤ 1/2
  · rw [core,abs_mul,abs_of_nonneg smallBump.nonneg]
    exact (mul_le_of_le_one_left (abs_nonneg _) smallBump.le_one).trans h
  · have hz : smallBump s=0 := smallBump.zero_of_le_dist (by simpa [smallBump,Real.dist_eq] using (le_of_not_ge h))
    simp [core,hz]
private def roundCoef (s:ℝ) := LloydSpiral.Chart.radial (core s)
private theorem round_smooth : ContDiff ℝ ∞ roundCoef := by
  have hcore : ContDiff ℝ ∞ core := smallBump.contDiff.mul contDiff_id
  apply (contDiff_const.sub (hcore.pow 2)).sqrt
  intro s; have h := abs_le.mp (core_abs s)
  change 1 - core s ^ 2 ≠ 0
  nlinarith [h.1,h.2,mul_nonneg (show 0 ≤ 1/2+core s by linarith [h.1]) (show 0≤1/2-core s by linarith [h.2])]
private theorem round_eq (t:ℝ) : roundCoef (height t) = LloydSpiral.Chart.radial (height t) := by
  have h := height_range t
  have hb : smallBump (height t)=1 := smallBump.one_of_mem_closedBall (by
    rw [Metric.mem_closedBall,Real.dist_eq,sub_zero,abs_of_nonneg h.1]
    change height t ≤ 1/3; linarith [h.2])
  simp [roundCoef,core,hb]

private theorem common_bound (f:ℕ → ℝ) (n:ℕ) :
    ∃ B:ℝ, 1≤B ∧ ∀ j≤n, f j ≤ B := by
  let S := ∑ j ∈ Finset.range (n+1), |f j|
  have hS : 0≤S := Finset.sum_nonneg fun _ _ => abs_nonneg _
  refine ⟨1+S,by linarith,fun j hj => ?_⟩
  have hj' : j ∈ Finset.range (n+1) := Finset.mem_range.mpr (by omega)
  have hh : |f j| ≤ S := Finset.single_le_sum (fun i _ => abs_nonneg (f i)) hj'
  linarith [le_abs_self (f j)]

private theorem compact_comp {f:ℝ → F} {g:F → G} (hf:BoundedJets f) (hg: ContDiff ℝ ∞ g)
    {S:Set F} (hc:IsCompact S) (hr:∀ t, f t ∈ S) : BoundedJets (g ∘ f) := by
  refine ⟨hg.comp hf.1,fun n => ?_⟩
  have eg (j:ℕ) := hc.exists_bound_of_continuousOn (hg.continuous_iteratedFDeriv (m:=j) (by simp)).continuousOn
  choose L hL using eg
  choose M hM using hf.2
  obtain ⟨C,_,hC⟩ := common_bound L n
  obtain ⟨D,hD,hD'⟩ := common_bound M n
  refine ⟨(n.factorial:ℝ)*C*D^n,fun t => norm_iteratedFDeriv_comp_le (n:=n) hg hf.1 (by simp) t ?_ ?_⟩
  · exact fun j hj => (hL j _ (hr t)).trans (hC _ hj)
  · exact fun j hj hj' => (hM j t).trans ((hD' _ hj').trans (le_self_pow₀ hD (by omega)))

private theorem jets_smul {f:ℝ → ℝ} {g:ℝ → F} (hf:BoundedJets f) (hg:BoundedJets g) :
    BoundedJets (fun t => f t • g t) := by
  refine ⟨hf.1.smul hg.1,fun n => ?_⟩
  choose A hA using hf.2
  choose B hB using hg.2
  obtain ⟨C,hC,hA'⟩ := common_bound A n
  obtain ⟨D,hD,hB'⟩ := common_bound B n
  refine ⟨∑ j ∈ Finset.range (n+1), (n.choose j:ℝ)*C*D, fun t => ?_⟩
  apply (norm_iteratedFDeriv_smul_le hf.1 hg.1 t (by simp : (n:ℕ∞ω) ≤ ∞)).trans
  refine Finset.sum_le_sum (fun j h => ?_)
  have hj := Finset.mem_range.mp h
  exact mul_le_mul (mul_le_mul_of_nonneg_left ((hA j t).trans (hA' _ (by omega))) (by positivity))
    ((hB (n-j) t).trans (hB' _ (by omega))) (norm_nonneg _) (by positivity)

private theorem jets_prod {f:ℝ → F} {g:ℝ → G} (hf:BoundedJets f) (hg:BoundedJets g) :
    BoundedJets (fun t => (f t,g t)) := by
  refine ⟨hf.1.prodMk hg.1,fun n => ?_⟩
  obtain ⟨A,hA⟩ := hf.2 n
  obtain ⟨B,hB⟩ := hg.2 n
  refine ⟨max A B,fun t => ?_⟩
  rw [iteratedFDeriv_prodMk hf.1.contDiffAt hg.1.contDiffAt (by simp : (n:ℕ∞ω) ≤ ∞),
    ContinuousMultilinearMap.opNorm_prod]
  exact max_le_max (hA t) (hB t)

private theorem jets_map {f:ℝ → F} (L : F →L[ℝ] G) (hf:BoundedJets f) : BoundedJets (L ∘ f) := by
  refine ⟨L.contDiff.comp hf.1, fun n => ?_⟩
  obtain ⟨C,hC⟩ := hf.2 n
  exact ⟨‖L‖*C, fun t => (L.norm_iteratedFDeriv_comp_left hf.1.contDiffAt (by simp : (n:ℕ∞ω) ≤ ∞)).trans
    (mul_le_mul_of_nonneg_left (hC t) (norm_nonneg _))⟩

def path {m:ℕ} (a:ℝ → E m) (t:ℝ) : E (m+1) := dir (height t) (a t)
theorem path_eq {m:ℕ} (a:ℝ → E m) {t:ℝ} (ht:5≤t) : path a t=dir t⁻¹ (a t) := by
  rw [path,height_eq ht]
theorem path_bounded {m:ℕ} {a:ℝ → E m} (ha:BoundedJets a) : BoundedJets (path a) := by
  have hs := compact_comp height_bounded round_smooth isCompact_Icc height_range
  have h := jets_map (packL (m:=m)) (jets_prod height_bounded (jets_smul hs ha))
  convert h using 1
  funext t; simp [path,dir,Function.comp,round_eq]

theorem path_unit {m:ℕ} {a:ℝ → E m} (ha:∀ t, ‖a t‖=1) (t:ℝ) : ‖path a t‖=1 := by
  apply dir_norm _ (ha t)
  have h := height_range t
  nlinarith [h.1,h.2,mul_nonneg h.1 (sub_nonneg.mpr h.2)]

theorem jets_lipschitz {f:ℝ → F} (hf:BoundedJets f) : ∃ K:NNReal, LipschitzWith K f := by
  obtain ⟨B,hB⟩ := hf.2 1
  refine ⟨⟨B,(norm_nonneg _).trans (hB 0)⟩,lipschitzWith_of_nnnorm_fderiv_le (hf.1.differentiable (by simp)) fun t => ?_⟩
  change ‖fderiv ℝ f t‖ ≤ B
  simpa only [norm_iteratedFDeriv_one] using hB t
theorem exists_path (k:ℕ) :
    ∃ (a:ℝ → E (k+2)) (P:ℝ → E ((k+2)+1)) (K:NNReal),
      BoundedJets a ∧ (∀ t, ‖a t‖=1) ∧ LipschitzWith K a ∧
      (∀ u, ‖u‖=1 → ∃ T:ℕ → ℝ, Tendsto T atTop atTop ∧ Tendsto (a ∘ T) atTop (𝓝 u)) ∧
      BoundedJets P ∧ (∀ t, ‖P t‖=1) ∧ ∀ t, 5≤t → P t=dir t⁻¹ (a t) := by
  obtain ⟨a,hs,hu,hb,ht⟩ := LloydNDDense.exists_curve k
  have ha : BoundedJets a := ⟨hs,hb⟩
  obtain ⟨K,hK⟩ := jets_lipschitz ha
  exact ⟨a,path a,K,ha,hu,hK,ht,path_bounded ha,path_unit hu,fun _ h => path_eq a h⟩

#print axioms exists_path
end LloydNDDensePath
