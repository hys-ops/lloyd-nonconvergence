import GaussianCurvature
import GaussianConservation
import SourceOrbit

/-! The normalized, isotropic Gaussian counterexample with the exact ordinary population
Lloyd orbit and quantitative strong log-concavity for the same probability law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set TopologicalSpace
open scoped RealInnerProductSpace Topology ContDiff SchwartzMap
namespace LloydGaussianExample
open LloydCosine LloydAngular LloydCentroid LloydSpiral.Chart LloydVerification

/-- An isotropic, strongly log-concave, everywhere-positive smooth probability law
agrees with the standard Gaussian outside 1<‖x‖<2 and admits a nonconvergent
exact nearest-cell Lloyd orbit with an entire projective circle of stationary limits. -/
theorem gaussian_counterexample :
    ∃ (ρ : E → ℝ) (δ : ℝ), let μ := LloydGaussian.law ρ
      0 < δ ∧ δ ≤ 1 ∧ (∀ x, 0 < ρ x) ∧ ContDiff ℝ ∞ ρ ∧
      (∀ x, ‖x‖ ∉ Ioo (1:ℝ) 2 → ρ x = LloydGaussian.pdf x) ∧
      (∀ x, ρ (-x) = ρ x) ∧ IsProbabilityMeasure μ ∧ Measure.IsOpenPosMeasure μ ∧
      (∫ x:E, x ∂μ) = 0 ∧ MemLp id 2 μ ∧ covarianceBilin μ = innerSL ℝ ∧
      (∀ x v : E, ‖v‖^2/2 ≤ fderiv ℝ (fderiv ℝ (fun y => -Real.log (ρ y))) x v v) ∧
      HasEquatorialOrbit μ δ := by
  obtain ⟨C,hC,hbase⟩ := LloydGaussian.standard_projection
  obtain ⟨a,F,ha,h1,htF,hFe,hFC⟩ := prescribed_family C
  have hsmall := (LloydGaussianShape.eventually_standard_shell htF).filter_mono
    (nhdsWithin_le_nhds : 𝓝[>] (0:ℝ) ≤ 𝓝 0)
  obtain ⟨t,ht,hpos⟩ := (hsmall.and (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[>] (0:ℝ), t ∈ Ioi 0)).exists
  have htne : t ≠ 0 := ne_of_gt hpos
  have hd := LloydFamily.parameter_pos ha htne
  have hd1 := (LloydFamily.parameter_range ha t).2.le.trans h1
  let A := radialize (F t)
  let ρ := LloydGaussian.density A
  let μ := LloydGaussian.source A
  have hangular : LloydNeutralShell.AngularSmooth A := by
    intro u hu
    apply (schwartz_radialize_smooth (F t)).contDiffAt
    exact away_open.mem_nhds (show u ∈ away by change 1/2 < ‖u‖; rw [hu]; norm_num)
  have he (u:E) (_ : ‖u‖=1) : A (-u)=A u := radialize_even (hFe t) u
  have hp : ∀ x, 0<ρ x := ht.1
  have hp' : ∀ x, 0≤LloydGaussian.density A x := fun x => (hp x).le
  have : IsProbabilityMeasure μ := LloydGaussian.source_probability hangular hp'
  have heven := LloydGaussian.source_neg he
  have hL2 := LloydGaussian.source_L2 hangular hp'
  have hi : Integrable (id:E→E) μ := hL2.integrable (by norm_num)
  have hac := (LloydGaussian.source_mutual_ac hangular hp).1
  have hproj (u:E) (hu : ‖u‖=1) : populationSupport μ u = C*LloydFamily.angular a t u := by
    unfold populationSupport
    conv_lhs => arg 2; ext x; rw [real_inner_comm u x]
    rw [LloydGaussian.source_projection hangular hp',hbase u hu]
    change _ + cosineTransform (fun w => radialize (F t) w.val) u = _
    rw [hFC t u hu]
    ring
  exact ⟨ρ,_,hd,hd1,hp,ht.2.1,ht.2.2.1,LloydGaussian.density_even he,inferInstanceAs
    (IsProbabilityMeasure μ),ht.2.2.2.1,LloydGaussian.source_mean he,hL2,
    LloydGaussian.source_covariance hangular hp' he,ht.2.2.2.2,orbit_of_projection heven hac hi ha h1 htne hC hproj⟩

#print axioms gaussian_counterexample
end LloydGaussianExample
