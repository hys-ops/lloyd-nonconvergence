import LloydOrbit
import Radius
import Mathlib.Topology.Order.MonotoneConvergence

open Filter Topology TopologicalSpace MeasureTheory
open scoped RealInnerProductSpace
open LloydCentroid
namespace LloydVerification
noncomputable section

def radius (μ : Measure LloydOrbit.E) (δ r₀ : ℝ) : ℕ → ℝ
  | 0 => r₀
  | n+1 => ‖signedMoment μ (dir δ n)‖

/-- The actual nearest-site orbit, with a fixed convention on ties. -/
def sites (μ : Measure LloydOrbit.E) (δ r₀ : ℝ) (n : ℕ) : LloydOrbit.E × LloydOrbit.E :=
  (ordinaryStep μ)^[n] (r₀ • dir δ 0, -(r₀ • dir δ 0))

theorem sites_coords {μ : Measure LloydOrbit.E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x : LloydOrbit.E => -x) μ μ)
    (hac : μ ≪ volume) (hi : Integrable (id : LloydOrbit.E → LloydOrbit.E) μ)
    {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hm : MatchesBelt μ δ) {r₀ : ℝ} (h₀ : 0 < r₀) (n : ℕ) :
    0 < radius μ δ r₀ n ∧
    sites μ δ r₀ n = (radius μ δ r₀ n • dir δ n, -(radius μ δ r₀ n • dir δ n)) := by
  induction n with
  | zero => exact ⟨h₀,rfl⟩
  | succ n ih =>
    obtain ⟨hp,hv,hs⟩ := actual_vector hsym hac hi hd hd' hm n ih.1
    refine ⟨hp,?_⟩
    change (ordinaryStep μ)^[n+1] _ = _
    rw [Function.iterate_succ_apply']
    change ordinaryStep μ (sites μ δ r₀ n) = _
    rw [ih.2,hs]
    exact congrArg (fun x : LloydOrbit.E => (x,-x)) hv

/-- Compute the common limiting radius, without assuming convergence or
quantitative approximation of the radius. -/
theorem radius_tendsto {μ : Measure LloydOrbit.E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x : LloydOrbit.E => -x) μ μ)
    (hac : μ ≪ volume) (hi : Integrable (id : LloydOrbit.E → LloydOrbit.E) μ)
    {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hm : MatchesBelt μ δ) (r₀ : ℝ) :
    ∃ c : ℝ, 0 < c ∧ Tendsto (radius μ δ r₀) atTop (𝓝 c) := by
  let H := fun n => populationSupport μ (dir δ n)
  have hbest (n : ℕ) : H n ≤ ‖signedMoment μ (dir δ n)‖ := by
    have h := real_inner_le_norm (dir δ n) (signedMoment μ (dir δ n))
    rwa [inner_signedMoment μ _ hi, dir_norm hd hd',one_mul] at h
  have hnext (n : ℕ) : ‖signedMoment μ (dir δ n)‖ ≤ H (n+1) := by
    have hg := (actual_vector hsym hac hi hd hd' hm n (r:=1) zero_lt_one).2.1
    have h := inner_signedMoment_le μ (dir δ n) (dir δ (n+1)) hi
    conv at h => lhs; rw [hg, real_inner_smul_right, real_inner_self_eq_norm_sq,dir_norm hd hd',one_pow,mul_one]
    exact h
  have hmono : Monotone H := monotone_nat_of_le_succ (fun n => (hbest n).trans (hnext n))
  have hbound : BddAbove (Set.range H) :=
    ⟨_, by rintro _ ⟨n,rfl⟩; exact (hbest n).trans (norm_signedMoment_le μ _)⟩
  let c : ℝ := ⨆ n, H n
  have hlim : Tendsto H atTop (𝓝 c) := tendsto_atTop_ciSup hmono hbound
  have h0 : dir δ 0 ≠ 0 := fun hh => by have hn := dir_norm hd hd' 0; rw [hh,norm_zero] at hn; norm_num at hn
  have hc : 0 < c := (populationSupport_pos μ _ (no_ties_of_ac μ hac _ h0) hi).trans_le (le_ciSup hbound 0)
  refine ⟨c,hc,(tendsto_add_atTop_iff_nat 1).1 ?_⟩
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le hlim (hlim.comp (tendsto_add_atTop_nat 1)) hbest hnext

/-- The only specialized input is the scalar support fit on the belt. -/
theorem actual_orbit_of_scalar_support {μ : Measure LloydOrbit.E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x : LloydOrbit.E => -x) μ μ)
    (hac : μ ≪ volume) (hi : Integrable (id : LloydOrbit.E → LloydOrbit.E) μ)
    {δ : ℝ} (hd : 0 < δ) (hd' : δ ≤ 1) (hm : MatchesBelt μ δ) {r₀ : ℝ} (h₀ : 0 < r₀) :
    ∃ c : ℝ, 0 < c ∧
    (∀ K : NonemptyCompacts LloydOrbit.E, MapClusterPt K atTop (fun n => unlabel (sites μ δ r₀ n))
      ↔ ∃ θ : ℝ, K = LloydOrbit.antipodes (c • LloydOrbit.equator θ)) ∧
    ¬∃ K, Tendsto (fun n => unlabel (sites μ δ r₀ n)) atTop (𝓝 K) := by
  obtain ⟨c,hc,hr⟩ := radius_tendsto hsym hac hi hd hd' hm r₀
  have heq : (fun n => unlabel (sites μ δ r₀ n)) =
      (fun n => LloydOrbit.antipodes (radius μ δ r₀ n • dir δ n)) := by
    funext n
    rw [(sites_coords hsym hac hi hd hd' hm h₀ n).2]
    rfl
  rw [heq]
  exact ⟨c,hc,axis_limits hd hd' hr hc⟩

#print axioms actual_orbit_of_scalar_support
end
end LloydVerification
