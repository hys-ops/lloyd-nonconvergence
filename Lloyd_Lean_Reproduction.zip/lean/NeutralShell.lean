import FrequencyAnnulus
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-! Exact smooth signed shell with prescribed first radial moment and neutral
zeroth and second moments for three-dimensional ambient volume. -/
noncomputable section
open MeasureTheory Set
open scoped Topology ContDiff
namespace LloydNeutralShell

def radMoment (k : ℕ) (b : ℝ → ℝ) : ℝ := ∫ r in Ioi (0:ℝ), r^k * b r

/-- Narrow base bump and geometric dilations 1, 5/4, 25/16 keep all
three radial pieces strictly inside the prescribed annulus (1,2). -/
private def bump : ContDiffBump (6/5:ℝ) := ⟨1/50,1/25,by norm_num,by norm_num⟩

private theorem bump_low (s : ℝ) (hs : s ≤ 29/25) : bump s = 0 := by
  apply bump.zero_of_le_dist
  change 1/25 ≤ |s-6/5|
  rw [abs_of_neg (by linarith)]
  linarith

private theorem bump_high (s : ℝ) (hs : 31/25 ≤ s) : bump s = 0 := by
  apply bump.zero_of_le_dist
  change 1/25 ≤ |s-6/5|
  rw [abs_of_pos (by linarith)]
  linarith

private def base (k : ℕ) (r : ℝ) : ℝ := r^k * bump r

private theorem base_int (k : ℕ) : Integrable (base k) :=
  ((continuous_id.pow k).mul bump.continuous).integrable_of_hasCompactSupport
    bump.hasCompactSupport.mul_left

theorem moment_dilate (k : ℕ) {a : ℝ} (ha : 0<a) (b : ℝ → ℝ) :
    radMoment k (fun r => b (a⁻¹*r)) = a^(k+1)*radMoment k b := by
  have h (r:ℝ) : r^k*b (a⁻¹*r) = a^k*((a⁻¹*r)^k*b (a⁻¹*r)) := by
    rw [mul_pow, ←mul_assoc, ←mul_assoc, ←mul_pow, mul_inv_cancel₀ ha.ne',one_pow,one_mul]
  unfold radMoment
  simp_rw [h]
  rw [integral_const_mul]
  have h' := integral_comp_mul_left_Ioi (fun s => s^k*b s) 0 (inv_pos.mpr ha)
  simp only [inv_inv,mul_zero,smul_eq_mul] at h'
  rw [h',pow_succ,mul_assoc]

private theorem dilate_int (k : ℕ) {a : ℝ} (ha : 0<a) :
    Integrable (fun r : ℝ => r^k*bump (a⁻¹*r)) := by
  have hi := ((integrable_comp_mul_left_iff (base k) (inv_ne_zero ha.ne')).mpr
    (base_int k)).const_mul (a^k)
  convert hi using 1
  funext r
  dsimp [base]
  rw [mul_pow, ←mul_assoc, ←mul_assoc, ←mul_pow, mul_inv_cancel₀ ha.ne',one_pow,one_mul]

private def raw (r : ℝ) :=
  (5125/1024)*bump ((5/4:ℝ)⁻¹*r) -
    (390625/65536)*bump r - bump ((25/16:ℝ)⁻¹*r)

private theorem raw_moment (k : ℕ) :
    radMoment k raw = ((5125/1024)*(5/4:ℝ)^(k+1)-(390625/65536)-(25/16:ℝ)^(k+1))*radMoment k bump := by
  have hi := (dilate_int k (a:=5/4) (by norm_num)).integrableOn (s:=Ioi 0)
  have hj := (dilate_int k (a:=25/16) (by norm_num)).integrableOn (s:=Ioi 0)
  have hk := (base_int k).integrableOn (s:=Ioi 0)
  change IntegrableOn (fun x:ℝ => x^k*bump x) (Ioi 0) at hk
  have hsub : IntegrableOn (fun x:ℝ => (5125/1024)*(x^k*bump ((5/4)⁻¹*x))-
      (390625/65536)*(x^k*bump x)) (Ioi 0) := (hi.const_mul (5125/1024)).sub (hk.const_mul (390625/65536))
  have hw (r : ℝ) : r^k*raw r =
      ((5125/1024)*(r^k*bump ((5/4)⁻¹*r))-(390625/65536)*(r^k*bump r))-
        r^k*bump ((25/16)⁻¹*r) := by unfold raw;ring
  unfold radMoment at *
  simp_rw [hw]
  rw [integral_sub hsub hj,
    integral_sub (hi.const_mul (5125/1024)) (hk.const_mul (390625/65536)),integral_const_mul,integral_const_mul]
  change (5125/1024)*radMoment k _-(390625/65536)*radMoment k _-radMoment k _ = _
  rw [moment_dilate k (a:=5/4) (by norm_num),moment_dilate k (a:=25/16) (by norm_num)]
  unfold radMoment
  ring

private theorem third_pos : 0 < radMoment 3 bump := by
  unfold radMoment
  rw [setIntegral_eq_integral_of_forall_compl_eq_zero (fun r hr => by
    have : r < 1 := by change ¬0<r at hr;linarith
    rw [bump_low r (by linarith), mul_zero])]
  apply integral_pos_of_integrable_nonneg_nonzero (x:=(6/5:ℝ))
    ((continuous_id.pow 3).mul bump.continuous) (base_int 3)
  · intro x
    change 0 ≤ x^3*bump x
    by_cases h : x<1
    · rw [bump_low x (by linarith),mul_zero]
    · exact mul_nonneg (pow_nonneg (by linarith) _) bump.nonneg
  · change (6/5:ℝ)^3*bump (6/5)≠0
    rw [show bump (6/5:ℝ) = 1 from bump.one_of_mem_closedBall (by simp [bump])]
    norm_num

private def weight := ((78125/262144)*radMoment 3 bump)⁻¹
def shell (r : ℝ) : ℝ := weight*raw r

theorem shell_moments :
    radMoment 2 shell = 0 ∧ radMoment 3 shell = 1 ∧ radMoment 4 shell = 0 := by
  have h (k:ℕ) : radMoment k shell = weight * radMoment k raw := by
    unfold radMoment shell
    rw [←integral_const_mul]
    congr 1;funext r;ring
  rw [h,h,h,raw_moment,raw_moment,raw_moment]
  norm_num [weight]
  field_simp [third_pos.ne']

theorem shell_smooth : ContDiff ℝ ∞ shell := by
  have h : ContDiff ℝ ∞ (bump : ℝ → ℝ) := bump.contDiff
  unfold shell raw
  fun_prop

theorem shell_zero_low {r : ℝ} (h : r≤1) : shell r=0 := by
  simp only [shell,raw,bump_low r (by linarith),
    bump_low ((5/4)⁻¹*r) (by norm_num;linarith),
    bump_low ((25/16)⁻¹*r) (by norm_num;linarith),mul_zero,sub_self]

theorem shell_zero_high {r : ℝ} (h : 2≤r) : shell r=0 := by
  simp only [shell,raw,bump_high r (by linarith),
    bump_high ((5/4)⁻¹*r) (by norm_num;linarith),
    bump_high ((25/16)⁻¹*r) (by norm_num;linarith),mul_zero,sub_self]

theorem shell_low (r : ℝ) (h : r<1) : shell r=0 := shell_zero_low h.le

theorem shell_high (r : ℝ) (h : 2<r) : shell r=0 := shell_zero_high h.le

#print axioms shell_moments
#print axioms shell_smooth
#print axioms shell_zero_high
end LloydNeutralShell
