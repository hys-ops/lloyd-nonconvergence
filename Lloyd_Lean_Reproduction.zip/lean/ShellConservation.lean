import NeutralShell
import Cosine

/-! The neutral shell changes the absolute axial moment by a prescribed spherical
cosine transform while preserving total mass and every bilinear second moment. -/
noncomputable section
open MeasureTheory Set
open scoped Topology ContDiff RealInnerProductSpace ENNReal
namespace LloydNeutralShell
open LloydCosine

def spatial (a : E → ℝ) : E → ℝ := LloydFrequency.profile a shell

abbrev AngularSmooth (a : E → ℝ) := ∀ w, ‖w‖=1 → ContDiffAt ℝ ∞ a w

theorem spatial_smooth {a : E → ℝ} (ha : AngularSmooth a) : ContDiff ℝ ∞ (spatial a) :=
  LloydFrequency.profile_smooth zero_lt_one ha shell_smooth shell_low

theorem spatial_compact (a : E → ℝ) : HasCompactSupport (spatial a) :=
  LloydFrequency.profile_compact shell_high

theorem spatial_even {a : E → ℝ} (he : ∀ w, ‖w‖=1 → a (-w)=a w) :
    ∀ x, spatial a (-x)=spatial a x := LloydFrequency.profile_even he

private theorem spatial_ray (a : E → ℝ) (w : S) (t : Ray) :
    spatial a (t.val • w.val) = shell t.val * a w.val := by
  have hw : ‖w.val‖=1 := by simp
  have ht : 0 < t.val := t.property
  simp [spatial,LloydFrequency.profile,norm_smul,Real.norm_eq_abs,hw,abs_of_pos ht,
    smul_smul,inv_mul_cancel₀ ht.ne']

theorem spatial_integrable {a : E → ℝ} (ha : AngularSmooth a) {p : E → ℝ} (hc : Continuous p) :
    Integrable (fun x => p x * spatial a x) :=
  (hc.mul (spatial_smooth ha).continuous).integrable_of_hasCompactSupport (spatial_compact a).mul_left

private theorem radial_integral (n : ℕ) :
    (∫ t : Ray, t.val^n*shell t.val ∂Measure.volumeIoiPow 2) = radMoment (n+2) shell := by
  unfold Measure.volumeIoiPow radMoment
  rw [integral_withDensity_eq_integral_toReal_smul (by fun_prop) (by simp)]
  rw [← integral_subtype_comap (μ := (volume : Measure ℝ)) measurableSet_Ioi]
  apply integral_congr_ae
  filter_upwards [] with t
  simp only [ENNReal.toReal_ofReal (sq_nonneg t.val),smul_eq_mul,pow_add]
  ring

/-- Applies to any continuous positively homogeneous scalar probe. -/
theorem homogeneous_moment {a : E → ℝ} (ha : AngularSmooth a) (p : E → ℝ)
    (hc : Continuous p) (n : ℕ) (hhom : ∀ r : ℝ, 0 < r → ∀ x, p (r • x)=r^n*p x) :
    (∫ x:E, p x * spatial a x) =
      radMoment (n+2) shell * ∫ w:S, p w.val*a w.val ∂(volume:Measure E).toSphere := by
  let e := homeomorphUnitSphereProd E
  let h := fun x:E => p x * spatial a x
  let g := fun v:S × Ray => h (e.symm v).val
  have rank : Module.finrank ℝ E - 1 = 2 := by simp [E]
  have hsub : Integrable (fun y : punctured => h y.val) (volume.comap Subtype.val) :=
    (integrableOn_iff_comap_subtypeVal (measurableSet_singleton _).compl).1
      (spatial_integrable ha hc).integrableOn
  have hg : Integrable g ((volume : Measure E).toSphere.prod (Measure.volumeIoiPow 2)) := by
    rw [← rank]
    apply ((volume : Measure E).measurePreserving_homeomorphUnitSphereProd.integrable_comp_emb
      e.measurableEmbedding).mp
    change Integrable (fun y : punctured => h (e.symm (e y)).val) _
    simpa only [Homeomorph.symm_apply_apply] using hsub
  calc
    _ = ∫ y : punctured, h y.val ∂(volume.comap Subtype.val) := by
      rw [integral_subtype_comap (measurableSet_singleton _).compl, restrict_compl_singleton]
    _ = ∫ y : punctured, g (e y) ∂(volume.comap Subtype.val) := by simp [g]
    _ = ∫ v, g v ∂((volume:Measure E).toSphere.prod (Measure.volumeIoiPow 2)) := by
      simpa [rank] using (volume:Measure E).measurePreserving_homeomorphUnitSphereProd.integral_comp
        e.measurableEmbedding g
    _ = _ := by
      rw [integral_prod g hg,←integral_const_mul]
      apply integral_congr_ae
      filter_upwards [] with w
      rw [←radial_integral,←integral_mul_const]
      apply integral_congr_ae
      filter_upwards [] with t
      change p (t.val • w.val)*spatial a (t.val • w.val) = _
      rw [hhom t.val t.2,spatial_ray]
      ring

theorem mass_zero {a : E → ℝ} (ha : AngularSmooth a) :
    (∫ x, spatial a x)=0 := by
  simpa [shell_moments.1] using
    homogeneous_moment ha (fun _=>1) continuous_const 0 (fun r hr x=>by simp)

theorem second_moment_zero {a : E → ℝ} (ha : AngularSmooth a) (u v:E) :
    (∫ x, (⟪u,x⟫*⟪v,x⟫)*spatial a x)=0 := by
  have h := homogeneous_moment ha (fun x => ⟪u,x⟫*⟪v,x⟫) (by fun_prop) 2
    (fun r hr x=>by simp only [real_inner_smul_right];ring)
  simpa [shell_moments.2.2] using h

theorem projection_moment {a : E → ℝ} (ha : AngularSmooth a) (u:E) :
    (∫ x, |⟪u,x⟫| * spatial a x)=cosineTransform (fun w=>a w.val) u := by
  have h := homogeneous_moment ha (fun x=> |⟪u,x⟫|) (by fun_prop) 1
    (fun r hr x=>by simp [real_inner_smul_right,abs_mul,abs_of_pos hr])
  simpa [shell_moments.2.1,cosineTransform] using h

#print axioms homogeneous_moment
#print axioms mass_zero
#print axioms second_moment_zero
#print axioms projection_moment
end LloydNeutralShell
