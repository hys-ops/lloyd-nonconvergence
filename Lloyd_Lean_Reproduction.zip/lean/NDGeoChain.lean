import NDGeoJets
open Filter Set MeasureTheory
open scoped Topology SchwartzMap ContDiff
noncomputable section
namespace LloydNDGeom
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => E dim

/-- A smooth scalar change of variable preserves uniform smallness of the first
two derivatives of a global perturbation. -/
theorem global_C2_change {ι : Type*} {l : Filter ι} {F : ι → Vn → ℝ}
    (hF : ∀ i, ContDiff ℝ ∞ (F i))
    (hsmall : ∀ j ≤ 2, ∀ η : ℝ, 0 < η →
      ∀ᶠ i in l, ∀ x, ‖iteratedFDeriv ℝ j (F i) x‖ < η)
    {g : ℝ → ℝ} {T : Set ℝ} (hT : IsOpen T) (h0 : (0:ℝ) ∈ T)
    (hg : ContDiffOn ℝ ∞ g T) (hg0 : g 0 = 0) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in l, ContDiff ℝ ∞ (g ∘ F i) ∧ ∀ j ≤ 2, ∀ x,
      ‖iteratedFDeriv ℝ j (g ∘ F i) x‖ < ε := by
  have hval {s : Set ℝ} (hs : s ∈ 𝓝 0) : ∀ᶠ i in l, ∀ x, F i x ∈ s := by
    obtain ⟨r,hr,hsub⟩ := Metric.mem_nhds_iff.1 hs
    filter_upwards [hsmall 0 (by decide) r hr] with i hi x
    apply hsub
    simpa only [Metric.mem_ball,dist_zero_right,norm_iteratedFDeriv_zero] using hi x
  have hgAt := hg.contDiffAt (hT.mem_nhds h0)
  have hmem := hval (hT.mem_nhds h0)
  have hev : {x : ℝ | ‖g x‖ < ε} ∈ 𝓝 0 := hgAt.continuousAt.norm.tendsto.eventually_lt_const (by simpa [hg0])
  let C := 1 + ∑ j ∈ Finset.range 3, ‖iteratedFDeriv ℝ j g 0‖
  have hC : 0 < C := by dsimp [C]; positivity
  have hbound (j : ℕ) (hj : j ∈ Finset.range 3) :
      {x : ℝ | ‖iteratedFDeriv ℝ j g x‖ < C} ∈ 𝓝 0 := by
    apply ((hgAt.continuousAt_iteratedFDeriv (k:=j) (by simp)).norm.tendsto).eventually_lt_const
    have hl := Finset.single_le_sum (f := fun j => ‖iteratedFDeriv ℝ j g 0‖)
      (fun j _ => norm_nonneg _) hj
    dsimp [C]
    linarith
  let D := min (1:ℝ) (ε/(4*C))
  have hD : 0<D := lt_min zero_lt_one (div_pos hε (by positivity))
  have hD1 : D≤1 := min_le_left _ _
  have hDe : 2*C*D < ε := by
    have he := (le_div_iff₀ (by positivity : 0<4*C)).mp (min_le_right 1 (ε/(4*C)))
    dsimp [D]; linarith
  have eB := (eventually_all_finset (Finset.range 3)).2 (fun j hj => hval (hbound j hj))
  have eD := (eventually_all_finset (Finset.range 3)).2 (fun j hj =>
    hsmall j (by have := Finset.mem_range.mp hj; omega) (D^j) (pow_pos hD _))
  filter_upwards [hmem,hval hev,eB,eD] with i hi hv hB hD'
  refine ⟨contDiff_iff_contDiffAt.mpr (fun x => (hg.contDiffAt (hT.mem_nhds (hi x))).comp x (hF i).contDiffAt),?_⟩
  intro j hj x
  have step := norm_iteratedFDeriv_comp_le' (g:=g) (f:=F i) (n:=j) (C:=C) (D:=D)
    (show range (F i) ⊆ T from fun y hy => by rcases hy with ⟨x,rfl⟩; exact hi x)
    hT.uniqueDiffOn hg (hF i) (by simp) x
    (fun k hk => by
      rw [iteratedFDerivWithin_of_isOpen _ hT (hi x)]
      exact (hB k (Finset.mem_range.mpr (by omega)) x).le)
    (fun k _ hk => (hD' k (Finset.mem_range.mpr (by omega)) x).le)
  interval_cases j
  · simpa only [norm_iteratedFDeriv_zero,Function.comp_apply] using hv x
  · refine step.trans_lt ?_
    norm_num
    nlinarith [mul_pos hC hD]
  · refine step.trans_lt ?_
    norm_num [Nat.factorial]
    nlinarith [mul_nonneg (mul_nonneg hC.le hD.le) (sub_nonneg.mpr hD1)]
end LloydNDGeom
