import NDScalar
import NDAngular
import NDFourierRange

/-! Uniform-source realization of smooth even one-parameter directional profiles
in every positive Euclidean dimension. The radial function itself is exhibited. -/
noncomputable section
open MeasureTheory Filter Set
open scoped RealInnerProductSpace Topology SchwartzMap ContDiff
namespace LloydND
open LloydNDPolar LloydNDAngular
variable {k : ℕ}
local notation "Vn" => E k
local notation "Sn" => S k

theorem uniform_realization (h : ℝ × Vn → ℝ) (hs : LloydNDFrequency.SmoothOnDirections h)
    (he : ∀ t (u:Vn), ‖u‖ = 1 → h (t,-u) = h (t,u))
    (hz : ∀ u:Vn, ‖u‖ = 1 → h (0,u) = 1) :
    ∀ᶠ t in 𝓝 (0:ℝ), ∃ (r : Sn → Ray) (c : ℝ),
      0<c ∧ Continuous r ∧ IsCompact (solidStar r) ∧
      IsProbabilityMeasure (ProbabilityTheory.cond volume (solidStar r)) ∧
      ∀ u:Vn, ‖u‖ = 1 →
        (∫ x, |⟪u,x⟫| ∂ProbabilityTheory.cond volume (solidStar r)) = c*h (t,u) := by
  obtain ⟨A,hA,hbase⟩ := constant_cosine_sphere (dim:=k)
  let H := fun p : ℝ × Vn => A * (h p - 1)
  have hsm : LloydNDFrequency.SmoothOnDirections H :=
    fun p hp => contDiffAt_const.mul ((hs p hp).sub contDiffAt_const)
  have h0 : ∀ u:Vn, ‖u‖=1 → H (0,u)=0 := by intro u hu; simp [H,hz u hu]
  have hev (t:ℝ) (u:Vn) (hu:‖u‖=1) : H (t,-u)=H (t,u) := by simp [H,he t u hu]
  let F := fun t => LloydNDFourierRange.rightInverse (fun u => H (t,u)) (LloydNDFrequency.slice_smooth hsm t)
  have hF : Tendsto F (𝓝 0) (𝓝 0) := LloydNDFourierRange.rightInverse_tendsto hsm h0
  filter_upwards [eventually_C2_small hF (k+1) zero_lt_one] with t small
  have spec := LloydNDFourierRange.rightInverse_spec (LloydNDFrequency.slice_smooth hsm t) (hev t)
  let q := fun w:Sn => 1 + radialize (F t) w.val
  have hq : Continuous q := continuous_const.add (sphere_radialize_continuous _)
  have hp (w:Sn) : 0 < q w := by
    have hw : w.val ∈ away := by change 1/2 < ‖w.val‖; norm_num
    have ha := (small w.val hw).1
    change |radialize (F t) w.val| < 1 at ha
    dsimp [q]; linarith [(abs_lt.mp ha).1]
  have hqe (w:Sn) : q (antipode w) = q w := by
    dsimp [q,antipode]
    rw [radialize_even spec.1]
  let r := positiveRoot q hp
  let K := solidStar r
  have hc : Continuous r := Continuous.subtype_mk (hq.rpow_const (fun w => Or.inl (hp w).ne')) _
  obtain ⟨hK,hprob,_,hm⟩ := solid_uniform_data hq hp hqe
  have hv : volume K ≠ 0 := by
    intro hh
    have hzero : ProbabilityTheory.cond volume K = 0 := ProbabilityTheory.cond_eq_zero_of_meas_eq_zero hh
    exact @IsProbabilityMeasure.ne_zero _ _ (ProbabilityTheory.cond volume K) hprob hzero
  have hvr : 0< volume.real K := ENNReal.toReal_pos hv hK.measure_lt_top.ne
  refine ⟨r,(volume.real K)⁻¹*(A/((k:ℝ)+2)),by positivity,hc,hK,hprob,?_⟩
  intro u hu
  rw [hm]
  change _ * (cosineTransform (fun w => 1+radialize (F t) w.val) u / _) = _
  rw [cosine_add_const (sphere_radialize_continuous _) 1,hbase u hu,schwartz_cosine]
  have hh := spec.2 u hu
  change (∫ x:Vn, |⟪x,u⟫| * F t x) = A*(h (t,u)-1) at hh
  conv_lhs => arg 2; lhs; rhs; arg 2; ext x; rw [real_inner_comm x u]
  rw [hh]; ring

#print axioms uniform_realization
end LloydND
