import NDLimitsRadius
import NDProduct
import Mathlib.Topology.Order.MonotoneConvergence

/-! In any finite Euclidean dimension, giving the successor directions determines the
actual Lloyd configurations. Their radial limit is obtained by ascent. Stationarity of
all accumulation sites follows from equality in the support estimate at a limit. -/

noncomputable section
open Filter Topology TopologicalSpace MeasureTheory Set
open scoped RealInnerProductSpace
namespace LloydNDLimits
variable {d : ℕ}
local notation "E" => EuclideanSpace ℝ (Fin d)

def axis (x : E) : NonemptyCompacts E := LloydProduct.unordered (x,-x)

theorem continuous_axis : Continuous (axis : E → NonemptyCompacts E) :=
  NonemptyCompacts.continuous_singleton.sup
    (NonemptyCompacts.continuous_singleton.comp continuous_neg)

def orbitRadius (μ : Measure E) (u : ℕ → E) (r₀ : ℝ) : ℕ → ℝ
  | 0 => r₀
  | n+1 => ‖signedMoment μ (u n)‖

def orbitSites (μ : Measure E) (u : ℕ → E) (r₀ : ℝ) (n : ℕ) : E × E :=
  (LloydProduct.step μ)^[n] (r₀ • u 0, -(r₀ • u 0))

private theorem nz_of_unit {u : E} (hu : ‖u‖=1) : u ≠ 0 := by
  intro h
  simpa [h] using hu

theorem orbit_dynamics {μ : Measure E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x:E => -x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {u : ℕ → E} (hu : ∀ n, ‖u n‖=1)
    (hstep : ∀ n, signedMoment μ (u n) = ‖signedMoment μ (u n)‖ • u (n+1))
    {r₀ : ℝ} (hr : 0<r₀) (n : ℕ) :
    0 < orbitRadius μ u r₀ n ∧
      orbitSites μ u r₀ n =
        (orbitRadius μ u r₀ n • u n, -(orbitRadius μ u r₀ n • u n)) := by
  induction n with
  | zero => exact ⟨hr,rfl⟩
  | succ n hn =>
    have ht := no_ties_of_ac μ hac (u n) (nz_of_unit (hu n))
    have hp := populationSupport_pos μ (u n) ht hi
    have hle := real_inner_le_norm (u n) (signedMoment μ (u n))
    rw [inner_signedMoment μ _ hi,hu,one_mul] at hle
    refine ⟨hp.trans_le hle,?_⟩
    change (LloydProduct.step μ)^[n+1] _ = _
    rw [Function.iterate_succ_apply']
    change LloydProduct.step μ (orbitSites μ u r₀ n) = _
    rw [hn.2]
    change update μ _ = _
    rw [(reflection_update μ (u n) hn.1 hsym ht hi).2.2]
    exact congrArg (fun x : E => (x,-x)) (hstep n)

theorem radial_ascent {μ : Measure E} [IsProbabilityMeasure μ]
    (hac : μ ≪ volume) (hi : Integrable (id:E→E) μ) {u : ℕ → E}
    (hu : ∀ n, ‖u n‖=1)
    (hstep : ∀ n, signedMoment μ (u n) = ‖signedMoment μ (u n)‖ • u (n+1))
    (r₀ : ℝ) :
    ∃ c : ℝ, 0<c ∧ Tendsto (fun n => populationSupport μ (u n)) atTop (𝓝 c) ∧
      Tendsto (orbitRadius μ u r₀) atTop (𝓝 c) := by
  let H := fun n => populationSupport μ (u n)
  have lo (n : ℕ) : H n ≤ ‖signedMoment μ (u n)‖ := by
    have h := real_inner_le_norm (u n) (signedMoment μ (u n))
    rwa [inner_signedMoment μ _ hi,hu,one_mul] at h
  have up (n : ℕ) : ‖signedMoment μ (u n)‖ ≤ H (n+1) := by
    have h := inner_signedMoment_le μ (u n) (u (n+1)) hi
    conv at h => lhs; rw [hstep,real_inner_smul_right,real_inner_self_eq_norm_sq,hu,one_pow,mul_one]
    exact h
  have hm : Monotone H := monotone_nat_of_le_succ (fun n => (lo n).trans (up n))
  have hb : BddAbove (range H) := ⟨_,by rintro _ ⟨n,rfl⟩; exact (lo n).trans (norm_signedMoment_le μ _)⟩
  let c := ⨆ n, H n
  have hc : Tendsto H atTop (𝓝 c) := tendsto_atTop_ciSup hm hb
  refine ⟨c,(populationSupport_pos μ _ (no_ties_of_ac μ hac _ (nz_of_unit (hu 0))) hi).trans_le
      (le_ciSup hb 0), hc, (tendsto_add_atTop_iff_nat 1).1 ?_⟩
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le hc (hc.comp (tendsto_add_atTop_nat 1)) lo up

theorem axis_limits {u : ℕ → E} (hu : ∀ n, ‖u n‖=1)
    {B : Set E} (hB : ∀ v, MapClusterPt v atTop u ↔ v ∈ B)
    {r : ℕ → ℝ} {c : ℝ} (hr : Tendsto r atTop (𝓝 c)) (K : NonemptyCompacts E) :
    MapClusterPt K atTop (fun n => axis (r n • u n)) ↔ ∃ v ∈ B, K = axis (c • v) := by
  constructor
  · intro hK
    obtain ⟨k,hk,h₁⟩ := hK.tendsto_subseq
    have bound (j : ℕ) : u (k j) ∈ Metric.sphere (0:E) 1 := by simp [Metric.mem_sphere,hu]
    obtain ⟨v,_,j,hj,h₂⟩ := (isCompact_sphere (0:E) 1).tendsto_subseq bound
    have hkj := hk.tendsto_atTop.comp hj.tendsto_atTop
    refine ⟨v,(hB v).mp (h₂.mapClusterPt.of_comp hkj),tendsto_nhds_unique (h₁.comp hj.tendsto_atTop) ?_⟩
    exact continuous_axis.continuousAt.tendsto.comp ((hr.comp hkj).smul h₂)
  · rintro ⟨v,hv,rfl⟩
    obtain ⟨k,hk,hv'⟩ := ((hB v).mpr hv).tendsto_subseq
    exact (continuous_axis.continuousAt.tendsto.comp ((hr.comp hk.tendsto_atTop).smul hv')).mapClusterPt.of_comp hk.tendsto_atTop

theorem stationary_at_cluster {μ : Measure E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x:E => -x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {u : ℕ → E} (hu : ∀ n, ‖u n‖=1)
    {c r₀ : ℝ} (hc : 0<c) (hH : Tendsto (fun n => populationSupport μ (u n)) atTop (𝓝 c))
    (hr : Tendsto (orbitRadius μ u r₀) atTop (𝓝 c))
    {v : E} (hv : MapClusterPt v atTop u) :
    signedMoment μ v = c • v ∧ LloydProduct.step μ (c • v,-(c • v)) = (c • v,-(c • v)) := by
  obtain ⟨k,hk,hv'⟩ := hv.tendsto_subseq
  have hvn : ‖v‖=1 := tendsto_nhds_unique hv'.norm (by simpa [Function.comp_def,hu] using
      (tendsto_const_nhds (x:=(1:ℝ)) : Tendsto (fun _:ℕ => (1:ℝ)) atTop (𝓝 1)))
  have ht := no_ties_of_ac μ hac v (nz_of_unit hvn)
  have hvH := (signedMoment_hasGradientAt μ v ht hi).continuousAt.tendsto.comp hv'
  have hval : populationSupport μ v = c := tendsto_nhds_unique hvH (hH.comp hk.tendsto_atTop)
  have hM := (continuousAt_signedMoment μ v hi ht).tendsto.comp hv'
  have hnorm : ‖signedMoment μ v‖ = c := tendsto_nhds_unique hM.norm
    (hr.comp ((tendsto_add_atTop_nat 1).comp hk.tendsto_atTop))
  have hi' := (inner_signedMoment μ v hi).trans hval
  have hdist := norm_sub_sq_real (signedMoment μ v) (c • v)
  rw [real_inner_smul_right,real_inner_comm v (signedMoment μ v),hi',norm_smul,hvn,hnorm,Real.norm_eq_abs,abs_of_pos hc,mul_one] at hdist
  have hzero : ‖signedMoment μ v - c • v‖=0 := by nlinarith [sq_nonneg (‖signedMoment μ v - c • v‖)]
  have he : signedMoment μ v = c • v := sub_eq_zero.mp (norm_eq_zero.mp hzero)
  exact ⟨he,by change update μ _ = _; rw [(reflection_update μ v hc hsym ht hi).2.2,he]⟩

theorem exact_orbit {μ : Measure E} [IsProbabilityMeasure μ]
    (hsym : MeasurePreserving (fun x:E => -x) μ μ) (hac : μ ≪ volume)
    (hi : Integrable (id:E→E) μ) {u : ℕ → E} (hu : ∀ n, ‖u n‖=1)
    (hstep : ∀ n, signedMoment μ (u n) = ‖signedMoment μ (u n)‖ • u (n+1))
    {B : Set E} (hB : ∀ v, MapClusterPt v atTop u ↔ v ∈ B)
    {r₀ : ℝ} (hr : 0<r₀) :
    ∃ c : ℝ, 0<c ∧
      (∀ K : NonemptyCompacts E,
        MapClusterPt K atTop (fun n => LloydProduct.unordered (orbitSites μ u r₀ n)) ↔
        ∃ v ∈ B, K = axis (c • v)) ∧
      (∀ v ∈ B, LloydProduct.step μ (c • v,-(c • v)) = (c • v,-(c • v))) := by
  obtain ⟨c,hc,hH,hrc⟩ := radial_ascent hac hi hu hstep r₀
  refine ⟨c,hc,?_, fun v hv => (stationary_at_cluster hsym hac hi hu hc hH hrc ((hB v).mpr hv)).2⟩
  have hs : (fun n => LloydProduct.unordered (orbitSites μ u r₀ n)) =
      fun n => axis (orbitRadius μ u r₀ n • u n) := by
    funext n
    rw [(orbit_dynamics hsym hac hi hu hstep hr n).2]
    rfl
  intro K
  rw [hs]
  exact axis_limits hu hB hrc K

#print axioms exact_orbit
end LloydNDLimits
