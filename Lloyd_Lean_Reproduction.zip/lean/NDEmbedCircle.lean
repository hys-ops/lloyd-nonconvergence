import NDEmbedFrame
open Filter Topology TopologicalSpace Set
noncomputable section
namespace LloydNDEmbed
open LloydNDFrame (E)

/-- Exact oriented subsequential limits before the radial and unordered quotients. -/
theorem embedded_direction_limits (k : ℕ) {δ : ℝ} (hd : 0<δ) (h1 : δ≤1) (v : E (k+3)) :
    MapClusterPt v atTop (fun n => extend k (LloydVerification.dir δ n)) ↔
      ∃ θ, extend k (LloydOrbit.equator θ)=v := by
  let z := LloydHeight.height δ
  let a := LloydHeight.phase δ
  have hz := LloydHeight.height_tendsto_zero hd h1
  change MapClusterPt v atTop (fun n => extend k (LloydOrbit.direction (z n) (a n))) ↔ _
  constructor
  · intro hv
    obtain ⟨j,hj,hv'⟩ := hv.tendsto_subseq
    let xy := fun n => (Real.cos (a (j n)), Real.sin (a (j n)))
    have hxy : ∀ n, xy n ∈ (Icc (-1:ℝ) 1 ×ˢ Icc (-1:ℝ) 1) :=
      fun n => ⟨⟨Real.neg_one_le_cos _,Real.cos_le_one _⟩,⟨Real.neg_one_le_sin _,Real.sin_le_one _⟩⟩
    obtain ⟨b,_,l,hl,hb⟩ := (isCompact_Icc.prod isCompact_Icc).tendsto_subseq hxy
    have hc : Tendsto (fun n => Real.cos (a (j (l n)))) atTop (𝓝 b.1) := continuous_fst.continuousAt.tendsto.comp hb
    have hs : Tendsto (fun n => Real.sin (a (j (l n)))) atTop (𝓝 b.2) := continuous_snd.continuousAt.tendsto.comp hb
    have ht := (hc.pow 2).add (hs.pow 2)
    simp only [Real.cos_sq_add_sin_sq] at ht
    obtain ⟨θ,ht1,ht2⟩ := LloydOrbit.cos_sin_surj (tendsto_nhds_unique ht tendsto_const_nhds)
    refine ⟨θ,tendsto_nhds_unique ?_ (hv'.comp hl.tendsto_atTop)⟩
    exact (extend k).continuous.continuousAt.tendsto.comp (LloydOrbit.tendsto_direction
      ((hz.comp hj.tendsto_atTop).comp hl.tendsto_atTop) (ht1 ▸ hc) (ht2 ▸ hs))
  · rintro ⟨θ,rfl⟩
    obtain ⟨j,hj,hc,hs⟩ := LloydCrossing.trig_crossing a (LloydHeight.phase_tendsto_atTop hd h1)
      (LloydHeight.phase_step_tendsto_zero hd h1) θ
    exact ((extend k).continuous.continuousAt.tendsto.comp (LloydOrbit.tendsto_direction
      (hz.comp hj) hc hs)).mapClusterPt.of_comp hj
end LloydNDEmbed
