import Mathlib.MeasureTheory.Constructions.HaarToSphere
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Normed.Lp.MeasurableSpace
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.Probability.ConditionalProbability
import Mathlib.Tactic

open MeasureTheory Set
open scoped ENNReal RealInnerProductSpace
noncomputable section

namespace LloydCosine
abbrev E := EuclideanSpace ℝ (Fin 3)
abbrev S := Metric.sphere (0 : E) 1
abbrev Ray := Ioi (0 : ℝ)
abbrev punctured := ({0}ᶜ : Set E)

lemma density_radial_succ (n : ℕ) :
    (Measure.volumeIoiPow n).withDensity (fun t : Ray => ENNReal.ofReal t.val) =
      Measure.volumeIoiPow (n+1) := by
  unfold Measure.volumeIoiPow
  rw [← withDensity_mul _ (by fun_prop) (by fun_prop)]
  congr 1
  ext t
  simp [pow_succ, ENNReal.ofReal_mul (pow_nonneg t.2.le n)]

lemma radial_first_moment (r : Ray) :
    ∫⁻ t in Iio r, ENNReal.ofReal t.val ∂(Measure.volumeIoiPow 2) =
      ENNReal.ofReal (r.val^4 / 4) := by
  rw [← withDensity_apply _ measurableSet_Iio, density_radial_succ, Measure.volumeIoiPow_apply_Iio]
  norm_num

/-- Open radial star domain. Its negligible origin can be added without changing a moment. -/
def star (ρ : S → Ray) : Set E := {x | ∃ hx : x ∈ punctured,
  ((homeomorphUnitSphereProd E) ⟨x,hx⟩).2 < ρ ((homeomorphUnitSphereProd E) ⟨x,hx⟩).1}

lemma star_polar (ρ : S → Ray) (p : S × Ray) :
    (↑((homeomorphUnitSphereProd E).symm p) : E) ∈ star ρ ↔ p.2 < ρ p.1 := by
  constructor
  · rintro ⟨h, hh⟩
    change ((homeomorphUnitSphereProd E) ((homeomorphUnitSphereProd E).symm p)).2 <
      ρ ((homeomorphUnitSphereProd E) ((homeomorphUnitSphereProd E).symm p)).1 at hh
    simpa only [Homeomorph.apply_symm_apply] using hh
  · intro h
    refine ⟨((homeomorphUnitSphereProd E).symm p).2, ?_⟩
    change ((homeomorphUnitSphereProd E) ((homeomorphUnitSphereProd E).symm p)).2 <
      ρ ((homeomorphUnitSphereProd E) ((homeomorphUnitSphereProd E).symm p)).1
    simpa only [Homeomorph.apply_symm_apply] using h

lemma measurableSet_star {ρ : S → Ray} (hρ : Measurable ρ) : MeasurableSet (star ρ) := by
  let e := homeomorphUnitSphereProd E
  have eq : star ρ = (Subtype.val : punctured → E) ''
      (e ⁻¹' {p : S × Ray | p.2 < ρ p.1}) := by
    ext x
    constructor
    · rintro ⟨hx,h⟩
      exact ⟨⟨x,hx⟩,h,rfl⟩
    · rintro ⟨⟨x,hx⟩,h,rfl⟩
      exact ⟨hx,h⟩
  rw [eq]
  exact (MeasurableEmbedding.subtype_coe (measurableSet_singleton _).compl).measurableSet_image'
    (e.measurable (measurableSet_lt measurable_snd (hρ.comp measurable_fst)))

/-- The unnormalised cosine moment of Lebesgue measure restricted to the star
domain is the sphere cosine transform of the fourth power of its radial function. -/
theorem star_abs_moment {ρ : S → Ray} (hρ : Measurable ρ) (u : E) :
    ∫⁻ x in star ρ, ENNReal.ofReal |⟪u,x⟫| =
      ∫⁻ w : S, ENNReal.ofReal |⟪u,(w:E)⟫| * ENNReal.ofReal ((ρ w).val^4 / 4)
        ∂(volume : Measure E).toSphere := by
  classical
  let e := homeomorphUnitSphereProd E
  let f := (star ρ).indicator (fun x : E => ENNReal.ofReal |⟪u,x⟫|)
  let g := fun p : S × Ray => if p.2 < ρ p.1 then
    ENNReal.ofReal |⟪u,(p.1:E)⟫| * ENNReal.ofReal p.2.val else 0
  have hg : Measurable g := by
    dsimp [g]
    exact Measurable.ite (measurableSet_lt measurable_snd (hρ.comp measurable_fst))
      (by fun_prop) measurable_const
  have eval (p : S × Ray) : f ((e.symm p).val) = g p := by
    by_cases h : p.2 < ρ p.1
    · rw [show f ((e.symm p).val) = ENNReal.ofReal |⟪u,((e.symm p).val)⟫| from
          Set.indicator_of_mem ((star_polar ρ p).2 h) _]
      have hpos : 0 < p.2.val := p.2.property
      simp [g, h, e, real_inner_smul_right, abs_mul, abs_of_pos hpos, ENNReal.ofReal_mul hpos.le, mul_comm]
    · rw [show f ((e.symm p).val) = 0 from
          Set.indicator_of_notMem (mt (star_polar ρ p).1 h) _]
      simp [g,h]
  have rank : Module.finrank ℝ E - 1 = 2 := by simp [E]
  rw [← lintegral_indicator (measurableSet_star hρ)]
  change (∫⁻ x, f x) = _
  calc
    _ = ∫⁻ x : punctured, f x.val ∂(volume.comap Subtype.val) := by
      rw [lintegral_subtype_comap (measurableSet_singleton _).compl, restrict_compl_singleton]
    _ = ∫⁻ x : punctured, g (e x) ∂(volume.comap Subtype.val) := by
      apply lintegral_congr
      intro x
      simpa using eval (e x)
    _ = ∫⁻ p, g p ∂((volume : Measure E).toSphere.prod (Measure.volumeIoiPow 2)) := by
      simpa [rank] using
        (volume : Measure E).measurePreserving_homeomorphUnitSphereProd.lintegral_comp_emb
          e.measurableEmbedding g
    _ = _ := by
      rw [lintegral_prod g hg.aemeasurable]
      apply lintegral_congr
      intro w
      change (∫⁻ t : Ray, (if t < ρ w then _ else 0) ∂(Measure.volumeIoiPow 2)) = _
      rw [show (fun t : Ray => if t < ρ w then ENNReal.ofReal |⟪u,(w:E)⟫| *
          ENNReal.ofReal t.val else 0) = (Iio (ρ w)).indicator
            (fun t : Ray => ENNReal.ofReal |⟪u,(w:E)⟫| * ENNReal.ofReal t.val) from rfl,
        lintegral_indicator measurableSet_Iio, lintegral_const_mul _ (by fun_prop), radial_first_moment]

/-- Real-valued first moment. Smooth positive bounded radial functions are included. -/
theorem real_star_abs_moment {ρ : S → Ray} (hρ : Measurable ρ) (u : E) :
    ∫ x in star ρ, |⟪u,x⟫| =
      ∫ w : S, |⟪u,(w:E)⟫| * ((ρ w).val^4 / 4) ∂(volume : Measure E).toSphere := by
  have h := congrArg ENNReal.toReal (star_abs_moment hρ u)
  have hm : Measurable (fun w : S => ENNReal.ofReal |⟪u,(w:E)⟫| *
      ENNReal.ofReal ((ρ w).val ^ 4 / 4)) := by fun_prop
  rw [← integral_toReal (by fun_prop) (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top),
    ← integral_toReal hm.aemeasurable (Filter.Eventually.of_forall fun _ =>
      ENNReal.mul_lt_top ENNReal.ofReal_lt_top ENNReal.ofReal_lt_top)] at h
  have hn (w : S) : 0 ≤ (ρ w).val ^ 4 / 4 := by positivity
  simpa only [ENNReal.toReal_mul, ENNReal.toReal_ofReal (abs_nonneg _),
    ENNReal.toReal_ofReal (hn _)] using h

/-- Uniform measure obtained by normalising Lebesgue measure on the open radial body. -/
def uniformStar (ρ : S → Ray) : Measure E :=
  (volume (star ρ))⁻¹ • volume.restrict (star ρ)

/-- Exact normalization of the radial cosine transform for the population expectation. -/
theorem uniformStar_abs_moment {ρ : S → Ray} (hρ : Measurable ρ) (u : E) :
    ∫ x, |⟪u,x⟫| ∂uniformStar ρ =
      (volume.real (star ρ))⁻¹ * ∫ w : S, |⟪u,(w:E)⟫| * ((ρ w).val^4 / 4)
        ∂(volume : Measure E).toSphere := by
  rw [uniformStar, integral_smul_measure, real_star_abs_moment hρ]
  simp [Measure.real, smul_eq_mul]

/-- A positive inner radius and finite outer radius suffice for genuine probability normalization. -/
theorem uniformStar_isProbability {ρ : S → Ray} {l L : ℝ} (hl : 0 < l)
    (hb : ∀ w, l ≤ (ρ w).val ∧ (ρ w).val ≤ L) : IsProbabilityMeasure (uniformStar ρ) := by
  let e := homeomorphUnitSphereProd E
  have lower : Metric.ball (0:E) l \ {0} ⊆ star ρ := by
    intro x hx
    have hx0 : x ∈ punctured := hx.2
    refine ⟨hx0, ?_⟩
    change (e ⟨x,hx0⟩).2.val < (ρ (e ⟨x,hx0⟩).1).val
    calc
      _ = ‖x‖ := homeomorphUnitSphereProd_apply_snd_coe _ _
      _ < l := by simpa using hx.1
      _ ≤ _ := (hb _).1
  have upper : star ρ ⊆ Metric.ball (0:E) L := by
    rintro x ⟨hx0,hx⟩
    change (e ⟨x,hx0⟩).2.val < (ρ (e ⟨x,hx0⟩).1).val at hx
    simpa [e] using hx.trans_le (hb _).2
  have hpos : 0 < volume (star ρ) := by
    have h := measure_mono (μ := volume) lower
    rw [measure_sdiff_null (measure_singleton _)] at h
    exact (Metric.measure_ball_pos volume _ hl).trans_le h
  have hfin : volume (star ρ) < ∞ := (measure_mono upper).trans_lt measure_ball_lt_top
  constructor
  simpa [uniformStar, Measure.smul_apply] using ENNReal.inv_mul_cancel hpos.ne' hfin.ne

/-- The radial boundary as the polar-coordinate graph of the radius. -/
def radialBoundary (ρ : S → Ray) : Set E :=
  (Subtype.val : punctured → E) '' ((homeomorphUnitSphereProd E) ⁻¹'
    {p : S × Ray | p.2 = ρ p.1})

/-- Even a merely measurable radial function has a Lebesgue-null radial boundary. -/
theorem null_radialBoundary {ρ : S → Ray} (hρ : Measurable ρ) : volume (radialBoundary ρ) = 0 := by
  let A := {p : S × Ray | p.2 = ρ p.1}
  have hA : MeasurableSet A := measurableSet_eq_fun measurable_snd (hρ.comp measurable_fst)
  have hem := MeasurableEmbedding.subtype_coe (measurableSet_singleton (0:E)).compl
  unfold radialBoundary
  rw [← hem.comap_apply, (volume : Measure E).measurePreserving_homeomorphUnitSphereProd.measure_preimage_emb
    (homeomorphUnitSphereProd E).measurableEmbedding A, Measure.prod_apply hA]
  convert lintegral_zero (μ := (volume : Measure E).toSphere) using 1
  apply lintegral_congr
  intro w
  change Measure.volumeIoiPow _ {ρ w} = 0
  unfold Measure.volumeIoiPow
  apply withDensity_absolutelyContinuous
  rw [(MeasurableEmbedding.subtype_coe measurableSet_Ioi).comap_apply, Set.image_singleton]
  exact measure_singleton _

def solidStar (ρ : S → Ray) : Set E := (star ρ ∪ radialBoundary ρ) ∪ {0}

theorem solidStar_ae {ρ : S → Ray} (hρ : Measurable ρ) : solidStar ρ =ᵐ[volume] star ρ := by
  have hb := measure_eq_zero_iff_ae_notMem.mp (null_radialBoundary hρ)
  have ho := measure_eq_zero_iff_ae_notMem.mp (measure_singleton (μ := (volume:Measure E)) (0:E))
  filter_upwards [hb,ho] with x hx hz
  apply propext
  change (x ∈ star ρ ∨ x ∈ radialBoundary ρ) ∨ x ∈ ({0}:Set E) ↔ x ∈ star ρ
  tauto

theorem uniform_closed_eq {ρ : S → Ray} (hρ : Measurable ρ) :
    (volume (solidStar ρ))⁻¹ • volume.restrict (solidStar ρ) = uniformStar ρ := by
  unfold uniformStar
  rw [Measure.restrict_congr_set (solidStar_ae hρ), measure_congr (solidStar_ae hρ)]

/-- Closed radial intervals really do describe the solid away from the origin. -/
theorem solidStar_polar (ρ : S → Ray) (p : S × Ray) :
    ((homeomorphUnitSphereProd E).symm p).val ∈ solidStar ρ ↔ p.2 ≤ ρ p.1 := by
  let e := homeomorphUnitSphereProd E
  have hb : (e.symm p).val ∈ radialBoundary ρ ↔ p.2 = ρ p.1 := by
    constructor
    · rintro ⟨x,hx,heq⟩
      change (e x).2 = ρ (e x).1 at hx
      have h : x = e.symm p := Subtype.ext heq
      simpa only [h,Homeomorph.apply_symm_apply] using hx
    · intro h
      refine ⟨e.symm p, ?_, rfl⟩
      change (e (e.symm p)).2 = ρ (e (e.symm p)).1
      simpa only [Homeomorph.apply_symm_apply] using h
  have hzero : (e.symm p).val ∉ ({0}:Set E) := (e.symm p).property
  change ((e.symm p).val ∈ star ρ ∨ (e.symm p).val ∈ radialBoundary ρ) ∨
    (e.symm p).val ∈ ({0}:Set E) ↔ _
  rw [hb,star_polar]
  exact (or_iff_left hzero).trans le_iff_lt_or_eq.symm

theorem continuous_star_isProbability {ρ : S → Ray} (hc : Continuous ρ) :
    IsProbabilityMeasure (uniformStar ρ) := by
  let : Nonempty S := NormedSpace.sphere_nonempty_rclike (𝕜 := ℝ) zero_le_one
  have h : Continuous (fun w => (ρ w).val) := continuous_subtype_val.comp hc
  obtain ⟨a,_,ha⟩ := isCompact_univ.exists_isMinOn (s := (univ : Set S)) univ_nonempty h.continuousOn
  obtain ⟨b,_,hb⟩ := isCompact_univ.exists_isMaxOn (s := (univ : Set S)) univ_nonempty h.continuousOn
  exact uniformStar_isProbability (ρ a).property (fun w =>
    ⟨isMinOn_univ_iff.mp ha w,isMaxOn_univ_iff.mp hb w⟩)

/-- A continuous positive radial graph, including the origin and boundary, is compact. -/
theorem compact_solidStar {ρ : S → Ray} (hc : Continuous ρ) : IsCompact (solidStar ρ) := by
  let J := Icc (0:ℝ) 1
  let sweep := fun p : S × J => (p.2.val * (ρ p.1).val) • (p.1.val : E)
  have hcont : Continuous sweep := by dsimp [sweep]; fun_prop
  suffices solidStar ρ = range sweep by rw [this]; exact isCompact_range hcont
  ext x
  constructor
  · intro hx
    by_cases hzero : x = 0
    · let w : S := (NormedSpace.sphere_nonempty_rclike (𝕜 := ℝ) (E := E) zero_le_one).some
      exact ⟨(w, ⟨0,le_rfl,zero_le_one⟩), by simp [sweep,hzero]⟩
    · let y := homeomorphUnitSphereProd E ⟨x,hzero⟩
      have he : ((homeomorphUnitSphereProd E).symm y).val = x := by
        simp only [y,Homeomorph.symm_apply_apply]
      have hbound := (solidStar_polar ρ y).1 (he.symm ▸ hx)
      let t := y.2.val / (ρ y.1).val
      have ht : t ∈ J := ⟨div_nonneg y.2.2.le (ρ y.1).2.le, (div_le_one (ρ y.1).2).2 hbound⟩
      refine ⟨(y.1,⟨t,ht⟩), ?_⟩
      have hn : (ρ y.1).val ≠ 0 := (show 0 < (ρ y.1).val from (ρ y.1).2).ne'
      simpa [sweep,t,div_mul_cancel₀ _ hn,homeomorphUnitSphereProd_symm_apply_coe] using he
  · rintro ⟨⟨w,t⟩,rfl⟩
    by_cases hz : t.val = 0
    · simp [sweep,hz,solidStar]
    · have ht : 0 < t.val := lt_of_le_of_ne t.property.1 (Ne.symm hz)
      let r : Ray := ⟨t.val * (ρ w).val,mul_pos ht (ρ w).2⟩
      have hr : r ≤ ρ w := by
        change t.val * (ρ w).val ≤ (ρ w).val
        nlinarith [mul_le_mul_of_nonneg_right t.property.2 (ρ w).2.le]
      exact (solidStar_polar ρ (w,r)).2 hr

/-- Antipodal involution on the unit sphere. -/
def antipode (w : S) : S := ⟨-(w:E), by simp⟩

theorem neg_preimage_star {ρ : S → Ray} (heven : ∀ w, ρ (antipode w) = ρ w) :
    (Neg.neg : E → E) ⁻¹' star ρ = star ρ := by
  let e := homeomorphUnitSphereProd E
  have H (y : E) (hy : y ∈ punctured) :
      y ∈ star ρ ↔ (e ⟨y,hy⟩).2 < ρ (e ⟨y,hy⟩).1 :=
    ⟨fun ⟨_,h⟩ => h,fun h => ⟨hy,h⟩⟩
  ext x
  change -x ∈ star ρ ↔ x ∈ star ρ
  by_cases h0 : x = 0
  · simp [h0]
  have hx : x ∈ punctured := h0
  have hm : -x ∈ punctured := neg_ne_zero.mpr h0
  have hdir : (e ⟨-x,hm⟩).1 = antipode (e ⟨x,hx⟩).1 := by
    apply Subtype.ext
    simp [e,antipode]
  have hrad : (e ⟨-x,hm⟩).2 = (e ⟨x,hx⟩).2 := by
    apply Subtype.ext
    simp [e]
  rw [H _ hm, H _ hx, hdir, hrad, heven]

/-- The actual uniform distribution is invariant under reversal for every even radius. -/
theorem uniformStar_neg {ρ : S → Ray} (heven : ∀ w, ρ (antipode w) = ρ w) :
    (uniformStar ρ).map Neg.neg = uniformStar ρ := by
  unfold uniformStar
  rw [Measure.map_smul _ (by fun_prop)]
  congr 1
  have h := measurableEmbedding_neg.restrict_map (volume : Measure E) (star ρ)
  have hn : MeasurePreserving (Neg.neg : E → E) volume volume :=
    (LinearIsometryEquiv.neg ℝ : E ≃ₗᵢ[ℝ] E).measurePreserving
  rw [hn.map_eq, neg_preimage_star heven] at h
  exact h.symm

/-- A strictly positive angular density gives an actual positive radial function. -/
def fourthRoot (q : S → ℝ) (hq : ∀ w, 0 < q w) (w : S) : Ray :=
  ⟨√(√(q w)), Real.sqrt_pos.2 (Real.sqrt_pos.2 (hq w))⟩

theorem fourthRoot_pow (q : S → ℝ) (hq : ∀ w, 0 < q w) (w : S) :
    (fourthRoot q hq w).val ^ 4 = q w := by
  change (√(√(q w))) ^ 4 = q w
  rw [show 4 = 2 * 2 by decide, pow_mul, Real.sq_sqrt (Real.sqrt_nonneg _),
    Real.sq_sqrt (hq w).le]

def cosineTransform (q : S → ℝ) (u : E) : ℝ :=
  ∫ w : S, |⟪u,(w:E)⟫| * q w ∂(volume : Measure E).toSphere

/-- Realization of the full cosine transform of every strictly positive measurable
angular density by the first moment of one explicitly constructed uniform star.
Constructing a preimage of a prescribed smooth function is a separate question. -/
theorem positive_density_realization {q : S → ℝ} (hm : Measurable q) (hq : ∀ w, 0 < q w) (u : E) :
    ∫ x, |⟪u,x⟫| ∂uniformStar (fourthRoot q hq) =
      (volume.real (star (fourthRoot q hq)))⁻¹ * (cosineTransform q u / 4) := by
  have hr : Measurable (fourthRoot q hq) := by unfold fourthRoot; fun_prop
  rw [uniformStar_abs_moment hr]
  congr 1
  simp only [fourthRoot_pow, ←mul_div_assoc, cosineTransform, integral_div]

/-- Geometric realization, with compactness, probability, reflection invariance,
and every cosine moment for the same closed set. The input is an arbitrary strictly
positive continuous even angular density, not an assumed convex body. -/
theorem solid_uniform_data {q : S → ℝ} (hc : Continuous q) (hq : ∀ w, 0 < q w)
    (he : ∀ w, q (antipode w) = q w) :
    let K := solidStar (fourthRoot q hq)
    IsCompact K ∧ IsProbabilityMeasure (ProbabilityTheory.cond volume K) ∧
      (ProbabilityTheory.cond volume K).map Neg.neg = ProbabilityTheory.cond volume K ∧
      ∀ u : E, (∫ x, |⟪u,x⟫| ∂ProbabilityTheory.cond volume K) =
        (volume.real K)⁻¹ * (cosineTransform q u / 4) := by
  let ρ := fourthRoot q hq
  have hr : Continuous ρ := by
    apply Continuous.subtype_mk
    exact Real.continuous_sqrt.comp (Real.continuous_sqrt.comp hc)
  have hev (w : S) : ρ (antipode w) = ρ w := by
    apply Subtype.ext
    simp [ρ,fourthRoot,he]
  have hcond : ProbabilityTheory.cond volume (solidStar ρ) = uniformStar ρ :=
    uniform_closed_eq hr.measurable
  refine ⟨compact_solidStar hr, hcond.symm ▸ continuous_star_isProbability hr, ?_, ?_⟩
  · rw [hcond]
    exact uniformStar_neg hev
  · intro u
    rw [hcond, Measure.real, measure_congr (solidStar_ae hr.measurable)]
    exact positive_density_realization hc.measurable hq u

theorem compact_uniform_realization {q : S → ℝ} (hc : Continuous q) (hq : ∀ w, 0 < q w)
    (he : ∀ w, q (antipode w) = q w) :
    ∃ K : Set E, IsCompact K ∧ IsProbabilityMeasure (ProbabilityTheory.cond volume K) ∧
      (ProbabilityTheory.cond volume K).map Neg.neg = ProbabilityTheory.cond volume K ∧
      ∀ u : E, (∫ x, |⟪u,x⟫| ∂ProbabilityTheory.cond volume K) =
        (volume.real K)⁻¹ * (cosineTransform q u / 4) := by
  exact ⟨_, solid_uniform_data hc hq he⟩

#print axioms star_abs_moment
#print axioms real_star_abs_moment
#print axioms uniformStar_abs_moment
#print axioms uniformStar_isProbability
#print axioms null_radialBoundary
#print axioms uniform_closed_eq
#print axioms continuous_star_isProbability
#print axioms compact_solidStar
#print axioms uniformStar_neg
#print axioms solidStar_polar
#print axioms positive_density_realization
#print axioms compact_uniform_realization
end LloydCosine
