import NDGaussBalanced

/-! On the real line, every nonzero antipodal initialization is stationary
after its first exact population Lloyd update. -/
noncomputable section
open Filter Set MeasureTheory
open scoped RealInnerProductSpace ENNReal Topology
namespace LloydNDLine
open LloydNDLimits
abbrev E1 := EuclideanSpace ℝ (Fin 1)

/-- No angular smoothness is needed in one dimension. The same ordered
configuration occurs at every positive time. -/
theorem one_step (μ : Measure E1) [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hsym : MeasurePreserving (fun x:E1 => -x) μ μ) (hi : Integrable (id:E1→E1) μ)
    (x : E1) (hx : x≠0) :
    ∃ v : E1, v≠0 ∧
      LloydProduct.step μ (x,-x) = (v,-v) ∧ LloydProduct.step μ (v,-v) = (v,-v) ∧
      ∀ n : ℕ, (LloydProduct.step μ)^[n+1] (x,-x) = (v,-v) := by
  let v := signedMoment μ x
  have ht := no_ties_of_ac μ hac x hx
  have hp := populationSupport_pos μ x ht hi
  have hin : 0 < ⟪x,v⟫ := (inner_signedMoment μ x hi).symm ▸ hp
  have hc : 0 < v 0 * x 0 := by simpa [PiLp.inner_apply,Fin.sum_univ_one,Real.inner_apply] using hin
  have hxo : x 0 ≠ 0 := by intro h; simp [h] at hc
  let r := v 0 / x 0
  have hr : 0<r := by
    rcases mul_pos_iff.mp hc with hs|hs
    · exact div_pos hs.1 hs.2
    · exact div_pos_of_neg_of_neg hs.1 hs.2
  have hv : v = r • x := by
    ext i; fin_cases i
    change v 0 = (v 0/x 0) * x 0
    field_simp
  have h₁ : LloydProduct.step μ (x,-x) = (v,-v) := by
    simpa only [one_smul] using! (reflection_update μ x (r:=1) zero_lt_one hsym ht hi).2.2
  have h₂ : LloydProduct.step μ (v,-v) = (v,-v) := by
    calc LloydProduct.step μ (v,-v) = LloydProduct.step μ (r • x,-(r • x)) := by rw [hv]
         _ = (v,-v) := (reflection_update μ x hr hsym ht hi).2.2
  refine ⟨v,hv ▸ smul_ne_zero hr.ne' hx,h₁,h₂,fun n => ?_⟩
  induction n with
  | zero => exact h₁
  | succ n ih => rw [Function.iterate_succ_apply',ih]; exact h₂

/-- With finite squared cost, every selection of balanced optimal plans
produces the same configuration after one step as well. -/
theorem balanced_one_step (μ : Measure E1) [IsProbabilityMeasure μ] (hac : μ ≪ volume)
    (hsym : MeasurePreserving (fun x:E1 => -x) μ μ) (h₂ : MemLp id 2 μ) (x:E1) (hx:x≠0) :
    ∃ v:E1, v≠0 ∧ ∀ Y:ℕ → E1×E1, Y 0=(x,-x) →
      (∀ n,IsBalancedStep μ (Y n).1 (Y (n+1))) → ∀ n, Y (n+1)=(v,-v) := by
  have hi : Integrable (id:E1→E1) μ := h₂.integrable (by norm_num)
  obtain ⟨v,hv,h₁,hfix,hit⟩ := one_step μ hac hsym hi x hx
  let p : LloydNDModels.Profile (k:=0) μ (populationSupport μ) 1 :=
    ⟨zero_lt_one,inferInstance,hsym,hac,hi,fun u _ => by ring⟩
  refine ⟨v,hv,fun Y h0 hY n => ?_⟩
  induction n with
  | zero =>
    have h:=hY 0
    rw [h0] at h
    exact ((p.balanced h₂ hx _).mp h).trans h₁
  | succ n ih =>
    have h:=hY (n+1)
    rw [ih] at h
    exact ((p.balanced h₂ hv _).mp h).trans hfix

#print axioms one_step
#print axioms balanced_one_step
end LloydNDLine
