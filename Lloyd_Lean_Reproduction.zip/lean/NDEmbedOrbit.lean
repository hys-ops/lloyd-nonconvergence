import NDEmbedCircle
import NDGeoRealize
import NDLimitsTransfer
open Filter Topology TopologicalSpace Set MeasureTheory
open scoped RealInnerProductSpace ContDiff
noncomputable section
namespace LloydNDEmbed
open LloydNDFrame (E)
open LloydNDLimits LloydNDGeom
local notation "law" => ProbabilityTheory.cond volume

/-- All finite jet tolerances are prescribed before the body. The conditional
centroids in the Euclidean body follow the older embedded 3D orbit, with radii
that converge to a positive scalar. -/
theorem uniform_embedded_circle (k m : ℕ) {ε : ℝ} (hε : 0<ε) :
    ∃ (K : Set (E (k+3))) (y : E (k+3)),
    IsCompact K ∧ 0<volume K ∧ (∀ x, -x ∈ K ↔ x∈K) ∧ StrictConvex ℝ K ∧
    HasPositiveCurvedBoundary K ∧ NearRound K m ε ∧
    y∈interior K ∧ -y∈interior K ∧ IsProbabilityMeasure (law K) ∧
    (∃ c : ℝ, 0<c ∧
      (∀ P, MapClusterPt P atTop (fun n : ℕ => LloydProduct.unordered ((LloydProduct.step (law K))^[n] (y,-y))) ↔
        ∃ θ, P=axis (c • extend k (LloydOrbit.equator θ))) ∧
      (∀ θ, let x := c • extend k (LloydOrbit.equator θ); LloydProduct.step (law K) (x,-x) = (x,-x))) ∧
    ¬ ∃ P, Tendsto (fun n : ℕ => LloydProduct.unordered ((LloydProduct.step (law K))^[n] (y,-y))) atTop (𝓝 P) := by
  obtain ⟨a,ha,ha1,hs⟩ := LloydFamily.exists_smooth_scale
  let H := fun w : ℝ × E (k+3) => LloydFamily.angular a w.1 (proj k w.2)
  have hsm : LloydNDFrequency.SmoothOnDirections H := fun w _ =>
    (hs.comp (contDiff_fst.prodMk ((proj k).contDiff.comp contDiff_snd))).contDiffAt
  have evenH (t:ℝ) (u:E (k+3)) (_ : ‖u‖=1) : H (t,-u) = H (t,u) := by
    simp [H,LloydFamily.angular_even]
  have zeroH (u:E (k+3)) (_ : ‖u‖=1) : H (0,u)=1 := by simp [H]
  obtain ⟨B,C,hB⟩ := local_profile_realization (dim:=k+2) hsm evenH zeroH
  have ev := (hB m ε hε).filter_mono (nhdsWithin_le_nhds : 𝓝[>] (0:ℝ) ≤ 𝓝 0)
  obtain ⟨t,⟨hC,hK,hvol,hsym,hstrict,hcurv,hball,hprob,hnear,hm⟩,ht⟩ :=
    (ev.and (self_mem_nhdsWithin : ∀ᶠ t in 𝓝[>] (0:ℝ), t ∈ Ioi 0)).exists
  let K := B t
  let μ := law K
  let : IsProbabilityMeasure μ := hprob
  let δ := LloydFamily.parameter a t
  have hd : 0<δ := LloydFamily.parameter_pos ha (ne_of_gt ht)
  have h1 : δ ≤ 1 := ((LloydFamily.parameter_range ha t).2.le.trans ha1)
  let f := LloydGlobal.modelPotential δ
  have hf : ContDiff ℝ ∞ f := (LloydGlobal.globally_smooth_counterexample hd h1).1
  let e := extend k
  let U := fun n => e (LloydVerification.dir δ n)
  have hU (n : ℕ) : ‖U n‖=1 := (norm_extend k _).trans (LloydVerification.dir_norm hd h1 n)
  have hi : Integrable (id : E (k+3) → E (k+3)) μ :=
    (continuous_id.continuousOn.integrableOn_compact (μ:=volume) hK).smul_measure (ENNReal.inv_ne_top.mpr hvol.ne')
  have hac : μ ≪ volume := ProbabilityTheory.cond_absolutelyContinuous
  have he : MeasurePreserving (fun x:E (k+3) => -x) μ μ := by
    have hr := (LinearIsometryEquiv.neg ℝ : E (k+3) ≃ₗᵢ[ℝ] E (k+3)).measurePreserving.restrict_preimage hK.measurableSet
    have hp : (fun x:E (k+3) => -x) ⁻¹' K = K := Set.ext hsym
    change MeasurePreserving (fun x:E (k+3) => -x) (volume.restrict ((fun x => -x) ⁻¹' K)) (volume.restrict K) at hr
    rw [hp] at hr
    refine ⟨measurable_neg,?_⟩
    change (Measure.map _ ((volume K)⁻¹ • volume.restrict K)) = _
    rw [Measure.map_smul _ measurable_neg.aemeasurable,hr.map_eq]
    rfl
  have hsupport (x:E (k+3)) (hx : ‖x‖=1) : populationSupport μ x=C t * Real.exp ((f ∘ proj k) x) := by
    rw [show populationSupport μ x = ∫ y, |⟪x,y⟫| ∂μ by simp only [populationSupport,real_inner_comm x _]]
    exact hm x hx
  have hstep (n : ℕ) : signedMoment μ (U n) = ‖signedMoment μ (U n)‖ • U (n+1) := by
    have hmap : LloydGlobal.mapping f (LloydVerification.dir δ n) = LloydVerification.dir δ (n+1) := by
      rw [←LloydGlobal.global_exact_iterates hd h1,←LloydGlobal.global_exact_iterates hd h1,
        Function.iterate_succ_apply']
    have hj := extend_jet (k:=k) (LloydVerification.dir_norm hd h1 n) hmap
      (hf.differentiable (by simp) _)
    exact signedMoment_of_kick hac hi hC hsupport (hU n) (hU (n+1)) hj.1
      ((hf.comp (proj k).contDiff).differentiable (by simp) _) hj.2
  let r₀ : ℝ := 1/4
  have hr : 0<r₀ := by norm_num [r₀]
  let y := r₀ • U 0
  have hnorm : ‖y‖=1/4 := by simp [y,norm_smul,hU,r₀]
  have inside {x : E (k+3)} (hx : ‖x‖=1/4) : x∈interior K := by
    apply interior_mono hball
    rw [interior_closedBall _ (by norm_num : (1/2:ℝ) ≠ 0),Metric.mem_ball,dist_zero_right,hx]
    norm_num
  refine ⟨K,y,hK,hvol,hsym,hstrict,hcurv,hnear,inside hnorm,inside (by simpa using hnorm),hprob,?_⟩
  constructor
  · let B₀ := Set.range (fun θ => extend k (LloydOrbit.equator θ))
    have hl (v:E (k+3)) : MapClusterPt v atTop U ↔ v ∈ B₀ := embedded_direction_limits k hd h1 v
    obtain ⟨c,hc,hcls,hfix⟩ := exact_orbit he hac hi hU hstep hl hr
    refine ⟨c,hc,?_,fun θ => hfix _ ⟨θ,rfl⟩⟩
    intro P
    change MapClusterPt P atTop (fun n => LloydProduct.unordered (orbitSites μ U r₀ n)) ↔ _
    rw [hcls]
    constructor
    · rintro ⟨v,⟨θ,rfl⟩,h⟩
      exact ⟨θ,h⟩
    · rintro ⟨θ,h⟩
      exact ⟨_,⟨θ,rfl⟩,h⟩
  obtain ⟨c,hc,_,hR⟩ := radial_ascent hac hi hU hstep r₀
  have hdvg := (LloydVerification.axis_limits hd h1 hR hc).2
  rintro ⟨P,hP⟩
  apply hdvg
  refine ⟨P.map _ (proj k).continuous,?_⟩
  have h := (proj k).continuous.nonemptyCompacts_map.continuousAt.tendsto.comp hP
  apply h.congr'
  apply Filter.Eventually.of_forall
  intro n
  change (LloydProduct.unordered (orbitSites μ U r₀ n)).map _ (proj k).continuous = _
  rw [(orbit_dynamics he hac hi hU hstep hr n).2]
  apply SetLike.coe_injective
  simp [LloydProduct.unordered,LloydOrbit.antipodes,U,e]
theorem uniform_embedded_counterexample (k m : ℕ) {ε : ℝ} (hε : 0<ε) :
    ∃ (K : Set (E (k+3))) (y : E (k+3)),
    IsCompact K ∧ 0<volume K ∧ (∀ x, -x ∈ K ↔ x∈K) ∧ StrictConvex ℝ K ∧
    HasPositiveCurvedBoundary K ∧ NearRound K m ε ∧
    y∈interior K ∧ -y∈interior K ∧ IsProbabilityMeasure (law K) ∧
    ¬ ∃ P, Tendsto (fun n : ℕ => LloydProduct.unordered ((LloydProduct.step (law K))^[n] (y,-y))) atTop (𝓝 P) := by
  obtain ⟨K,y,h₁,h₂,h₃,h₄,h₅,h₆,h₇,h₈,h₉,_,h₁₀⟩ := uniform_embedded_circle k m hε
  exact ⟨K,y,h₁,h₂,h₃,h₄,h₅,h₆,h₇,h₈,h₉,h₁₀⟩

#print axioms uniform_embedded_circle
#print axioms uniform_embedded_counterexample
end LloydNDEmbed
