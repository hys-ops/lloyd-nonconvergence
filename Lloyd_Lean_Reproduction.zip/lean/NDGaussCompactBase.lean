import NDPolar
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-! The actual radial compact reference density and its finite mass. -/
noncomputable section
open Set MeasureTheory
open scoped RealInnerProductSpace Topology ContDiff
namespace LloydNDCompactDensity
open LloydNDPolar
variable {dim : ℕ}
local notation "Vn" => LloydNDPolar.E dim
local notation "Sn" => LloydNDPolar.S dim


def base (x : Vn) : ℝ := Real.exp (-‖x‖^2) * expNegInvGlue (9-‖x‖^2)

lemma base_nonneg (x : Vn) : 0 ≤ base x := mul_nonneg (Real.exp_pos _).le (expNegInvGlue.nonneg _)

lemma base_radial {x y : Vn} (hn : ‖x‖=‖y‖) : base x = base y := by simp [base,hn]

lemma base_positive_form {x : Vn} (hx : ‖x‖ < 3) : base x = Real.exp (-‖x‖^2-(9-‖x‖^2)⁻¹) := by
  have hp : 0 < 9-‖x‖^2 := by nlinarith [mul_pos (sub_pos.mpr hx) (by linarith [norm_nonneg x] : 0<3+‖x‖)]
  unfold base expNegInvGlue
  rw [ite_eq_right hp.not_ge,sub_eq_add_neg (-‖x‖^2),Real.exp_add]

lemma base_zero {x : Vn} (hx : 3 ≤ ‖x‖) : base x = 0 := by
  have hh : 9-‖x‖^2 ≤ 0 := by nlinarith [mul_nonneg (sub_nonneg.mpr hx) (by linarith [norm_nonneg x] : 0≤‖x‖+3)]
  simp [base,expNegInvGlue.zero_of_nonpos hh]

lemma base_pos_iff (x : Vn) : 0 < base x ↔ ‖x‖ < 3 := by
  constructor
  · intro h; by_contra! hn; simp [base_zero hn] at h
  · intro h; rw [base_positive_form h]; exact Real.exp_pos _

theorem base_smooth : ContDiff ℝ ∞ (base (dim:=dim)) := by
  have hn : ContDiff ℝ ∞ (fun x : Vn => ‖x‖^2) := contDiff_norm_sq ℝ
  exact hn.neg.exp.mul (expNegInvGlue.contDiff.comp (contDiff_const.sub hn))

theorem base_support : Function.support base = Metric.ball (0:Vn) 3 := by
  ext x
  simp only [Function.mem_support,Metric.mem_ball,dist_zero_right]
  exact ⟨fun h => (base_pos_iff x).mp (lt_of_le_of_ne (base_nonneg x) h.symm),
    fun h => ((base_pos_iff x).mpr h).ne'⟩

theorem base_compact : HasCompactSupport (base (dim:=dim)) := by
  apply (isCompact_closedBall (0:Vn) 3).of_isClosed_subset isClosed_closure
  rw [base_support]
  exact closure_minimal Metric.ball_subset_closedBall Metric.isClosed_closedBall

theorem base_integrable : Integrable (base (dim:=dim)) := base_smooth.continuous.integrable_of_hasCompactSupport base_compact

theorem base_mass_pos : 0 < ∫ x : Vn, base x := by
  apply integral_pos_of_integrable_nonneg_nonzero (x:=(0:Vn)) base_smooth.continuous base_integrable base_nonneg
  exact ((base_pos_iff 0).mpr (by norm_num)).ne'

#print axioms base_smooth
#print axioms base_support
#print axioms base_mass_pos
end LloydNDCompactDensity
