import NDJetShift
import NDPrescribe
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct
noncomputable section
open Set Filter Function
open scoped SchwartzMap RealInnerProductSpace ContDiff Topology
namespace LloydNDJet
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

private def gate : ContDiffBump (0:ℝ) := ⟨1/2, 3/4, by norm_num, by norm_num⟩
private def reciprocal (x : ℝ) := gate x * (1+x)⁻¹
private theorem reciprocal_smooth : ContDiff ℝ ∞ reciprocal := by
  apply contDiff_iff_contDiffAt.mpr
  intro x
  by_cases h : 1 + x = 0
  · have e : x = -1 := by linarith
    subst x
    apply (contDiffAt_const (c:=(0:ℝ))).congr_of_eventuallyEq
    filter_upwards [gt_mem_nhds (by norm_num : (-1:ℝ) < -(3/4))] with y hy
    have zero : gate y = 0 := gate.zero_of_le_dist (by
      change 3/4 ≤ dist y 0; rw [Real.dist_eq,sub_zero,abs_of_neg (by linarith : y<0)]; linarith)
    simp [reciprocal,zero]
  · exact gate.contDiffAt.mul ((contDiffAt_const.add contDiffAt_id).inv h)
private theorem reciprocal_temp : HasTemperateGrowth reciprocal := by
  exact (gate.hasCompactSupport.mul_right (f':=fun x : ℝ => (1+x)⁻¹)).hasTemperateGrowth reciprocal_smooth
private theorem reciprocal_value {x : ℝ} (h : |x| ≤ 1/2) : reciprocal x = (1+x)⁻¹ := by
  have hg : gate x=1 := gate.one_of_mem_closedBall (by simpa [Metric.mem_closedBall,Real.dist_eq,gate] using h)
  simp [reciprocal,hg]

def defect (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) : 𝓢(X,ℝ) :=
  SchwartzMap.bilinLeftCLM (innerSL ℝ : E →L[ℝ] E →L[ℝ] ℝ)
    (hp.temperate.comp clock.hasTemperateGrowth) (shiftedDifference P hp b)

def kicks (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) : 𝓢(X,E) :=
  let d := defect P hp b
  let main := shiftedDifference P hp b -
    SchwartzMap.bilinLeftCLM (ContinuousLinearMap.lsmul ℝ ℝ : ℝ →L[ℝ] E →L[ℝ] E)
      (hp.temperate.comp clock.hasTemperateGrowth) d
  SchwartzMap.smulLeftCLM E (reciprocal ∘ d) main

theorem defect_apply (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) (p : X) :
    defect P hp b p = ⟪P (p.2+b p)-P p.2,P p.2⟫ := rfl

theorem kicks_apply (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) (p : X) :
    kicks P hp b p = reciprocal (defect P hp b p) •
       ((P (p.2+b p)-P p.2) - defect P hp b p • P p.2) := by
  rw [kicks,SchwartzMap.smulLeftCLM_apply_apply (reciprocal_temp.comp (defect P hp b).hasTemperateGrowth)]
  rfl

theorem kicks_zero (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) (p : X)
    (hb : b p=0) : kicks P hp b p = 0 := by
  simp [kicks_apply,defect_apply,hb]

theorem kicks_exact (P : ℝ → E) (hp : BoundedJets P) (b : 𝓢(X,ℝ)) (p : X)
    (hu : ‖P p.2‖ = 1) (hs : ‖P (p.2+b p) - P p.2‖ ≤ 1/2) :
    0 < ⟪P p.2,P (p.2+b p)⟫ ∧ kicks P hp b p = LloydNDSpiral.kick (P p.2) (P (p.2+b p)) := by
  let U := P p.2
  let V := P (p.2+b p)
  let D := defect P hp b p
  have hd : |D| ≤ 1/2 := by
    rw [show D = ⟪V-U,U⟫ from rfl]
    exact (abs_real_inner_le_norm _ _).trans (by simpa [U,V,hu] using hs)
  have hi : 1+D = ⟪U,V⟫ := by
    dsimp [D,defect_apply,U,V]
    rw [inner_sub_left,real_inner_self_eq_norm_sq,hu,real_inner_comm]
    ring
  have hd1 : 0<1+D := by linarith [(abs_le.1 hd).1]
  refine ⟨hi ▸ hd1,?_⟩
  rw [kicks_apply,reciprocal_value hd]
  change (1+D)⁻¹ • ((V-U)-D • U) = ⟪U,V⟫⁻¹ • V - U
  rw [←hi]
  have one : (1+D)⁻¹*(1+D) = 1 := inv_mul_cancel₀ hd1.ne'
  have eq : (V-U)-D • U = V - (1+D) • U := by rw [add_smul,one_smul]; abel
  rw [eq,smul_sub,smul_smul,one,one_smul]

theorem uniformly_close (P : ℝ → E) (hp : BoundedJets P) :
    ∃ ε:ℝ, 0<ε ∧ ∀ t h:ℝ, |h| ≤ ε → ‖P (t+h)-P t‖ ≤ 1/2 := by
  obtain ⟨C,hC⟩ := hp.derivative.2 0
  have bound (t:ℝ) : ‖deriv P t‖≤C := by simpa using hC t
  have hc := (norm_nonneg _).trans (bound 0)
  refine ⟨(2*(C+1))⁻¹, by positivity, fun t h hh => ?_⟩
  have lip := (convex_univ : Convex ℝ (univ:Set ℝ)).norm_image_sub_le_of_norm_deriv_le
    (fun t _ => hp.1.differentiable (by simp) t) (fun t _ => bound t)
    (mem_univ t) (mem_univ (t+h))
  rw [add_sub_cancel_left,Real.norm_eq_abs] at lip
  apply lip.trans ((mul_le_mul_of_nonneg_left hh hc).trans ?_)
  rw [←div_eq_mul_inv]
  apply (div_le_iff₀ (by positivity)).2
  linarith
end LloydNDJet
