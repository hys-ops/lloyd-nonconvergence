"""Independent numerical differentiations of the proposed local scalar potential.
Uses a primitive with the same first jet at the evaluation height and compares
against the full normalized discrete step. All errors are relative to the
nonzero displacement, so an unchanged direction would fail.
"""
import json
import mpmath as mp

mp.mp.dps = 100

def dot(v, w):
    return mp.fdot(v, w)

def unit(v):
    return v / mp.norm(v)

def angular(t, m):
    product = mp.mpf(1)
    result = []
    for j in range(m):
        angle = mp.pi**j * t
        result.append(product * mp.cos(angle))
        product *= mp.sin(angle)
    return mp.matrix(result + [product])

def trial(d, height, delta):
    m = d - 2
    z = mp.mpf(height)
    delta = mp.mpf(delta)
    def a(x):
        return angular(-mp.log(x), m)
    def args(x):
        b = mp.sqrt(1-x*x)
        ax = a(x)
        u = mp.matrix(list(b*ax) + [x])
        return b, ax, u
    def local(x):
        b, ax, u = args(x)
        s = x - delta * mp.exp(-1/x**2)
        _, _, v = args(s)
        g = v / dot(u,v) - u
        gh = mp.matrix(list(g)[:-1])
        p = -x/b * dot(gh,ax) + g[d-1]
        q = b * (gh-dot(gh,ax)*ax)
        return p,q
    b,ax,u = args(z)
    _,_,v = args(z-delta*mp.exp(-1/z**2))
    p,q = local(z)
    da = mp.matrix([mp.diff(lambda s: a(s)[j], z) for j in range(m+1)])
    Aprime = p + dot(q,da)
    def surface(x, xi):
        return Aprime*(x-z) + dot(local(x)[1],xi-a(x))
    fz = mp.diff(lambda x: surface(x,ax), z)
    components = []
    for j in range(m+1):
        ej = mp.eye(m+1)[:,j]
        components.append(mp.diff(lambda t: surface(z,unit(ax+t*ej)),0))
    grad_ang = mp.matrix(components)
    wz = mp.matrix(list((-z/b)*ax) + [1])
    grad = b*b*fz*wz + mp.matrix(list(grad_ang/b) + [0])
    obtained = unit(u+grad)
    displacement = mp.norm(v-u)
    err = mp.norm(obtained-v)/displacement
    assert displacement > 0 and err < mp.mpf('1e-55'), (d, err)
    return dict(dimension=d, height=height, amplitude=str(delta), displacement=mp.nstr(displacement,9),
                error_relative_to_step=mp.nstr(err,9))

if __name__ == '__main__':
    print(json.dumps([trial(d,z,delta) for d in [3,4,5,8] for z,delta in [('0.125','0.1'),('0.193','0.35')]],indent=2))
