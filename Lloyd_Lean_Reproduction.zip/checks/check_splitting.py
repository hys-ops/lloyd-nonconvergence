"""Exact finite illustration of the seed calculation in development note §5.

The symmetric test law is discrete. The chosen projections avoid ties.
The general statement for continuous laws is proved in the note.
"""
from fractions import Fraction as F

def dot(x, y):
    return sum(a * b for a, b in zip(x, y))

def dist2(x, y):
    return sum((a - b) ** 2 for a, b in zip(x, y))

def scaled(r, x):
    return tuple(r * a for a in x)

def nearest_cost(law, sites):
    return sum(p * min(dist2(x, site) for site in sites) for x, p in law)

def pair(y):
    return (y, scaled(-1, y))

def positive_centroid(law, y):
    positive = [(x, p) for x, p in law if dot(x, y) > 0]
    mass = sum(p for x, p in positive)
    assert mass == F(1, 2)
    return tuple(sum(p*x[i] for x, p in positive) / mass for i in range(len(y)))

def main():
    law = [(scaled(sign, x), p) for x, p in [((2, 1), F(1, 3)), ((1, 4), F(1, 6))] for sign in (1, -1)]
    u = (F(1), F(0))
    h = sum(p*abs(dot(x, u)) for x, p in law)
    s = sum(p*dot(x, x) for x, p in law)
    m = positive_centroid(law, u)
    assert all(sum(p*x[i] for x,p in law) == 0 for i in range(2))
    for r in [h/5, h, 2*h, 3*h]:
        y = scaled(r, u)
        assert nearest_cost(law, pair(y)) == s - h*h + (r-h)**2
        assert positive_centroid(law, y) == m
    y = scaled(h, u)
    d = nearest_cost(law, pair(y))
    frozen = sum(p * dist2(x, scaled(1 if dot(x,u)>0 else -1, m)) for x,p in law)
    assert nearest_cost(law, pair(m)) <= frozen == d - dist2(y,m) < d < s
    print(f"PASS: h={h}, D1={s}, initial D2={d}, updated D2={nearest_cost(law,pair(m))}")

if __name__ == "__main__":
    main()
